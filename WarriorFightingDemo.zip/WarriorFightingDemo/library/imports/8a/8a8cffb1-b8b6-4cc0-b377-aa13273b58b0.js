"use strict";
cc._RF.push(module, '8a8cf+xuLZMwLN3qhMnO1iw', 'MagicNode');
// Script/UI/MagicNode.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {
        progressBar: cc.Node,
        magicNum: cc.Label,
        hero: cc.Node
    },

    // use this for initialization
    update: function update() {
        var script = this.hero.getComponent("Player");
        this.magicNum.string = Math.floor(script.mana).toFixed(0) + '/' + script.maxMana.toFixed(0);
        // this.magicNum.node.x = 90*script.mana - 440;
        // this.progressBar.scaleX = 90*script.mana/744;
        this.progressBar.scaleX = script.mana / 10;
    }

});

cc._RF.pop();