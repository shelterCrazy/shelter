"use strict";
cc._RF.push(module, 'c0f78FX2PVGX7CvvAz0Zbla', 'Door');
// MainScene/Scripts/Door.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {
        storeNode: cc.Node
    },

    // use this for initialization
    onLoad: function onLoad() {
        this.inDoor = false;
        cc.director.getCollisionManager().enabled = true;
        cc.eventManager.addListener({
            event: cc.EventListener.KEYBOARD,
            //onKeyPressed: this.onKeyPressed.bind(this),
            onKeyReleased: this.onKeyReleased.bind(this)
        }, this.node);
    },

    onKeyReleased: function onKeyReleased(keyCode, event) {
        if (this.inDoor === true) {
            switch (keyCode) {
                case cc.KEY.e:
                case cc.KEY.space:
                    this.inDoor = false;
                    this.storeNode.active = true;
                    break;
            }
        }
    },
    onCollisionEnter: function onCollisionEnter(other, self) {
        //�����Ӵ��ж�
        if (other.node.group === "Hero") {
            console.log("touch the Hero");
            this.inDoor = true;
        }
    },
    onCollisionExit: function onCollisionExit(other, self) {
        if (other.node.group === "Hero") {
            this.inDoor = false;
        }
    },
    battleScene: function battleScene() {
        cc.director.loadScene("game");
    }
});

cc._RF.pop();