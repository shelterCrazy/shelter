"use strict";
cc._RF.push(module, 'c94ffdYtItFFJd8p9TMTZZ5', 'FirstPageCard');
// MainScene/Scripts/FirstPageCard.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {
        moonLightWorm: {
            default: null,
            type: cc.Prefab
        },
        unDeadBird: {
            default: null,
            type: cc.Prefab
        }
    },

    // use this for initialization
    onLoad: function onLoad() {
        this.creatCard(this.moonLightWorm, 0);
        this.creatCard(this.unDeadBird, 1);
    },
    creatCard: function creatCard(cardType, i) {
        var newCard = cc.instantiate(cardType);
        newCard.x = -120 + 120 * i;
        newCard.y = 130;
        this.node.addChild(newCard);
    }

    // called every frame, uncomment this function to activate update callback
    // update: function (dt) {

    // },
});

cc._RF.pop();