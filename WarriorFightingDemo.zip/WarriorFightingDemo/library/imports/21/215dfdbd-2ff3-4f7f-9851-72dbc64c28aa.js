"use strict";
cc._RF.push(module, '215df29L/NPf5hRctvGTCiq', 'CloseButton');
// MainScene/Scripts/CloseButton.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {
        panelNode: cc.Node
    },

    // use this for initialization
    onLoad: function onLoad() {},

    close: function close() {
        this.panelNode.active = false;
    }
    // called every frame, uncomment this function to activate update callback
    // update: function (dt) {

    // },
});

cc._RF.pop();