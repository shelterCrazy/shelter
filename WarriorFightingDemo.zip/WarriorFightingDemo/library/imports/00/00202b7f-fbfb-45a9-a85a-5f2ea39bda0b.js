"use strict";
cc._RF.push(module, '00202t/+/tFqahaXy6jm9oL', 'StoreButton');
// MainScene/Scripts/StoreButton.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {
        storeNode: cc.Node
    },

    openStore: function openStore() {
        this.storeNode.active = true;
    },
    // use this for initialization
    onLoad: function onLoad() {}

    // called every frame, uncomment this function to activate update callback
    // update: function (dt) {

    // },
});

cc._RF.pop();