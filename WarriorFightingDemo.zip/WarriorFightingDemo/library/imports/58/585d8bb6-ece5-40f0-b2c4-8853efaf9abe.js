"use strict";
cc._RF.push(module, '585d8u27OVA8LLEiFPvr5q+', 'SelectMenuManager');
// MainScene/Scripts/SelectMenuManager.js

'use strict';

cc.Class({
    extends: cc.Component,

    properties: {
        selectMenuKind: {
            default: null,
            type: cc.Label
        },
        selectMenuList: {
            default: null,
            type: cc.Node
        },
        selectMenuButton: {
            default: null,
            type: cc.Button
        }
        //occupationList:{
        //    default: [],
        //    type: cc.Node,
        //},
        //occupationListName:{
        //    default: [],
        //    type: cc.Label,
        //},
    },
    callback: function callback(event, customEventData) {
        switch (customEventData) {
            case 'total':
                this.selectMenuList.active = false;
                this.selectMenuKind.string = "所有阵营";break;
            case 'science':
                this.selectMenuList.active = false;
                this.selectMenuKind.string = "科学";break;
            case 'fantasy':
                this.selectMenuList.active = false;
                this.selectMenuKind.string = "幻想";break;
            case 'chaos':
                this.selectMenuList.active = false;
                this.selectMenuKind.string = "混沌";break;
            case 'neutrality':
                this.selectMenuList.active = false;
                this.selectMenuKind.string = "中立";break;
            default:
                break;
        }
    },
    rareSelect: function rareSelect(event, customEventData) {
        switch (customEventData) {
            case 'total':
                this.selectMenuList.active = false;
                this.selectMenuKind.string = "全部";break;
            case 'N':
                this.selectMenuList.active = false;
                this.selectMenuKind.string = "N";break;
            case 'R':
                this.selectMenuList.active = false;
                this.selectMenuKind.string = "R";break;
            case 'SR':
                this.selectMenuList.active = false;
                this.selectMenuKind.string = "SR";break;
            case 'SSR':
                this.selectMenuList.active = false;
                this.selectMenuKind.string = "SSR";break;
            default:
                break;
        }
    },
    consumeSelect: function consumeSelect(event, customEventData) {
        if (customEventData === 'total') {
            this.selectMenuList.active = false;
            this.selectMenuKind.string = "所有消耗";
        } else {
            this.selectMenuList.active = false;
            this.selectMenuKind.string = "" + customEventData;
        }
    },
    // use this for initialization
    onLoad: function onLoad() {
        this.selectMenuList.active = false;
    },
    showSelectMenuList: function showSelectMenuList() {
        this.selectMenuList.active = true;
        //this.selectMenuListOperation(this.occupationList);
        this.hideSelectMenuList(this.selectMenuList);
        //this.pickSelectMenuItem(this.occupationList);
    },
    //function stopAction() {
    //    this.selectMenuList.active = false;
    //}
    hideSelectMenuList: function hideSelectMenuList(selectBoard) {
        selectBoard.on(cc.Node.EventType.MOUSE_UP, hideSelectBoard, this);
        function hideSelectBoard() {
            selectBoard.active = false;
        }
    }

    // called every frame, uncomment this function to activate update callback
    // update: function (dt) {

    // },
});

cc._RF.pop();