"use strict";
cc._RF.push(module, '8ea80f9obpPJZBjh3ssw2YY', 'Skill');
// Skill（法术生物技能）/Common/Skill.js

"use strict";

// Learn cc.Class:
//  - [Chinese] http://www.cocos.com/docs/creator/scripting/class.html
//  - [English] http://www.cocos2d-x.org/docs/editors_and_tools/creator-chapters/scripting/class/index.html
// Learn Attribute:
//  - [Chinese] http://www.cocos.com/docs/creator/scripting/reference/attributes.html
//  - [English] http://www.cocos2d-x.org/docs/editors_and_tools/creator-chapters/scripting/reference/attributes/index.html
// Learn life-cycle callbacks:
//  - [Chinese] http://www.cocos.com/docs/creator/scripting/life-cycle-callbacks.html
//  - [English] http://www.cocos2d-x.org/docs/editors_and_tools/creator-chapters/scripting/life-cycle-callbacks/index.html

cc.Class({
    extends: cc.Component,

    properties: {

        //释放功能的节点们
        releaseFunc: [cc.Node],

        hero: [cc.Node],
        //基地层
        baseLayer: cc.Node,
        //生物层
        creatureLayer: cc.Node,
        //魔法层
        magicLayer: cc.Node
        // foo: {
        //     // ATTRIBUTES:
        //     default: null,        // The default value will be used only when the component attaching
        //                           // to a node for the first time
        //     type: cc.SpriteFrame, // optional, default is typeof default
        //     serializable: true,   // optional, default is true
        // },
        // bar: {
        //     get () {
        //         return this._bar;
        //     },
        //     set (value) {
        //         this._bar = value;
        //     }
        // },
    },

    // LIFE-CYCLE CALLBACKS:
    /**
     * @主要功能 释放生物的效果
     * @author C14
     * @Date 2018/1/16
     * @parameters
     * @returns
     */
    releaseFunction: function releaseFunction(dat, target) {
        var script = this.releaseFunc[dat].getComponents(cc.Component);
        for (var i = 0; i < script.length; i++) {
            script[i].releaseFunction(target);
        }
    },
    releaseFunctionWithTarget: function releaseFunctionWithTarget(target) {
        var script = this.releaseWithTarget.getComponents(cc.Component);
        for (var i = 0; i < script.length; i++) {
            script[i].releaseFunctionWithTarget(target);
        }
    },
    onLoad: function onLoad() {
        this.selfObject = this.node.parent;
        this.selfObjectScript = this.selfObject.getComponent("Creature");
        if (this.selfObjectScript === null) {
            this.selfObjectScript = this.selfObject.getComponent("AreaMagic");
            if (this.selfObjectScript === null) this.selfObjectScript = this.selfObject.getComponent("DirectionMagic");
        }

        this.hero = this.selfObjectScript.GameManager.heros;
        //基地层
        this.baseLayer = this.selfObjectScript.GameManager.baseLayer;
        //生物层
        this.creatureLayer = this.selfObjectScript.GameManager.creatureLayer;
        //魔法层
        this.magicLayer = this.selfObjectScript.GameManager.magicLayer;
    }

    // update (dt) {},
});

cc._RF.pop();