require=(function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);var f=new Error("Cannot find module '"+o+"'");throw f.code="MODULE_NOT_FOUND",f}var l=n[o]={exports:{}};t[o][0].call(l.exports,function(e){var n=t[o][1][e];return s(n?n:e)},l,l.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s})({"AttackBehavior":[function(require,module,exports){
"use strict";
cc._RF.push(module, '67fcbVbXx5GG6Re+5DO6f9I', 'AttackBehavior');
// MainBattleScene/Scripts/Manager/AttackBehavior.js

'use strict';

/**
 * @主要功能:   攻击行为
 * @author kenan
 * @Date 2017/7/23 2:41
 * @type {Function}
 */
var attackBehavior = cc.Class({
    extends: cc.Component,

    properties: {
        atk: 0, //物理
        matk: 1 //魔法		
    },

    /** 攻击行为 1v1 单体
     * @param attcNode  攻击节点
     * @param node  被攻击节点
     * @param nodeType  被攻击节点类型
     */
    attack: function attack(attcNode, Node, nodeType) {

        //目标被销毁  或者为null  不执行
        if (Node == null || !Node.isValid) {
            return;
        }

        //申请脚本
        var script = null,
            attackScript = null;
        //被攻击节点类型不同
        if (nodeType === 1) {
            script = Node.getComponent('Player');
        } else if (nodeType === 0) {
            script = Node.getComponent('Creature');
        } else {
            script = Node.getComponent('Base');
        }
        //获取发起攻击者的脚本
        attackScript = attcNode.getComponent('Creature');

        //1伤害计算
        // var hitValue = hitTransform(attackScript.attack, attcNode.atkType, node.defValue);     //atk攻击力   攻击类型   node该类型防御值

        //2伤害反馈给node   kenan  如果被攻击对象已死亡 清空攻击对象的目标
        var deadFlag = script.changeHealth(-attackScript.attack, this.node.parent);
        if (deadFlag != null && deadFlag == 1) {
            script.releaseTarget();
        }
    }
});

cc._RF.pop();
},{}],"BackRoll":[function(require,module,exports){
"use strict";
cc._RF.push(module, 'e5176MeFwRGjZ1mlp0W8iM1', 'BackRoll');
// Script/BackRoll.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {
        follow: cc.Node,

        hero: cc.Node,
        camera: cc.Node
    },

    // use this for initialization
    onLoad: function onLoad() {
        this.follow = this.hero;
    },
    update: function update() {
        if (this.follow.x < cc.director.getWinSize().width / 2) {
            this.node.x = -cc.director.getWinSize().width / 2;
        } else if (this.follow.x > cc.director.getWinSize().width * 2.5) {
            this.node.x = -cc.director.getWinSize().width * 2.5;
        } else {
            this.node.x = -this.follow.x;
        }
    }

});

cc._RF.pop();
},{}],"Base":[function(require,module,exports){
"use strict";
cc._RF.push(module, '94f19VYIWlOarIvJZchgRRG', 'Base');
// Script/Prefab/others/Base.js

"use strict";

var globalConstant = require("Constant");
cc.Class({
    extends: cc.Component,

    properties: {
        team: 0,
        health: 0,
        element: [cc.Node],

        healthLabel: cc.Label,

        audioSource: cc.AudioClip

    },

    // use this for initialization
    onLoad: function onLoad() {
        this.health = 200;
        this.healthLabel.string = this.health;
    },
    init: function init(element, offset, team) {
        this.team = team;
        this.node.x = offset + cc.director.getWinSize().width * globalConstant.sceneWidth / 2;
        this.initElement(element);
    },
    initElement: function initElement(element) {
        var i;
        for (i = 0; i < 3; i++) {
            if (i !== element) {
                this.element[i].active = false;
            }
        }
    },

    changeHealth: function changeHealth(value) {
        this.health += value;
        this.healthLabel.string = this.health;
        if (this.health <= 0) {
            return 1;
        }
    },

    releaseTarget: function releaseTarget() {

        var eventsend = new cc.Event.EventCustom('isWin', true);

        if (this.team === this.hero.team) {
            eventsend.setUserData({ win: 0 });
        } else {
            cc.log("you win!!!!!!!!!!!!!!!");
            eventsend.setUserData({ win: 1 });
        }

        this.node.dispatchEvent(eventsend);
    }

    // called every frame, uncomment this function to activate update callback
    // update: function (dt) {

    // },
});

cc._RF.pop();
},{"Constant":"Constant"}],"Button":[function(require,module,exports){
"use strict";
cc._RF.push(module, '0a57axQPmVAi4hJZkegvyLP', 'Button');
// Script/UI/Button.js

'use strict';

/**
 * @主要功能:   创建npc类
 * @type {Function}
 */
var buttonClass = cc.Class({
    extends: cc.Component,

    properties: {
        button: cc.Button,
        enemy: cc.Node,
        team: 0,

        delay: 0
    },

    onLoad: function onLoad() {
        this.delay = 50;
    },

    /**
     * @主要功能:  点击事件  npc创建事件     需要说明的是npc属性以后需要专门的buff属性管理器js管理  并提供回调函数，并且最好交由创建类去调用处理。
     * @param event
     * @param customEventData
     */
    onButtonTouchEvent: function onButtonTouchEvent(event, customEventData) {
        var eventsend = new cc.Event.EventCustom('creatureCreate', true);
        if (this.team === -1) {
            eventsend.setUserData({ X: 512 + this.team * 200, Y: -95, attack: 2, health: 20, team: this.team, velocity: 2, id: 0 });
        } else {
            eventsend.setUserData({ X: 512 + this.team * 200, Y: -95, attack: 2, health: 10, team: this.team, velocity: 3, id: 1 });
        }
        //cc.eventManager.dispatchEvent(event);  
        this.node.dispatchEvent(eventsend);

        // cc.log("onButtonTouchEvent事件发射后")
    }

});

cc._RF.pop();
},{}],"C0":[function(require,module,exports){
"use strict";
cc._RF.push(module, 'afb47vF4rxEaobk6qdViIqm', 'C0');
// Script/Prefab/Cards/C0.js

'use strict';

//月光虫 1费生物 1攻-7血（id 0000生物）
//无效果。
var globalConstant = require("Constant");

cc.Class({
    extends: cc.Component,

    properties: {},

    // use this for initialization
    onLoad: function onLoad() {
        this.creepScript = this.node.getComponent('CreepCard');
        this.cardScript = this.node.getComponent('Card');
    },

    getUseState: function getUseState() {
        return true;
    },

    useCard: function useCard() {
        var eventsend = new cc.Event.EventCustom('creatureCreate', true);
        var position = this.node.x + globalConstant.cameraOffset + cc.director.getWinSize().width * globalConstant.sceneEdge;
        eventsend.setUserData({
            X: 0,
            Y: null,
            attack: this.creepScript.attack,
            health: this.creepScript.health,
            team: this.cardScript.team,
            id: this.cardScript.cardId,
            velocity: this.creepScript.velocity
        });
        this.node.dispatchEvent(eventsend);

        this.cardScript.drawCardScript.deleteCard(this.node);
    }
    // called every frame, uncomment this function to activate update callback
    // update: function (dt) {

    // },
});

cc._RF.pop();
},{"Constant":"Constant"}],"C1":[function(require,module,exports){
"use strict";
cc._RF.push(module, '6cbe2Ln7YNM6r5Zv2hotCaU', 'C1');
// Script/Prefab/Cards/C1.js

'use strict';

var globalConstant = require("Constant");

cc.Class({
    extends: cc.Component,

    properties: {},

    // use this for initialization
    onLoad: function onLoad() {
        var self = this;
        self.creepScript = this.node.getComponent('CreepCard');
        self.cardScript = self.node.getComponent('Card');
    },

    getUseState: function getUseState() {
        var state;
        var self = this;
        if (self.cardScript.hero.x - 200 < this.node.x + this.node.parent.x - this.roll.x && self.cardScript.hero.x + 200 > this.node.x + this.node.parent.x - this.roll.x) {
            state = true;
        } else {
            state = false;
        }
        return state;
    },

    useCard: function useCard() {
        var eventsend = new cc.Event.EventCustom('creatureCreate', true);
        var position = this.node.x + globalConstant.cameraOffset + cc.director.getWinSize().width * globalConstant.sceneEdge;
        eventsend.setUserData({
            X: position,
            Y: null,
            attack: this.creepScript.attack,
            health: this.creepScript.health,
            team: this.cardScript.team,
            id: this.cardScript.cardId,
            velocity: this.creepScript.velocity
        });
        this.node.dispatchEvent(eventsend);

        this.cardScript.drawCardScript.deleteCard(this.node);
    }
    // called every frame, uncomment this function to activate update callback
    // update: function (dt) {

    // },
});

cc._RF.pop();
},{"Constant":"Constant"}],"C2":[function(require,module,exports){
"use strict";
cc._RF.push(module, '709d1toA7xJtrXnVYHkBGNy', 'C2');
// Script/Prefab/Cards/C2.js

'use strict';

//�¹��� 1������ 1��-7Ѫ��id 0000���
//��Ч����
var globalConstant = require("Constant");

cc.Class({
    extends: cc.Component,

    properties: {},

    // use this for initialization
    onLoad: function onLoad() {
        this.creepScript = this.node.getComponent('CreepCard');
        this.cardScript = this.node.getComponent('Card');
    },

    getUseState: function getUseState() {
        return true;
    },

    useCard: function useCard() {
        var eventsend = new cc.Event.EventCustom('creatureCreate', true);
        var position = this.node.x + globalConstant.cameraOffset + cc.director.getWinSize().width * globalConstant.sceneEdge;
        eventsend.setUserData({
            X: 0,
            Y: null,
            attack: this.creepScript.attack,
            health: this.creepScript.health,
            team: this.cardScript.team,
            id: this.cardScript.cardId,
            velocity: this.creepScript.velocity
        });
        this.node.dispatchEvent(eventsend);

        this.cardScript.drawCardScript.deleteCard(this.node);
    }
    // called every frame, uncomment this function to activate update callback
    // update: function (dt) {

    // },
});

cc._RF.pop();
},{"Constant":"Constant"}],"CameraControl":[function(require,module,exports){
"use strict";
cc._RF.push(module, '05863W3ILBA5KPipWoJvHUu', 'CameraControl');
// Script/UI/CameraControl.js

"use strict";

var globalConstant = require("Constant");

cc.Class({
    extends: cc.Component,

    properties: {
        target: {
            default: null,
            type: cc.Node
        },

        targets: {
            default: [],
            type: [cc.Node]
        },
        //�����ƶ���Χ����
        areaLeft: 0,
        areaRight: 0,

        mainScene: false
    },

    // use this for initialization
    onLoad: function onLoad() {
        this.camera = this.getComponent(cc.Camera);
        if (this.mainScene === false) {
            this.areaRight = globalConstant.sceneWidth;
        }
    },

    // called every frame, uncomment this function to activate update callback
    lateUpdate: function lateUpdate(dt) {
        var targetPos = this.target.convertToWorldSpaceAR(cc.Vec2.ZERO);
        var position = this.node.parent.convertToNodeSpaceAR(targetPos);

        if (position.x > cc.director.getWinSize().width * (this.areaRight - globalConstant.sceneEdge)) {
            this.node.x = cc.director.getWinSize().width * (this.areaRight - globalConstant.sceneEdge);
        } else if (position.x < cc.director.getWinSize().width * globalConstant.sceneEdge) {
            this.node.x = cc.director.getWinSize().width * globalConstant.sceneEdge;
        } else {
            this.node.x = position.x;
        }

        var ratio = targetPos.y / cc.winSize.height;
        this.camera.zoomRatio = 1 + (0.5 - ratio) * 0.5;
    }
});

cc._RF.pop();
},{"Constant":"Constant"}],"CameraFollow":[function(require,module,exports){
"use strict";
cc._RF.push(module, '7be1f1H+NlIVIKDJG+ct6EX', 'CameraFollow');
// MainScene/Scripts/CameraFollow.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {
        target: {
            default: null,
            type: cc.Node
        }
    },

    // use this for initialization
    onLoad: function onLoad() {
        // 由于需要键盘操作所以只能在 PC 才可用
        this.node.active = !cc.sys.isMobile;

        if (!this.target) {
            return;
        }
        var follow = cc.follow(this.target, cc.rect(0, 0, 3072, 640));
        this.node.runAction(follow);
    }
});

cc._RF.pop();
},{}],"CameraMove":[function(require,module,exports){
"use strict";
cc._RF.push(module, '749ceXi+g9Jg5XVjoNRj84A', 'CameraMove');
// Script/UI/CameraMove.js

"use strict";

/**
cc.Class({
    extends: cc.Component,

    properties: {
        //����ȥ�����õĶ���
        camera:cc.Node,
        //���ڵľ�ͷ
        viewField:cc.Node,

        hero:cc.Node,

        viewObject:cc.Node,

        backRoll:cc.Node,
        // foo: {
        //    default: null,      // The default value will be used only when the component attaching
        //                           to a node for the first time
        //    url: cc.Texture2D,  // optional, default is typeof default
        //    serializable: true, // optional, default is true
        //    visible: true,      // optional, default is true
        //    displayName: 'Foo', // optional
        //    readonly: false,    // optional, default is false
        // },
        // ...
    },

    // use this for initialization
    onLoad: function () {
        var self = this;
        self.camera = self.hero;
        self.backRollScript = self.backRoll.getComponent("BackRoll");

        self.node.on(cc.Node.EventType.MOUSE_DOWN, self.startListen, self);

        self.node.on(cc.Node.EventType.MOUSE_UP, self.endListen, self);
    },

    startListen:function(event){
        var self = this;
        self.viewObject.x = ((event.getLocationX() - (self.node.parent.x + cc.director.getWinSize().width / 2))
        / 440
        * (cc.director.getWinSize().width * 3));

        if(self.viewObject.x > cc.director.getWinSize().width * 2.5){
            self.viewObject.x = cc.director.getWinSize().width * 2.5;
        }else if(self.viewObject.x < cc.director.getWinSize().width / 2){
            self.viewObject.x = cc.director.getWinSize().width / 2;
        }

        self.camera = self.viewObject;
        self.backRollScript.follow = self.backRollScript.camera;

        self.node.on(cc.Node.EventType.MOUSE_MOVE, self.moveListen, self);
    },
    moveListen:function(event){
        var self = this;
        self.viewObject.x = ((event.getLocationX() - (self.node.parent.x + cc.director.getWinSize().width / 2))
        / 440
        * (cc.director.getWinSize().width * 3));
        if(self.viewObject.x > cc.director.getWinSize().width * 2.5){
            self.viewObject.x = cc.director.getWinSize().width * 2.5;
        }else if(self.viewObject.x < cc.director.getWinSize().width / 2){
            self.viewObject.x = cc.director.getWinSize().width / 2;
        }
        self.camera = self.viewObject;
        self.backRollScript.follow = self.backRollScript.camera;
    },
    endListen:function(event){
        var self = this;
        self.node.off(cc.Node.EventType.MOUSE_MOVE, self.moveListen, self);
    },
    // called every frame, uncomment this function to activate update callback
    update: function (dt) {
            this.camera = this.backRollScript.follow;
            if(this.camera.x > cc.director.getWinSize().width * 2.5){
                this.viewField.x = (cc.director.getWinSize().width * 2.5) / (cc.director.getWinSize().width * 3) * 440;
            }else if(this.camera.x < cc.director.getWinSize().width / 2){
                this.viewField.x = (cc.director.getWinSize().width / 2) / (cc.director.getWinSize().width * 3) * 440;
            }else {
                this.viewField.x = this.camera.x / (cc.director.getWinSize().width * 3) * 440;
            }
    },
});*/
var globalConstant = require("Constant");
cc.Class({
    extends: cc.Component,

    properties: {
        //����ȥ�����õĶ���
        camera: cc.Node,

        //С��ͼ������ʾ�ķ�Χ����
        viewField: cc.Node,

        hero: cc.Node,
        //���ڸ���������
        viewObject: cc.Node,

        cameraControl: cc.Node,

        targets: [cc.Node]
    },

    // use this for initialization
    onLoad: function onLoad() {
        var self = this;
        self.camera = self.hero;
        self.cameraControlScript = self.cameraControl.getComponent("CameraControl");

        self.node.on(cc.Node.EventType.MOUSE_DOWN, self.startListen, self);

        self.node.on(cc.Node.EventType.MOUSE_UP, self.endListen, self);
    },

    startListen: function startListen(event) {
        var self = this;
        //self.viewObject.x = ((event.getLocationX() - (self.node.parent.x + cc.director.getWinSize().width * globalConstant.sceneEdge))
        /// 440
        //* (cc.director.getWinSize().width * globalConstant.sceneWidth));
        self.viewObject.x = (event.getLocationX() - (self.node.parent.x + cc.director.getWinSize().width * globalConstant.sceneEdge)) / 440 * (cc.director.getWinSize().width * globalConstant.sceneWidth);

        if (self.viewObject.x > cc.director.getWinSize().width * (globalConstant.sceneWidth - globalConstant.sceneEdge)) {
            self.viewObject.x = cc.director.getWinSize().width * (globalConstant.sceneWidth - globalConstant.sceneEdge);
        } else if (self.viewObject.x < cc.director.getWinSize().width * globalConstant.sceneEdge) {
            self.viewObject.x = cc.director.getWinSize().width * globalConstant.sceneEdge;
        }

        self.cameraControlScript.target = self.cameraControlScript.targets[1];

        self.node.on(cc.Node.EventType.MOUSE_MOVE, self.moveListen, self);
    },
    moveListen: function moveListen(event) {
        var self = this;
        self.viewObject.x = (event.getLocationX() - (self.node.parent.x + cc.director.getWinSize().width * globalConstant.sceneEdge)) / 440 * (cc.director.getWinSize().width * globalConstant.sceneWidth);

        if (self.viewObject.x > cc.director.getWinSize().width * (globalConstant.sceneWidth - globalConstant.sceneEdge)) {
            self.viewObject.x = cc.director.getWinSize().width * (globalConstant.sceneWidth - globalConstant.sceneEdge);
        } else if (self.viewObject.x < cc.director.getWinSize().width * globalConstant.sceneEdge) {
            self.viewObject.x = cc.director.getWinSize().width * globalConstant.sceneEdge;
        }

        self.cameraControlScript.target = self.cameraControlScript.targets[1];
    },
    endListen: function endListen(event) {
        var self = this;
        self.node.off(cc.Node.EventType.MOUSE_MOVE, self.moveListen, self);
    },
    // called every frame, uncomment this function to activate update callback
    lateUpdate: function lateUpdate(dt) {
        //this.viewObject.x = this.backRollScript.follow;


        if (this.cameraControl.x >= cc.director.getWinSize().width * (globalConstant.sceneWidth - globalConstant.sceneEdge)) {
            //this.viewField.x = (cc.director.getWinSize().width * (globalConstant.sceneWidth - globalConstant.sceneEdge))
            //    / (cc.director.getWinSize().width * globalConstant.sceneWidth) * 440;
            globalConstant.cameraOffset = cc.director.getWinSize().width * (globalConstant.sceneWidth - 1);
        } else if (this.cameraControl.x <= cc.director.getWinSize().width * globalConstant.sceneEdge) {
            //this.viewField.x = (cc.director.getWinSize().width * globalConstant.sceneEdge)
            //    / (cc.director.getWinSize().width * globalConstant.sceneWidth) * 440;
            globalConstant.cameraOffset = 0;
        } else {
            //this.viewField.x = this.cameraControlScript.target.x / (cc.director.getWinSize().width * globalConstant.sceneWidth) * 440;
            globalConstant.cameraOffset = this.cameraControlScript.target.x - cc.director.getWinSize().width / 2;
        }
        this.viewField.x = this.cameraControl.x / (cc.director.getWinSize().width * globalConstant.sceneWidth) * 440;
    }
});

cc._RF.pop();
},{"Constant":"Constant"}],"CardLayout":[function(require,module,exports){
"use strict";
cc._RF.push(module, 'dba69YUGJhHLbIuqnFV8thV', 'CardLayout');
// MainBattleScene/Scripts/CardLayout.js

"use strict";

//本脚本用于使用代码批量调整卡牌牌面布局
cc.Class({
    extends: cc.Component,

    properties: {
        //是否是生物牌
        creatureCard: true,
        //卡牌数值放置节点（布局），准备一下坐标
        cardNumNode: cc.Node,
        //卡牌名称节点
        cardNameNode: cc.Node,
        //卡牌细节（描述节点）
        cardDetailNode: cc.Node,
        //卡牌细节（描述节点）
        cardDetailLabel: cc.Label,
        //卡牌尺寸节点
        cardSizeNode: cc.Node,
        //卡牌的图片遮罩尺寸
        cardMaskNode: cc.Node,
        //卡牌的法力消耗节点
        cardManaNode: cc.Node,
        //卡牌的法力消耗节点
        cardManaLabel: cc.Label,

        //具体卡牌攻击力生命值等等的标签，主要用于改字体大小
        cardDatLabel: [cc.Label],
        //具体卡牌攻击力生命值等等的节点
        cardDatNode: [cc.Node]
    },

    // use this for initialization
    onLoad: function onLoad() {
        //初始化卡牌的布局，实现只要修改脚本就可以完成的操作

        //卡牌名字的节点位置
        this.cardNameNode.x = 0;
        this.cardNameNode.y = 75;
        //卡牌细节（描述）的节点位置
        this.cardDetailNode.x = -43;
        this.cardDetailNode.y = -52;
        //卡牌细节（描述）的节点位置
        this.cardSizeNode.width = 92;
        this.cardSizeNode.height = 177;
        //卡牌消耗的节点位置
        this.cardManaNode.x = -47;
        this.cardManaNode.y = 87;
        this.cardManaNode.width = 20;
        this.cardManaNode.height = 20;
        //卡牌遮罩的宽度高度，以及节点的Y坐标
        this.cardMaskNode.y = 8;
        this.cardMaskNode.width = 86;
        this.cardMaskNode.height = 109;

        this.cardManaLabel.fontSize = 20;

        this.cardDetailLabel.fontSize = 12;
        this.cardDetailLabel.lineHeight = 12;
        this.cardDetailLabel.node.width = 74;

        if (this.creatureCard === true) {
            //卡牌数据节点（布局）的位置坐标
            this.cardNumNode.x = 42;
            this.cardNumNode.y = 10;
            //攻击力节点宽度高度
            this.cardDatNode[0].width = 28;
            this.cardDatNode[0].height = 50;
            //生命值节点宽度高度
            this.cardDatNode[1].width = 28;
            this.cardDatNode[1].height = 32;
            //速度节点宽度高度
            this.cardDatNode[2].width = 28;
            this.cardDatNode[2].height = 32;

            for (var i = 0; i < 3; i++) {
                this.cardDatLabel[i].fontSize = 20;
            }
        }
    }

});

cc._RF.pop();
},{}],"CardList":[function(require,module,exports){
"use strict";
cc._RF.push(module, '82328btXvhD8LYO3oiw6hl+', 'CardList');
// MainScene/Scripts/CardList.js

'use strict';

var Global = require('Global');

cc.Class({
    extends: cc.Component,

    properties: {
        /*moonLightWorm:{
         default: null,
         type: cc.Prefab,
         },
         undeadBirdDirt:{
         default: null,
         type:cc.Prefab,
         },*/
        cardGroup: {
            default: [],
            type: cc.Prefab
        },

        //lastPage: {
        //    default: null,
        //    type: cc.Button,
        //},
        //
        //nextPage: {
        //    default: null,
        //    type: cc.Button,
        //},

        cardBoard: {
            default: null,
            type: cc.Node
        },

        infoBoard: {
            default: null,
            type: cc.Node
        },

        deck: {
            default: [],
            type: cc.Node
        },
        layout: {
            default: null,
            type: cc.Layout
        },

        mode: {
            type: cc.Enum({
                //普通浏览模式
                Normal: 0,
                //当前合成分解模式
                Craft: 1,
                //组卡组模式
                Edit: 2,
                //全部显示，合成分解模式
                Total: 3
            }),
            default: 0
        },
        //是否显示全部的卡片
        allCardEnable: false,
        //卡组里面的OK按钮
        ojbk: cc.Node,
        //卡组里面的改名字框框
        changeName: cc.Prefab,

        //用于将添加到遮罩的节点
        cardLayout: cc.Node,
        pagePrefab: cc.Prefab,

        deckPrefab: cc.Prefab,

        buttons: cc.Node,
        //调整合成分解卡牌的选项按钮
        toggles: [cc.Toggle],

        mainScence: cc.Node,
        deckNum: 0,
        positionX: -1,
        positionY: 1,
        cardIndex: 0
    },

    // use this for initialization
    onLoad: function onLoad() {
        var assWeCan = false;
        this.mainScript = this.mainScence.getComponent('MainSceneManager');
        this.infoBoardScript = null;
        this.buttons.active = false;
        this.ojbk.active = false;
        this.renewShowCardGroup();
        if (this.mode === 2) this.cardDeckInit();
        this.renewDeckView();
        this.initListenEvent();
        // this.insertCardElement(this.moonLightWorm);
        // this.insertCardElement(this.undeadBirdDirt);
        // while(this.cardIndex < 2){
        //     this.showCardGroup(this.cardGroup[this.cardIndex]);
        //     this.cardIndex++;
        // }
    },

    changeAllCardEnable: function changeAllCardEnable() {
        this.allCardEnable = !this.allCardEnable;
        this.renewShowCardGroup();
    },
    modeChange0: function modeChange0() {
        this.mode = 0;
        this.toggles[0].interactable = true;
        this.toggles[1].interactable = true;
        this.toggles[1].node.active = true;
        if (this.infoBoard !== null) {
            this.infoBoard.removeFromParent();
        }
        this.buttons.active = false;
    },
    modeChange1: function modeChange1() {
        this.mode = 1;
        this.toggles[0].interactable = true;
        this.toggles[1].interactable = true;
        this.toggles[1].node.active = true;
    },
    modeChange2: function modeChange2() {
        this.mode = 2;
        this.toggles[0].interactable = false;
        this.toggles[1].interactable = false;
        this.toggles[1].node.active = false;
        if (this.infoBoard !== null) {
            this.infoBoard.removeFromParent();
        }
        this.buttons.active = false;
        cc.log(this.mode);
    },
    modeChange3: function modeChange3() {
        this.mode = 3;
        this.toggles[0].interactable = false;
        this.toggles[1].interactable = false;
        this.toggles[1].node.active = false;
        if (this.infoBoard !== null) {
            this.infoBoard.removeFromParent();
        }
    },

    dispose: function dispose() {
        if (this.infoBoardScript.cardType === 0) {
            if (this.mainScript.myMCards[this.infoBoardScript.cardId] > 0) {
                if (--this.mainScript.myMCards[this.infoBoardScript.cardId] === 0) {
                    if (this.infoBoard !== null) {
                        this.infoBoard.removeFromParent();
                    }
                    this.buttons.active = false;
                }
            }
        } else {
            if (this.mainScript.myCCards[this.infoBoardScript.cardId] > 0) {
                if (--this.mainScript.myCCards[this.infoBoardScript.cardId] === 0) {
                    if (this.infoBoard !== null) {
                        this.infoBoard.removeFromParent();
                    }
                    this.buttons.active = false;
                }
            }
        }
        this.renewShowCardGroup();
    },
    craft: function craft() {
        if (this.infoBoardScript.cardType === 0) {
            this.mainScript.myMCards[this.infoBoardScript.cardId]++;
        } else {
            this.mainScript.myCCards[this.infoBoardScript.cardId]++;
        }
        this.renewShowCardGroup();
    },

    /**
     * @主要功能 更新一次现在的总卡组浏览
     * @author C14
     * @Date 2017/10/21
     * @parameters
     * @returns
     */
    renewDeckView: function renewDeckView() {
        var i = 0;
        this.layout.node.removeAllChildren();
        for (i = 0; i < Global.totalDeckData.length; i++) {
            var decks = cc.instantiate(this.deckPrefab);
            var deckScript = decks.getComponent("ViewDeck");
            if (Global.totalDeckData[i].usable === false) decks.opacity = 100;
            deckScript.num = i;
            deckScript.changeType(Global.totalDeckData[i].type);
            deckScript.changeName(Global.totalDeckData[i].name);
            this.layout.node.addChild(decks);
        }
    },

    //更新一次现在的卡片浏览
    renewShowCardGroup: function renewShowCardGroup() {
        this.cardGroup = [];
        //this.cardLayout.removeAllChildren(false);
        for (var i = 0; i < this.mainScript.myCCards.length; i++) {
            //if(this.mode === 1 && this.mainScript.myCCards[i] === 0){
            this.showCardGroup(i, this.mainScript.myCCards[i], 1);
            //}else if(this.mainScript.myCCards[i] !== 0){
            //    this.showCardGroup(i,this.mainScript.myCCards[i],1);
            //}
        }
        for (var j = 0; j < this.mainScript.myMCards.length; j++) {
            //if(this.mode === 1 && this.mainScript.myMCards[j] === 0){
            this.showCardGroup(j, this.mainScript.myMCards[j], 0);
            //}else if(this.mainScript.myMCards[j] !== 0){
            //    this.showCardGroup(j,this.mainScript.myMCards[j],0);
            //}
        }
        this.cardGroup = this.sortShowCardGroup();
        this.sortCardGroupLayout();
    },

    //重新更新卡组的顺序
    sortShowCardGroup: function sortShowCardGroup() {
        var i = 0,
            j = 0;
        var out = [];
        var script = null;
        for (j = 0; j <= 10; j++) {
            for (i = 0; i < this.cardGroup.length; i++) {
                script = this.cardGroup[i].getComponent('MiniCard');
                if (script.manaConsume === j) {
                    out.push(this.cardGroup[i]);
                }
            }
        }

        return out;
    },

    //整理卡组用的布局
    sortCardGroupLayout: function sortCardGroupLayout() {
        var i = 0,
            j = 0;
        var pageNode = [];
        this.cardLayout.removeAllChildren(false);
        var pageNum = Math.ceil(this.cardGroup.length / 9);
        cc.log(pageNum);
        for (j = 0; j < pageNum + 1; j++) {
            var nodeData = cc.instantiate(this.pagePrefab);
            pageNode.push(nodeData);

            this.cardLayout.addChild(pageNode[j]);
            //if(j === 1){
            //    pageNode[j].addChild(this.cardGroup[1]);
            //}
            for (i = j * 9; i < this.cardGroup.length && i < j * 9 + 9; i++) {
                pageNode[j].addChild(this.cardGroup[i]);
            }
        }

        //for(i = 0 ;i < this.cardGroup.length; i++){
        //    this.cardLayout.addChild(this.cardGroup[i]);
        //}
    },

    //将展示用的全体卡组展示出来
    showCardGroup: function showCardGroup(indication, num, cardTypeId) {
        var newCard = null;
        if (cardTypeId === 1) {
            newCard = cc.instantiate(this.mainScript.miniCreaturePrefab[indication]);
        } else {
            newCard = cc.instantiate(this.mainScript.miniMagicPrefab[indication]);
        }
        var script = newCard.getComponent('MiniCard');
        script.num = num;
        script.label = 'x' + num;
        if (num === 0) {
            if (this.allCardEnable === true) {
                newCard.opacity = 100;
            } else {
                return;
            }
        }
        newCard.x = 0;
        newCard.y = 0;
        //if(script.manaConsume === this.mainScript.filterType[2] || this.mainScript.filterType[2] === 9) {
        //    this.cardGroup.push(newCard);
        //}

        if (((this.mainScript.filterType[0] - 1) * 100 <= script.cardId && (this.mainScript.filterType[0] - 1) * 100 + 100 > script.cardId || this.mainScript.filterType[0] === 0) && (script.rarity + 1 === this.mainScript.filterType[1] || this.mainScript.filterType[1] === 0) && (script.manaConsume === this.mainScript.filterType[2] || this.mainScript.filterType[2] === 9)) {
            this.cardGroup.push(newCard);
        }
        //this.insertCardElement(newCard);
        return true;
    },

    cleanCardBoard: function cleanCardBoard() {
        for (var i = 0; i < this.cardGroup.length; i++) {
            this.cardGroup[i].active = false; //removeFromParent();    
        }
    },

    initListenEvent: function initListenEvent() {

        this.node.on("whenMouseEnterTheMiniCard", mouseEnterMiniCard, this);
        this.node.on("whenMouseLeaveTheMiniCard", mouseLeaveMiniCard, this);
        this.node.on("whenMouseUpTheMiniCard", mouseUpMiniCard, this);

        function mouseEnterMiniCard(event) {
            if (this.mode !== 1) {
                this.buttons.active = false;
            }
            if (this.mode === 2) {
                if (event.detail.typeId === 1) {
                    this.infoBoard = cc.instantiate(this.mainScript.showCPrefab[event.detail.id]);
                } else {
                    this.infoBoard = cc.instantiate(this.mainScript.showMPrefab[event.detail.id]);
                }
                this.infoBoard.x = 300;
                this.infoBoard.y = 200;
                this.infoBoardScript = event.detail.cardScript;
                this.node.addChild(this.infoBoard);
            }
        }
        function mouseLeaveMiniCard(event) {
            if (this.mode === 2) {
                if (this.infoBoard !== null) {
                    this.infoBoard.removeFromParent();
                }
            }
        }

        function mouseUpMiniCard(event) {
            ////用预制创建一个预览用的小方块的节点
            //var view = cc.instantiate(this.mainScript.deckBuildPrefab);
            //var script = view.getComponent('ViewCard');
            //var deckScript = null;
            //var i = 0;
            //script.addViewCard(event.detail);

            if (this.mode === 2) {
                if (this.mainScript.maxDeckNum > this.deckNum) {
                    if (event.detail.typeId === 1) {
                        if (this.mainScript.myCDeck[event.detail.id] < event.detail.num) {
                            this.mainScript.myCDeck[event.detail.id]++;
                            this.deckNum++;
                            this.cardDeckInit();
                        }
                    } else {
                        if (this.mainScript.myMDeck[event.detail.id] < event.detail.num) {
                            this.mainScript.myMDeck[event.detail.id]++;
                            this.deckNum++;
                            this.cardDeckInit();
                        }
                    }
                }
            } else if (this.mode === 1) {
                if (this.infoBoard !== null) {
                    this.infoBoard.removeFromParent();
                }
                if (event.detail.typeId === 1) {
                    this.infoBoard = cc.instantiate(this.mainScript.showCPrefab[event.detail.id]);
                } else {
                    this.infoBoard = cc.instantiate(this.mainScript.showMPrefab[event.detail.id]);
                }
                this.infoBoard.x = 300;
                this.infoBoard.y = 200;
                this.infoBoardScript = event.detail.cardScript;
                this.node.addChild(this.infoBoard);

                this.buttons.active = true;
            }
        }
    },

    sortDeck: function sortDeck() {
        var i = 0,
            j = 0;
        var out = [];
        var script = null;
        for (j = 0; j <= 10; j++) {
            for (i = 0; i < this.deck.length; i++) {
                script = this.deck[i].getComponent('ViewCard');
                if (script.manaConsume === j) {
                    out.push(this.deck[i]);
                }
            }
        }

        return out;
    },

    //将卡组的具体卡的组成呈现出来
    cardDeckInit: function cardDeckInit() {
        var i;
        var deckScript = null;
        //if(this.deck !== null)this.deck = [null];
        var deck = [],
            deckNum = 0;

        for (i = 0; i < this.mainScript.myCDeck.length; i++) {
            var view = cc.instantiate(this.mainScript.deckBuildPrefab);
            var script = view.getComponent('ViewCard');
            if (this.mainScript.myCDeck[i] !== 0) {
                deckScript = cc.instantiate(this.mainScript.miniCreaturePrefab[i]);
                deckScript = deckScript.getComponent('MiniCard');
                view.x = 0;
                script.num = this.mainScript.myCDeck[i];
                script.cardType = 1;
                script.cardId = deckScript.cardId;
                script.cName = deckScript.cName;
                script.manaConsume = deckScript.manaConsume;

                deck.push(view);

                deckNum += this.mainScript.myCDeck[i];
            }
        }
        for (i = 0; i < this.mainScript.myMDeck.length; i++) {
            var view = cc.instantiate(this.mainScript.deckBuildPrefab);
            var script = view.getComponent('ViewCard');
            if (this.mainScript.myMDeck[i] !== 0) {
                deckScript = cc.instantiate(this.mainScript.miniMagicPrefab[i]);
                deckScript = deckScript.getComponent('MiniCard');
                view.x = 0;
                script.num = this.mainScript.myMDeck[i];
                script.cardType = 0;
                script.cardId = deckScript.cardId;
                script.cName = deckScript.cName;
                script.manaConsume = deckScript.manaConsume;
                deck.push(view);

                deckNum += this.mainScript.myMDeck[i];
            }
        }
        this.deckNum = deckNum;
        this.deck = deck;
        cc.log(deck);
        this.deck = this.sortDeck();

        this.sortLayout();
        cc.log(this.mainScript.myCDeck);
    },

    sortLayout: function sortLayout() {
        var i = 0;
        this.layout.node.removeAllChildren(false);
        var dat = cc.instantiate(this.changeName);
        var script = dat.getComponent(cc.EditBox);
        script.string = Global.totalDeckData[Global.deckView].name;
        dat.x = 0;
        this.layout.node.addChild(dat);
        for (i = 0; i < this.deck.length; i++) {
            this.layout.node.addChild(this.deck[i]);
        }
        //this.layout.node.addChild(cc.instantiate(this.ojbk));
    }

});

cc._RF.pop();
},{"Global":"Global"}],"Card":[function(require,module,exports){
"use strict";
cc._RF.push(module, '29d534tY1RIN63t/oqPNrNE', 'Card');
// Script/Prefab/others/Card.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {
        //魔法消耗
        manaConsume: 0,
        //魔法消耗标签
        manaConsumeLabel: cc.Label,

        team: 0,

        //卡片类型
        cardType: {
            type: cc.Enum({
                MagicCard: 0,
                CreepCard: 1
            }),
            default: 0
        }, //0法术牌；1生物牌
        rarity: {
            type: cc.Enum({
                N: 0,
                R: 1,
                SR: 2,
                SSR: 3
            }),
            default: 0
        },
        //卡片ID
        cardId: 0,
        //卡片名称
        cName: cc.String,
        //卡片名称的标签
        cNameLabel: cc.Label,
        /*//描述
        describe: cc.String,*/
        describe: cc.String,
        //描述的标签
        describeLabel: cc.Label,
        //手牌的2个位置
        cardHand: cc.Node,
        cardUsing: cc.Node,

        //用于读取英雄的节点
        hero: cc.Node,

        //使用了卡牌播放音效或者没有使用，收回的音效
        startCardEffect: cc.AudioClip,
        endCardEffect: cc.AudioClip
    },

    // use this for initialization
    onLoad: function onLoad() {
        var self = this;
        self.heroScirpt = self.hero.getComponent("Player");
        // this.cardHand = require("CardHand");
        // this.cardUsing = require("CardUsing");

        switch (self.cardType) {
            case 0:
                self.typeComponent = self.node.getComponent("MagicCard");
                if (self.typeComponent) {
                    //console.log("This is a MagicCard!");
                }
                break;
            case 1:
                self.typeComponent = self.node.getComponent("CreepCard");
                if (self.typeComponent) {
                    //console.log("This is a CreepCard!");
                }
                break;
            default:
                break;
        }

        var cardObject = this.node;
        cardObject.on(cc.Node.EventType.MOUSE_ENTER, this.enterMouseEvent, this);
        cardObject.on(cc.Node.EventType.MOUSE_LEAVE, this.leaveMouseEvent, this);

        self.manaConsumeLabel.string = self.manaConsume;
        self.cNameLabel.string = self.cName;
        self.describeLabel.string = self.describe;
    },

    //获得使用情况 false 无法使用；true可以使用
    getUseState: function getUseState() {
        // var self = this;
        // var script = null;
        // if(self.cardType === 0){
        //     script = self.node.getComponent('M' + self.cardId);
        // }else{
        //     script = self.node.getComponent('C' + self.cardId);
        // }
        // var state = script.getUseState();
        // return state;
        var state = true;

        //卡牌的判断
        //若真，则往下一层判断
        if (state) {
            state = this.typeComponent.getUseState();
        }

        return state;
    },
    useCard: function useCard() {
        // var self = this;
        // var script = null;
        // if(self.cardType === 0){
        //     script = self.node.getComponent('M' + self.cardId);
        // }else{
        //     script = self.node.getComponent('C' + self.cardId);
        // }
        // script.useCard();
        if (this.getUseState()) {
            //卡牌层面的操作
            //下一层的操作
        }
    },

    enterMouseEvent: function enterMouseEvent(event) {
        var cardObject = this.node;
        cardObject.runAction(cc.speed(cc.scaleBy(1.3, 1.3), 7));

        cardObject.on(cc.Node.EventType.TOUCH_START, this.downMouseEvent, this);

        event.stopPropagation();
    },

    leaveMouseEvent: function leaveMouseEvent(event) {
        var cardObject = this.node;
        cardObject.stopAllActions();
        cardObject.runAction(cc.speed(cc.scaleTo(1, 1), 7));

        event.stopPropagation();
    },

    downMouseEvent: function downMouseEvent(event) {
        var self = this;

        // 判断魔法值
        if (self.heroScirpt.checkMana(self.manaConsume)) {
            //开始监听鼠标移动事件

            var cardObject = this.node;
            var sender = new cc.Event.EventCustom('cardSelect', true);
            sender.setUserData({ card: this.node, posX: event.getLocationX(), posY: event.getLocationY() });
            this.node.dispatchEvent(sender);
            //console.log("downMouse!");

            this.node.x = event.getLocationX() - cc.director.getWinSize().width / 2;
            this.node.y = event.getLocationY() - (cc.director.getWinSize().height / 2 - 220);

            // 开启移动监听
            cardObject.on(cc.Node.EventType.TOUCH_MOVE, this.moveMouseEvent, this);
            cardObject.on(cc.Node.EventType.TOUCH_END, this.upMouseEvent, this);
        } else {

            var sender1 = new cc.Event.EventCustom('errorTips', true);
            sender1.setUserData({ text: "No enough mana!" });
            this.node.dispatchEvent(sender1);
        }

        event.stopPropagation();
    },

    upMouseEvent: function upMouseEvent(event) {
        //关闭监听鼠标移动事件
        var cardObject = this.node;

        var sender = new cc.Event.EventCustom('cardExit', true);
        sender.setUserData({ card: this.node });
        this.node.dispatchEvent(sender);

        console.log("upMouse");

        // 关闭一系列监听
        cardObject.off(cc.Node.EventType.TOUCH_MOVE, this.moveMouseEvent, this);
        cardObject.off(cc.Node.EventType.TOUCH_START, this.downMouseEvent, this);
        cardObject.off(cc.Node.EventType.TOUCH_END, this.upMouseEvent, this);

        // this.drawCardScript.deleteCard(this.cardIndex);

        event.stopPropagation();
    },

    moveMouseEvent: function moveMouseEvent(event) {
        //鼠标移动监听
        var cardObject = this.node;
        cardObject.x += event.getDeltaX();
        cardObject.y += event.getDeltaY();

        event.stopPropagation();
    }

});

cc._RF.pop();
},{}],"Chant":[function(require,module,exports){
"use strict";
cc._RF.push(module, '6e5e99z6+pGc4EbvRjiNONd', 'Chant');
// Script/Prefab/Chant Magic/Chant.js

'use strict';

cc.Class({
    extends: cc.Component,

    properties: {
        //ʣ���Ļغ�����ǩ
        roundLabel: cc.Label,
        //ʣ���Ļغ���
        round: 0,
        //����ħ��������
        chantName: cc.Label,
        //����������
        id: 0,
        //�÷����İٷֱ�
        percent: 0,
        //����
        team: 0,
        //��Χ
        area: 0,
        //�Ƕ�
        angel: 0,
        //�ٶ�
        speed: 0

    },
    fnInitChant: function fnInitChant(detail) {
        this.chantName.string = detail.name;
        this.round = detail.round;
        this.roundLabel.string = this.round;
        this.team = detail.team;
        //������position y��ָ��������ħ��Ӧ�õ�λ��
        this.position = detail.position != null ? detail.position : 0;
        this.y = detail.y !== null ? detail.y : null;
        this.angel = detail.angel != null ? detail.angel : 0;
        this.speed = detail.speed != null ? detail.speed : 0;

        this.id = detail.id;
        this.area = detail.area != null ? detail.area : 0;

        this.node.x = Math.cos(-this.percent * 2 * Math.PI) * this.r;
        this.node.y = Math.sin(-this.percent * 2 * Math.PI) * this.r;

        if (this.node.x > 0) {
            this.chantName.anchor = 0;
            this.chantName.node.x = 320;
        } else {
            this.chantName.anchor = 1;
            this.chantName.node.x = -320;
        }
    },
    fnChangeRound: function fnChangeRound(num) {
        this.round += num;
        this.roundLabel.string = this.round;
        if (this.round <= 0) {
            var eventsend = new cc.Event.EventCustom('magicCreate', true);
            eventsend.setUserData({
                team: this.team,
                id: this.id,
                position: this.position,
                y: this.y,
                area: this.area,
                angel: this.angel,
                speed: this.speed
            });
            this.node.dispatchEvent(eventsend);

            this.node.removeFromParent();
        } else {
            var eventsend = new cc.Event.EventCustom('magicCreate', true);
            eventsend.setUserData({
                team: this.team,
                id: this.id,
                position: this.position,
                y: this.y,
                area: this.area,
                angel: this.angel,
                speed: this.speed
            });
            this.node.dispatchEvent(eventsend);
        }
    },
    // use this for initialization
    onLoad: function onLoad() {
        this.position = 0;
        this.y = 0;
        this.r = 90;
        this.flag = true;
    }

});

cc._RF.pop();
},{}],"CloseButton":[function(require,module,exports){
"use strict";
cc._RF.push(module, '215df29L/NPf5hRctvGTCiq', 'CloseButton');
// MainScene/Scripts/CloseButton.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {
        panelNode: cc.Node
    },

    // use this for initialization
    onLoad: function onLoad() {},

    close: function close() {
        this.panelNode.active = false;
    }
    // called every frame, uncomment this function to activate update callback
    // update: function (dt) {

    // },
});

cc._RF.pop();
},{}],"Constant":[function(require,module,exports){
"use strict";
cc._RF.push(module, '01010K4wmdP15nLMKsB6IVl', 'Constant');
// Constant.js

"use strict";

// Constant.js,用于确定某些全局常量

module.exports = {
    //全场景宽度（单位个数 * 屏幕宽 为 场景宽度）
    sceneWidth: 3,
    //场景边界的单位个数
    sceneEdge: 0.5,

    //卡牌使用的Y坐标上界（到了此坐标后卡片虚化）
    cardUseLine: 100,
    //单位时间，单位长度，单位速度
    unitTime: 8,
    unitLength: 200,
    unitVelocity: 1,

    //生物召唤的默认Y坐标
    summonY: -130,
    //法术的默认Y坐标
    magicY: -50,

    //小地图的长度（像素）
    smallMapLength: 440,
    //少有的全局变量，相机坐标
    cameraOffset: 0,

    //生物状态的枚举
    stateEnum: cc.Enum({
        none: 0,
        freeze: 1,
        confine: 2,
        burn: 3,
        weak: 4,
        speedDown: 5,
        heal: 6
    }),
    //故事模式所需的的金币
    storyModeNeedMoney: 500,

    jf: []
};

cc._RF.pop();
},{}],"CreatureRange":[function(require,module,exports){
"use strict";
cc._RF.push(module, 'f69d7NMEqdAe4r9wHuKylTA', 'CreatureRange');
// Script/Prefab/others/CreatureRange.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {
        creatureNode: cc.Node
    },

    // use this for initialization
    onLoad: function onLoad() {
        this.creatureScript = this.creatureNode.getComponent("Creature");
    },
    onCollisionEnter: function onCollisionEnter(other, self) {
        var script = null;
        if (this.creatureScript.death === false) {
            //�ж�
            if (other.node.group === "Creature") {
                //cc.log("touch the Creature");
                script = other.node.getComponent('Creature');
                if (script.team !== this.creatureScript.team && script.death === false) {
                    this.creatureScript.target.push(other.node);
                    this.creatureScript.targetType.push(0);
                    if (!this.creatureScript.ATKActionFlag) {
                        this.creatureScript.ATKActionFlag = 1; //����
                    }
                }
            }

            //�ж�
            if (other.node.group === "Hero") {
                script = other.node.getComponent('Player');

                if (script.team !== this.creatureScript.team && script.death === false) {
                    this.creatureScript.target.push(other.node);
                    this.creatureScript.targetType.push(1);
                    if (!this.creatureScript.ATKActionFlag) {
                        this.creatureScript.ATKActionFlag = 1; //����
                    }
                }
            }

            //�ж�
            if (other.node.group === "Base") {
                //console.log("touch the Base");
                script = other.node.getComponent('Base');
                if (script.team !== this.creatureScript.team) {
                    this.creatureScript.target.push(other.node);
                    this.creatureScript.targetType.push(2);
                    if (!this.creatureScript.ATKActionFlag) {
                        this.creatureScript.ATKActionFlag = 1; //����
                    }
                }
            }
        }
    },

    onCollisionExit: function onCollisionExit(other, self) {
        var i = 0;
        //�ж�
        if (other.node.group === "Creature" || other.node.group === "Hero" || other.node.group === "Base") {
            for (i; i < this.creatureScript.target.length; i++) {
                if (other.node === this.creatureScript.target[i]) {
                    this.creatureScript.target.splice(i, 1);
                    this.creatureScript.targetType.splice(i, 1);
                }
            }
        }
    }
});

cc._RF.pop();
},{}],"CreatureState":[function(require,module,exports){
"use strict";
cc._RF.push(module, '5bef5SHYGtAHb2G77GtNqpV', 'CreatureState');
// Script/Prefab/others/CreatureState.js

"use strict";

/**
 * @��Ҫ���� ���ڴ���������״̬
 * @author C4
 * @Date 2017/12/10
 */
var globalConstant = require("Constant");
cc.Class({
    extends: cc.Component,

    properties: {
        state: {
            type: [cc.Boolean],
            default: []
        },
        stateParam1: {
            type: [cc.Integer],
            default: []
        },
        stateParam2: {
            type: [cc.Integer],
            default: []
        }
    },
    /**
     * @��Ҫ���� ����һ��״̬���Ҵ����߼�
     * @author C14
     * @Date 2017/12/10
     * @param state,dat1,dat2
     * @returns
     */
    addState: function addState(state, dat1, dat2) {
        this.state[state] = true;
        this.stateParam1[state] = dat1 === null ? 0 : dat1;
        if (state === globalConstant.stateEnum.burn) {
            this.stateParam2[state] += dat2 === null ? 0 : dat2;
        } else {
            this.stateParam2[state] = dat2 === null ? 0 : dat2;
        }

        if (state === globalConstant.stateEnum.freeze) {
            this.removeState(globalConstant.stateEnum.burn);
        }
        if (state === globalConstant.stateEnum.burn) {
            this.removeState(globalConstant.stateEnum.freeze);
        }
        this.runState();
    },

    /**
     * @��Ҫ���� �Ƴ�һ��״̬
     * @author C14
     * @Date 2017/12/10
     * @param state
     * @returns
     */
    removeState: function removeState(state) {
        this.state[state] = false;
        this.stateParam1[state] = 0;
        this.stateParam2[state] = 0;
    },
    /**
     * @��Ҫ���� �Ƴ�ȫ��״̬
     * @author C14
     * @Date 2017/12/10
     * @param void
     * @returns
     */
    removeAllState: function removeAllState() {
        for (var i = 0; i < this.state.length; i++) {
            this.state[i] = false;
            this.stateParam1[i] = 0;
            this.stateParam2[i] = 0;
        }
    },
    /**
     * @��Ҫ���� ÿ����λʱ�������߼�������ʱȫ����һ��Ϊ0�ľͽ���״̬
     * @author C14
     * @Date 2017/12/10
     * @param void
     * @returns
     */
    adjustLogic: function adjustLogic() {
        for (var i = 0; i < this.state.length; i++) {
            //״̬�Ĳ���1����������ʱ�Ĳ�����һ
            if (this.stateParam1[i] > 0) {
                this.stateParam1[i]--;
            }
            //��������ʱ�������������ص�״̬
            if (this.stateParam1[i] === 0) {
                if (i === globalConstant.stateEnum.freeze) {
                    this.creatureScript.attackFreeze = false;
                    this.creatureScript.moveFreeze = false;
                }
                if (i === globalConstant.stateEnum.confine) {
                    this.creatureScript.moveFreeze = false;
                }
                if (i === globalConstant.stateEnum.burn) {}
                if (i === globalConstant.stateEnum.weak) {
                    this.creatureScript.weekness = false;
                }
                if (i === globalConstant.stateEnum.speedDown) {
                    this.creatureScript.speed++;
                }
                if (i === globalConstant.stateEnum.heal) {}
                this.removeState(i);
            }
        }
    },
    /**
     * @��Ҫ���� ����״̬�߼�
     * @author C14
     * @Date 2017/12/10
     * @param
     * @returns
     */
    runState: function runState() {
        if (this.state[globalConstant.stateEnum.freeze] === true) {
            this.creatureScript.attackFreeze = true;
            this.creatureScript.moveFreeze = true;
        }
        if (this.state[globalConstant.stateEnum.confine] === true) {
            this.creatureScript.moveFreeze = true;
        }
        if (this.state[globalConstant.stateEnum.burn] === true) {}
        if (this.state[globalConstant.stateEnum.weak] === true) {
            this.creatureScript.weakness = true;
        }
        if (this.state[globalConstant.stateEnum.speedDown] === true) {
            this.creatureScript.speed--;
        }
    },
    // use this for initialization
    onLoad: function onLoad() {
        this.creatureScript = this.node.parent.getComponent("Creature");
        this.schedule(function () {
            var change = 0;
            if (this.state[globalConstant.stateEnum.burn] === true) {
                change += -this.stateParam2[globalConstant.stateEnum.burn];
                if (--this.stateParam2[globalConstant.stateEnum.burn] === 0) {
                    this.removeState(this.stateParam2[globalConstant.stateEnum.burn]);
                }
            }
            if (this.state[globalConstant.stateEnum.heal] === true) {
                change += this.stateParam2[globalConstant.stateEnum.heal];
            }
            this.creatureScript.changeHealth(change);
            this.adjustLogic();
        }, globalConstant.unitTime);
    }

});

cc._RF.pop();
},{"Constant":"Constant"}],"Creature":[function(require,module,exports){
"use strict";
cc._RF.push(module, '91527sQuwNA64TKbH7BGe+8', 'Creature');
// Script/Prefab/others/Creature.js

"use strict";

/**
 * @主要功能:   怪物史莱克
 * @type {Function}
 */
var monsterShrek = cc.Class({
    extends: cc.Component,

    properties: {
        //主游戏管理器组件
        GameManager: cc.Component,
        //攻击行为组件
        AttackBehavior: cc.Component,
        //锁定的目标
        focusTarget: cc.Node,
        //目标数组
        target: [cc.Node],
        //目标数组 0生物 1英雄 2基地 3魔法
        targetType: [],
        //目标的坐标
        targetX: null,

        id: "",
        //目标的类型0英雄;1生物;-1无
        focusType: 0,
        //生命值
        health: 0,
        //生命值标签
        healthLabel: cc.Label,
        //生命值的节点
        healthNode: [cc.Node],
        //生物宽度
        width: 0,
        //攻击力
        attack: 0,
        //攻击力标签
        attackLabel: cc.Label,
        //攻击范围
        attackArea: 0,
        //速度
        velocity: 0,
        //可移动标记
        move: true,
        //

        //所属的队伍
        team: 0,
        //延时用
        delay: 0,
        //是否死亡
        death: false,
        //是否处于召唤状态
        summon: true,
        //攻击进行立Flag
        ATKActionFlag: 0,
        //攻击间隔
        attackSpace: 0,
        //攻击计时器 作废
        // attackTimer: 0,
        bodyNode: cc.Node,

        stateNode: cc.Node,

        //召唤生物的音效
        summonEffect: cc.AudioClip,
        //召唤完成时的音效
        summonEndEffect: cc.AudioClip,
        //生物移动的音效
        moveEffect: cc.AudioClip,
        //生物攻击的音效
        attackEffect: cc.AudioClip,
        //死亡时的音效
        dieEffect: cc.AudioClip
    },

    onLoad: function onLoad() {
        var i;
        this.ATKActionFlag = 0; //攻击行为标记 1攻击进行中
        this.attackTimer = 0; //攻击计时器

        this.moveFreeze = false;
        this.attackFreeze = false;
        this.weekness = false;

        /*for(i = 0;i < 3;i ++){
            this.healthNode[i].active = false;
        }*/

        this.initAction();
    },

    /**
     * @主要功能:   初始化行为方法
     * @author kenan
     * @Date 2017/7/23 3:39
     */
    initAction: function initAction() {
        //开启攻击轮询侦测      0.5执行一次   直到销毁     监听ATKActionFlag
        this.schedule(function () {
            // cc.log("攻击轮询")
            if (this.target.length === 0 && this.moveFreeze === false) {
                this.ATKActionFlag = false;
                this.animationClip.resume(this.id + " " + "walk");
            }
            if (this.attackFreeze === true) {
                this.animationClip.pause(this.id + " " + "walk");
            }
            if (this.ATKActionFlag && this.death === false && this.summon === false && this.attackFreeze === false) {
                this.attackAction();
            }
        }, 0.5, cc.macro.REPEAT_FOREVER);

        //开启敌对目标轮询侦测      0.5执行一次   直到销毁       不监听
        //this.schedule(function(){
        //    // cc.log("获取敌对目标轮询")
        //    var eventsend = new cc.Event.EventCustom('dataget',true);
        //    eventsend.setUserData({target:this.node});
        //    this.node.dispatchEvent(eventsend);
        //}, 0.5, cc.macro.REPEAT_FOREVER);
    },

    update: function update(dt) {
        var self = this;
        self.delay++;
        self.healthLabel.string = self.health.toFixed(0);
        self.attackLabel.string = self.attack.toFixed(0);

        //自身移动判定  存在目标+非攻击+可以移动标记+自己没死
        if (!self.ATKActionFlag && self.move === true && self.death === false && this.moveFreeze === false) {

            //kenan 由于现在行为并不同步  所以会有在执行过程中 目标节点已经被注销的情况  所以这里用上次更新的坐标处理
            if (this.team > 0) {
                self.node.x -= this.velocity;
            } else {
                self.node.x += this.velocity;
            }
        }
    },

    /**
     * @主要功能:  攻击行为
     * @author kenan
     * @Date 2017/7/23 1:39
     */
    attackAction: function attackAction() {
        //目标为空 或者被销毁  不执行
        if (this.target.length === 0) {
            this.ATKActionFlag = false;
            this.animationClip.resume(this.id + " " + "walk");
            return;
        }

        var script;
        if (this.targetType[0] === 0) {
            script = this.target[0].getComponent("Creature");
        } else if (this.targetType[0] === 1) {
            script = this.target[0].getComponent("Player");
        } else if (this.targetType[0] === 2) {
            script = this.target[0].getComponent("Base");
        }

        while (script.death === true) {
            this.removeTarget(0);
            if (this.target.length === 0) {
                this.ATKActionFlag = false;
                this.animationClip.resume(this.id + " " + "walk");
                return;
            }
            if (this.targetType[0] === 0) {
                script = this.target[0].getComponent("Creature");
            } else if (this.targetType[0] === 1) {
                script = this.target[0].getComponent("Player");
            } else if (this.targetType[0] === 2) {
                script = this.target[0].getComponent("Base");
            }
        }

        //如果有攻击动画效果   和子弹  就这里执行和创建吧   攻速可以用动画时长+延迟处理

        this.animationClip.play(this.id + " " + "attack");
        this.animationClip.stop(this.id + " " + "walk");
        this.sendEvent(this.attackEffect);
        var anim1 = this.animationClip.getAnimationState(this.id + " " + "attack");
        anim1.on('finished', function () {
            this.animationClip.play(this.id + " " + "walk");
            this.animationClip.pause(this.id + " " + "walk");
        }, this);
        // this.attackAnimation.play();
        // this.walkAnimation.stop();
        //this.skillAnimation.on('finished', function(){
        //    this.animation[0].active = true;
        //    this.animation[1].active = false;
        //    this.animation[2].active = false;
        //
        //},   this);延时后调用攻击行为是

        //延时后调用攻击行为
        //setTimeout(function(){
        if (this.attackArea === 0) {
            this.AttackBehavior.attack(this.node, this.target[0], this.targetType[0]);
        } else {
            this.AttackBehavior.areaAttack(this.node);
        }

        //}.bind(this),500);
        //单体或者范围攻击    调用伤害发生器
    },

    /**
     * @主要功能:   生命变更函数改变值为value，发动这个函数的对方目标为target
     * @author kenan
     * @Date 2017/7/23 1:41
     * @parameters value target
     * @returns {number}   阵亡标记 0活着  1死了
     */
    changeHealth: function changeHealth(value, target) {
        //用于改变伤害倍数的变量
        var add = 1;
        if (this.weekness === true) add = 2;
        if (this.death === false) {
            if (this.health + value > 0) {
                this.health = this.health + value * add;
            } else {
                //死亡
                this.death = true;
                if (this.death === true) {
                    this.release();
                }
            }
            //if(target !== undefined)target.x += -this.team * 200;
        }
        return this.death; //返回自己是否已经阵亡
    },

    /**
     * @主要功能 改变生物的队伍，并且更新他们
     * @author C14
     * @Date 2017/12/10
     * @parameters team
     * @returns null
     */
    changeTeam: function changeTeam(team) {
        this.cleanTarget();
        this.team = team;
        this.fnTeamRenew();
    },

    /**
     * @主要功能 清除所有攻击目标
     * @author C14
     * @Date 2017/12/10
     * @parameters null
     * @returns null
     */
    removeAllTarget: function removeAllTarget() {
        this.target = [];
        this.targetType = [];
    },
    /**
     * @主要功能 清除一个攻击目标
     * @author C14
     * @Date 2017/12/10
     * @param null
     * @returns null
     */
    removeTarget: function removeTarget(num) {
        this.target.splice(num, 1);
        this.targetType.splice(num, 1);
    },
    /**
     * @主要功能:   释放敌人目标
     * @author kenan
     * @Date 2017/7/23 2:46
     */
    releaseTarget: function releaseTarget() {
        this.focusTarget = null;
        this.targetX = null;
    },

    //释放资源
    release: function release() {
        this.animationClip.stop(this.id + " " + "walk");
        this.animationClip.play(this.id + " " + "death");
        this.sendEvent(this.dieEffect);
        var anim1 = this.animationClip.getAnimationState(this.id + " " + "death");
        anim1.on('finished', function () {
            this.GameManager.removeCreature(this.node);
            this.node.removeFromParent();
        }, this);
    },

    /**
     * @主要功能:    初始化基本参数   为啥不叫init呢？
     * @parameters data
     */
    fnCreateCreature: function fnCreateCreature(data) {
        this.node.x = data.X;
        this.node.y = data.Y;
        this.attack = data.attack;
        this.health = data.health;
        this.velocity = 0;
        this.team = data.team;

        this.AttackBehavior = this.AttackBehavior.getComponent("AttackBehavior");
        this.animationClip = this.node.getComponent(cc.Animation);

        this.animationClip.play(this.id + " " + "appear");
        this.summon = true;

        this.sendEvent(this.summonEffect);
        var anim1 = this.animationClip.getAnimationState(this.id + " " + "appear");
        anim1.on('finished', function () {
            this.sendEvent(this.summonEndEffect);
            this.animationClip.play(this.id + " " + "walk");
            this.velocity = data.velocity;
            this.summon = false;
        }, this);

        this.fnTeamRenew();
        cc.log(this.team);
    },

    /**
     * @主要功能:   初始化注入管理类
     * @parameters Manager
     */
    fnGetManager: function fnGetManager(Manager) {
        this.GameManager = Manager;
    },

    /**
     * @主要功能 向上级节点传递消息，使之播放音效
     * @author C14
     * @Date 2017/12/12
     * @parameters audioChip volume
     * @returns null
     */
    sendEvent: function sendEvent(audioChip, fullVolume, volume) {
        var eventsend = new cc.Event.EventCustom("playEffect", true);
        if (volume === undefined || volume === null) {
            volume = 1;
        }
        if (fullVolume === undefined || fullVolume === null || fullVolume === false) {
            fullVolume = false;
        } else {
            fullVolume = true;
        }
        eventsend.setUserData({
            effect: audioChip,
            volume: volume,
            fullVolume: fullVolume,
            target: this.node
        });
        this.node.dispatchEvent(eventsend);
    },
    /**
     * @主要功能:   初始化阵营显示内容
     */
    fnTeamRenew: function fnTeamRenew() {
        this.bodyNode.scaleX = -this.team;
        if (this.team > 0) {
            this.healthNode[0].active = 0;
            this.healthNode[1].active = 0;
            this.healthNode[2].active = 1;
        } else if (this.team < 0) {
            this.healthNode[0].active = 1;
            this.healthNode[1].active = 0;
            this.healthNode[2].active = 0;
        } else {
            this.healthNode[0].active = 0;
            this.healthNode[1].active = 1;
            this.healthNode[2].active = 0;
        }
    }

});

cc._RF.pop();
},{}],"CreepCard":[function(require,module,exports){
"use strict";
cc._RF.push(module, '2dafchiSNxLGJUT3GiHZldp', 'CreepCard');
// Script/Prefab/others/CreepCard.js

'use strict';

var globalConstant = require("Constant");

cc.Class({
    extends: cc.Component,

    cardId: 0,

    cardType: 0,

    properties: {
        // 这个是枚举，相当的好用啊，以后都用这个好了
        magicType: {
            type: cc.Enum({
                NoTarget: 0,
                AreaTarget: 1,
                DirectionTarget: 2
            }),
            default: 0
        },

        //攻击力
        attack: 0,
        //攻击力标签
        attackLabel: cc.Label,
        //生命值
        health: 0,
        //生命值标签
        healthLabel: cc.Label,
        //速度
        velocity: 0,
        //速度
        velocityLabel: cc.Label,

        backRoll: cc.Node

    },

    // use this for initialization
    onLoad: function onLoad() {
        var self = this;
        self.magicTypeEnum = cc.Enum({
            NoTarget: 0,
            AreaTarget: 1,
            DirectionTarget: 2
        });

        self.cardScript = self.node.getComponent('Card');
        this.heroScirpt = this.cardScript.hero.getComponent('Player');

        this.preUse = false;

        self.attackLabel.string = self.attack;
        self.healthLabel.string = self.health;
        self.velocityLabel.string = self.velocity;
        //this.cScript = null;
        if (self.cardScript.cardType === 0) {
            this.cScript = self.node.getComponent('M' + self.cardScript.cardId);
        } else {
            this.cScript = self.node.getComponent('C' + self.cardScript.cardId);
        }

        this.startListen();
        // 这个添加监听为测试用
        // self.startListen();
    },
    setHealthTo: function setHealthTo(health) {
        var self = this;
        self.health = health;
        self.healthLabel.string = self.health;
    },
    setHealthBy: function setHealthBy(dHealth) {
        var self = this;
        self.health += dHealth;
        self.healthLabel.string = self.health;
    },
    setAttackTo: function setAttackTo(attack) {
        var self = this;
        self.attack += attack;
        self.attackLabel.string = self.attack;
    },
    setAttackBy: function setAttackBy(dAttack) {
        var self = this;
        self.attackLabel.string = self.attack += dAttack;
    },
    /**
     *
     * @param event
     * @constructor
     */
    NoTargetMagicStartListen: function NoTargetMagicStartListen(event) {
        if (event.getButton() === cc.Event.EventMouse.BUTTON_LEFT) {
            console.log("NoTargetMagicStartListen" + event.getLocationX().toFixed(0));
        }
    },
    /**
     *
     * @param event
     * @constructor
     */
    AreaTargetMagicStartListen: function AreaTargetMagicStartListen(event) {
        //console.log("AreaTargetMagicStartListen");
    },
    /**
     *
     * @param event
     * @constructor
     */
    DirectionTargetMagicStartListen: function DirectionTargetMagicStartListen(event) {
        //console.log("DirectionTargetMagicStartListen");
    },
    /**
     *
     * @param event
     * @constructor
     */
    NoTargetMagicMoveListen: function NoTargetMagicMoveListen(event) {
        if (this.node.y > globalConstant.cardUseLine && this.preUse === false) {
            this.node.opacity = 200;
            this.preUse = true;
        }
        if (this.node.y <= globalConstant.cardUseLine && this.preUse === true) {
            this.node.opacity = 1000;
            this.preUse = false;
        }
        // console.log("NoTargetMagicStartListen " + event.getLocationX().toFixed(0) + "," + event.getLocationY().toFixed(0));
    },
    /**
     *
     * @param event
     * @constructor
     */
    AreaTargetMagicMoveListen: function AreaTargetMagicMoveListen(event) {
        //console.log("AreaTargetMagicMoveListen");
    },
    /**
     *
     * @param event
     * @constructor
     */
    DirectionTargetMagicMoveListen: function DirectionTargetMagicMoveListen(event) {
        //console.log("DirectionTargetMagicMoveListen");
    },
    /**
     *
     * @param event
     * @constructor
     */
    NoTargetMagicEndListen: function NoTargetMagicEndListen(event) {
        //console.log("NoTargetMagicEndListen");
        if (this.preUse === true) {
            this.heroScirpt.mana -= this.cardScript.manaConsume;
            this.cScript.useCard();
        }
    },
    /**
     *
     * @param event
     * @constructor
     */
    AreaTargetMagicEndListen: function AreaTargetMagicEndListen(event) {
        //console.log("AreaTargetMagicEndListen");
        // this.node.removeFromParent();
    },
    /**
     *
     * @param event
     * @constructor
     */
    DirectionTargetMagicEndListen: function DirectionTargetMagicEndListen(event) {
        //console.log("DirectionTargetMagicEndListen");
    },

    // 开启监听的位置，不过嘛，后面还得改，这里先搭个模子，至少保证功能正常
    startListen: function startListen() {
        var self = this;
        console.log("add listen");
        switch (self.magicType) {
            case 0:
                self.node.on(cc.Node.EventType.MOUSE_DOWN, self.NoTargetMagicStartListen, self);
                self.node.on(cc.Node.EventType.MOUSE_MOVE, self.NoTargetMagicMoveListen, self);
                self.node.on(cc.Node.EventType.MOUSE_UP, self.NoTargetMagicEndListen, self);
                break;
            case 1:
                self.node.on(cc.Node.EventType.MOUSE_DOWN, self.AreaTargetMagicStartListen, self);
                self.node.on(cc.Node.EventType.MOUSE_MOVE, self.AreaTargetMagicMoveListen, self);
                self.node.on(cc.Node.EventType.MOUSE_UP, self.AreaTargetMagicEndListen, self);
                break;
            case 2:
                self.node.on(cc.Node.EventType.MOUSE_DOWN, self.DirectionTargetMagicStartListen, self);
                self.node.on(cc.Node.EventType.MOUSE_MOVE, self.DirectionTargetMagicMoveListen, self);
                self.node.on(cc.Node.EventType.MOUSE_UP, self.DirectionTargetMagicEndListen, self);
                break;
        }
    }

});

cc._RF.pop();
},{"Constant":"Constant"}],"Deck":[function(require,module,exports){
"use strict";
cc._RF.push(module, '75fb6UqavpDI5bemd9FcuPJ', 'Deck');
// MainScene/Scripts/Deck.js

'use strict';

var Global = require('Global');

cc.Class({
    extends: cc.Component,

    properties: {

        cardBoard: cc.Node,
        mainScence: cc.Node,

        deckNum: cc.Label,

        deckAddButton: cc.Node
    },

    // use this for initialization
    onLoad: function onLoad() {
        this.delay = 0;
        this.cardList = this.cardBoard.getComponent('CardList');
        this.mainScript = this.mainScence.getComponent('MainSceneManager');
        this.deckAddScript = this.deckAddButton.getComponent(cc.Button);

        this.initListenEvent();
    },

    initListenEvent: function initListenEvent() {

        this.node.on("mouseDownTheShowCard", removeCard, this);
        this.node.on("mouseDownTheDeck", getInDeck, this);
        this.node.on("nameTheDeck", changeDeckName, this);
        this.node.on("removeTheDeck", removeDeck, this);

        function removeCard(event) {
            var i = 0;
            event.detail.object.addNumBy(-1);
            if (event.detail.object.cardType === 1) {
                //this.mainScript.myCDeck[event.detail.object.cardId]--;
                this.cardList.deckNum--;
                if (--this.mainScript.myCDeck[event.detail.object.cardId] === 0) {
                    this.cardList.cardDeckInit();
                }
            } else {
                //this.mainScript.myMDeck[event.detail.object.cardId]--;
                this.cardList.deckNum--;
                if (--this.mainScript.myMDeck[event.detail.object.cardId] === 0) {
                    this.cardList.cardDeckInit();
                }
            }
        }
        //for(i=0;i<this.cardList.deck.length;i++){
        //    if(this.cardList.deck[i] === event.detail.object.node){
        //        this.cardList.deck.splice(i,1);
        //        event.detail.object.node.removeFromParent();
        //    }else{
        //        this.mainScript.myMDeck[event.detail.object.cardId]--;
        //        this.cardList.deckNum--;
        //        if(this.mainScript.myMDeck[event.detail.object.cardId] === 0){
        //            for(i=0;i<this.cardList.deck.length;i++){
        //                if(this.cardList.deck[i] === event.detail.object.node){
        //                    this.cardList.deck.splice(i,1);
        //                    event.detail.object.node.removeFromParent();
        //                }
        //            }
        //        }
        //    }
        //}
        function changeDeckName(event) {
            Global.totalDeckData[Global.deckView].name = event.detail.name;
        }
        function removeDeck(event) {
            cc.log(event.detail.object.num);
            Global.totalDeckData.splice(event.detail.object.num, 1);
            for (var i = 0; i < Global.totalDeckData.length; i++) {
                Global.totalDeckData[i].num = i;
            }
            event.detail.object.node.removeFromParent();
        }
        function getInDeck(event) {
            this.cardList.modeChange2();
            Global.deckView = event.detail.object.num;

            this.mainScript.myMDeck = Global.totalDeckData[Global.deckView].magicDeck;
            this.mainScript.myCDeck = Global.totalDeckData[Global.deckView].creatureDeck;
            this.deckAddScript.interactable = false;
            this.cardList.ojbk.active = true;

            this.cardList.cardDeckInit();
        }
    },
    getOutDeck: function getOutDeck(event) {
        this.cardList.modeChange0();
        //Global.totalDeckData.deckView = event.detail.object.num;
        Global.totalDeckData[Global.deckView].magicDeck = this.mainScript.myMDeck;
        Global.totalDeckData[Global.deckView].creatureDeck = this.mainScript.myCDeck;
        if (this.cardList.deckNum === 30) Global.totalDeckData[Global.deckView].usable = true;else Global.totalDeckData[Global.deckView].usable = false;
        this.deckAddScript.interactable = true;
        this.cardList.ojbk.active = false;

        this.cardList.renewDeckView();
    },
    addDeck: function addDeck() {
        var deckData = {
            name: "new deck",
            //deckView:0,
            num: 0,
            magicDeck: {
                default: [],
                type: cc.Integer
            },
            creatureDeck: {
                default: [],
                type: cc.Integer
            },
            //?????
            type: {
                type: cc.Enum({
                    //??
                    //??
                    Science: 0,
                    Fantasy: 1,
                    //??
                    Chaos: 2
                }),
                default: 0
            },
            usable: false
        };

        this.cardList.modeChange2();
        deckData.num = Global.totalDeckData.length;
        deckData.magicDeck = [0, 0];
        deckData.creatureDeck = [0, 0];
        Global.totalDeckData.push(deckData);
        Global.deckView = Global.totalDeckData.length - 1;
        this.mainScript.myMDeck = Global.totalDeckData[Global.deckView].magicDeck;
        this.mainScript.myCDeck = Global.totalDeckData[Global.deckView].creatureDeck;
        this.deckAddScript.interactable = false;
        this.cardList.ojbk.active = true;

        this.cardList.cardDeckInit();
    },
    // called every frame, uncomment this function to activate update callback
    update: function update(dt) {
        this.delay++;
        if (this.delay >= 6) {
            this.delay = 0;
            if (this.cardList.mode === 2) {
                this.deckNum.string = this.cardList.deckNum + '/' + this.mainScript.maxDeckNum;
            } else {
                this.deckNum.string = Global.totalDeckData.length + '/' + 9;
            }
        }
    }
});

cc._RF.pop();
},{"Global":"Global"}],"Door":[function(require,module,exports){
"use strict";
cc._RF.push(module, 'c0f78FX2PVGX7CvvAz0Zbla', 'Door');
// MainScene/Scripts/Door.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {
        storeNode: cc.Node
    },

    // use this for initialization
    onLoad: function onLoad() {
        this.inDoor = false;
        cc.director.getCollisionManager().enabled = true;
        cc.eventManager.addListener({
            event: cc.EventListener.KEYBOARD,
            //onKeyPressed: this.onKeyPressed.bind(this),
            onKeyReleased: this.onKeyReleased.bind(this)
        }, this.node);
    },

    onKeyReleased: function onKeyReleased(keyCode, event) {
        if (this.inDoor === true) {
            switch (keyCode) {
                case cc.KEY.e:
                case cc.KEY.space:
                    this.inDoor = false;
                    this.storeNode.active = true;
                    break;
            }
        }
    },
    onCollisionEnter: function onCollisionEnter(other, self) {
        //�����Ӵ��ж�
        if (other.node.group === "Hero") {
            console.log("touch the Hero");
            this.inDoor = true;
        }
    },
    onCollisionExit: function onCollisionExit(other, self) {
        if (other.node.group === "Hero") {
            this.inDoor = false;
        }
    },
    battleScene: function battleScene() {
        cc.director.loadScene("game");
    }
});

cc._RF.pop();
},{}],"DrawCard":[function(require,module,exports){
"use strict";
cc._RF.push(module, 'fd76avs6/lF57p86d368xef', 'DrawCard');
// MainBattleScene/Scripts/Manager/DrawCard.js

'use strict';

//获取全局变量脚本
var Global = require('Global');
/**
 * @主要功能 加载牌库，实现抽牌
 * @author 天际/老黄/C14
 * @Date 2017/8/12
 */
cc.Class({
    extends: cc.Component,

    properties: {
        //魔法生物牌的预制
        magicCardPrefab: {
            default: [],
            type: [cc.Prefab]
        },
        biologyCardPrefab: {
            default: [],
            type: cc.Prefab
        },

        //魔法牌预制组，按照卡组的数据进行初始化
        myMDeck: {
            default: [],
            type: cc.Prefab
        },
        //生物牌预制组，按照卡组的数据进行初始化
        myCDeck: {
            default: [],
            type: cc.Prefab
        },
        //总牌库，节点形式存放
        Deck: {
            default: [],
            type: cc.Node
        },
        //英雄的节点
        heroNode: cc.Node,

        //指定卡片生成的X坐标    
        positionX: 0,
        //指定卡片生成的类型  
        cardTypeFlag: 0,
        //handCardMaxNum: 0,
        drawCardFlag: 0,

        roll: cc.Node
    },

    // use this for initialization
    onLoad: function onLoad() {
        var i = 0,
            j = 0;
        this.returnPostion = 0;
        this.cardTypeFlag = cc.randomMinus1To1();
        this.heroScript = this.heroNode.getComponent('Player');

        var deckDatas = {
            name: "我的卡组",
            num: 0,
            magicDeck: {
                default: [],
                type: cc.Integer
            },
            creatureDeck: {
                default: [],
                type: cc.Integer
            },
            //卡组的类型
            type: {
                type: cc.Enum({
                    //幻想
                    //科学
                    Science: 0,
                    Fantasy: 1,
                    //混沌
                    Chaos: 2
                }),
                default: 0
            },
            usable: true
        };
        Global.totalDeckData.push(deckDatas);
        Global.deckUsage = 0;
        Global.totalDeckData[Global.deckUsage].magicDeck = [30, 30];
        Global.totalDeckData[Global.deckUsage].creatureDeck = [30, 30];
        //this.cardListScript = this.cardList.getComponent('CardList');


        for (i = 0; i < Global.totalDeckData[Global.deckUsage].magicDeck.length; i++) {
            if (Global.totalDeckData[Global.deckUsage].magicDeck[i] !== 0) {
                for (j = 0; j < Global.totalDeckData[Global.deckUsage].magicDeck[i]; j++) {
                    this.myMDeck.push(this.magicCardPrefab[i]);
                }
            }
        }
        for (i = 0; i < Global.totalDeckData[Global.deckUsage].creatureDeck.length; i++) {
            if (Global.totalDeckData[Global.deckUsage].creatureDeck[i] !== 0) {
                for (j = 0; j < Global.totalDeckData[Global.deckUsage].creatureDeck[i]; j++) {
                    this.myCDeck.push(this.biologyCardPrefab[i]);
                }
            }
        }
        //先发6张牌再说
        for (i = 0; i < 6; i++) {
            this.showNewCard();
        }
        //4秒补充一张牌
        this.delayTime(4);
    },

    showNewCard: function showNewCard() {
        if (this.heroScript.handCard.length < 9) {
            this.creatCardType();
        }
    },
    creatCardType: function creatCardType() {
        var rand = 0;
        if (this.myCDeck.length + this.myMDeck.length === 0) return;

        rand = Math.floor(Math.random() * (this.myCDeck.length + this.myMDeck.length - 1));

        if (rand >= this.myMDeck.length) {
            if (this.heroScript.handCard.length < 9) {
                this.creatNewCard(this.myCDeck[rand - this.myMDeck.length]);
            }
            this.myCDeck.splice(rand - this.myMDeck.length, 1);
        } else {
            if (this.heroScript.handCard.length < 9) {
                this.creatNewCard(this.myMDeck[rand]);
            }
            this.myMDeck.splice(rand, 1);
        }
    },
    creatNewCard: function creatNewCard(cardObject) {
        var newCard = cc.instantiate(cardObject);
        //script作为初始化使用的卡牌的脚本
        var script = newCard.getComponent('Card');
        script.roll = this.roll;
        script.hero = this.heroNode;
        script.team = this.heroScript.team;
        newCard.y = 0;

        var script2 = null;
        if (script.cardType === 0) {
            script2 = newCard.getComponent('MagicCard');
        } else {
            script2 = newCard.getComponent('CreepCard');
        }
        script2.hero = this.heroNode;
        script2.backRoll = this.roll;

        //newCard.tag = this.positionX;
        // ------------------------------------------------------------------------------ //
        script.drawCardScript = this;
        //script.cardIndex = this.cardGroup.length;
        // ------------------------------------------------------------------------------ //
        this.heroScript.handCard.push(newCard);

        //this.positionX++;
        //this.cardTypeFlag = cc.randomMinus1To1();
        this.node.addChild(newCard, script.cardIndex);
        // this.cardShape(newCard);
        // this.cardUse(newCard);
    },

    // 删除牌
    deleteCard: function deleteCard(card) {
        for (var index = 0; index < this.heroScript.handCard.length; index++) {
            if (card === this.heroScript.handCard[index]) {
                this.heroScript.handCard.splice(index, 1);
            }
        }
        cc.log(this.heroScript.handCard.length);
        card.removeFromParent(true);
    },

    delayTime: function delayTime(time) {
        this.schedule(this.showNewCard, time);
    },

    //cardShape: function(cardObject){
    //    cardObject.on(cc.Node.EventType.MOUSE_ENTER,function () {
    //            cardObject.runAction(cc.speed(cc.scaleBy(1.2,1.2), 7));
    //    }, this);
    //    cardObject.on(cc.Node.EventType.MOUSE_LEAVE,function(){
    //        cardObject.stopAllActions();
    //        cardObject.runAction(cc.speed(cc.scaleTo(1,1),7));
    //    },this);
    //},

    //cardUse: function(cardObject){
    //        cardObject.on(cc.Node.EventType.MOUSE_DOWN, function () {
    //            //cardObject.opacity = 90;
    //            cardObject.on(cc.Node.EventType.MOUSE_MOVE,cardMove,this);
    //        }, this);
    //        cardObject.on(cc.Node.EventType.MOUSE_UP,function(){
    //            //cardObject.opacity = 1000;
    //            cardObject.off(cc.Node.EventType.MOUSE_MOVE,cardMove,this);
    //
    //            if(cardObject.y >= 100){
    //                var script = cardObject.getComponent('Card');
    //                if(this.heroComponent.mana >= script.manaConsume
    //                   && script.getUseState() === true){
    //
    //                    this.heroComponent.mana -= script.manaConsume;
    //                    script.useCard();
    //                    this.cardGroup.splice(this.cardGroup.indexOf(cardObject),1);
    //                    this.fnRenewCard();
    //                    this.positionX--;
    //                    cardObject.removeFromParent();
    //                }else{
    //                    cardObject.x = 120*this.cardGroup.indexOf(cardObject);
    //                    cardObject.y = 0;
    //                }
    //
    //            }else{
    //                    cardObject.x = 120*this.cardGroup.indexOf(cardObject);
    //                    cardObject.y = 0;
    //                }
    //        },this);
    //        function cardMove(event) {
    //                cardObject.x += event.getDeltaX();
    //                cardObject.y += event.getDeltaY();
    //                if(cardObject.y >= 100){
    //                //cardObject.opacity = 1000;
    //            }
    //        }
    //},

    ////刷新卡牌的位置
    //    fnRenewCard:function(){
    //        var i = 0;
    //        for(i = 0;i < this.cardGroup.length ; i++){
    //            this.cardGroup[i].x = 120*i;
    //        }
    //    },

    changeCardToUsing: function changeCardToUsing(event) {}

});

cc._RF.pop();
},{"Global":"Global"}],"Fire":[function(require,module,exports){
"use strict";
cc._RF.push(module, 'b5dbbh9iwxKrqDK2VmTsp4/', 'Fire');
// Script/Prefab/others/Fire.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {
        damage: 0,
        flySpeed: 0,
        flyDistance: 0
    },

    // use this for initialization
    onLoad: function onLoad() {}

});

cc._RF.pop();
},{}],"FirstPageCard":[function(require,module,exports){
"use strict";
cc._RF.push(module, 'c94ffdYtItFFJd8p9TMTZZ5', 'FirstPageCard');
// MainScene/Scripts/FirstPageCard.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {
        moonLightWorm: {
            default: null,
            type: cc.Prefab
        },
        unDeadBird: {
            default: null,
            type: cc.Prefab
        }
    },

    // use this for initialization
    onLoad: function onLoad() {
        this.creatCard(this.moonLightWorm, 0);
        this.creatCard(this.unDeadBird, 1);
    },
    creatCard: function creatCard(cardType, i) {
        var newCard = cc.instantiate(cardType);
        newCard.x = -120 + 120 * i;
        newCard.y = 130;
        this.node.addChild(newCard);
    }

    // called every frame, uncomment this function to activate update callback
    // update: function (dt) {

    // },
});

cc._RF.pop();
},{}],"GameTimer":[function(require,module,exports){
"use strict";
cc._RF.push(module, '5330bazy1FJPqwJOjLqLjcA', 'GameTimer');
// MainBattleScene/Scripts/Manager/GameTimer.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {
        // foo: {
        //    default: null,      // The default value will be used only when the component attaching
        //                           to a node for the first time
        //    url: cc.Texture2D,  // optional, default is typeof default
        //    serializable: true, // optional, default is true
        //    visible: true,      // optional, default is true
        //    displayName: 'Foo', // optional
        //    readonly: false,    // optional, default is false
        // },
        // ...
    },

    // use this for initialization
    onLoad: function onLoad() {
        this.processBar = this.node.getComponent(cc.ProgressBar);
        this.timer = 0;
        this.maxTimer = 800;
        cc.log(this.processBar.progress);
        this.processBar.progress = this.timer / this.maxTimer;
        this.schedule(function () {
            this.timer++;

            if (this.timer > this.maxTimer) {
                this.timer = 0;
                var allChild = this.node.getChildren();
                for (var i = 0; i < allChild.length; i++) {
                    var chantScript = allChild[i].getComponent("Chant");
                    if (chantScript != null) {
                        chantScript.flag = false;
                    }
                }
            }

            var allChild1 = this.node.getChildren();
            for (var j = 0; j < allChild1.length; j++) {
                var chantScript1 = allChild1[j].getComponent("Chant");
                if (chantScript1 != null) {
                    if (chantScript1.percent <= this.timer / this.maxTimer && chantScript1.flag === false) {
                        chantScript1.flag = true;
                        chantScript1.fnChangeRound(-1);
                    }
                }
            }
            //cc.log(j);
            this.processBar.progress = this.timer / this.maxTimer;

            //cc.eventManager.dispatchEvent(event);
        }, 0.01);
    }

});

cc._RF.pop();
},{}],"Global":[function(require,module,exports){
"use strict";
cc._RF.push(module, 'bb282okogNMoLL+BUKhYixY', 'Global');
// Global.js

"use strict";

// Global.js, now the filename matters

module.exports = {

    //玩家持有的金币
    money: 1000,
    //灵魂碎片
    soul: 12,
    //卡包的数量
    bagNum: 10,
    //现在正在浏览的卡组
    deckView: 0,

    //卡组的类型
    type: {
        type: cc.Enum({
            //科学
            Science: 0,
            //幻想
            Fantasy: 1,
            //混沌
            Chaos: 2
        }),
        default: 0
    },

    //所有的卡组数据在此
    totalDeckData: [],

    //出战选择的卡组编号
    deckUsage: 0
};
//{
//deckData:{
//    name:"我的卡组",
//    num:0,
//    magicDeck:{
//        default: [],
//        type: cc.Integer
//    },
//    creatureDeck:{
//        default:[],
//        type: cc.Integer
//    },
//    //卡组的类型
//    type: {
//        type: cc.Enum({
//            //幻想
//            //科学
//            Science: 0,
//            Fantasy: 1,
//            //混沌
//            Chaos: 2,
//        }),
//        default: 0,
//    },
//    usable:true,
//},

cc._RF.pop();
},{}],"HeroControl":[function(require,module,exports){
"use strict";
cc._RF.push(module, '1de3dfXxWNK7L0bM+67omk7', 'HeroControl');
// MainScene/Scripts/HeroControl.js

'use strict';

var Global = require('Global');

cc.Class({
    extends: cc.Component,

    properties: {
        panelNode: cc.Node,
        // foo: {
        //    default: null,      // The default value will be used only when the component attaching
        //                           to a node for the first time
        //    url: cc.Texture2D,  // optional, default is typeof default
        //    serializable: true, // optional, default is true
        //    visible: true,      // optional, default is true
        //    displayName: 'Foo', // optional
        //    readonly: false,    // optional, default is false
        // },
        // ...
        gravite: 0,
        moveSpeed: 0,
        jumpSpeed: 0,
        mainScence: cc.Node

    },

    // use this for initialization
    onLoad: function onLoad() {
        this.speed = cc.v2(0, 0);
        this.isGoLeft = false; //判断是否向左走
        this.isGoRight = false; //判断是否向右走
        this.isStand = false; //站立状态
        this.isStandPlatform = false; //是否站在台上
        this.isStandWall = false; //是否站在墙体上
        this.isTouchWallL = false;
        this.isTouchWallR = false;
        this.isTouchWallD = false;
        this.inDoor = false;

        this.climbSpeed = cc.v2(0, 0);
        this.isClimbingUp = false; //判断是否为向上攀爬状态
        this.isClimbingDown = false; //判断是否为向下攀爬状态
        this.isClimbing = false; //是否正在攀爬
        this.touchedLadder = null;

        this.mainScript = this.mainScence.getComponent('MainSceneManager');
        //开启碰撞
        cc.director.getCollisionManager().enabled = true;
        //cc.director.getCollisionManager().enabledDebugDraw = true;

        cc.eventManager.addListener({
            event: cc.EventListener.KEYBOARD,
            onKeyPressed: this.onKeyPressed.bind(this),
            onKeyReleased: this.onKeyReleased.bind(this)
        }, this.node);

        this.initMouseEvent();
    },

    initMouseEvent: function initMouseEvent() {
        this.node.on(cc.Node.EventType.MOUSE_DOWN, openPanel, this);

        function openPanel() {
            this.panelNode.active = true;
        }
    },
    onKeyPressed: function onKeyPressed(keyCode, event) {
        switch (keyCode) {
            case cc.KEY.a:
            case cc.KEY.left:
                this.isGoLeft = true;
                this.isTouchWallL = false;
                break;
            case cc.KEY.d:
            case cc.KEY.right:
                this.isGoRight = true;
                this.isTouchWallR = false;
                break;
            case cc.KEY.w:
            case cc.KEY.up:
                if (this.touchedLadder === null) {
                    //|| this.isStandPlatform//this.isStand   ||(this.isStandWall) &&
                    this.speed.y = this.jumpSpeed;
                    this.isStand = false;
                    this.isStandPlatform = false;
                    this.isStandWall = false;
                } else if (this.touchedLadder !== null) {
                    this.isClimbing = true;
                    this.isClimbingUp = true;
                    this.node.x = this.touchedLadder.x;
                    this.speed.y = 0;
                    this.isStandPlatform = false;
                    //this.isStandWall = false;
                }
                break;
            case cc.KEY.s:
            case cc.KEY.down:
                if (this.touchedLadder !== null) {
                    this.isClimbing = true;
                    this.isClimbingDown = true;
                    this.node.x = this.touchedLadder.x;
                    this.speed.y = 0;
                    this.isStandPlatform = false;
                    //this.isStandWall = false;
                }
                break;
        }
    },

    onKeyReleased: function onKeyReleased(keyCode, event) {
        switch (keyCode) {
            case cc.KEY.a:
            case cc.KEY.left:
                this.isGoLeft = false;
                break;
            case cc.KEY.d:
            case cc.KEY.right:
                this.isGoRight = false;
                break;
            case cc.KEY.w:
            case cc.KEY.up:
                this.isClimbingUp = false;
                if (this.touchedLadder !== null) {
                    this.isStandPlatform = false;
                    //this.isStandWall = false;
                }
                break;
            case cc.KEY.s:
            case cc.KEY.down:
                this.isClimbingDown = false;
                if (this.touchedLadder !== null) {
                    this.isStandPlatform = false;
                    //this.isStandWall = false;
                }
                break;
            case cc.KEY.e:
            case cc.KEY.space:
                if (this.inDoor === true) {
                    Global.totalDeckData[Global.deckUsage].magicDeck = this.mainScript.myMDeck;
                    Global.totalDeckData[Global.deckUsage].creatureDeck = this.mainScript.myCDeck;
                    this.battleScene();
                }
                break;
        }
    },
    battleScene: function battleScene() {
        cc.director.preloadScene('game', function () {
            cc.log('Next scene preloaded');
            cc.director.loadScene('game');
        });
    },

    onCollisionEnter: function onCollisionEnter(other, self) {
        //地面接触判断
        if (other.node.group === "Ground") {
            console.log("touch the ground");
            this.isStand = true;
            this.speed.y = 0;
            self.node.y = other.node.y + other.node.height / 2 + self.node.height / 2;
        }
        if (other.node.group === "Door") {
            console.log("touch the Door");
            this.inDoor = true;
        }
        //爬梯接触判断
        if (other.node.group === "Ladder") {
            console.log("touch the ladder");
            this.touchedLadder = other.node;
        }

        //平台接触判断
        if (other.node.group === "Platform") {
            if (self.node.y > other.node.y && Math.abs(self.node.x - other.node.x) < other.node.width / 2) {
                this.isStandPlatform = true;
                this.speed.y = 0;
            }
            console.log("touch the Platform");
        }

        //与完全墙体的接触判断
        if (other.node.group === "WallU") {
            if (self.node.y > other.node.y && Math.abs(self.node.x - other.node.x) < other.node.width / 2) {
                this.isStandWall = true;
                this.speed.y = 0;
            }
            console.log("touch the WallU");
        }
        if (other.node.group === "WallD") {
            if (self.node.y < other.node.y && Math.abs(self.node.x - other.node.x) - self.node.width / 2 < other.node.width / 2) {
                this.isTouchWallD = true;
                this.speed.y = 0;
            }
            console.log("touch the WallD");
        }
        if (other.node.group === "WallL") {
            if (self.node.x < other.node.x && Math.abs(self.node.y - other.node.y) < other.node.height / 2 + self.node.height / 2) {
                this.isTouchWallL = true;
                this.speed.x = 0;
            }
            console.log("touch the WallL");
        }
        if (other.node.group === "WallR") {
            if (self.node.x > other.node.x && Math.abs(self.node.y - other.node.y) < other.node.height / 2 + self.node.height / 2) {
                this.isTouchWallR = true;
                this.speed.x = 0;
            }
            console.log("touch the WallR");
        }
    },

    onCollisionExit: function onCollisionExit(other, self) {
        if (other.node.group === "Ground") {
            this.isStand = false;
        }

        if (other.node.group === "Ladder") {
            this.touchedLadder = null;
            this.isClimbing = false;
        }
        if (other.node.group === "Door") {
            console.log("untouch the Door");
            this.inDoor = false;
        }
        if (other.node.group === "Platform") {
            this.isStandPlatform = false;
        }

        if (other.node.group === "WallU") {
            this.isStandWall = false;
            console.log("untouch the WallU");
        }
        if (other.node.group === "WallD") {
            this.isTouchWallD = false;
            console.log("untouch the WallD");
        }
        if (other.node.group === "WallL" /* && this.isGoLeft === true*/) {
                this.isTouchWallL = false;
                console.log("untouch the WallL");
            }
        if (other.node.group === "WallR" /* && this.isGoRight === true*/) {
                this.isTouchWallR = false;
                console.log("untouch the WallR");
            }
    },

    // called every frame, uncomment this function to activate update callback
    update: function update(dt) {
        //处理X轴的速度
        if (this.isGoLeft === this.isGoRight) {
            //左右键同时按或不按，则不动
            this.speed.x = 0;
        } else if (this.isGoLeft === true && this.isTouchWallR === false) {
            this.speed.x = -this.moveSpeed; //向左
        } else if (this.isGoRight === true && this.isTouchWallL === false) {
            this.speed.x = this.moveSpeed; //向右
        }
        //处理Y轴的攀爬速度
        if (this.isClimbingUp === this.isClimbingDown) {
            //左右键同时按或不按，则不动
            this.climbSpeed.y = 0;
        } else if (this.isClimbingUp === true && !this.isTouchWallD) {
            this.climbSpeed.y = this.moveSpeed; //向上
        } else if (this.isClimbingDown === true && !this.isStand && !this.isStandWall) {
            this.climbSpeed.y = -this.moveSpeed; //向下
        } else {
            this.climbSpeed.y = 0;
        }

        //处理重力加速度
        if (!this.isStand && !this.isClimbing && !this.isStandPlatform && !this.isStandWall) {
            this.speed.y -= this.gravite * dt; //加速度对时间积分
        }

        //速度对时间的积分变为位移
        this.node.x += (this.speed.x + this.climbSpeed.x) * dt;
        this.node.y += (this.speed.y + this.climbSpeed.y) * dt;
    }
});

cc._RF.pop();
},{"Global":"Global"}],"InfoBoard":[function(require,module,exports){
"use strict";
cc._RF.push(module, 'bdce4nx9mVDgbZ+9gcHwNBY', 'InfoBoard');
// Prefab/Card/Show/InfoBoard.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {
        // foo: {
        //    default: null,      // The default value will be used only when the component attaching
        //                           to a node for the first time
        //    url: cc.Texture2D,  // optional, default is typeof default
        //    serializable: true, // optional, default is true
        //    visible: true,      // optional, default is true
        //    displayName: 'Foo', // optional
        //    readonly: false,    // optional, default is false
        // },
        // ...
    },

    // use this for initialization
    onLoad: function onLoad() {}

});

cc._RF.pop();
},{}],"Item":[function(require,module,exports){
"use strict";
cc._RF.push(module, 'e42c4dBhgZKyITTUKDmkBaY', 'Item');
// MainScene/Scripts/Prefab/Item.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {
        purchaseButton: cc.Node,

        folded: false,

        id: 0,
        //����
        iName: "",
        //���Ƶı�ǩ
        iNameLabel: cc.Label,

        //����
        detailLabel: cc.Label,
        //�����Ľ���
        money: 0,

        moneyLabel: cc.Label,

        clickable: true,
        type: {
            type: cc.Enum({
                bag: 0,
                story: 1
            }),
            default: 0
        }
        // foo: {
        //    default: null,      // The default value will be used only when the component attaching
        //                           to a node for the first time
        //    url: cc.Texture2D,  // optional, default is typeof default
        //    serializable: true, // optional, default is true
        //    visible: true,      // optional, default is true
        //    displayName: 'Foo', // optional
        //    readonly: false,    // optional, default is false
        // },
        // ...
    },

    // use this for initialization
    onLoad: function onLoad() {

        this.iNameLabel.string = this.iName;
        this.node.on(cc.Node.EventType.MOUSE_ENTER, this.enterBag, this);
        this.node.on(cc.Node.EventType.MOUSE_LEAVE, this.leaveBag, this);
        this.node.on(cc.Node.EventType.MOUSE_UP, this.clickBag, this);
    },
    init: function init() {
        this.folded = false;
        this.node.y = 0;
    },
    enterBag: function enterBag() {
        if (this.folded === false) {
            var action = cc.scaleTo(0.7, 1.4);
            //this.node.runAction(action.easing(cc.easeCircleActionInOut()));
            this.node.runAction(action.easing(cc.easeBackInOut()));
        }
    },
    leaveBag: function leaveBag() {
        if (this.folded === false) {
            var action = cc.scaleTo(0.7, 1);
            //this.node.runAction(action.easing(cc.easeCircleActionInOut()));
            this.node.runAction(action.easing(cc.easeBackInOut()));
        }
    },
    clickBag: function clickBag() {
        if (this.clickable === true) {
            var children = this.node.parent.children;
            var finished = cc.callFunc(function () {
                this.folded = false;
                for (var i = 0; i < children.length; i++) {
                    children[i].getComponent("Item").clickable = true;
                }
            }, this);
            var action1 = cc.sequence(cc.moveTo(0.7, 0, 0).easing(cc.easeCircleActionInOut()), cc.scaleTo(0.5, 1).easing(cc.easeCircleActionInOut()), finished);

            this.node.runAction(action1);
            //this.purchaseButton.runAction(cc.moveTo(0.7,this.node.x).easing(cc.easeBackInOut()));
            for (var i = 0; i < children.length; i++) {
                if (children[i] !== this.node) {
                    var action = cc.spawn(cc.scaleTo(0.7, 0.3), cc.moveTo(0.7, 0, -100));
                    children[i].runAction(action.easing(cc.easeCircleActionInOut()));
                    children[i].getComponent("Item").folded = true;
                    children[i].getComponent("Item").clickable = false;
                }
            }

            var eventsend = new cc.Event.EventCustom('purchaseId', true);
            eventsend.setUserData({ id: this.id, script: this });
            this.node.dispatchEvent(eventsend);
        }
    }
    // called every frame, uncomment this function to activate update callback
    // update: function (dt) {

    // },
});

cc._RF.pop();
},{}],"LayerManager":[function(require,module,exports){
"use strict";
cc._RF.push(module, '906b1b6elBA1rapMjb8qd6m', 'LayerManager');
// MainScene/Scripts/LayerManager.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {
        cardGroupButton: {
            default: null,
            type: cc.Button
        },
        openCardButton: {
            default: null,
            type: cc.Button
        },
        heroInfButton: {
            default: null,
            type: cc.Button
        },
        choiceHeroBoard: {
            default: null,
            type: cc.Node
        },
        choiceOpenBoard: {
            default: null,
            type: cc.Node
        },
        choiceCardBoard: {
            default: null,
            type: cc.Node
        },
        cardListNode: cc.Node
    },

    onLoad: function onLoad() {
        this.choiceHeroBoard.active = false;
        this.choiceOpenBoard.active = false;
        this.choiceCardBoard.active = true;
        this.cardListScript = this.cardListNode.getComponent("CardList");
    },
    //Ӣ��
    heroInfLayout: function heroInfLayout() {
        this.layoutSwitch(this.choiceHeroBoard, this.heroInfButton);
        this.choiceHeroBoard.active = true;
        this.choiceOpenBoard.active = false;
        this.choiceCardBoard.active = false;
        //cc.director.loadScene("HeroInfScene.fire");
    },
    //����
    openCardLayout: function openCardLayout() {
        this.layoutSwitch(this.choiceOpenBoard, this.openCardButton);
        this.choiceHeroBoard.active = false;
        this.choiceOpenBoard.active = true;
        this.choiceCardBoard.active = false;
        //cc.director.loadScene("OpenCardScene.fire");
    },
    //����
    cardGroupLayout: function cardGroupLayout() {
        this.layoutSwitch(this.choiceCardBoard, this.cardGroupButton);
        this.cardListScript.renewShowCardGroup();
        this.choiceHeroBoard.active = false;
        this.choiceOpenBoard.active = false;
        this.choiceCardBoard.active = true;
        //cc.director.loadScene("CardGroupScene.fire");
    },
    /*layoutSwitch: function(choiceBoard,choiceButton){
        choiceBoard.zIndex = 2;
        choiceBoard.zIndex = 1;
        choiceButton.pressedColor = new cc.Color.toCSS("#E9BF81");
    }*/
    layoutSwitch: function layoutSwitch(choiceBoard, choiceButton) {
        choiceBoard.zIndex = 2;
        choiceButton.zIndex = 1;
    }

    // called every frame, uncomment this function to activate update callback
    // update: function (dt) {

    // },
});

cc._RF.pop();
},{}],"M0":[function(require,module,exports){
"use strict";
cc._RF.push(module, '587156He0pGd5Ik0V6mqx22', 'M0');
// Script/Prefab/Cards/M0.js

'use strict';

var globalConstant = require("Constant");
cc.Class({
    extends: cc.Component,

    properties: {},

    // use this for initialization
    onLoad: function onLoad() {
        this.cardScript = this.node.getComponent('Card');
        this.magicCardScript = this.node.getComponent('MagicCard');
        var type = cc.Enum({
            NoTarget: 0,
            AreaTarget: 1,
            DirectionTarget: 2
        });
        //        var self = this;
        if (this.magicCardScript.magicType === type.AreaTarget) {
            this.useCard = function (position, area) {
                var eventsend = new cc.Event.EventCustom('magicCreate', true);
                eventsend.setUserData({
                    name: this.cardScript.cName,
                    round: 3,
                    y: null,
                    position: position,
                    area: area,
                    team: this.cardScript.team,
                    id: this.cardScript.cardId
                });
                this.node.dispatchEvent(eventsend);
                this.cardScript.drawCardScript.deleteCard(this.node);
            };
        } else if (this.magicCardScript.magicType === type.DirectionTarget) {
            this.useCard = function (id, angel, speed, area, x, y) {};
        } else {
            this.useCard = function () {};
        }
    },

    getUseState: function getUseState() {
        return true;
    },

    //useCard: function(position,area){
    //
    //    var eventsend = new cc.Event.EventCustom('magicCreate',true);
    //    eventsend.setUserData({
    //        name:this.cardScript.cName,
    //        round:3,
    //        y:null,
    //        position:position,
    //        area:area,
    //        team:this.cardScript.team,
    //        id:this.cardScript.cardId
    //    });
    //    this.node.dispatchEvent(eventsend);
    //    this.cardScript.drawCardScript.deleteCard(this.node);
    //},
    useCard: function useCard() {}

});

cc._RF.pop();
},{"Constant":"Constant"}],"M1":[function(require,module,exports){
"use strict";
cc._RF.push(module, '76ff78XbdRKKbU6/018iIZh', 'M1');
// Script/Prefab/Cards/M1.js

'use strict';

var globalConstant = require("Constant");
cc.Class({
    extends: cc.Component,

    properties: {
        magicType: {
            type: cc.Enum({
                NoTarget: 0,
                AreaTarget: 1,
                DirectionTarget: 2
            }),
            default: 0
        }

    },

    // use this for initialization
    onLoad: function onLoad() {
        this.cardScript = this.node.getComponent('Card');
        this.magicCardScript = this.node.getComponent('MagicCard');
        var type = cc.Enum({
            NoTarget: 0,
            AreaTarget: 1,
            DirectionTarget: 2
        });
        //        var self = this;
        if (this.magicCardScript.magicType === type.AreaTarget) {
            this.useCard = function (position, area) {};
        } else if (this.magicCardScript.magicType === type.DirectionTarget) {
            this.useCard = function (id, angel, speed, area, x, y) {
                var eventsend = new cc.Event.EventCustom('magicCreate', true);
                eventsend.setUserData({
                    name: this.cardScript.cName,
                    round: 1,
                    position: x,
                    y: y,
                    angel: angel,
                    speed: speed,
                    area: area,
                    team: this.cardScript.team,
                    id: this.cardScript.cardId
                });
                this.node.dispatchEvent(eventsend);
                this.cardScript.heroScirpt.drawCard(1);
                this.cardScript.drawCardScript.deleteCard(this.node);
            };
        } else {
            this.useCard = function () {};
        }
    },

    getUseState: function getUseState() {
        return true;
    },
    useCard: function useCard() {}
    //useCard: function(id,angel,speed,x,y){
    //
    //    var eventsend = new cc.Event.EventCustom('magicCreate',true);
    //    eventsend.setUserData({
    //        name:this.cardScript.cName,
    //        round:1,
    //        position:x,
    //        y:y,
    //        angel:angel,
    //        speed:speed,
    //        team:this.cardScript.team,
    //        id:this.cardScript.cardId
    //    });
    //    this.node.dispatchEvent(eventsend);
    //    this.cardScript.heroScirpt.drawCard(2);
    //    //for(var i = 0;i < (360/3);i++) {
    //    //    var eventsend = new cc.Event.EventCustom('chantCreate', true);
    //    //    eventsend.setUserData({
    //    //        name:this.cardScript.cName,
    //    //        round:15,
    //    //        position: x,
    //    //        y: y,
    //    //        angel: angel + 3*i,
    //    //        id: this.cardScript.cardId,
    //    //        speed: speed,
    //    //        team: this.cardScript.team
    //    //    });
    //    //    this.node.dispatchEvent(eventsend);
    //    //}
    //
    //    this.cardScript.drawCardScript.deleteCard(this.node);
    //}
    // called every frame, uncomment this function to activate update callback
    // update: function (dt) {

    // },
});

cc._RF.pop();
},{"Constant":"Constant"}],"Magic0":[function(require,module,exports){
"use strict";
cc._RF.push(module, '58aac2RxHhMZLCRKT7hza4d', 'Magic0');
// Script/Prefab/Magic/Magic0.js

"use strict";

var globalConstant = require("Constant");
cc.Class({
    extends: cc.Component,

    properties: {
        //魔法创建成功的音乐
        loadEffect: cc.AudioClip,
        //命中时的音乐
        hitEffect: cc.AudioClip

    },

    // use this for initialization
    onLoad: function onLoad() {

        var animation = this.node.getComponent(cc.Animation);
        this.team = 0;

        //传递创建法术成功时音效的事件
        if (this.loadEffect !== null) this.sendEvent(this.loadEffect);

        animation.on('finished', this.onFinished, this);

        cc.director.getCollisionManager().enabled = true;
        //cc.director.getCollisionManager().enabledDebugDraw = true;
    },

    onCollisionEnter: function onCollisionEnter(other, self) {
        //�����Ӵ��ж�
        if (other.node.group === "Ground") {}

        //�����Ӵ��ж�
        if (other.node.group === "Creature") {
            var script1 = other.node.getComponent('Creature');
            var stateScript = script1.stateNode.getComponent('CreatureState');
            cc.log("现在的队伍是" + script1.team);
            if (script1.team !== this.team) {

                //传递播放音效的事件
                if (this.hitEffect !== null) this.sendEvent(this.hitEffect);

                //stateScript.addState(globalConstant.stateEnum.heal,3,40);

                //传递播放音效的事件
                script1.changeHealth(-10);
                //script.cleanTarget();
            }
        }
        if (other.node.group === "Hero") {
            var script2 = other.node.getComponent('Player');
            if (script2.team !== this.team) {
                //传递播放音效的事件
                if (this.hitEffect !== null) this.sendEvent(this.hitEffect);
                //script.changeHealth(-10);

                var deadFlag = script2.changeHealth(-10);
                if (deadFlag != null && deadFlag == 1) {
                    script2.releaseTarget();
                }
            }
        }
        if (other.node.group === "Base") {
            var script3 = other.node.getComponent('Base');
            if (script3.team !== this.team) {
                //传递播放音效的事件
                if (this.hitEffect !== null) this.sendEvent(this.hitEffect);
                script3.changeHealth(-10);
            }
        }
    },

    onCollisionExit: function onCollisionExit(other, self) {
        if (other.node.group === "Ground") {}

        if (other.node.group === "Creature") {}
    },
    onFinished: function onFinished() {
        this.node.removeFromParent();
    },
    initMagic: function initMagic(detail) {
        var box = this.node.getComponent(cc.BoxCollider);
        box.size.width = detail.area;
        this.team = detail.team;
        this.node.width = detail.area;
    },
    /**
     * @主要功能 向上级节点传递消息，使之播放音效
     * @author C14
     * @Date 2017/12/12
     * @parameters audioChip volume
     * @returns null
     */
    sendEvent: function sendEvent(audioChip, fullVolume, volume) {
        var eventsend = new cc.Event.EventCustom("playEffect", true);
        if (volume === undefined || volume === null) {
            volume = 1;
        }
        if (fullVolume === undefined || fullVolume === null || fullVolume === false) {
            fullVolume = false;
        } else {
            fullVolume = true;
        }
        eventsend.setUserData({
            effect: audioChip,
            volume: volume,
            fullVolume: fullVolume,
            target: this.node
        });
        this.node.dispatchEvent(eventsend);
    }
});

cc._RF.pop();
},{"Constant":"Constant"}],"Magic1":[function(require,module,exports){
"use strict";
cc._RF.push(module, '1ab83Zv/jhAg4DVYpx8ySd7', 'Magic1');
// Script/Prefab/Magic/Magic1.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {
        //魔法创建成功的音乐
        loadEffect: cc.AudioClip,
        //命中时的音乐
        hitEffect: cc.AudioClip
    },

    // use this for initialization
    onLoad: function onLoad() {
        this.speed = cc.v2(0, 0);
        this.team = 0;
        this.area = 0;
        this.collisionTime = 0;

        //传递创建法术成功时音效的事件
        if (this.loadEffect !== null) this.sendEvent(this.loadEffect);

        var animation = this.node.getComponent(cc.Animation);
        var animState = animation.play();
        animState.repeatCount = Infinity;

        //animation.on('finished',  this.onFinished,    this);

        //������ײ
        cc.director.getCollisionManager().enabled = true;
        //cc.director.getCollisionManager().enabledDebugDraw = true;
    },

    onCollisionEnter: function onCollisionEnter(other, self) {
        //�����Ӵ��ж�
        if (other.node.group === "Ground") {
            this.collisionTime++;
            if (this.collisionTime >= 14) {
                var eventsend = new cc.Event.EventCustom('magicCreate', true);
                eventsend.setUserData({
                    position: this.node.x,
                    y: null,
                    area: this.area,
                    team: this.team,
                    id: 0
                });
                this.node.dispatchEvent(eventsend);
                this.node.removeFromParent();
            }
            this.speed.y = -this.speed.y;
            //this.node.removeFromParent();
        }
        if (other.node.group === "Sky") {
            this.collisionTime++;
            this.speed.y = -this.speed.y;
        }
        if (other.node.group === "LBound") {
            this.speed.x = -this.speed.x;
        }
        if (other.node.group === "RBound") {
            this.speed.x = -this.speed.x;
        }
        //�����Ӵ��ж�
        if (other.node.group === "Creature") {
            var script = other.node.getComponent('Creature');
            if (script.team !== this.team) {
                //传递播放音效的事件
                if (this.hitEffect !== null) this.sendEvent(this.hitEffect);
                //script.changeHealth(-10);

                var eventsend = new cc.Event.EventCustom('magicCreate', true);
                eventsend.setUserData({
                    position: this.node.x,
                    y: null,
                    area: this.area,
                    team: this.team,
                    id: 0
                });
                this.node.dispatchEvent(eventsend);

                this.node.removeFromParent();
            }
        }
        if (other.node.group === "Base") {
            var script2 = other.node.getComponent('Base');
            if (script2.team !== this.team) {
                //传递播放音效的事件
                if (this.hitEffect !== null) this.sendEvent(this.hitEffect);
                //script.changeHealth(-10);

                var eventsend2 = new cc.Event.EventCustom('magicCreate', true);
                eventsend2.setUserData({
                    position: this.node.x,
                    y: null,
                    area: this.area,
                    team: this.team,
                    id: 0
                });
                this.node.dispatchEvent(eventsend2);

                this.node.removeFromParent();
            }
        }
        if (other.node.group === "Hero") {
            var script3 = other.node.getComponent('Player');
            if (script3.team !== this.team) {
                //传递播放音效的事件
                if (this.hitEffect !== null) this.sendEvent(this.hitEffect);
                //script.changeHealth(-10);

                var eventsend3 = new cc.Event.EventCustom('magicCreate', true);
                eventsend3.setUserData({
                    position: this.node.x,
                    y: null,
                    area: this.area,
                    team: this.team,
                    id: 0
                });
                this.node.dispatchEvent(eventsend3);

                this.node.removeFromParent();
            }
        }
    },

    onCollisionExit: function onCollisionExit(other, self) {
        if (other.node.group === "Ground") {}

        if (other.node.group === "Creature") {}
    },

    changeTeam: function changeTeam(team) {
        //this.node.removeFromParent();
    },
    initMagic: function initMagic(detail) {
        this.team = detail.team;
        this.area = detail.area;
        this.speed.x = Math.sin((detail.angel + 90) * Math.PI / 180) * detail.speed;
        this.speed.y = Math.cos((detail.angel + 90) * Math.PI / 180) * detail.speed;
    },
    //called every frame, uncomment this function to activate update callback
    update: function update(dt) {
        //delayTime(1);
        this.node.x += this.speed.x * dt;
        this.node.y += this.speed.y * dt;
    },
    /**
     * @主要功能 向上级节点传递消息，使之播放音效
     * @author C14
     * @Date 2017/12/12
     * @parameters audioChip volume
     * @returns null
     */
    sendEvent: function sendEvent(audioChip, fullVolume, volume) {
        var eventsend = new cc.Event.EventCustom("playEffect", true);
        if (volume === undefined || volume === null) {
            volume = 1;
        }
        if (fullVolume === undefined || fullVolume === null || fullVolume === false) {
            fullVolume = false;
        } else {
            fullVolume = true;
        }
        eventsend.setUserData({
            effect: audioChip,
            volume: volume,
            fullVolume: fullVolume,
            target: this.node
        });
        this.node.dispatchEvent(eventsend);
    }
});

cc._RF.pop();
},{}],"MagicCard":[function(require,module,exports){
"use strict";
cc._RF.push(module, 'af2a9L9hlVLQqrOGnyDSxgc', 'MagicCard');
// Script/Prefab/others/MagicCard.js

"use strict";

var globalConstant = require("Constant");

cc.Class({
    extends: cc.Component,

    properties: {

        cardId: 0,

        cardType: 0,
        // 这个是枚举，相当的好用啊，以后都用这个好了
        magicType: {
            type: cc.Enum({
                NoTarget: 0,
                AreaTarget: 1,
                DirectionTarget: 2
            }),
            default: 0
        },
        //为该层添加范围法术，投掷法术的参数
        area: 0,
        //投掷速度
        speed: 0,

        hero: cc.Node,
        backRoll: cc.Node,

        rangeNode: cc.Prefab,
        rangeAnimationNode: cc.Prefab,
        arrowNode: cc.Prefab,

        prepareCardEffect: cc.AudioClip,
        useCardEffect: cc.AudioClip

    },

    // use this for initialization
    onLoad: function onLoad() {
        var self = this;
        self.magicTypeEnum = cc.Enum({
            NoTarget: 0,
            AreaTarget: 1,
            DirectionTarget: 2
        });
        //this.arrow = cc.instantiate(this.arrowNode);
        this.startListen();
        //是否移动到上面准备使用了，初始值，否
        this.preUse = false;
        this.backRollScript = this.backRoll.getComponent("BackRoll");
        self.cardScript = self.node.getComponent('Card');
        this.heroScirpt = this.cardScript.hero.getComponent('Player');

        //这个的最深层代码JS的获取
        this.mScript = null;
        if (self.cardType === 0) {
            this.mScript = self.node.getComponent('M' + self.cardId);
        } else {
            this.mScript = self.node.getComponent('C' + self.cardId);
        }

        this.currentEffect = false;
        //为该层添加范围法术，投掷法术的参数
        this.mAngle = 0;
        //var state = this.script.getUseState();
        //return state;

        // 这个添加监听为测试用
        // self.startListen();
    },

    /**
     *
     * @param event
     * @constructor
     */
    NoTargetMagicStartListen: function NoTargetMagicStartListen(event) {
        // this.node.x = event.getLocationX();
        // this.node.y = event.getLocationY();
        if (event.getButton() === cc.Event.EventMouse.BUTTON_LEFT) {
            // console.log("NoTargetMagicStartListen" + event.getLocationX().toFixed(0));
        }
    },
    /**
     *
     * @param event
     * @constructor
     */
    AreaTargetMagicStartListen: function AreaTargetMagicStartListen(event) {
        //向主控制脚本传递信息，播放开始的音效
    },
    /**
     *
     * @param event
     * @constructor
     */
    DirectionTargetMagicStartListen: function DirectionTargetMagicStartListen(event) {
        // this.node.x = event.getLocationX();
        // this.node.y = event.getLocationY();
        // console.log("DirectionTargetMagicStartListen");
    },
    /**
     *
     * @param event
     * @constructor
     */
    NoTargetMagicMoveListen: function NoTargetMagicMoveListen(event) {
        // console.log("NoTargetMagicStartListen " + event.getLocationX().toFixed(0) + "," + event.getLocationY().toFixed(0));
        if (this.node.y > globalConstant.cardUseLine && this.preUse === false) {
            this.node.opacity = 200;
            this.preUse = true;
            //播放法术准备用的音效
            this.currentEffect = cc.audioEngine.playEffect(this.prepareCardEffect, true, 1);
        }
        if (this.node.y <= globalConstant.cardUseLine && this.preUse === true) {
            this.node.opacity = 1000;
            this.preUse = false;
            //停止准备用的音乐
            cc.audioEngine.stopEffect(this.currentEffect);
        }
    },
    /**
     *
     * @param event
     * @constructor
     */
    AreaTargetMagicMoveListen: function AreaTargetMagicMoveListen(event) {
        //console.log("AreaTargetMagicMoveListen");
        if (this.node.y > globalConstant.cardUseLine) {
            if (this.preUse === false) {
                this.node.opacity = 0;
                this.preUse = true;
                this.rangeLNode.active = true;
                this.rangeRNode.active = true;
                this.rangeAnimeNode.active = true;
                //播放法术准备用的音效
                this.currentEffect = cc.audioEngine.playEffect(this.prepareCardEffect, true, 1);
            }
            this.rangeAnimeNode.x = this.node.x;
            this.rangeLNode.x = this.node.x - this.area * globalConstant.unitLength / 2;
            this.rangeRNode.x = this.node.x + this.area * globalConstant.unitLength / 2;
        }

        if (this.node.y <= globalConstant.cardUseLine && this.preUse === true) {
            this.node.opacity = 1000;
            this.preUse = false;
            this.rangeLNode.active = false;
            this.rangeRNode.active = false;
            this.rangeAnimeNode.active = false;
            //停止准备用的音乐
            cc.audioEngine.stopEffect(this.currentEffect);
        }
    },
    /**
     *
     * @param event
     * @constructor
     */
    DirectionTargetMagicMoveListen: function DirectionTargetMagicMoveListen(event) {

        // console.log("DirectionTargetMagicMoveListen");
        if (this.node.y > globalConstant.cardUseLine) {
            if (this.preUse === false) {
                this.node.opacity = 0;
                this.preUse = true;
                this.arrow.active = true;
                //播放法术准备用的音效
                this.currentEffect = cc.audioEngine.playEffect(this.prepareCardEffect, true, 1);
            }
            var targetPos = this.arrow.convertToWorldSpaceAR(cc.Vec2.ZERO);
            if (globalConstant.cameraOffset === 0) {
                this.arrow.rotation = 360 - Math.atan2(event.getLocationY() - targetPos.y, event.getLocationX() - this.hero.x) * 180 / Math.PI;
            } else if (this.hero.x > cc.director.getWinSize().width * (globalConstant.sceneWidth - globalConstant.sceneEdge)) {
                this.arrow.rotation = 360 - Math.atan2(event.getLocationY() - cc.director.getWinSize().height / 2 - (this.arrow.y + this.arrow.parent.y), event.getLocationX() - this.hero.x + cc.director.getWinSize().width * (globalConstant.sceneWidth - globalConstant.sceneEdge * 2)) * 180 / Math.PI;
            } else {
                this.arrow.rotation = 360 - Math.atan2(event.getLocationY() - cc.director.getWinSize().height / 2 - (this.arrow.y + this.arrow.parent.y), event.getLocationX() - cc.director.getWinSize().width * globalConstant.sceneEdge) * 180 / Math.PI;
            }
        }

        if (this.node.y <= globalConstant.cardUseLine && this.preUse === true) {
            this.node.opacity = 1000;
            this.preUse = false;
            this.arrow.active = false;
            //停止准备用的音乐
            cc.audioEngine.stopEffect(this.currentEffect);
        }
    },
    /**
     *
     * @param event
     * @constructor
     */
    NoTargetMagicEndListen: function NoTargetMagicEndListen(event) {
        //停止准备用的音乐
        this.stopEffect();
        this.sendEvent(this.useCardEffect, true);
    },
    /**
     *
     * @param event
     * @constructor
     */
    AreaTargetMagicEndListen: function AreaTargetMagicEndListen(event) {

        //停止准备用的音乐
        this.stopEffect();

        if (this.preUse === true) {
            this.rangeLNode.active = false;
            this.rangeRNode.active = false;
            this.rangeAnimeNode.active = false;

            this.heroScirpt.mana -= this.cardScript.manaConsume;

            this.sendEvent(this.useCardEffect, true);
            this.mScript.useCard(event.getLocationX() + globalConstant.cameraOffset, this.area * globalConstant.unitLength);
        }
    },
    /**
     *
     * @param event
     * @constructor
     */
    DirectionTargetMagicEndListen: function DirectionTargetMagicEndListen(event) {
        // console.log("DirectionTargetMagicEndListen");
        //停止准备用的音乐
        this.stopEffect();
        if (this.preUse === true) {
            this.arrow.active = false;
            this.heroScirpt.mana -= this.cardScript.manaConsume;
            this.sendEvent(this.useCardEffect, true);
            if (globalConstant.cameraOffset === 0) {
                this.mAngle = 360 - Math.atan2(event.getLocationY() - cc.director.getWinSize().height / 2 - (this.arrow.y + this.arrow.parent.y), event.getLocationX() - this.hero.x) * 180 / Math.PI;
            } else if (this.hero.x > cc.director.getWinSize().width * (globalConstant.sceneWidth - globalConstant.sceneEdge)) {
                this.mAngle = 360 - Math.atan2(event.getLocationY() - cc.director.getWinSize().height / 2 - (this.arrow.y + this.arrow.parent.y), event.getLocationX() - this.hero.x + cc.director.getWinSize().width * (globalConstant.sceneWidth - globalConstant.sceneEdge * 2)) * 180 / Math.PI;
            } else {
                this.mAngle = 360 - Math.atan2(event.getLocationY() - cc.director.getWinSize().height / 2 - (this.arrow.y + this.arrow.parent.y), event.getLocationX() - cc.director.getWinSize().width * globalConstant.sceneEdge) * 180 / Math.PI;
            }

            this.mScript.useCard(this.cardId, this.mAngle, this.speed, this.area * globalConstant.unitLength, this.hero.x, this.arrow.y + this.hero.y);
        }
    },

    /**
     * @主要功能 向上级节点传递消息，使之播放音效
     * @author C14
     * @Date 2017/12/12
     * @parameters  audioChip volume fullVolume
     * @returns null
     */
    sendEvent: function sendEvent(audioChip, fullVolume, volume) {
        var eventsend = new cc.Event.EventCustom("playEffect", true);
        if (volume === undefined || volume === null) {
            volume = 1;
        }
        if (fullVolume === undefined || fullVolume === null || fullVolume === false) {
            fullVolume = false;
        } else {
            fullVolume = true;
        }
        eventsend.setUserData({
            effect: audioChip,
            volume: volume,
            fullVolume: fullVolume,
            target: this.node
        });
        this.node.dispatchEvent(eventsend);
    },
    /**
     * @主要功能 停止当前播放的音效
     * @author C14
     * @Date 2017/12/12
     * @parameters null
     * @returns null
     */
    stopEffect: function stopEffect() {
        cc.audioEngine.stopEffect(this.currentEffect);
    },
    // 开启监听的位置，不过嘛，后面还得改，这里先搭个模子，至少保证功能正常
    startListen: function startListen() {
        var self = this;
        //console.log("add listen");
        switch (self.magicType) {
            case 0:
                self.node.on(cc.Node.EventType.MOUSE_DOWN, self.NoTargetMagicStartListen, self);
                self.node.on(cc.Node.EventType.MOUSE_MOVE, self.NoTargetMagicMoveListen, self);
                self.node.on(cc.Node.EventType.MOUSE_UP, self.NoTargetMagicEndListen, self);
                break;
            case 1:
                self.node.on(cc.Node.EventType.MOUSE_DOWN, self.AreaTargetMagicStartListen, self);
                self.node.on(cc.Node.EventType.MOUSE_MOVE, self.AreaTargetMagicMoveListen, self);
                self.node.on(cc.Node.EventType.MOUSE_UP, self.AreaTargetMagicEndListen, self);

                this.rangeLNode = cc.instantiate(this.rangeNode);
                this.rangeRNode = cc.instantiate(this.rangeNode);

                this.rangeLNode.active = false;
                this.rangeRNode.active = false;

                this.rangeLNode.y = -100;
                this.rangeRNode.y = -100;

                this.rangeAnimeNode = cc.instantiate(this.rangeAnimationNode);
                this.rangeAnimeNode.active = false;
                this.rangeAnimeNode.y = -100;

                this.node.parent.parent.addChild(this.rangeAnimeNode);
                this.node.parent.parent.addChild(this.rangeLNode);
                this.node.parent.parent.addChild(this.rangeRNode);

                break;
            case 2:
                self.node.on(cc.Node.EventType.MOUSE_DOWN, self.DirectionTargetMagicStartListen, self);
                self.node.on(cc.Node.EventType.MOUSE_MOVE, self.DirectionTargetMagicMoveListen, self);
                self.node.on(cc.Node.EventType.MOUSE_UP, self.DirectionTargetMagicEndListen, self);

                this.arrow = cc.instantiate(this.arrowNode);
                this.arrow.active = false;
                this.arrow.y = 200;
                this.arrow.x = 0;
                this.hero.addChild(this.arrow);

                break;
        }
    }

});

cc._RF.pop();
},{"Constant":"Constant"}],"MagicNode":[function(require,module,exports){
"use strict";
cc._RF.push(module, '8a8cf+xuLZMwLN3qhMnO1iw', 'MagicNode');
// Script/UI/MagicNode.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {
        progressBar: cc.Node,
        magicNum: cc.Label,
        hero: cc.Node
    },

    // use this for initialization
    update: function update() {
        var script = this.hero.getComponent("Player");
        this.magicNum.string = Math.floor(script.mana).toFixed(0) + '/' + script.maxMana.toFixed(0);
        // this.magicNum.node.x = 90*script.mana - 440;
        // this.progressBar.scaleX = 90*script.mana/744;
        this.progressBar.scaleX = script.mana / 10;
    }

});

cc._RF.pop();
},{}],"MainGameManager":[function(require,module,exports){
"use strict";
cc._RF.push(module, 'a20d5+tWFZJ6aKmZzEYglmk', 'MainGameManager');
// MainBattleScene/Scripts/Manager/MainGameManager.js

'use strict';

//var SmallMap = require('SmallMap');
var globalConstant = require("Constant");
/**
 * @主要功能:  游戏主流程控制器
 * @type {Function}
 */
var MainGameManager = cc.Class({
        extends: cc.Component,

        properties: {
                //各种小兵预制
                creaturePrefab: [cc.Prefab],
                //全部法术预制
                magicPrefab: [cc.Prefab],
                //全部咏唱预制
                chantPrefab: cc.Prefab,
                //生物节点
                creatures: [cc.Node],
                //英雄节点(2个)
                heros: [cc.Node],
                ////逻辑层
                //logicLayer: cc.Node,    //背景节点
                //基地层
                baseLayer: cc.Node,
                //生物层
                creatureLayer: cc.Node,
                //魔法层
                magicLayer: cc.Node,

                //小地图节点
                mapLayer: cc.Node,
                //右下角定时器的节点
                timerLayer: cc.Node,
                //摄像机节点
                cameraLayer: cc.Node,

                audioSource: cc.AudioSource,

                //基地预制
                base: cc.Prefab,
                //左侧玩家
                baseData1: 0,
                //yoo侧玩家
                baseData2: 0,

                baseOffset: 0,

                delay: 0
        },

        onLoad: function onLoad() {

                //获取基地节点，将预制实例化
                var baseNode = cc.instantiate(this.base);
                //获取基地节点的js脚本
                var script1 = baseNode.getComponent('Base');
                var baseNode2 = cc.instantiate(this.base);
                var script2 = baseNode2.getComponent('Base');

                //获取网络脚本
                this.network = this.node.getComponent("network");

                //初始化两个基地坐标，以及注入一些关键数据
                script1.init(this.baseData1, -this.baseOffset, -1);
                script1.hero = this.heros[0].getComponent("Player");
                //基地层添加上述节点
                this.baseLayer.addChild(baseNode);
                script2.init(this.baseData2, this.baseOffset, 1);
                script2.hero = this.heros[1].getComponent("Player");
                this.baseLayer.addChild(baseNode2);

                //碰撞系统打开
                cc.director.getCollisionManager().enabled = true;

                //获取小地图脚本
                var mapScript = this.mapLayer.getComponent("SmallMap");
                //英雄标记中添加两个英雄节点（方便坐标获取）
                mapScript.fnCreateHeroSign(this.heros[0]);
                mapScript.fnCreateHeroSign(this.heros[1]);

                //获取时间记录器脚本，此脚本负责自动推进时间轴
                this.timerLayerScript = this.timerLayer.getComponent("GameTimer");

                //每隔一段时间召唤一个小怪
                //this.schedule(function() {
                //    var eventsend = new cc.Event.EventCustom('creatureCreate',true);
                //    eventsend.setUserData({X:(cc.director.getWinSize().width * globalConstant.sceneWidth),Y:null,attack:2,health:10,team:1,velocity:3,id:1});
                //
                //    this.node.dispatchEvent(eventsend);
                //},2);

                //创建npc 小地图节点 事件
                this.node.on('creatureCreate', this.creatureCreate, this);
                //创建咏唱法术事件
                this.node.on('chantCreate', this.chantCreate, this);
                //英雄死亡事件
                this.node.on('heroDeath', this.heroDeath, this);
                //魔法创建事件
                this.node.on('magicCreate', this.magicCreate, this);
                //游戏是否获胜事件
                this.node.on('isWin', this.isWin, this);
                //音效播放事件
                this.node.on('playEffect', this.playEffect, this);
        },

        /**
         * @主要功能 判断胜利，胜利就返回到初始场景中
         * @author C14
         * @Date 2017/11/19
         * @parameters
         * @returns
         */
        isWin: function isWin(event) {
                //this.current = cc.audioEngine.play(this.audio, false, 1);
                //this.audio.schedule(back());
                //var back = function(){
                cc.director.loadScene("MainScene");
                //}
        },

        /**
         * @主要功能 负责处理传输上来的音效，直接播放
         * @author C14
         * @Date 2018/1/2
         * @parameters
         * @returns
         */
        playEffect: function playEffect(event) {
                var volume = 1;
                if (event.detail.fullVolume === false) {
                        if (Math.abs(this.cameraLayer.x - event.detail.target.x) < globalConstant.sceneWidth * cc.director.getWinSize().width / 2) {
                                volume = 1 - Math.abs(this.cameraLayer.x - event.detail.target.x) / (globalConstant.sceneWidth * cc.director.getWinSize().width / 2);
                        } else {
                                volume = 0;
                        }
                }
                //播放音效
                //cc.audioEngine.playEffect(event.detail.effect,false,event.detail.volume * volume);
        },

        /**
         * @主要功能 英雄死亡后运行一个定时器，即，复活英雄
         * @author C14
         * @Date 2017/12/20
         * @parameters
         * @returns
         */
        heroDeath: function heroDeath(event) {
                //让Y坐标下去
                event.detail.heroScript.node.y = -1000;
                //定时器，死亡次数越多复活需要越长的时间
                this.scheduleOnce(function () {
                        //复活的x坐标根据队伍而选择左右
                        event.detail.heroScript.node.x = cc.director.getWinSize().width * globalConstant.sceneWidth / 2 + cc.director.getWinSize().width * globalConstant.sceneWidth / 2 * event.detail.heroScript.team;
                        //运行英雄内部的复活接口
                        event.detail.heroScript.relive();
                }, 8 * event.detail.heroScript.deathTimes);
                event.detail.heroScript.node.opacity = 0;
                event.stopPropagation();
        },

        /**
         * @主要功能:  创建法术
         *              建议以后改用资源池获取节点   资源池使用工厂创建节点，这里可以负责初始化节点属性
         * @author C14
         * @Date 2017/11/01 13:04
         * @param event
         */
        magicCreate: function magicCreate(event) {
                //event为父类事件  实际这里是Event.EventCustom子类
                this.network.roomMsg('roomChat', { name: "magicCreate", detail: event.detail });
                //kenan 实验证明  事件是同步的  计时器是异步的
                // this.scheduleOnce(function() {

                /** kenan 这里获取npc的资源方法可以改为，使用资源池获取npc节点*/
                var mag = cc.instantiate(this.magicPrefab[event.detail.id]);
                var magScript = mag.getComponent('Magic' + event.detail.id);

                //       magScript.fnCreateMagic(event.detail);//初始化npc属性
                mag.x = event.detail.position;
                if (event.detail.y === null) {
                        mag.y = globalConstant.magicY;
                } else {
                        mag.y = event.detail.y;
                }
                this.magicLayer.addChild(mag);
                magScript.initMagic(event.detail);
                //停止事件冒泡(停止继续向上传递此事件)
                event.stopPropagation();
        },
        /**
         * @主要功能    网络模块调用此代码
         *               创建其他人的法术
         * @author C14
         * @Date 2018/1/9
         * @parameters
         * @returns
         */
        magicCreateNetwork: function magicCreateNetwork(data) {
                /** kenan 这里获取npc的资源方法可以改为，使用资源池获取npc节点*/
                var mag = cc.instantiate(this.magicPrefab[data.id]);
                var magScript = mag.getComponent('Magic' + data.id);

                // magScript.fnCreateMagic(event.detail);//初始化npc属性
                mag.x = data.position;
                if (data.y === null) {
                        mag.y = globalConstant.magicY;
                } else {
                        mag.y = data.y;
                }
                this.magicLayer.addChild(mag);
                magScript.initMagic(data);
        },

        /**
         * @主要功能:  创建生物节点
         *              建议以后改用资源池获取节点   资源池使用工厂创建节点，这里可以负责初始化节点属性
         * @author kenan
         * @Date 2017/7/23 0:25
         * @param event
         */
        creatureCreate: function creatureCreate(data) {
                //event为父类事件  实际这里是Event.EventCustom子类

                this.network.roomMsg('roomChat', { name: "creatureCreate", detail: data.detail });
                //kenan 实验证明  事件是同步的  计时器是异步的
                // this.scheduleOnce(function() {
                /** kenan 这里获取npc的资源方法可以改为，使用资源池获取npc节点*/
                var npc = cc.instantiate(this.creaturePrefab[data.detail.id]);
                var npcScript = npc.getComponent("Creature");

                var mapScript = this.mapLayer.getComponent("SmallMap");

                var detail = data.detail;
                detail.Y = detail.Y === null ? globalConstant.summonY : detail.Y;

                npcScript.fnGetManager(this);

                this.creatures.push(npc);

                mapScript.fnCreateCreatureSign(this.creatures[this.creatures.length - 1]);
                npcScript.fnCreateCreature(detail); //初始化npc属性
                this.creatureLayer.addChild(this.creatures[this.creatures.length - 1]);

                //kenan 停止事件冒泡   (停止继续向上传递此事件)
                data.stopPropagation();

                // console.log("creatureCreate结束");

                // });
        },
        /**
         * @主要功能    网络模块调用此代码
         *               创建其他人的生物
         * @author C14
         * @Date 2018/1/9
         * @parameters
         * @returns
         */
        creatureCreateNetwork: function creatureCreateNetwork(data) {
                //kenan 实验证明  事件是同步的  计时器是异步的
                // this.scheduleOnce(function() {
                /** kenan 这里获取npc的资源方法可以改为，使用资源池获取npc节点*/
                var npc = cc.instantiate(this.creaturePrefab[data.id]);
                var npcScript = npc.getComponent("Creature");

                var mapScript = this.mapLayer.getComponent("SmallMap");

                var detail = data;
                detail.Y = detail.Y === null ? globalConstant.summonY : detail.Y;

                npcScript.fnGetManager(this);

                this.creatures.push(npc);

                mapScript.fnCreateCreatureSign(this.creatures[this.creatures.length - 1]);
                npcScript.fnCreateCreature(detail); //初始化npc属性
                this.creatureLayer.addChild(this.creatures[this.creatures.length - 1]);
        },
        /**
         * @主要功能:  创建吟唱
         *              建议以后改用资源池获取节点   资源池使用工厂创建节点，这里可以负责初始化节点属性
         * @author C14
         * @Date 2017/11/17 20:03
         * @param event
         */
        chantCreate: function chantCreate(event) {
                //event为父类事件  实际这里是Event.EventCustom子类
                this.network.roomMsg('roomChat', { name: "chantCreate", detail: event.detail });

                /** kenan 这里获取npc的资源方法可以改为，使用资源池获取npc节点*/
                var chantMag = cc.instantiate(this.chantPrefab);
                var chantMagScript = chantMag.getComponent('Chant');

                chantMagScript.percent = this.timerLayerScript.timer / this.timerLayerScript.maxTimer;
                chantMagScript.fnInitChant(event.detail);
                this.timerLayer.addChild(chantMag);
                //       magScript.fnCreateMagic(event.detail);//初始化npc属性


                //kenan 停止事件冒泡   (停止继续向上传递此事件)
                event.stopPropagation();

                // console.log("creatureCreate结束");

                // });
        },
        /**
         * @主要功能    网络模块调用此代码
         *               创建其他人的咏唱法术
         * @author C14
         * @Date 2018/1/9
         * @parameters
         * @returns
         */
        chantCreateNetwork: function chantCreateNetwork(data) {
                //event为父类事件  实际这里是Event.EventCustom子类

                //kenan 实验证明  事件是同步的  计时器是异步的
                // this.scheduleOnce(function() {

                /** kenan 这里获取npc的资源方法可以改为，使用资源池获取npc节点*/
                var chantMag = cc.instantiate(this.chantPrefab);
                var chantMagScript = chantMag.getComponent('Chant');

                //       magScript.fnCreateMagic(event.detail);//初始化npc属性
                chantMagScript.percent = this.timerLayerScript.timer / this.timerLayerScript.maxTimer;
                chantMagScript.fnInitChant(data);
                this.timerLayer.addChild(chantMag);
        },
        /**
         * @主要功能 调整敌人的血量，速度方向，X坐标
         * @author C14
         * @Date 2018/1/9
         * @parameters
         * @returns
         */
        changeEnemyMove: function changeEnemyMove(data) {
                var script = this.heros[1].getComponent("Player");
                this.heros[1].x = data.x;
                script.accLeft = data.accLeft;
                script.accRight = data.accRight;
                script.health = data.health;
        },

        /**
         * @主要功能: 释放小兵节点
         *          建议使用资源池回收节点
         * @param node
         */
        removeCreature: function removeCreature(node) {
                var i = 0;
                var script = node.getComponent('Creature');
                var mapScript = this.mapLayer.getComponent('SmallMap');
                mapScript.fnDeleteSign(node);
                for (i = 0; i < this.creatures.length; i++) {
                        if (this.creatures[i] === node) {

                                //this.creatures[i].removeFromParent();
                                this.creatures.splice(i, 1);
                        }
                }

                //kenan 因为没有回收池  这里需要释放资源
                //        node.destroy();
        }

});

cc._RF.pop();
},{"Constant":"Constant"}],"MainSceneManager":[function(require,module,exports){
"use strict";
cc._RF.push(module, '98b4eiaEo5PHLEFB7jZowM3', 'MainSceneManager');
// MainScene/Scripts/MainSceneManager.js

'use strict';

//此组件挂载于SceneManager。用于储存各种数据，以及组件，便于取用与管理
var Global = require('Global');
cc.Class({
    extends: cc.Component,

    properties: {

        //玩家的金币数量
        coin: 0,

        //玩家的灵魂(类似粉尘)数量
        soul: 0,

        //玩家可以打开的卡牌包数量
        bags: 0,

        //生物卡片预览用的预制
        miniCreaturePrefab: [cc.Prefab],

        //魔法卡片预览用的预制
        miniMagicPrefab: [cc.Prefab],

        //玩家现在拥有的卡
        myCCards: [cc.Integer],

        myMCards: [cc.Integer],

        deckBuildPrefab: cc.Prefab,

        //一个卡组的数据
        //totalDeckData: [Global.totalDeckData.type],
        //玩家现在在组的卡组的组成
        myMDeck: {
            default: [],
            type: cc.Integer
        },
        myCDeck: {
            default: [],
            type: cc.Integer
        },

        showMPrefab: {
            default: [],
            type: cc.Prefab
        },

        showCPrefab: {
            default: [],
            type: cc.Prefab
        },

        //筛选类型，三种，分别是 正营，稀有度，法力消耗
        filterType: {
            default: [],
            type: cc.Integer
        },

        maxDeckNum: 0,

        cardList: cc.Node
    },
    filterTypeSelect: function filterTypeSelect(event, customEventData) {
        this.filterType[customEventData[0] - '0'] = customEventData[1] - '0';
        this.cardListScript.renewShowCardGroup();
        cc.log(this.filterType);
    },
    // use this for initialization
    onLoad: function onLoad() {
        //var deckDatas = Global.deckData;
        //deckDatas.magicDeck = [1,2,3];
        var deckDatas = {
            name: "我的卡组",
            num: 0,
            magicDeck: {
                default: [],
                type: cc.Integer
            },
            creatureDeck: {
                default: [],
                type: cc.Integer
            },
            //卡组的类型
            type: {
                type: cc.Enum({
                    //幻想
                    //科学
                    Science: 0,
                    Fantasy: 1,
                    //混沌
                    Chaos: 2
                }),
                default: 0
            },
            usable: true
        };

        this.cardListScript = this.cardList.getComponent('CardList');
        Global.totalDeckData.push(deckDatas);
        Global.totalDeckData[Global.deckUsage].magicDeck = this.myMDeck;
        Global.totalDeckData[Global.deckUsage].creatureDeck = this.myCDeck;
    }

});

cc._RF.pop();
},{"Global":"Global"}],"MiniCard":[function(require,module,exports){
"use strict";
cc._RF.push(module, '11e0fJ4fnlCWp7SnkjNAD7M', 'MiniCard');
// MainScene/Scripts/MiniCard.js

'use strict';

cc.Class({
    extends: cc.Component,

    properties: {
        //魔法消耗
        manaConsume: 0,
        //魔法消耗标签
        manaConsumeLabel: cc.Label,

        //卡片类型
        cardType: 0, //0法术牌；1生物牌 
        //卡片ID
        cardId: 0,

        //稀有度
        rarity: {
            type: cc.Enum({
                N: 0,
                R: 1,
                SR: 2,
                SSR: 3
            }),
            default: 0
        },

        //张数
        num: 0,
        //张数标签
        numLabel: cc.Label,

        //卡片名称
        cName: cc.String,
        //卡片名称的标签
        cNameLabel: cc.Label
    },

    // use this for initialization
    onLoad: function onLoad() {
        this.init();
    },

    init: function init() {
        var self = this;
        self.manaConsumeLabel.string = self.manaConsume;
        self.numLabel.string = 'X' + self.num;
        self.cNameLabel.string = self.cName;
        this.initMouseEvent();
    },

    adjustCount: function adjustCount(num) {
        this.num = num;
        this.numLabel.string = 'X' + num;
    },

    initMouseEvent: function initMouseEvent() {
        var newInfoBoard = null;
        this.node.on(cc.Node.EventType.MOUSE_ENTER, this.showInfo, this);
        this.node.on(cc.Node.EventType.MOUSE_LEAVE, this.cleanInfo, this);
        this.node.on(cc.Node.EventType.MOUSE_UP, this.addCardtoDeck, this);
    },
    showInfo: function showInfo() {
        var eventsend = new cc.Event.EventCustom('whenMouseEnterTheMiniCard', true);
        eventsend.setUserData({ id: this.cardId, typeId: this.cardType, count: this.num, cardScript: this });
        this.node.dispatchEvent(eventsend);
        cc.log('MouseEnterTheMiniCard');
    },
    cleanInfo: function cleanInfo() {
        var eventsend = new cc.Event.EventCustom('whenMouseLeaveTheMiniCard', true);
        this.node.dispatchEvent(eventsend);
        cc.log('MouseLeaveTheMiniCard');
    },
    addCardtoDeck: function addCardtoDeck() {
        var eventsend = new cc.Event.EventCustom('whenMouseUpTheMiniCard', true);
        eventsend.setUserData({
            id: this.cardId,
            typeId: this.cardType,
            cName: this.cName,
            manaConsume: this.manaConsume,
            num: this.num,
            cardScript: this
        });
        cc.log('MouseUpTheMiniCard');
        this.node.dispatchEvent(eventsend);
    }
    // called every frame, uncomment this function to activate update callback
    // update: function (dt) {

    // },
});

cc._RF.pop();
},{}],"OpenCardManager":[function(require,module,exports){
"use strict";
cc._RF.push(module, '600c5l5QJ9PG6rLNm5z7J9B', 'OpenCardManager');
// MainScene/Scripts/OpenCardManager.js

'use strict';

var Global = require('Global');

cc.Class({
    extends: cc.Component,

    properties: {

        mainSceneManager: cc.Node,
        cardBagNumLabel: cc.Label,
        cardOutLayout: cc.Node
        // foo: {
        //    default: null,      // The default value will be used only when the component attaching
        //                           to a node for the first time
        //    url: cc.Texture2D,  // optional, default is typeof default
        //    serializable: true, // optional, default is true
        //    visible: true,      // optional, default is true
        //    displayName: 'Foo', // optional
        //    readonly: false,    // optional, default is false
        // },
        // ...
    },

    // use this for initialization
    onLoad: function onLoad() {
        this.mainSceneScript = this.mainSceneManager.getComponent("MainSceneManager");
        this.renewBags();
    },
    /**
     * @��Ҫ���� ����һ������
     * @author C14
     * @Date 2017/12/21
     * @parameters
     * @returns
     */
    openBag: function openBag() {
        var rand = 0;
        var card = null;
        var dat = 0;
        this.cardOutLayout.removeAllChildren();
        if (this.mainSceneScript.bags > 0) {
            this.mainSceneScript.bags--;
            this.renewBags();
            for (var i = 0; i < 5; i++) {
                rand = this.randomCard();
                if (rand < this.mainSceneScript.miniMagicPrefab.length) {
                    this.mainSceneScript.myMCards[rand]++;
                    card = cc.instantiate(this.mainSceneScript.miniMagicPrefab[rand]);
                    this.cardOutLayout.addChild(card);
                } else {

                    dat = rand - this.mainSceneScript.miniMagicPrefab.length;
                    cc.log(dat);
                    this.mainSceneScript.myCCards[dat]++;
                    var card2 = cc.instantiate(this.mainSceneScript.miniCreaturePrefab[dat]);
                    this.cardOutLayout.addChild(card2);
                }
            }
        }
    },

    /**
     * @��Ҫ���� ����һ��������
     * @author C14
     * @Date 2017/12/21
     * @parameters
     * @returns
     */
    randomCard: function randomCard() {
        var num = 0;
        num = Math.floor(Math.random() * (this.mainSceneScript.miniMagicPrefab.length + this.mainSceneScript.miniCreaturePrefab.length));
        return num;
    },
    /**
     * @��Ҫ���� ����10����
     * @author C14
     * @Date 2017/12/21
     * @parameters
     * @returns
     */
    addBags: function addBags() {
        this.mainSceneScript.bags += 10;
        this.renewBags();
    },
    renewBags: function renewBags() {
        this.cardBagNumLabel.string = 'bags:' + this.mainSceneScript.bags;
    }
    // called every frame, uncomment this function to activate update callback
    // update: function (dt) {

    // },
});

cc._RF.pop();
},{"Global":"Global"}],"Player":[function(require,module,exports){
"use strict";
cc._RF.push(module, '6f0721iBntJLa146f4bRZsP', 'Player');
// Script/Player.js

"use strict";

var globalConstant = require("Constant");

cc.Class({
    extends: cc.Component,

    properties: {

        // 主角跳跃高度
        jumpHeight: 0,
        // 主角跳跃持续时间
        jumpDuration: 0,
        // 最大移动速度
        maxMoveSpeed: 0,
        // 射出子弹
        launchButton: cc.Prefab,
        //生命值
        health: 0,
        //生命值
        maxHealth: 0,
        //生命值标签
        healthLabel: cc.Label,
        //单位
        body: cc.Node,
        //蓝恢复速度
        manaRecoverSpeedK: 0,
        //最大蓝量
        maxMana: 0,
        //耗蓝
        manaUse: 0,
        //队伍
        team: 0,
        //死亡
        death: false,

        //自我
        self: true,
        //是否使AI
        ai: false,
        //能否移动
        movable: true,

        mainGameManager: cc.Node,
        gameManager: cc.Node,
        cameraControl: cc.Node,

        drawCardNode: cc.Node,
        //英雄的手牌
        handCard: [cc.Node]
    },
    // use this for initialization
    onLoad: function onLoad() {

        this.drawCardScript = this.drawCardNode.getComponent("DrawCard");

        this.networkScript = this.mainGameManager.getComponent("network");
        // 初始化跳跃动作
        this.jumpAction = this.setJumpAction();
        //this.node.runAction(this.jumpAction);
        this.cameraControlScript = this.cameraControl.getComponent('CameraControl');

        this.deathTimes = 0;
        // 加速度方向开关
        this.accLeft = false;
        this.accRight = false;
        // 主角当前水平方向速度
        this.xSpeed = 0;
        this.isCanJump = true;

        if (this.ai === true) {
            this.schedule(function () {
                this.accLeft = true;
                this.accRight = false;
            }, 2);
            this.schedule(function () {
                this.accLeft = false;
                this.accRight = true;
            }, 3);
        }

        //初始蓝
        this.mana = 0;
        if (this.self === true) {
            // 初始化键盘输入监听
            this.setInputControl();
            //this._pool = new cc.NodePool('PoolHandler');
        }
    },
    //抽取X张牌
    drawCard: function drawCard(x) {
        //抽牌循环
        for (var i = 0; i < x; i++) {
            this.drawCardScript.creatCardType();
        }
    },
    update: function update(dt) {
        //处理X轴的速度
        if (this.accLeft === this.accRight) {
            //左右键同时按或不按，则不动
            this.xSpeed = 0;
        } else if (this.accLeft === true) {
            this.body.scaleX = -1;
            this.xSpeed = -this.maxMoveSpeed; //向左
            if (this.self === true) this.cameraControlScript.target = this.cameraControlScript.targets[0];
        } else if (this.accRight === true) {
            this.body.scaleX = 1;
            this.xSpeed = this.maxMoveSpeed; //向右
            if (this.self === true) this.cameraControlScript.target = this.cameraControlScript.targets[0];
        }
        if (0 > this.node.x) {
            this.node.x = 0;
        }
        if (this.node.x > cc.director.getWinSize().width * globalConstant.sceneWidth) {
            this.node.x = cc.director.getWinSize().width * globalConstant.sceneWidth;
        }
        if (this.death === false && 0 <= this.node.x && this.node.x <= cc.director.getWinSize().width * globalConstant.sceneWidth) {
            // 根据当前速度更新主角的位置
            this.node.x += this.xSpeed;
        }

        if (this.mana < this.maxMana) {
            this.mana += this.manaRecoverSpeedK * Math.sqrt(1 - this.mana / this.maxMana) * dt;
        } else {
            this.mana = this.maxMana;
        }

        this.healthLabel.string = this.health.toFixed(0);
        //this.manaBar.progress = this.mana / this.maxMana;
        //this.manaLabel.string = this.mana.toFixed(0) + "/" + this.maxMana.toFixed(0);
    },

    setJumpAction: function setJumpAction() {
        var jumpUp = cc.moveBy(this.jumpDuration, cc.p(0, this.jumpHeight)).easing(cc.easeCubicActionOut());
        var jumpDown = cc.moveBy(this.jumpDuration, cc.p(0, -this.jumpHeight)).easing(cc.easeCubicActionIn());

        return cc.repeatForever(cc.sequence(jumpUp, jumpDown));
    },

    onceJumpAciton: function onceJumpAciton() {
        var self = this;
        var jumpUp = cc.moveBy(self.jumpDuration, cc.p(0, self.jumpHeight)).easing(cc.easeCubicActionOut());
        var jumpDown = cc.moveBy(self.jumpDuration, cc.p(0, -self.jumpHeight)).easing(cc.easeCubicActionIn());

        self.node.runAction(cc.sequence(jumpUp, jumpDown, cc.callFunc(function () {
            self.isCanJump = true;
        })));
    },

    changeHealth: function changeHealth(value) {
        if (this.health + value > 0) {
            this.health = this.health + value;
        } else if (this.death === false) {
            this.health = 0;
            this.death = true;
        }
        return this.death;
    },

    releaseTarget: function releaseTarget() {
        if (this.deathTimes < 3) {
            this.deathTimes++;
        }

        var eventsend = new cc.Event.EventCustom('heroDeath', true);
        eventsend.setUserData({ heroScript: this });
        this.node.dispatchEvent(eventsend);
    },
    //复活英雄
    relive: function relive() {
        //Y坐标为 -85
        this.node.y = -85;
        //透明度
        this.node.opacity = 1000;
        this.health = this.maxHealth;
        this.death = false;
    },

    sendMoveMessage: function sendMoveMessage() {
        var self = this;
        self.networkScript.roomMsg('roomChat', {
            name: "enemyMove",
            detail: {
                accLeft: self.accLeft,
                accRight: self.accRight,
                health: self.health,
                x: self.node.x
            }
        });
    },
    setInputControl: function setInputControl() {
        var self = this;
        // 添加键盘事件监听
        cc.eventManager.addListener({
            event: cc.EventListener.KEYBOARD,
            // 有按键按下时，判断是否是我们指定的方向控制键，并设置向对应方向加速
            onKeyPressed: function onKeyPressed(keyCode, event) {
                switch (keyCode) {
                    case cc.KEY.a:
                    case cc.KEY.left:
                        //cc.log(self.death);
                        self.accLeft = true;
                        self.sendMoveMessage();
                        cc.log(self.node.x + "X坐标，Y坐标：" + self.node.y + "透明" + self.node.opacity);
                        // self.accRight = false;
                        break;
                    case cc.KEY.d:
                    case cc.KEY.right:
                        // self.accLeft = false;
                        self.accRight = true;
                        self.sendMoveMessage();
                        break;
                    case cc.KEY.w:
                    case cc.KEY.up:
                        if (self.isCanJump) {
                            self.isCanJump = false;
                            self.onceJumpAciton();
                        }
                        break;
                    case cc.KEY.j:
                    case cc.KEY.z:
                        if (self.mana >= self.manaUse) {
                            self.mana -= self.manaUse;
                            self.generateNode();
                        }
                        break;
                }
            },
            // 松开按键时，停止向该方向的加速
            onKeyReleased: function onKeyReleased(keyCode, event) {
                switch (keyCode) {
                    case cc.KEY.a:
                    case cc.KEY.left:
                        self.accLeft = false;
                        self.sendMoveMessage();
                        break;
                    case cc.KEY.d:
                    case cc.KEY.right:
                        self.accRight = false;
                        self.sendMoveMessage();
                        break;
                }
            }
        }, self.node);
    },

    // 判断魔法是否足够
    checkMana: function checkMana(cost) {
        var self = this;
        return cost <= self.mana;
    },

    generateNode: function generateNode() {
        var monster = this._pool.get();
        if (!monster) {
            monster = cc.instantiate(this.launchButton);

            // Add pool handler component which will control the touch event
            monster.addComponent('PoolHandler');
        }
        monster.x = this.node.x;
        monster.y = this.node.y;

        var dx = monster.getComponent('Fire').flyDistance * this.body.scaleX;
        var dy = 0;

        console.log(dx, dy);

        monster.runAction(cc.sequence(cc.moveBy(monster.getComponent('Fire').flyDistance / monster.getComponent('Fire').flySpeed, dx, dy), cc.callFunc(this.removeNode, this, monster)));

        this.node.parent.addChild(monster);
    },

    removeNode: function removeNode(sender, monster) {
        this._pool.put(monster);
    }

    // called every frame, uncomment this function to activate update callback

});

cc._RF.pop();
},{"Constant":"Constant"}],"PoolHandler":[function(require,module,exports){
"use strict";
cc._RF.push(module, 'ed1a3Xfn2xGzoNoFkEuwqYr', 'PoolHandler');
// MainBattleScene/Scripts/Class/PoolHandler.js

"use strict";

function pauseresume() {
    if (this.paused) {
        cc.director.getActionManager().resumeTarget(this);
    } else {
        cc.director.getActionManager().pauseTarget(this);
    }
    this.paused = !this.paused;
}

cc.Class({
    extends: cc.Component,

    properties: {},

    onLoad: function onLoad() {
        this.node.paused = false;
        this.node.on(cc.Node.EventType.TOUCH_END, pauseresume, this.node);
    },

    unuse: function unuse() {
        this.node.off(cc.Node.EventType.TOUCH_END, pauseresume, this.node);
    },

    reuse: function reuse() {
        this.node.on(cc.Node.EventType.TOUCH_END, pauseresume, this.node);
    }
});

cc._RF.pop();
},{}],"SelectMenuManager":[function(require,module,exports){
"use strict";
cc._RF.push(module, '585d8u27OVA8LLEiFPvr5q+', 'SelectMenuManager');
// MainScene/Scripts/SelectMenuManager.js

'use strict';

cc.Class({
    extends: cc.Component,

    properties: {
        selectMenuKind: {
            default: null,
            type: cc.Label
        },
        selectMenuList: {
            default: null,
            type: cc.Node
        },
        selectMenuButton: {
            default: null,
            type: cc.Button
        }
    },
    callback: function callback(event, customEventData) {
        switch (customEventData) {
            case 'total':
                this.selectMenuList.active = false;
                this.selectMenuKind.string = "所有阵营";break;
            case 'science':
                this.selectMenuList.active = false;
                this.selectMenuKind.string = "科学";break;
            case 'fantasy':
                this.selectMenuList.active = false;
                this.selectMenuKind.string = "幻想";break;
            case 'chaos':
                this.selectMenuList.active = false;
                this.selectMenuKind.string = "混沌";break;
            case 'neutrality':
                this.selectMenuList.active = false;
                this.selectMenuKind.string = "中立";break;
            default:
                break;
        }
    },
    rareSelect: function rareSelect(event, customEventData) {
        switch (customEventData) {
            case 'total':
                this.selectMenuList.active = false;
                this.selectMenuKind.string = "全部";break;
            case 'N':
                this.selectMenuList.active = false;
                this.selectMenuKind.string = "N";break;
            case 'R':
                this.selectMenuList.active = false;
                this.selectMenuKind.string = "R";break;
            case 'SR':
                this.selectMenuList.active = false;
                this.selectMenuKind.string = "SR";break;
            case 'SSR':
                this.selectMenuList.active = false;
                this.selectMenuKind.string = "SSR";break;
            default:
                break;
        }
    },
    consumeSelect: function consumeSelect(event, customEventData) {
        if (customEventData === 'total') {
            this.selectMenuList.active = false;
            this.selectMenuKind.string = "所有消耗";
        } else {
            this.selectMenuList.active = false;
            this.selectMenuKind.string = "" + customEventData;
        }
    },
    // use this for initialization
    onLoad: function onLoad() {
        this.selectMenuList.active = false;
    },
    showSelectMenuList: function showSelectMenuList() {
        this.selectMenuList.active = true;
        //this.selectMenuListOperation(this.occupationList);
        this.hideSelectMenuList(this.selectMenuList);
        //this.pickSelectMenuItem(this.occupationList);
    },
    //function stopAction() {
    //    this.selectMenuList.active = false;
    //}
    hideSelectMenuList: function hideSelectMenuList(selectBoard) {
        selectBoard.on(cc.Node.EventType.MOUSE_LEAVE, hideSelectBoard, this);
        function hideSelectBoard() {
            selectBoard.active = false;
        }
    }

});

cc._RF.pop();
},{}],"SignScript":[function(require,module,exports){
"use strict";
cc._RF.push(module, '57e120wGA5AzpHtOSCP0Pmu', 'SignScript');
// Script/Prefab/others/SignScript.js

'use strict';

var globalConstant = require("Constant");
cc.Class({
    extends: cc.Component,

    properties: {
        creature: cc.Node,
        attack: cc.Label,
        health: cc.Label,
        script: null,
        //�ж������� hero creature
        nodeType: {
            type: cc.Enum({
                Creature: 0,
                Hero: 1,
                Base: 2
            }),
            default: 0
        },

        signState: 0,
        signNode: [cc.Node]
    },

    // use this for initialization
    onLoad: function onLoad() {
        this.node.y = -16;
    },
    fnGiveNode: function fnGiveNode(node) {
        this.creature = node;
        this.node.x = this.creature.x / (cc.director.getWinSize().width * 3) * globalConstant.smallMapLength;
        if (this.nodeType === 0) {
            this.script = this.creature.getComponent('Creature');
        } else if (this.nodeType === 1) {
            this.script = this.creature.getComponent('Player');
        } else {}
    },
    fnRenewSign: function fnRenewSign() {
        this.node.x = this.creature.x / (cc.director.getWinSize().width * 3) * globalConstant.smallMapLength;
        this.attack.string = this.script.attack;
        this.health.string = this.script.health;
        for (var i = 0; i < this.signNode.length; i++) {
            if (this.signState === i) {
                this.signNode[i].active = true;
            } else {
                this.signNode[i].active = false;
            }
        }
    },
    renewTeam: function renewTeam() {
        if (this.nodeType === 0) {
            if (this.script.team < 0) {
                this.signState = 0;
            } else if (this.script.team > 0) {
                this.signState = 1;
            } else {}
        } else {
            if (this.script.team < 0) {
                if (this.script.death === true) {
                    this.signState = 4;
                } else {
                    this.signState = 2;
                }
            } else if (this.script.team > 0) {
                if (this.script.death === true) {
                    this.signState = 5;
                } else {
                    this.signState = 3;
                }
            } else {}
        }
    },
    removeSign: function removeSign() {
        this.node.removeFromParent();
        this.node.active = false;
    },

    // called every frame, uncomment this function to activate update callback
    update: function update(dt) {
        this.renewTeam();
        this.fnRenewSign();
    }

});

cc._RF.pop();
},{"Constant":"Constant"}],"SmallMap":[function(require,module,exports){
"use strict";
cc._RF.push(module, '69448xNL5hApKl47epOKXkz', 'SmallMap');
// Script/UI/SmallMap.js

'use strict';

/**
 * @主要功能:   小地图类
 * @type {Function}
 */
var smallMap = cc.Class({
    extends: cc.Component,

    properties: {
        signs: [cc.Node],
        signPrefab: [cc.Prefab],
        //小地图标识0：蓝色 属于小于0的阵营
        //小地图标识1：红色 属于大于0的阵营
        data: cc.Node,
        script: null
    },

    onLoad: function onLoad() {
        this.script = this.data.getComponent('MainGameManager');
    },

    /**
     * @主要功能:  创建小地图标记节点
     * @param node
     */
    fnCreateCreatureSign: function fnCreateCreatureSign(node) {
        //借用一个node来创建一个小兵标记，将Node绑定在预制资源中
        var script = node.getComponent('Creature');
        var newsign;

        newsign = cc.instantiate(this.signPrefab[0]);
        var signScript = newsign.getComponent('SignScript');

        signScript.nodeType = 0;
        signScript.fnGiveNode(node);

        this.signs.push(newsign);
        this.node.addChild(this.signs[this.signs.length - 1]);
    },
    fnCreateHeroSign: function fnCreateHeroSign(node) {
        //借用一个node来创建一个小兵标记，将Node绑定在预制资源中
        var script = node.getComponent('Player');
        var newsign;

        newsign = cc.instantiate(this.signPrefab[0]);
        var signScript = newsign.getComponent('SignScript');

        signScript.nodeType = 1;
        signScript.fnGiveNode(node);

        this.signs.push(newsign);
        this.node.addChild(this.signs[this.signs.length - 1]);
    },

    /**
     * @主要功能: 释放小兵节点
     *          建议使用资源池回收节点
     * @param node
     */
    fnDeleteSign: function fnDeleteSign(node) {
        var i, script;
        for (i = 0; i < this.signs.length; i++) {
            script = this.signs[i].getComponent('SignScript');
            if (script.creature === node) {
                this.node.removeChild(this.signs[i], true);
                this.signs[i].active = false;
                this.signs.splice(i, 1);
                script.removeSign();
                break;
            }
        }

        //kenan 因为没有回收池  这里需要释放资源
        //node.destroy();
    }

});

cc._RF.pop();
},{}],"StoreButton":[function(require,module,exports){
"use strict";
cc._RF.push(module, '00202t/+/tFqahaXy6jm9oL', 'StoreButton');
// MainScene/Scripts/StoreButton.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {
        storeNode: cc.Node
    },

    openStore: function openStore() {
        this.storeNode.active = true;
    },
    // use this for initialization
    onLoad: function onLoad() {}

    // called every frame, uncomment this function to activate update callback
    // update: function (dt) {

    // },
});

cc._RF.pop();
},{}],"StoreCloseButton":[function(require,module,exports){
"use strict";
cc._RF.push(module, '6b66b2DN/JMZ6QN5dZMrMMz', 'StoreCloseButton');
// MainScene/Scripts/StoreCloseButton.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {
        storeNode: cc.Node
        // foo: {
        //    default: null,      // The default value will be used only when the component attaching
        //                           to a node for the first time
        //    url: cc.Texture2D,  // optional, default is typeof default
        //    serializable: true, // optional, default is true
        //    visible: true,      // optional, default is true
        //    displayName: 'Foo', // optional
        //    readonly: false,    // optional, default is false
        // },
        // ...
    },

    closeStore: function closeStore() {
        this.storeNode.active = false;
    },
    // use this for initialization
    onLoad: function onLoad() {}

    // called every frame, uncomment this function to activate update callback
    // update: function (dt) {

    // },
});

cc._RF.pop();
},{}],"StoreManager":[function(require,module,exports){
"use strict";
cc._RF.push(module, 'a2464OvF+9MTIK1o0G3TOqF', 'StoreManager');
// MainScene/Scripts/Store/StoreManager.js

"use strict";

var global = require("Global");
var globalConstant = require("Constant");
cc.Class({
    extends: cc.Component,

    properties: {

        purchaseButton: [cc.Node],
        purchaseNumLabel: cc.EditBox,
        //显示用的所需金币
        needMoney: 0,
        needMoneyLabel: cc.Label,
        needMoneyStoryLabel: cc.Label,
        massage: cc.Label,
        massageNode: cc.Node,
        //故事模式的金币
        storyNeedMoney: 0,
        //购买的卡包编号是
        purchaseId: 0,
        //当前页面位置
        pageId: 0,
        //现在的单价
        nowMoney: 0,
        //滑动页面
        pages: [cc.Node],
        //卡包购买项目
        bagItem: cc.Node,
        //故事购买项目
        storyItem: cc.Node,
        //氪金购买项目
        moneyItem: cc.Node
    },

    // use this for initialization
    onLoad: function onLoad() {
        this.node.on('purchaseId', this.purchaseIdChange, this);
    },
    purchaseIdChange: function purchaseIdChange(event) {
        this.purchaseId = event.detail.id;
        this.nowMoney = event.detail.script.money;

        if (event.detail.script.type === 0) {
            this.purchaseNumChange();
        } else if (event.detail.script.type === 1) {
            this.changeStoryMode();
        }
        this.purchaseButton[0].runAction(cc.moveTo(0.5, 200 * this.purchaseId + -300, this.purchaseButton[0].y).easing(cc.easeCircleActionInOut()));
        this.purchaseButton[1].runAction(cc.moveTo(0.5, 200 * this.purchaseId + -300, this.purchaseButton[1].y).easing(cc.easeCircleActionInOut()));
    },
    /**
     * @主要功能 提供购买数量更新的操作
     * @author C14
     * @Date 2018/1/1
     * @parameters
     * @returns
     */
    purchaseNumChange: function purchaseNumChange() {
        this.purchaseNumLabel.string = Math.floor(this.purchaseNumLabel.string);
        this.needMoney = this.purchaseNumLabel.string * this.nowMoney;
        this.needMoneyLabel.string = this.needMoney;
    },
    /**
     * @主要功能 更新故事模式的操作
     * @author C14
     * @Date 2018/1/2
     * @parameters
     * @returns
     */
    changeStoryMode: function changeStoryMode() {
        this.needMoney = 1 * this.nowMoney;
        this.needMoneyStoryLabel.string = this.needMoney;
    },
    /**
     * @主要功能 购买卡包X个
     * @author C14
     * @Date 2018/1/1
     * @parameters
     * @returns
     */
    purchaseCardBag: function purchaseCardBag() {
        if (global.money >= this.needMoney) {
            global.money -= this.needMoney;
            this.purchaseNumLabel.string = 0;
            this.purchaseNumChange();
        } else {
            this.massage.string = "抱歉，已经没有钱了";
            var action = cc.sequence(cc.fadeIn(1).easing(cc.easeSineOut()), cc.fadeOut(1).easing(cc.easeSineIn()));
            this.massageNode.runAction(action);
        }
    },
    /**
     * @主要功能 购买卡包X个
     * @author C14
     * @Date 2018/1/2
     * @parameters
     * @returns
     */
    purchaseStoryMode: function purchaseStoryMode() {
        if (global.money >= globalConstant.storyModeNeedMoney) {
            global.money -= globalConstant.storyModeNeedMoney;
            this.purchaseNumLabel.string = 0;
            this.purchaseNumChange();
        } else {
            this.massage.string = "抱歉，已经没有钱了";
            var action = cc.sequence(cc.fadeIn(1).easing(cc.easeSineOut()), cc.fadeOut(1).easing(cc.easeSineIn()));
            this.massageNode.runAction(action);
        }
    },
    /**
     * @主要功能
     * @author
     * @Date 2018/1/1
     * @parameters
     * @returns
     */
    pageTurning: function pageTurning(string) {
        this.pageId = parseInt(string);

        var bagItem = this.bagItem.children;
        var storyItem = this.storyItem.children;

        for (var i = 0; i < bagItem.length; i++) {
            var script = bagItem[i].getComponent("Item");
            bagItem[i].scale = 1;
            script.init();
        }
        for (i = 0; i < storyItem.length; i++) {
            var script = storyItem[i].getComponent("Item");
            storyItem[i].scale = 1;
            script.init();
        }
    }
    // called every frame, uncomment this function to activate update callback
    // update: function (dt) {

    // },
});

cc._RF.pop();
},{"Constant":"Constant","Global":"Global"}],"UsingCard":[function(require,module,exports){
"use strict";
cc._RF.push(module, '9f13dbWQ9FDFZMCtJCWhaSW', 'UsingCard');
// MainBattleScene/Scripts/Manager/UsingCard.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {
        // foo: {
        //    default: null,      // The default value will be used only when the component attaching
        //                           to a node for the first time
        //    url: cc.Texture2D,  // optional, default is typeof default
        //    serializable: true, // optional, default is true
        //    visible: true,      // optional, default is true
        //    displayName: 'Foo', // optional
        //    readonly: false,    // optional, default is false
        // },
        // ...
        // 使用中节点
        cardUsing: cc.Node,
        // 手牌节点
        cardHand: cc.Node,
        // 警告提示节点
        labelTips: cc.Label,
        nodeTips: cc.Node
    },

    // use this for initialization
    onLoad: function onLoad() {
        // 当前使用卡牌
        this.cardObject = null;

        // 卡牌选择与退出的监听
        this.node.on("cardSelect", this.cardSelectEvent, this);
        this.node.on("cardExit", this.cardExitEvent, this);
        this.node.on("errorTips", this.catchTips, this);

        this.cardHandScript = this.cardHand.getComponent("DrawCard");
        //
        // this.node.on(cc.Node.EventType.MOUSE_DOWN,this.downMouseEvent,this);
        // this.node.on(cc.Node.EventType.MOUSE_UP,this.upMouseEvent,this);
    },

    cardSelectEvent: function cardSelectEvent(event) {
        var self = this;

        console.log("select a card");
        self.cardObject = event.detail.card;
        self.cardObject.parent = self.cardUsing;
        // this.cardObject.x = event.detail.posX;
        // this.cardObject.y = event.detail.posY;
        event.stopPropagation();
    },
    cardExitEvent: function cardExitEvent(event) {
        console.log("exit a card");
        // this.cardObject.parent = this.cardHand;
        this.cardObject.parent = null;
        this.cardHand.addChild(this.cardObject, this.cardObject.getComponent("Card").cardIndex);
        this.cardObject = null;
        event.stopPropagation();
    },

    catchTips: function catchTips(event) {
        var self = this;
        if (event.detail.text !== null) {
            var fadeIn = cc.fadeIn(1.0);
            var fadeOut = cc.fadeOut(1.0);
            // console.log(self.warningTips.str);
            self.labelTips.string = event.detail.text;
            // console.log(self.warningTips.string);

            self.labelTips.node.runAction(cc.sequence(fadeIn, fadeOut));
        }

        event.stopPropagation();
    }

});

cc._RF.pop();
},{}],"ViewCard":[function(require,module,exports){
"use strict";
cc._RF.push(module, 'eca7bYCXERHIZuxgniJt5WL', 'ViewCard');
// MainScene/Scripts/Prefab/ViewCard.js

'use strict';

cc.Class({
    extends: cc.Component,

    properties: {

        //魔法消耗
        manaConsume: 0,
        //魔法消耗标签
        manaConsumeLabel: cc.Label,

        //卡片类型
        cardType: 0, //0法术牌；1生物牌 
        //卡片ID
        cardId: 0,

        //张数
        num: 0,
        //张数标签
        numLabel: cc.Label,

        //卡片名称
        cName: cc.String,
        //卡片名称的标签
        cNameLabel: cc.Label

    },

    // use this for initialization
    onLoad: function onLoad() {
        this.init();
        this.initMouseEvent();
    },

    init: function init() {
        var self = this;
        self.manaConsumeLabel.string = self.manaConsume;
        if (self.num > 1) {
            self.numLabel.string = 'x' + self.num;
        } else {
            self.numLabel.string = '';
        }

        if (self.cName.length <= 3) {
            self.cNameLabel.string = self.cName;
        } else {
            self.cNameLabel.string = self.cName.slice(0, 3) + '...';
        }
    },
    addViewCard: function addViewCard(detail) {
        var self = this;

        self.manaConsume = detail.manaConsume;
        self.cName = detail.cName;
        self.num = 1;

        self.cardType = detail.typeId;
        self.cardId = detail.id;

        self.init();
    },
    addNumBy: function addNumBy(num) {
        var self = this;
        self.num += num;
        self.numLabel.string = 'x' + self.num;
    },

    initMouseEvent: function initMouseEvent() {
        this.node.on(cc.Node.EventType.MOUSE_DOWN, removeCard, this);

        function removeCard() {
            var eventsend = new cc.Event.EventCustom('mouseDownTheShowCard', true);
            eventsend.setUserData({ object: this });
            this.node.dispatchEvent(eventsend);
        }
    }

});

cc._RF.pop();
},{}],"ViewDeck":[function(require,module,exports){
"use strict";
cc._RF.push(module, '14953jWI69G1LekpH0jCZzj', 'ViewDeck');
// MainScene/Scripts/Prefab/ViewDeck.js

'use strict';

cc.Class({
    extends: cc.Component,

    properties: {
        num: 0,
        //����������
        type: {
            type: cc.Enum({
                //��ѧ
                Science: 0,
                //����
                Fantasy: 1,
                //����
                Chaos: 2
            }),
            default: 0
        },
        //�Ƿ�����ʹ�ã���ʼΪ��
        usable: true,

        nameLabel: cc.Label
    },

    // use this for initialization
    onLoad: function onLoad() {
        this.initMouseEvent();
    },
    initMouseEvent: function initMouseEvent() {
        this.node.on(cc.Node.EventType.MOUSE_DOWN, removeCard, this);

        function removeCard() {
            var eventsend = new cc.Event.EventCustom('mouseDownTheDeck', true);
            eventsend.setUserData({ object: this });
            this.node.dispatchEvent(eventsend);
        }
    },
    removeThisDeck: function removeThisDeck() {
        var eventsend = new cc.Event.EventCustom('removeTheDeck', true);
        eventsend.setUserData({ object: this });
        this.node.dispatchEvent(eventsend);
    },
    changeType: function changeType(type) {
        this.type = type;
    },
    changeName: function changeName(name) {
        this.nameLabel.string = name;
    }
});

cc._RF.pop();
},{}],"changeDeckName":[function(require,module,exports){
"use strict";
cc._RF.push(module, '2dbc8ZyixpFwZuX+q7nxgPl', 'changeDeckName');
// MainScene/Scripts/Prefab/changeDeckName.js

'use strict';

cc.Class({
    extends: cc.Component,

    properties: {
        // foo: {
        //    default: null,      // The default value will be used only when the component attaching
        //                           to a node for the first time
        //    url: cc.Texture2D,  // optional, default is typeof default
        //    serializable: true, // optional, default is true
        //    visible: true,      // optional, default is true
        //    displayName: 'Foo', // optional
        //    readonly: false,    // optional, default is false
        // },
        // ...
    },

    // use this for initialization
    onLoad: function onLoad() {
        //this.node.on(cc.Node.EventType.MOUSE_DOWN,back, this);


    },
    changeName: function changeName() {
        var eventsend = new cc.Event.EventCustom('nameTheDeck', true);
        var text = this.node.getComponent(cc.EditBox);
        eventsend.setUserData({ name: text.string });
        this.node.dispatchEvent(eventsend);
    }

    // called every frame, uncomment this function to activate update callback
    // update: function (dt) {

    // },
});

cc._RF.pop();
},{}],"network":[function(require,module,exports){
"use strict";
cc._RF.push(module, '052c4pbRqxA1q538BY1v5oY', 'network');
// network.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {
        label: cc.Label,
        //editBox:cc.Node,
        url: "http://39.106.67.112:3000",
        socket: null,
        token: 1,
        userName: "kenan",
        password: "123456",
        //���������˳������ı���
        sign: 0,

        manager: cc.Script,

        editBoxNode: cc.Node,

        messageLabel: cc.Label
    },

    // use this for initialization
    onLoad: function onLoad() {

        //this.edit = this.editBoxNode.getComponent(cc.EditBox);
        this.manager = this.node.getComponent("MainGameManager");
        cc.log(this.manager);

        //��ʼ��ҳ��  ��½����   �����˻� kenan : 123456
        this.login = function () {
            this.socket.emit('login', { 'userName': this.userName, 'password': this.password });
        };
        //Ĭ�Ͽռ�  Ĭ��room  ��ͨ��Ϣ����
        this.broadcastMsg = function (msg) {
            this.socket.emit('broadcastMsg', { 'msg': msg, 'token': this.token });
        };
        //room����������
        this.roomMsg = function (room, msg) {
            this.socket.emit('room', { 'room': room, 'msg': msg, 'token': this.token });
            cc.log("send message");
        };
        //��ͨ��Ϣ����
        this.msg = function (msg, id) {
            this.socket.emit('msg', { 'msg': msg, 'id': id, 'token': this.token });
        };

        this.start = function () {
            this.socket = io.connect(this.url + "/index");
            var token = this.token;
            var self = this;
            //��½��������
            this.socket.on('loginResult', function (data) {
                console.log('loginResult:' + data.msg + " results:" + data.results);
                token = data.results;
                self.roomMsg('roomChat', '  do you like me?');
            });
            //��������
            this.socket.on('error', function (error) {
                console.log('error:' + error);
            });
            //�����ѹر�
            this.socket.on('disconnect', function () {
                if (self.userName != null && self.userName.length > 0) {
                    login();
                    //self.roomMsg('roomChat','  do you like me?');
                }
                console.log('disconnect');
            });
            //��������
            this.socket.on('reconnect', function () {
                log('reconnect');
                if (this.userName != null && this.userName.length > 0) {
                    self.login();
                }
            });
            //��������
            this.socket.on('reconnect_error', function () {
                log('reconnect_error');
            });
            //�㲥��Ϣ����
            this.socket.on('msg', function (data) {
                console.log('msg' + data.msg);
            });
            //room����
            this.socket.on('roomChat', function (data) {
                cc.log(data.msg.name);
                if (data.msg.name === "creatureCreate") {
                    self.manager.creatureCreateNetwork(data.msg.detail);
                } else if (data.msg.name === "magicCreate") {
                    self.manager.magicCreateNetwork(data.msg.detail);
                } else if (data.msg.name === "chantCreate") {
                    self.manager.chantCreateNetwork(data.msg.detail);
                } else if (data.msg.name === "heroDeath") {
                    //self.manager.heroDeathDetail(data.msg.detail);
                } else if (data.msg.name === "enemyMove") {
                    self.manager.changeEnemyMove(data.msg.detail);
                } else if (data.msg.name === "message") {
                    self.messageLabel.string = data.msg.detail;
                }
            });
        };

        this.start();
        this.login();
    }

});

cc._RF.pop();
},{}]},{},["Constant","Global","CardLayout","PoolHandler","AttackBehavior","DrawCard","GameTimer","MainGameManager","UsingCard","CameraFollow","CardList","CloseButton","Deck","Door","FirstPageCard","HeroControl","LayerManager","MainSceneManager","MiniCard","OpenCardManager","Item","ViewCard","ViewDeck","changeDeckName","SelectMenuManager","StoreButton","StoreCloseButton","StoreManager","InfoBoard","BackRoll","Player","C0","C1","C2","M0","M1","Chant","Magic0","Magic1","Base","Card","Creature","CreatureRange","CreatureState","CreepCard","Fire","MagicCard","SignScript","Button","CameraControl","CameraMove","MagicNode","SmallMap","network"])

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0cy9NYWluQmF0dGxlU2NlbmUvU2NyaXB0cy9NYW5hZ2VyL0F0dGFja0JlaGF2aW9yLmpzIiwiYXNzZXRzL1NjcmlwdC9CYWNrUm9sbC5qcyIsImFzc2V0cy9TY3JpcHQvUHJlZmFiL290aGVycy9CYXNlLmpzIiwiYXNzZXRzL1NjcmlwdC9VSS9CdXR0b24uanMiLCJhc3NldHMvU2NyaXB0L1ByZWZhYi9DYXJkcy9DMC5qcyIsImFzc2V0cy9TY3JpcHQvUHJlZmFiL0NhcmRzL0MxLmpzIiwiYXNzZXRzL1NjcmlwdC9QcmVmYWIvQ2FyZHMvQzIuanMiLCJhc3NldHMvU2NyaXB0L1VJL0NhbWVyYUNvbnRyb2wuanMiLCJhc3NldHMvTWFpblNjZW5lL1NjcmlwdHMvQ2FtZXJhRm9sbG93LmpzIiwiYXNzZXRzL1NjcmlwdC9VSS9DYW1lcmFNb3ZlLmpzIiwiYXNzZXRzL01haW5CYXR0bGVTY2VuZS9TY3JpcHRzL0NhcmRMYXlvdXQuanMiLCJhc3NldHMvTWFpblNjZW5lL1NjcmlwdHMvQ2FyZExpc3QuanMiLCJhc3NldHMvU2NyaXB0L1ByZWZhYi9vdGhlcnMvQ2FyZC5qcyIsImFzc2V0cy9TY3JpcHQvUHJlZmFiL0NoYW50IE1hZ2ljL0NoYW50LmpzIiwiYXNzZXRzL01haW5TY2VuZS9TY3JpcHRzL0Nsb3NlQnV0dG9uLmpzIiwiYXNzZXRzL0NvbnN0YW50LmpzIiwiYXNzZXRzL1NjcmlwdC9QcmVmYWIvb3RoZXJzL0NyZWF0dXJlUmFuZ2UuanMiLCJhc3NldHMvU2NyaXB0L1ByZWZhYi9vdGhlcnMvQ3JlYXR1cmVTdGF0ZS5qcyIsImFzc2V0cy9TY3JpcHQvUHJlZmFiL290aGVycy9DcmVhdHVyZS5qcyIsImFzc2V0cy9TY3JpcHQvUHJlZmFiL290aGVycy9DcmVlcENhcmQuanMiLCJhc3NldHMvTWFpblNjZW5lL1NjcmlwdHMvRGVjay5qcyIsImFzc2V0cy9NYWluU2NlbmUvU2NyaXB0cy9Eb29yLmpzIiwiYXNzZXRzL01haW5CYXR0bGVTY2VuZS9TY3JpcHRzL01hbmFnZXIvRHJhd0NhcmQuanMiLCJhc3NldHMvU2NyaXB0L1ByZWZhYi9vdGhlcnMvRmlyZS5qcyIsImFzc2V0cy9NYWluU2NlbmUvU2NyaXB0cy9GaXJzdFBhZ2VDYXJkLmpzIiwiYXNzZXRzL01haW5CYXR0bGVTY2VuZS9TY3JpcHRzL01hbmFnZXIvR2FtZVRpbWVyLmpzIiwiYXNzZXRzL0dsb2JhbC5qcyIsImFzc2V0cy9NYWluU2NlbmUvU2NyaXB0cy9IZXJvQ29udHJvbC5qcyIsImFzc2V0cy9QcmVmYWIvQ2FyZC9TaG93L0luZm9Cb2FyZC5qcyIsImFzc2V0cy9NYWluU2NlbmUvU2NyaXB0cy9QcmVmYWIvSXRlbS5qcyIsImFzc2V0cy9NYWluU2NlbmUvU2NyaXB0cy9MYXllck1hbmFnZXIuanMiLCJhc3NldHMvU2NyaXB0L1ByZWZhYi9DYXJkcy9NMC5qcyIsImFzc2V0cy9TY3JpcHQvUHJlZmFiL0NhcmRzL00xLmpzIiwiYXNzZXRzL1NjcmlwdC9QcmVmYWIvTWFnaWMvTWFnaWMwLmpzIiwiYXNzZXRzL1NjcmlwdC9QcmVmYWIvTWFnaWMvTWFnaWMxLmpzIiwiYXNzZXRzL1NjcmlwdC9QcmVmYWIvb3RoZXJzL01hZ2ljQ2FyZC5qcyIsImFzc2V0cy9TY3JpcHQvVUkvTWFnaWNOb2RlLmpzIiwiYXNzZXRzL01haW5CYXR0bGVTY2VuZS9TY3JpcHRzL01hbmFnZXIvTWFpbkdhbWVNYW5hZ2VyLmpzIiwiYXNzZXRzL01haW5TY2VuZS9TY3JpcHRzL01haW5TY2VuZU1hbmFnZXIuanMiLCJhc3NldHMvTWFpblNjZW5lL1NjcmlwdHMvTWluaUNhcmQuanMiLCJhc3NldHMvTWFpblNjZW5lL1NjcmlwdHMvT3BlbkNhcmRNYW5hZ2VyLmpzIiwiYXNzZXRzL1NjcmlwdC9QbGF5ZXIuanMiLCJhc3NldHMvTWFpbkJhdHRsZVNjZW5lL1NjcmlwdHMvQ2xhc3MvUG9vbEhhbmRsZXIuanMiLCJhc3NldHMvTWFpblNjZW5lL1NjcmlwdHMvU2VsZWN0TWVudU1hbmFnZXIuanMiLCJhc3NldHMvU2NyaXB0L1ByZWZhYi9vdGhlcnMvU2lnblNjcmlwdC5qcyIsImFzc2V0cy9TY3JpcHQvVUkvU21hbGxNYXAuanMiLCJhc3NldHMvTWFpblNjZW5lL1NjcmlwdHMvU3RvcmUvU3RvcmVCdXR0b24uanMiLCJhc3NldHMvTWFpblNjZW5lL1NjcmlwdHMvU3RvcmUvU3RvcmVDbG9zZUJ1dHRvbi5qcyIsImFzc2V0cy9NYWluU2NlbmUvU2NyaXB0cy9TdG9yZS9TdG9yZU1hbmFnZXIuanMiLCJhc3NldHMvTWFpbkJhdHRsZVNjZW5lL1NjcmlwdHMvTWFuYWdlci9Vc2luZ0NhcmQuanMiLCJhc3NldHMvTWFpblNjZW5lL1NjcmlwdHMvUHJlZmFiL1ZpZXdDYXJkLmpzIiwiYXNzZXRzL01haW5TY2VuZS9TY3JpcHRzL1ByZWZhYi9WaWV3RGVjay5qcyIsImFzc2V0cy9NYWluU2NlbmUvU2NyaXB0cy9QcmVmYWIvY2hhbmdlRGVja05hbWUuanMiLCJhc3NldHMvbmV0d29yay5qcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7O0FBQUE7Ozs7OztBQU1BO0FBQ0k7O0FBRUE7QUFDSTtBQUNOO0FBRmM7O0FBS1o7Ozs7O0FBS0E7O0FBRUk7QUFDQTtBQUNJO0FBQ0g7O0FBRUQ7QUFDQTtBQUFBO0FBQ0E7QUFDSDtBQUNJO0FBQ0g7QUFDRztBQUNIO0FBQ007QUFDSDtBQUNEO0FBQ0g7O0FBRUE7QUFDRTs7QUFFQztBQUNIO0FBQ0E7QUFDTztBQUNIO0FBQ0o7QUF6Q3lCOzs7Ozs7Ozs7O0FDTjlCO0FBQ0k7O0FBRUE7QUFDSTs7QUFFQTtBQUNBO0FBSlE7O0FBaUJaO0FBQ0E7QUFDSTtBQUNIO0FBQ0Q7QUFDSTtBQUVJO0FBQ0g7QUFDRztBQUNIO0FBQ0c7QUFDSDtBQUNKOztBQWpDSTs7Ozs7Ozs7OztBQ0FUO0FBQ0E7QUFDSTs7QUFFQTtBQUNJO0FBQ0E7QUFDQTs7QUFFQTs7QUFFQTs7QUFQUTs7QUFxQlo7QUFDQTtBQUNJO0FBQ0E7QUFDSDtBQUNEO0FBQ0k7QUFDQTtBQUNBO0FBQ0g7QUFDRDtBQUNJO0FBQ0E7QUFDSTtBQUNJO0FBQ0g7QUFDSjtBQUNKOztBQUVEO0FBQ0k7QUFDQTtBQUNBO0FBQ0k7QUFDSDtBQUNKOztBQUVEOztBQUVJOztBQUdBO0FBQ0k7QUFDSDtBQUNHO0FBQ0E7QUFDSDs7QUFFRDtBQUNIOztBQUVEO0FBQ0E7O0FBRUE7QUFyRUs7Ozs7Ozs7Ozs7QUNEVDs7OztBQUlBO0FBQ0k7O0FBRUE7QUFDSTtBQUNBO0FBQ0E7O0FBRUE7QUFMUTs7QUFTWjtBQUNJO0FBQ0g7O0FBR0Q7Ozs7O0FBS0E7QUFDSTtBQUNBO0FBQ0k7QUFDSDtBQUNHO0FBQ0g7QUFDRDtBQUNBOztBQUVBO0FBQ0g7O0FBakNzQjs7Ozs7Ozs7OztBQ0ozQjtBQUNBO0FBQ0E7O0FBRUE7QUFDSTs7QUFFQTs7QUFJQTtBQUNBO0FBQ0k7QUFDQTtBQUNIOztBQUlEO0FBQ0k7QUFDSDs7QUFFRDtBQUNJO0FBQ0E7QUFDSTtBQUNJO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBUGtCO0FBUzFCOztBQUVBO0FBQ0g7QUFDRDtBQUNBOztBQUVBO0FBdENLOzs7Ozs7Ozs7O0FDSlQ7O0FBRUE7QUFDSTs7QUFFQTs7QUFJQTtBQUNBO0FBQ0k7QUFDQTtBQUNBO0FBQ0g7O0FBR0Q7QUFDSTtBQUNBO0FBQ0E7QUFFTztBQUNIO0FBQ0c7QUFDSDtBQUNKO0FBQ0g7O0FBRUQ7QUFDSTtBQUNBO0FBQ0k7QUFDSTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQVBrQjtBQVMxQjs7QUFFQTtBQUNIO0FBQ0Q7QUFDQTs7QUFFQTtBQTlDSzs7Ozs7Ozs7OztBQ0ZUO0FBQ0E7QUFDQTs7QUFFQTtBQUNJOztBQUVBOztBQUlBO0FBQ0E7QUFDSTtBQUNBO0FBQ0g7O0FBSUQ7QUFDSTtBQUNIOztBQUVEO0FBQ0k7QUFDQTtBQUNBO0FBQ0k7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFQa0I7QUFTdEI7O0FBRUE7QUFDSDtBQUNEO0FBQ0E7O0FBRUE7QUF0Q0s7Ozs7Ozs7Ozs7QUNKVDs7QUFFQTtBQUNJOztBQUVBO0FBQ0k7QUFDSTtBQUNBO0FBRkk7O0FBS1I7QUFDSTtBQUNBO0FBRks7QUFJVDtBQUNBO0FBQ0E7O0FBRUE7QUFkUTs7QUEyQlo7QUFDQTtBQUNJO0FBQ0E7QUFDSTtBQUNIO0FBQ0o7O0FBRUQ7QUFDQTtBQUNJO0FBQ0E7O0FBRUE7QUFDSTtBQUNIO0FBQ0c7QUFDSDtBQUNHO0FBQ0g7O0FBRUQ7QUFDQTtBQUNIO0FBckRJOzs7Ozs7Ozs7O0FDRlQ7QUFDSTs7QUFFQTtBQUNJO0FBQ0k7QUFDQTtBQUZJO0FBREE7O0FBT1o7QUFDQTtBQUNJO0FBQ0E7O0FBRUE7QUFDSTtBQUNIO0FBQ0Q7QUFDQTtBQUNIO0FBcEJJOzs7Ozs7Ozs7O0FDQVQ7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQW9GQTtBQUNBO0FBQ0k7O0FBRUE7QUFDSTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBOztBQUVBO0FBYlE7O0FBMEJaO0FBQ0E7QUFDSTtBQUNBO0FBQ0E7O0FBRUE7O0FBRUE7QUFFSDs7QUFFRDtBQUNJO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBSUE7QUFDSTtBQUNIO0FBQ0c7QUFDSDs7QUFFRDs7QUFFQTtBQUNIO0FBQ0Q7QUFDSTtBQUNBOztBQUlBO0FBQ0k7QUFDSDtBQUNHO0FBQ0g7O0FBRUQ7QUFDSDtBQUNEO0FBQ0k7QUFDQTtBQUNIO0FBQ0Q7QUFDQTtBQUNJOzs7QUFHQTtBQUNJO0FBQ0E7QUFDQTtBQUNIO0FBQ0c7QUFDQTtBQUNBO0FBQ0g7QUFDRztBQUNBO0FBQ0g7QUFDRDtBQUNIO0FBaEdJOzs7Ozs7Ozs7O0FDckZUO0FBQ0E7QUFDSTs7QUFFQTtBQUNJO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQXZCUTs7QUEwQlo7QUFDQTtBQUNJOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDSTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDSTtBQURKO0FBR0g7QUFDSjs7QUE1RUk7Ozs7Ozs7Ozs7QUNEVDs7QUFFQTtBQUNJOztBQUVBO0FBQ0k7Ozs7Ozs7O0FBUUE7QUFDSTtBQUNBO0FBRk87O0FBS1g7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0k7QUFDQTtBQUZPOztBQUtYO0FBQ0k7QUFDQTtBQUZPOztBQUtYO0FBQ0k7QUFDQTtBQUZFO0FBSU47QUFDSTtBQUNBO0FBRkk7O0FBS1I7QUFDSTtBQUNJO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFSVTtBQVVkO0FBWEU7QUFhTjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBN0VROztBQWdGWjtBQUNBO0FBQ0k7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0g7O0FBRUQ7QUFDSTtBQUNBO0FBQ0g7QUFDRDtBQUNJO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDSTtBQUNIO0FBQ0Q7QUFDSDtBQUNEO0FBQ0k7QUFDQTtBQUNBO0FBQ0E7QUFDSDtBQUNEO0FBQ0k7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNJO0FBQ0g7QUFDRDtBQUNBO0FBQ0g7QUFDRDtBQUNJO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDSTtBQUNIO0FBQ0o7O0FBRUQ7QUFDSTtBQUNJO0FBQ0k7QUFDSTtBQUNJO0FBQ0g7QUFDRDtBQUNIO0FBQ0o7QUFDSjtBQUNHO0FBQ0k7QUFDSTtBQUNJO0FBQ0g7QUFDRDtBQUNIO0FBQ0o7QUFDSjtBQUNEO0FBQ0g7QUFDRDtBQUNJO0FBQ1E7QUFDUDtBQUNPO0FBQ1A7QUFDRDtBQUNIOztBQUVEOzs7Ozs7O0FBT0E7QUFDSTtBQUNBO0FBQ0k7QUFDSTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNIO0FBQ1I7O0FBRUQ7QUFDQTtBQUNJO0FBQ0E7QUFDQTtBQUNJO0FBQ0k7QUFDSjtBQUNBO0FBQ0E7QUFDSDtBQUNEO0FBQ0k7QUFDSTtBQUNKO0FBQ0E7QUFDQTtBQUNIO0FBQ0Q7QUFDQTtBQUNIOztBQUVEO0FBQ0E7QUFDSTtBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0k7QUFDSTtBQUNBO0FBQ0k7QUFDSDtBQUNKO0FBQ0o7O0FBRUQ7QUFDSDs7QUFFRDtBQUNBO0FBQ0k7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDSTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDSTtBQUNIO0FBQ0o7O0FBRUQ7QUFDQTtBQUNBO0FBQ0g7O0FBRUQ7QUFDQTtBQUNJO0FBQ0E7QUFDSTtBQUNIO0FBQ0c7QUFDSDtBQUNEO0FBQ0E7QUFDQTtBQUNBO0FBQ0k7QUFDSTtBQUNIO0FBQ0c7QUFDSDtBQUNKO0FBQ0Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUtJO0FBQ0g7QUFDRDtBQUNBO0FBQ0g7O0FBSUQ7QUFDSTtBQUNJO0FBQ0g7QUFDSjs7QUFFRDs7QUFFQTtBQUNBO0FBQ0E7O0FBRUc7QUFDSTtBQUNJO0FBQ0g7QUFDRDtBQUNJO0FBQ0k7QUFDSDtBQUNHO0FBQ0g7QUFDRDtBQUNBO0FBQ0E7QUFDQTtBQUNIO0FBQ0g7QUFDRjtBQUNJO0FBQ0k7QUFDSTtBQUNIO0FBQ0o7QUFDSDs7QUFFRjtBQUNJO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNJO0FBQ0k7QUFDSTtBQUNJO0FBQ0E7QUFDQTtBQUNIO0FBQ0o7QUFDRztBQUNJO0FBQ0E7QUFDQTtBQUNIO0FBQ0o7QUFDSjtBQUNKO0FBQ0c7QUFDSTtBQUNIO0FBQ0Q7QUFDSTtBQUNIO0FBQ0c7QUFDSDtBQUNEO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0g7QUFDSjtBQUNIOztBQUVEO0FBQ0E7QUFBQTtBQUNBO0FBQ0E7QUFDSTtBQUNJO0FBQ0k7QUFDQTtBQUNJO0FBQ0g7QUFDSjtBQUNKOztBQUVMO0FBQ0M7O0FBRUQ7QUFDQTtBQUNJO0FBQ0E7QUFDQTtBQUNBO0FBQUE7O0FBRUE7QUFDSTtBQUNBO0FBQ0E7QUFFSTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBOztBQUVBO0FBQ0g7QUFDSjtBQUNEO0FBQ0k7QUFDQTtBQUNBO0FBQ0k7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0g7QUFDSjtBQUNEO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDSDs7QUFFRDtBQUNBO0FBQ0E7QUFDSTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDSTtBQUNIO0FBQ0Q7QUFDSDs7QUF2Y0k7Ozs7Ozs7Ozs7QUNGVDtBQUNJOztBQUVBO0FBQ0k7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7O0FBRUE7QUFDQTtBQUNJO0FBQ0c7QUFDQTtBQUZXO0FBSWQ7QUFMTTtBQU9WO0FBQ0k7QUFDSTtBQUNBO0FBQ0E7QUFDQTtBQUpVO0FBTWQ7QUFQRztBQVNQO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQTdDUTs7QUFnRFo7QUFDQTtBQUNJO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0k7QUFDSTtBQUNBO0FBQ0k7QUFDSDtBQUNEO0FBQ0o7QUFDSTtBQUNBO0FBQ0k7QUFDSDtBQUNEO0FBQ0o7QUFDSTtBQWRSOztBQWlCQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0g7O0FBRUQ7QUFDQTtBQUNJO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNJO0FBQ0g7O0FBRUQ7QUFDSDtBQUNEO0FBQ0k7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0k7QUFDQTtBQUNIO0FBRUo7O0FBRUQ7QUFDSTtBQUNBOztBQUdBOztBQUVBO0FBQ0g7O0FBRUQ7QUFDSTtBQUNBO0FBQ0E7O0FBRUE7QUFDSDs7QUFFRDtBQUNJOztBQUVBO0FBQ0E7QUFDSTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0g7O0FBRUc7QUFDQTtBQUNBO0FBRUg7O0FBRUQ7QUFDSDs7QUFFRDtBQUNJO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUVBOztBQUVBO0FBQ0g7O0FBRUQ7QUFDSTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNIOztBQXBNSTs7Ozs7Ozs7OztBQ0FUO0FBQ0k7O0FBRUE7QUFDSTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBbEJRO0FBK0JaO0FBQ0k7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNJO0FBQ0E7QUFDSDtBQUNHO0FBQ0E7QUFDSDtBQUNKO0FBQ0Q7QUFDSTtBQUNBO0FBQ0E7QUFDSTtBQUNBO0FBQ0k7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFQa0I7QUFTdEI7O0FBRUE7QUFDSDtBQUNHO0FBQ0E7QUFDSTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQVBrQjtBQVN0QjtBQUNIO0FBQ0o7QUFDRDtBQUNBO0FBQ0k7QUFDQTtBQUNBO0FBQ0E7QUFDSDs7QUFoR0k7Ozs7Ozs7Ozs7QUNBVDtBQUNJOztBQUVBO0FBQ0k7QUFEUTs7QUFJWjtBQUNBOztBQUlBO0FBQ0k7QUFDSDtBQUNEO0FBQ0E7O0FBRUE7QUFsQks7Ozs7Ozs7Ozs7QUNBVDs7QUFFQTtBQUNJO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0k7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFQYztBQVNsQjtBQUNBOztBQUVBO0FBcENhOzs7Ozs7Ozs7O0FDRmpCO0FBQ0k7O0FBRUE7QUFDSTtBQURROztBQWNaO0FBQ0E7QUFDSTtBQUNIO0FBQ0Q7QUFDSTtBQUNBO0FBQ0k7QUFDQTtBQUNJO0FBQ0E7QUFDQTtBQUNJO0FBQ0E7QUFDQTtBQUNJO0FBQ0g7QUFDSjtBQUNKOztBQUdEO0FBQ0E7QUFDSTs7QUFFQTtBQUNJO0FBQ0E7QUFDQTtBQUNJO0FBQ0g7QUFDSjtBQUNKOztBQUVEO0FBQ0E7QUFDSTtBQUNBO0FBQ0E7QUFDSTtBQUNBO0FBQ0E7QUFDSTtBQUNIO0FBQ0o7QUFDSjtBQUNKO0FBQ0o7O0FBRUQ7QUFDSTtBQUNBO0FBQ0E7QUFDSTtBQUNJO0FBQ0k7QUFDQTtBQUNIO0FBQ0o7QUFDSjtBQUNKO0FBN0VJOzs7Ozs7Ozs7O0FDQVQ7Ozs7O0FBS0E7QUFDQTtBQUNJOztBQUVBO0FBQ0k7QUFDSTtBQUNBO0FBRkU7QUFJTjtBQUNJO0FBQ0E7QUFGUTtBQUlaO0FBQ0k7QUFDQTtBQUZRO0FBVEo7QUFjWjs7Ozs7OztBQU9BO0FBQ0k7QUFDQTtBQUNBO0FBQ0k7QUFDSDtBQUNHO0FBQ0g7O0FBRUQ7QUFDSTtBQUNIO0FBQ0Q7QUFDSTtBQUNIO0FBQ0Q7QUFDSDs7QUFFRDs7Ozs7OztBQU9BO0FBQ0k7QUFDQTtBQUNBO0FBQ0g7QUFDRDs7Ozs7OztBQU9BO0FBQ0k7QUFDSTtBQUNBO0FBQ0E7QUFDSDtBQUNKO0FBQ0Q7Ozs7Ozs7QUFPQTtBQUNJO0FBQ0k7QUFDQTtBQUNJO0FBQ0g7QUFDRDtBQUNBO0FBQ0k7QUFDSTtBQUNBO0FBQ0g7QUFDRDtBQUNJO0FBQ0g7QUFDRDtBQUdBO0FBQ0k7QUFDSDtBQUNEO0FBQ0k7QUFDSDtBQUNEO0FBR0E7QUFDSDtBQUNKO0FBQ0o7QUFDRDs7Ozs7OztBQU9BO0FBQ0k7QUFDSTtBQUNBO0FBQ0g7QUFDRDtBQUNJO0FBQ0g7QUFDRDtBQUdBO0FBQ0k7QUFDSDtBQUNEO0FBQ0k7QUFDSDtBQUNKO0FBQ0Q7QUFDQTtBQUNJO0FBQ0E7QUFDSTtBQUNBO0FBQ0k7QUFDQTtBQUNJO0FBQ0g7QUFDSjtBQUNEO0FBQ0k7QUFDSDtBQUNEO0FBQ0E7QUFDSDtBQUNKOztBQXBKSTs7Ozs7Ozs7OztBQ05UOzs7O0FBSUE7QUFDSTs7QUFFQTtBQUNJO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFoRVE7O0FBb0VaO0FBQ0k7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTs7OztBQUtBO0FBQ0g7O0FBR0Q7Ozs7O0FBS0E7QUFDSTtBQUNBO0FBQ0k7QUFDQTtBQUNJO0FBQ0E7QUFDSDtBQUNEO0FBQ0k7QUFDSDtBQUNEO0FBQ0k7QUFDSDtBQUNKOztBQUlEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0g7O0FBSUQ7QUFDSTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBOztBQUVJO0FBQ0E7QUFDSTtBQUNIO0FBQ0c7QUFDSDtBQUNKO0FBQ0o7O0FBR0Q7Ozs7O0FBS0E7QUFDSTtBQUNBO0FBQ0k7QUFDQTtBQUNBO0FBQ0g7O0FBRUQ7QUFDQTtBQUNJO0FBQ0g7QUFDRztBQUNIO0FBQ0c7QUFDSDs7QUFFRDtBQUNJO0FBQ0E7QUFDSTtBQUNBO0FBQ0E7QUFDSDtBQUNEO0FBQ0k7QUFDSDtBQUNHO0FBQ0g7QUFDRztBQUNIO0FBQ0o7O0FBR0Q7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNJO0FBQ0E7QUFDSDtBQUNEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNDO0FBQ0M7QUFDQTtBQUNBO0FBQ0E7O0FBRUY7QUFDQTtBQUVIOztBQUVEOzs7Ozs7O0FBT0E7QUFDSTtBQUNBO0FBQ0E7QUFDQTtBQUNJO0FBQ0k7QUFDSDtBQUNHO0FBQ0E7QUFDQTtBQUNJO0FBQ0g7QUFDSjtBQUNEO0FBQ0g7QUFDSjtBQUNBOztBQUVEOzs7Ozs7O0FBT0E7QUFDSTtBQUNBO0FBQ0E7QUFDSDs7QUFFRDs7Ozs7OztBQU9BO0FBQ0k7QUFDQTtBQUNIO0FBQ0Q7Ozs7Ozs7QUFPQTtBQUNJO0FBQ0E7QUFDSDtBQUNEOzs7OztBQUtBO0FBQ0k7QUFDQTtBQUNIOztBQUlEO0FBQ0E7QUFDSTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0k7QUFDQTtBQUNIO0FBQ0o7O0FBR0Q7Ozs7QUFJQTtBQUNJO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFHQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0k7QUFDQTtBQUNBO0FBQ0E7QUFDSDs7QUFHRDtBQUNBO0FBQ0g7O0FBR0Q7Ozs7QUFJQTtBQUNJO0FBQ0g7O0FBRUQ7Ozs7Ozs7QUFPQTtBQUNJO0FBQ0E7QUFDSTtBQUNIO0FBQ0Q7QUFDSTtBQUNIO0FBQ0c7QUFDSDtBQUNEO0FBQ0k7QUFDQTtBQUNBO0FBQ0E7QUFKa0I7QUFNdEI7QUFDSDtBQUNEOzs7QUFHQTtBQUNJO0FBQ0E7QUFDSTtBQUNBO0FBQ0E7QUFDSDtBQUNHO0FBQ0E7QUFDQTtBQUNIO0FBQ0c7QUFDQTtBQUNBO0FBQ0g7QUFDSjs7QUFoWXVCOzs7Ozs7Ozs7O0FDSjVCOztBQUVBO0FBQ0k7O0FBRUE7O0FBRUE7O0FBRUE7QUFDSTtBQUNBO0FBQ0k7QUFDSTtBQUNBO0FBQ0E7QUFIVTtBQUtkO0FBTk87O0FBU1g7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBOztBQXhCUTs7QUE0Qlo7QUFDQTtBQUNJO0FBQ0E7QUFDSTtBQUNBO0FBQ0E7QUFIeUI7O0FBTTdCO0FBQ0E7O0FBRUE7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNJO0FBQ0g7QUFDRztBQUNIOztBQUVEO0FBQ0E7QUFDQTtBQUNIO0FBQ0Q7QUFDSTtBQUNBO0FBQ0E7QUFDSDtBQUNEO0FBQ0k7QUFDQTtBQUNBO0FBQ0g7QUFDRDtBQUNJO0FBQ0E7QUFDQTtBQUNIO0FBQ0Q7QUFDSTtBQUNBO0FBQ0g7QUFDRDs7Ozs7QUFLQTtBQUNJO0FBRUk7QUFDSDtBQUNKO0FBQ0Q7Ozs7O0FBS0E7QUFDSTtBQUNIO0FBQ0Q7Ozs7O0FBS0E7QUFDSTtBQUNIO0FBQ0Q7Ozs7O0FBS0E7QUFDSTtBQUNJO0FBQ0E7QUFDSDtBQUNEO0FBQ0k7QUFDQTtBQUNIO0FBQ0Q7QUFDSDtBQUNEOzs7OztBQUtBO0FBQ0k7QUFDSDtBQUNEOzs7OztBQUtBO0FBQ0k7QUFDSDtBQUNEOzs7OztBQUtBO0FBQ0k7QUFDQTtBQUNJO0FBQ0E7QUFDSDtBQUNKO0FBQ0Q7Ozs7O0FBS0E7QUFDSTtBQUNBO0FBQ0g7QUFDRDs7Ozs7QUFLQTtBQUNJO0FBQ0g7O0FBR0Q7QUFDQTtBQUNJO0FBQ0E7QUFDQTtBQUNJO0FBQ0k7QUFDQTtBQUNBO0FBQ0E7QUFDSjtBQUNJO0FBQ0E7QUFDQTtBQUNBO0FBQ0o7QUFDSTtBQUNBO0FBQ0E7QUFDQTtBQWZSO0FBaUJIOztBQWpNSTs7Ozs7Ozs7OztBQ0ZUOztBQUVBO0FBQ0k7O0FBRUE7O0FBRUk7QUFDQTs7QUFFQTs7QUFFQTtBQVBROztBQVVaO0FBQ0E7QUFDSTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNIOztBQUVEOztBQUVJO0FBQ0E7QUFDQTtBQUNBOztBQUVJO0FBQ0E7QUFDSTtBQUNBO0FBQ0k7QUFDQTtBQUNBO0FBQ0k7QUFDSDtBQUNKO0FBQ0c7QUFDQTtBQUNBO0FBQ0k7QUFDSDtBQUNKO0FBQ0o7QUFDRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDSTtBQUNIO0FBQ0Q7QUFDSTtBQUNBO0FBQ0E7QUFFSTtBQUNIO0FBQ0Q7QUFDSDtBQUNEO0FBQ0k7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNIO0FBR1I7QUFDRDtBQUNJO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBOztBQUVBO0FBQ0g7QUFDRDtBQUNJO0FBQ0k7QUFDQTtBQUNBO0FBQ0E7QUFDSTtBQUNBO0FBRk07QUFJVjtBQUNJO0FBQ0E7QUFGUztBQUliO0FBQ0E7QUFDSTtBQUNJO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQU5VO0FBUWQ7QUFURTtBQVdOO0FBeEJXOztBQTJCZjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNIO0FBQ0Q7QUFDQTtBQUNJO0FBQ0E7QUFDSTtBQUNBO0FBQ0k7QUFDSDtBQUNHO0FBQ0g7QUFDSjtBQUNKO0FBMUpJOzs7Ozs7Ozs7O0FDRlQ7QUFDSTs7QUFFQTtBQUNJO0FBRFE7O0FBY1o7QUFDQTtBQUNJO0FBQ0E7QUFDQTtBQUNJO0FBQ0E7QUFDQTtBQUh3QjtBQUsvQjs7QUFFRDtBQUNJO0FBQ0k7QUFDSTtBQUNBO0FBQ0k7QUFDQTtBQUNBO0FBTFI7QUFPSDtBQUNKO0FBQ0Q7QUFDSTtBQUNBO0FBQ0k7QUFDQTtBQUNIO0FBQ0o7QUFDRDtBQUNJO0FBQ0k7QUFDSDtBQUNKO0FBQ0Q7QUFDSTtBQUNIO0FBckRJOzs7Ozs7Ozs7O0FDQVQ7QUFDQTtBQUNBOzs7OztBQUtBO0FBQ0k7O0FBRUE7QUFDSTtBQUNBO0FBQ0k7QUFDQTtBQUZhO0FBSWpCO0FBQ0k7QUFDQTtBQUZlOztBQU9uQjtBQUNBO0FBQ0k7QUFDQTtBQUZJO0FBSVI7QUFDQTtBQUNJO0FBQ0E7QUFGSTtBQUlSO0FBQ0E7QUFDSTtBQUNBO0FBRkU7QUFJTjtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQXRDUTs7QUF5Q1o7QUFDQTtBQUNJO0FBQUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDSTtBQUNBO0FBQ0E7QUFDSTtBQUNBO0FBRk07QUFJVjtBQUNJO0FBQ0E7QUFGUztBQUliO0FBQ0E7QUFDSTtBQUNJO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQU5VO0FBUWQ7QUFURTtBQVdOO0FBdkJZO0FBeUJoQjtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFHQTtBQUNJO0FBQ0k7QUFDSTtBQUNIO0FBQ0o7QUFDSjtBQUNEO0FBQ0k7QUFDSTtBQUNJO0FBQ0g7QUFDSjtBQUNKO0FBQ0Q7QUFDQTtBQUNJO0FBQ0g7QUFDRDtBQUNBO0FBQ0g7O0FBRUQ7QUFDSTtBQUNJO0FBQ0g7QUFDSjtBQUNEO0FBQ0k7QUFDQTs7QUFFQTs7QUFFQTtBQUNJO0FBQ0k7QUFDSDtBQUNEO0FBQ0g7QUFDRztBQUNJO0FBQ0g7QUFDRDtBQUNIO0FBQ0o7QUFDRDtBQUNJO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDSTtBQUNIO0FBQ0c7QUFDSDtBQUNEO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDSDs7QUFFRDtBQUNBO0FBQ0k7QUFDSTtBQUNJO0FBQ0g7QUFDSjtBQUNEO0FBQ0E7QUFDSDs7QUFHRDtBQUNJO0FBQ0g7O0FBRUQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUo7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUk7O0FBek9LOzs7Ozs7Ozs7O0FDUFQ7QUFDSTs7QUFFQTtBQUNJO0FBQ0E7QUFDQTtBQUhROztBQWdCWjtBQUNBOztBQXBCSzs7Ozs7Ozs7OztBQ0FUO0FBQ0k7O0FBRUE7QUFDSTtBQUNJO0FBQ0E7QUFGVTtBQUlkO0FBQ0k7QUFDQTtBQUZPO0FBTEg7O0FBV1o7QUFDQTtBQUNJO0FBQ0E7QUFDSDtBQUNEO0FBQ0k7QUFDQTtBQUNBO0FBQ0E7QUFDSDs7QUFFRDtBQUNBOztBQUVBO0FBN0JLOzs7Ozs7Ozs7O0FDQVQ7QUFDSTs7QUFFQTtBQUNJO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBVlE7O0FBYVo7QUFDQTtBQUNJO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNJOztBQUVBO0FBQ0k7QUFDQTtBQUNJO0FBQ0k7QUFDQTtBQUNRO0FBQ1A7QUFDSjtBQUNSOztBQUVEO0FBQ0E7QUFDSTtBQUNBO0FBQ0k7QUFDSTtBQUNBO0FBQ0g7QUFDSjtBQUNKO0FBQ0Q7QUFDQTs7QUFFQTtBQUNIO0FBQ0o7O0FBcERJOzs7Ozs7Ozs7O0FDQVQ7O0FBRUE7O0FBRUk7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0k7QUFDSTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFOVTtBQVFkO0FBVEU7O0FBWU47QUFDQTs7QUFFQTtBQUNBO0FBNUJhO0FBOEJqQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7O0FDekRBOztBQUdBO0FBQ0k7O0FBRUE7QUFDSTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBZlE7O0FBb0JaO0FBQ0E7QUFDSTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0k7QUFDQTtBQUNBO0FBSHdCOztBQU01QjtBQUdIOztBQUVEO0FBQ0k7O0FBRUE7QUFDSTtBQUNIO0FBQ0o7QUFDRDtBQUNJO0FBQ0k7QUFDQTtBQUNJO0FBQ0E7QUFDQTtBQUNKO0FBQ0E7QUFDSTtBQUNBO0FBQ0E7QUFDSjtBQUNBO0FBQ0k7QUFBa0M7QUFDOUI7QUFDQTtBQUNBO0FBQ0E7QUFDSDtBQUNHO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNIO0FBQ0Q7QUFDSjtBQUNBO0FBQ0k7QUFDSTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDSDtBQUNEO0FBckNSO0FBdUNIOztBQUVEO0FBQ0k7QUFDSTtBQUNBO0FBQ0k7QUFDQTtBQUNKO0FBQ0E7QUFDSTtBQUNBO0FBQ0o7QUFDQTtBQUNJO0FBQ0E7QUFDSTtBQUNBO0FBQ0g7QUFDRDtBQUNKO0FBQ0E7QUFDSTtBQUNBO0FBQ0k7QUFDQTtBQUNIO0FBQ0Q7QUFDSjtBQUNBO0FBQ0k7QUFDSTtBQUNBO0FBQ0E7QUFDSDtBQUNEO0FBaENSO0FBa0NIO0FBQ0Q7QUFDSTtBQUNJO0FBQ0E7QUFDSDtBQUNKOztBQUVEO0FBQ0k7QUFDQTtBQUNJO0FBQ0E7QUFDQTtBQUNBO0FBQ0g7QUFDRDtBQUNJO0FBQ0E7QUFDSDtBQUNEO0FBQ0E7QUFDSTtBQUNBO0FBQ0g7O0FBRUQ7QUFDQTtBQUNJO0FBQ0k7QUFDQTtBQUNIO0FBQ0Q7QUFDSDs7QUFFRDtBQUNBO0FBQ0k7QUFDSTtBQUNBO0FBQ0g7QUFDRDtBQUNIO0FBQ0Q7QUFDSTtBQUNJO0FBQ0E7QUFDSDtBQUNEO0FBQ0g7QUFDRDtBQUNJO0FBQ0k7QUFDQTtBQUNIO0FBQ0Q7QUFDSDtBQUNEO0FBQ0k7QUFDSTtBQUNBO0FBQ0g7QUFDRDtBQUNIO0FBQ0o7O0FBRUQ7QUFDSTtBQUNJO0FBQ0g7O0FBRUQ7QUFDSTtBQUNBO0FBQ0g7QUFDRDtBQUNJO0FBQ0E7QUFDSDtBQUNEO0FBQ0k7QUFDSDs7QUFFRDtBQUNJO0FBQ0E7QUFDSDtBQUNEO0FBQ0k7QUFDQTtBQUNIO0FBQ0Q7QUFDSTtBQUNBO0FBQ0g7QUFDRDtBQUNJO0FBQ0E7QUFDSDtBQUNKOztBQUVEO0FBQ0E7QUFDSTtBQUNBO0FBQXVDO0FBQ25DO0FBQ0g7QUFDRztBQUNIO0FBQ0c7QUFDSDtBQUNEO0FBQ0E7QUFBZ0Q7QUFDNUM7QUFDSDtBQUNHO0FBQ0g7QUFDRztBQUNIO0FBQ0c7QUFDSDs7QUFFRDtBQUNBO0FBQ0k7QUFDSDs7QUFFRDtBQUNBO0FBQ0E7QUFDSDtBQWhSSTs7Ozs7Ozs7OztBQ0hUO0FBQ0k7O0FBRUE7QUFDSTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQVZROztBQWFaO0FBQ0E7O0FBakJLOzs7Ozs7Ozs7O0FDQVQ7QUFDSTs7QUFFQTtBQUNJOztBQUVBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7O0FBRUE7QUFDQTtBQUNJO0FBQ0k7QUFDQTtBQUZTO0FBSWI7QUFMQztBQU9MO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBbkNROztBQXNDWjtBQUNBOztBQUVJO0FBQ0E7QUFDQTtBQUNBO0FBQ0g7QUFDRDtBQUNJO0FBQ0E7QUFDSDtBQUNEO0FBQ0k7QUFDSTtBQUNBO0FBQ0E7QUFDSDtBQUNKO0FBQ0Q7QUFDSTtBQUNJO0FBQ0E7QUFDQTtBQUNIO0FBQ0o7QUFDRDtBQUNJO0FBQ0k7QUFDQTtBQUNJO0FBQ0E7QUFDSTtBQUNIO0FBQ0o7QUFDRDs7QUFJQTtBQUNBO0FBQ0E7QUFDSTtBQUNJO0FBQ0E7QUFDQTtBQUNBO0FBQ0g7QUFDSjs7QUFFRDtBQUNBO0FBQ0E7QUFDSDtBQUNKO0FBQ0Q7QUFDQTs7QUFFQTtBQW5HSzs7Ozs7Ozs7OztBQ0FUO0FBQ0k7O0FBRUE7QUFDSTtBQUNJO0FBQ0E7QUFGWTtBQUloQjtBQUNJO0FBQ0E7QUFGVztBQUlmO0FBQ0k7QUFDQTtBQUZVO0FBSWQ7QUFDSTtBQUNBO0FBRlk7QUFJaEI7QUFDSTtBQUNBO0FBRlk7QUFJaEI7QUFDSTtBQUNBO0FBRlk7QUFJaEI7QUF6QlE7O0FBNEJaO0FBQ0k7QUFDQTtBQUNBO0FBQ0E7QUFDSDtBQUNEO0FBQ0E7QUFDSTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0g7QUFDRDtBQUNBO0FBQ0k7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNIO0FBQ0Q7QUFDQTtBQUNJO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNIO0FBQ0Q7Ozs7O0FBS0E7QUFDSTtBQUNBO0FBQ0g7O0FBR0Q7QUFDQTs7QUFFQTtBQTVFSzs7Ozs7Ozs7OztBQ0FUO0FBQ0E7QUFDSTs7QUFFQTs7QUFJQTtBQUNBO0FBQ0k7QUFDQTtBQUNBO0FBQ0k7QUFDQTtBQUNBO0FBSGU7QUFLM0I7QUFDUTtBQUNJO0FBQ0k7QUFDQTtBQUNJO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBUGtCO0FBU3RCO0FBQ0E7QUFDSDtBQUNKO0FBQ0c7QUFHSDtBQUNHO0FBR0g7QUFDSjs7QUFFRDtBQUNJO0FBQ0g7O0FBRUQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBOURLOzs7Ozs7Ozs7O0FDRFQ7QUFDQTtBQUNJOztBQUVBO0FBQ0k7QUFDSTtBQUNJO0FBQ0E7QUFDQTtBQUhVO0FBS2Q7QUFOTzs7QUFESDs7QUFZWjtBQUNBO0FBQ0k7QUFDQTtBQUNBO0FBQ0k7QUFDQTtBQUNBO0FBSGU7QUFLM0I7QUFDUTtBQUNJO0FBR0g7QUFDRztBQUNJO0FBQ0E7QUFDSTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFUa0I7QUFXdEI7QUFDQTtBQUNBO0FBQ0g7QUFDSjtBQUNHO0FBR0g7QUFDSjs7QUFFRDtBQUNJO0FBQ0g7QUFDRDtBQUdBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBL0ZLOzs7Ozs7Ozs7O0FDRFQ7QUFDQTtBQUNJOztBQUVBO0FBQ0k7QUFDQTtBQUNBO0FBQ0E7O0FBSlE7O0FBUVo7QUFDQTs7QUFFSTtBQUNBOztBQUVBO0FBQ0E7O0FBR0E7O0FBRUE7QUFDQTtBQUVIOztBQUVEO0FBQ0k7QUFDQTs7QUFJQTtBQUNBO0FBQ0k7QUFDQTtBQUNBO0FBQ0E7O0FBRUk7QUFDQTs7QUFHQTs7QUFFQTtBQUNBO0FBQ0E7QUFDSDtBQUVKO0FBQ0Q7QUFDSTtBQUNBO0FBQ0k7QUFDQTtBQUVBOztBQUVBO0FBQ0E7QUFDSTtBQUNIO0FBQ0o7QUFDSjtBQUNEO0FBQ0k7QUFDQTtBQUNJO0FBQ0E7QUFFQTtBQUNIO0FBQ0o7QUFDSjs7QUFFRDtBQUNJOztBQUlBO0FBR0g7QUFDRDtBQUNJO0FBQ0g7QUFDRDtBQUNJO0FBQ0E7QUFDQTtBQUNBO0FBQ0g7QUFDRDs7Ozs7OztBQU9BO0FBQ0k7QUFDQTtBQUNJO0FBQ0g7QUFDRDtBQUNJO0FBQ0g7QUFDRztBQUNIO0FBQ0Q7QUFDSTtBQUNBO0FBQ0E7QUFDQTtBQUprQjtBQU10QjtBQUNIO0FBeEhJOzs7Ozs7Ozs7O0FDRFQ7QUFDSTs7QUFFQTtBQUNJO0FBQ0E7QUFDQTtBQUNBO0FBSlE7O0FBaUJaO0FBQ0E7QUFDSTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBOztBQUdBO0FBQ0E7QUFDQTs7QUFFQTs7QUFFQTtBQUNBO0FBQ0E7QUFFSDs7QUFFRDtBQUNJO0FBQ0E7QUFDSTtBQUNBO0FBRUk7QUFDQTtBQUNJO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFMa0I7QUFPdEI7QUFDQTtBQUNIO0FBQ0Q7QUFDQTtBQUNIO0FBQ0Q7QUFDSTtBQUNBO0FBQ0g7QUFDRDtBQUNJO0FBQ0g7QUFDRDtBQUNJO0FBQ0g7QUFDRDtBQUNBO0FBQ0k7QUFDQTtBQUNJO0FBQ0E7QUFFQTs7QUFFQTtBQUNBO0FBQ0k7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUxrQjtBQU90Qjs7QUFFQTtBQUNIO0FBQ0o7QUFDRDtBQUNJO0FBQ0E7QUFDSTtBQUNBO0FBRUE7O0FBRUE7QUFDQTtBQUNJO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFMbUI7QUFPdkI7O0FBRUE7QUFDSDtBQUNKO0FBQ0Q7QUFDSTtBQUNBO0FBQ0k7QUFDQTtBQUVBOztBQUVBO0FBQ0E7QUFDSTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBTG1CO0FBT3ZCOztBQUVBO0FBQ0g7QUFDSjtBQUNKOztBQUVEO0FBQ0k7O0FBSUE7QUFHSDs7QUFFRDtBQUNJO0FBQ0g7QUFDRDtBQUNJO0FBQ0E7QUFDQTtBQUNBO0FBQ0g7QUFDQTtBQUNEO0FBQ0k7QUFDQTtBQUNBO0FBQ0g7QUFDRDs7Ozs7OztBQU9BO0FBQ0k7QUFDQTtBQUNJO0FBQ0g7QUFDRDtBQUNJO0FBQ0g7QUFDRztBQUNIO0FBQ0Q7QUFDSTtBQUNBO0FBQ0E7QUFDQTtBQUprQjtBQU10QjtBQUNIO0FBNUxJOzs7Ozs7Ozs7O0FDQVQ7O0FBRUE7QUFDSTs7QUFFQTs7QUFFSTs7QUFFQTtBQUNBO0FBQ0E7QUFDSTtBQUNJO0FBQ0E7QUFDQTtBQUhVO0FBS2Q7QUFOTztBQVFYO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUdBO0FBQ0E7O0FBNUJROztBQWdDWjtBQUNBO0FBQ0k7QUFDQTtBQUNJO0FBQ0E7QUFDQTtBQUh5QjtBQUs3QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNDO0FBQ0E7QUFDSTtBQUNIO0FBQ0c7QUFDSjs7QUFFRDtBQUNBO0FBQ0E7QUFDQTtBQUNDOztBQUVEO0FBQ0E7QUFDSDs7QUFFRDs7Ozs7QUFLQTtBQUNJO0FBQ0E7QUFDQTtBQUVJO0FBQ0g7QUFDSjtBQUNEOzs7OztBQUtBO0FBQ0k7QUFDSDtBQUNEOzs7OztBQUtBO0FBQ0k7QUFDQTtBQUNBO0FBQ0g7QUFDRDs7Ozs7QUFLQTtBQUNJO0FBQ0E7QUFDSTtBQUNBO0FBQ0E7QUFDQTtBQUNIO0FBQ0Q7QUFDSTtBQUNBO0FBQ0E7QUFDQTtBQUNIO0FBQ0o7QUFDRDs7Ozs7QUFLQTtBQUNLO0FBQ0Q7QUFDSTtBQUNJO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0g7QUFDRDtBQUNBO0FBQ0E7QUFDSDs7QUFHRDtBQUNJO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0g7QUFDSjtBQUNEOzs7OztBQUtBOztBQUVJO0FBQ0E7QUFDSTtBQUNJO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDSDtBQUNEO0FBQ0E7QUFDSTtBQUVIO0FBQ0c7QUFFSDtBQUNHO0FBRUg7QUFDSjs7QUFHRDtBQUNJO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDSDtBQUVKO0FBQ0Q7Ozs7O0FBS0E7QUFDSTtBQUNBO0FBQ0E7QUFDSDtBQUNEOzs7OztBQUtBOztBQUVJO0FBQ0E7O0FBRUE7QUFDSTtBQUNBO0FBQ0E7O0FBRUE7O0FBRUE7QUFDQTtBQUNIO0FBQ0o7QUFDRDs7Ozs7QUFLQTtBQUNJO0FBQ0E7QUFDQTtBQUNBO0FBQ0k7QUFDQTtBQUNBO0FBQ0E7QUFDSTtBQUVIO0FBQ0c7QUFFSDtBQUNHO0FBRUg7O0FBRUQ7QUFDSDtBQUNKOztBQUdEOzs7Ozs7O0FBT0E7QUFDSTtBQUNBO0FBQ0k7QUFDSDtBQUNEO0FBQ0k7QUFDSDtBQUNHO0FBQ0g7QUFDRDtBQUNJO0FBQ0E7QUFDQTtBQUNBO0FBSmtCO0FBTXRCO0FBQ0g7QUFDRDs7Ozs7OztBQU9BO0FBQ0k7QUFDSDtBQUNEO0FBQ0E7QUFDSTtBQUNBO0FBQ0E7QUFDSTtBQUNJO0FBQ0E7QUFDQTtBQUNBO0FBQ0o7QUFDSTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNKO0FBQ0k7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUF4Q1I7QUEwQ0g7O0FBN1VJOzs7Ozs7Ozs7O0FDRlQ7QUFDSTs7QUFFQTtBQUNJO0FBQ0E7QUFDQTtBQUhROztBQWdCWjtBQUNBO0FBQ0k7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNIOztBQTFCSTs7Ozs7Ozs7OztBQ0FUO0FBQ0E7QUFDQTs7OztBQUlBO0FBQ0k7O0FBRUE7QUFDSTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUdBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTs7QUFFQTtBQXZDUTs7QUEwQ1o7O0FBRUk7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFSDs7QUFFRDs7Ozs7OztBQU9BO0FBQ0k7QUFDQTtBQUNBO0FBQ0k7QUFDSjtBQUNIOztBQUVEOzs7Ozs7O0FBT0E7QUFDSTtBQUNBO0FBQ0k7QUFFSTtBQUVIO0FBQ0c7QUFDSDtBQUNKO0FBQ0Q7QUFDQTtBQUNIOztBQUVEOzs7Ozs7O0FBT0E7QUFDSTtBQUNBO0FBQ0E7QUFDQTtBQUNJO0FBQ0E7QUFFQTtBQUNBO0FBRUg7QUFDRDtBQUNBO0FBQ0g7O0FBRUQ7Ozs7Ozs7QUFPQTtBQUErQjtBQUMzQjtBQUNBO0FBQ0E7O0FBRUk7QUFDQTtBQUNBOztBQUVQO0FBQ087QUFDSjtBQUNJO0FBQ0g7QUFDRztBQUNIO0FBQ0Q7QUFDQTtBQUNBO0FBQ0E7QUFDSDtBQUNEOzs7Ozs7OztBQVFBO0FBQ0k7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNJO0FBQ0g7QUFDRztBQUNIO0FBQ0Q7QUFDQTtBQUNIOztBQUVEOzs7Ozs7O0FBT0E7QUFBaUM7O0FBRTdCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTs7QUFFQTtBQUNBOztBQUVBOztBQUVBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBOztBQUVBOztBQUVBO0FBQ0g7QUFDRDs7Ozs7Ozs7QUFRQTtBQUNJO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7O0FBRUE7QUFDQTs7QUFFQTs7QUFFQTs7QUFFQTtBQUNBO0FBQ0E7QUFDSDtBQUNEOzs7Ozs7O0FBT0E7QUFBK0I7QUFDM0I7O0FBRUE7QUFDQTtBQUNBOztBQUdBO0FBQ0E7QUFDQTtBQUNBOzs7QUFJQTtBQUNBOztBQUVBOztBQUVBO0FBQ0g7QUFDRDs7Ozs7Ozs7QUFRQTtBQUFxQzs7QUFFakM7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDSDtBQUNEOzs7Ozs7O0FBT0E7QUFDSTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0g7O0FBRUQ7Ozs7O0FBS0E7QUFDSTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0k7O0FBRUk7QUFDQTtBQUNIO0FBQ0o7O0FBRUQ7QUFDUjtBQUVLOztBQTVXMEI7Ozs7Ozs7Ozs7QUNOL0I7QUFDQTtBQUNBO0FBQ0k7O0FBRUE7O0FBRUk7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7O0FBR0E7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7O0FBR0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDSTtBQUNBO0FBRkk7QUFJUjtBQUNJO0FBQ0E7QUFGSTs7QUFNUjtBQUNJO0FBQ0E7QUFGUTs7QUFLWjtBQUNJO0FBQ0E7QUFGUTs7QUFLWjtBQUNBO0FBQ0k7QUFDQTtBQUZPOztBQUtYOztBQUVBO0FBekRRO0FBcUVaO0FBQ0k7QUFDQTtBQUNBO0FBQ0g7QUFDRDtBQUNBO0FBQ0k7QUFDQTtBQUNBO0FBQ0k7QUFDQTtBQUNBO0FBQ0k7QUFDQTtBQUZNO0FBSVY7QUFDSTtBQUNBO0FBRlM7QUFJYjtBQUNBO0FBQ0k7QUFDSTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFOVTtBQVFkO0FBVEU7QUFXTjtBQXZCWTs7QUEwQmhCO0FBQ0E7QUFDQTtBQUNBO0FBRUg7O0FBaEhJOzs7Ozs7Ozs7O0FDRlQ7QUFDSTs7QUFFQTtBQUNJO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDSTtBQUNJO0FBQ0E7QUFDQTtBQUNBO0FBSlU7QUFNZDtBQVBHOztBQVVQO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBOUJROztBQWlDWjtBQUNBO0FBQ0k7QUFDSDs7QUFFRDtBQUNJO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDSDs7QUFFRDtBQUNJO0FBQ0E7QUFDSDs7QUFFRDtBQUNJO0FBQ0E7QUFDQTtBQUNBO0FBR0g7QUFDRDtBQUNJO0FBQ0E7QUFDQTtBQUNBO0FBQ0g7QUFDRDtBQUNJO0FBQ0E7QUFDQTtBQUNIO0FBQ0Q7QUFDSTtBQUNBO0FBQ0k7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBTmtCO0FBUXRCO0FBQ0E7QUFDSDtBQUNMO0FBQ0k7O0FBRUE7QUF6Rks7Ozs7Ozs7Ozs7QUNBVDs7QUFFQTtBQUNJOztBQUVBOztBQUVJO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBZFE7O0FBaUJaO0FBQ0E7QUFDSTtBQUNBO0FBQ0g7QUFDRDs7Ozs7OztBQU9BO0FBQ0k7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNJO0FBQ0E7QUFDQTtBQUNJO0FBQ0E7QUFDSTtBQUNBO0FBQ0E7QUFDSDs7QUFFRztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0g7QUFDSjtBQUNKO0FBQ0o7O0FBRUQ7Ozs7Ozs7QUFPQTtBQUNJO0FBQ0E7QUFFQTtBQUNIO0FBQ0Q7Ozs7Ozs7QUFPQTtBQUNJO0FBQ0E7QUFDSDtBQUNEO0FBQ0k7QUFDSDtBQUNEO0FBQ0E7O0FBRUE7QUF4Rks7Ozs7Ozs7Ozs7QUNGVDs7QUFFQTtBQUNJOztBQUVBOztBQUVJO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUExQ1E7QUE0Q1o7QUFDQTs7QUFFSTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0k7QUFDSTtBQUNBO0FBQ0g7QUFDRDtBQUNJO0FBQ0E7QUFDSDtBQUNKOztBQUVEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNDO0FBQ0o7QUFDRDtBQUNBO0FBQ0k7QUFDQTtBQUNJO0FBQ0g7QUFDSjtBQUNEO0FBQ0k7QUFDQTtBQUFxQztBQUNqQztBQUNIO0FBQ087QUFDSjtBQUNBO0FBRUg7QUFDTztBQUNKO0FBQ0E7QUFFSDtBQUNEO0FBQ0k7QUFDSDtBQUNEO0FBQ0k7QUFDSDtBQUNEO0FBQ0k7QUFDQTtBQUNIOztBQUVEO0FBQ0k7QUFDSDtBQUNHO0FBQ0g7O0FBRUQ7QUFDQTtBQUNBO0FBQ0g7O0FBRUQ7QUFDSTtBQUNBOztBQUVBO0FBQ0g7O0FBRUQ7QUFDSTtBQUNBO0FBQ0E7O0FBRUE7QUFDdUI7QUFBdUI7QUFFakQ7O0FBRUQ7QUFDQztBQUNDO0FBQ0E7QUFDTTtBQUNBO0FBQ047QUFDRTtBQUNIOztBQUVEO0FBQ0k7QUFDSTtBQUNIOztBQUVEO0FBQ0E7QUFDQTtBQUNIO0FBQ0Q7QUFDQTtBQUNJO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNIOztBQUVEO0FBQ0k7QUFDQTtBQUNJO0FBQ0E7QUFDSTtBQUNBO0FBQ0E7QUFDQTtBQUpJO0FBRjJCO0FBUzFDO0FBQ0Q7QUFDSTtBQUNBO0FBQ0E7QUFDSTtBQUNBO0FBQ0E7QUFDSTtBQUNJO0FBQ0E7QUFDSTtBQUNJO0FBQ0E7QUFDQTtBQUNKO0FBQ0E7QUFDSjtBQUNBO0FBQ1E7QUFDQTtBQUNBO0FBQ0o7QUFDSjtBQUNBO0FBQ0k7QUFDSTtBQUNBO0FBQ0g7QUFDRDtBQUNKO0FBQ0E7QUFDSTtBQUNJO0FBQ0E7QUFDSDtBQUNEO0FBNUJSO0FBOEJIO0FBQ0Q7QUFDQTtBQUNJO0FBQ0k7QUFDQTtBQUNJO0FBQ0E7QUFDQTtBQUNKO0FBQ0E7QUFDSTtBQUNBO0FBQ0E7QUFWUjtBQVlIO0FBakR1QjtBQW1EL0I7O0FBRUQ7QUFDQTtBQUNJO0FBQ0E7QUFDSDs7QUFFRDtBQUNJO0FBQ0E7QUFDSTs7QUFFQTtBQUNBO0FBQ0g7QUFDRDtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7O0FBRUE7O0FBS0E7QUFDSDs7QUFFRDtBQUNJO0FBQ0g7O0FBRUQ7O0FBclJLOzs7Ozs7Ozs7O0FDRlQ7QUFDSTtBQUNJO0FBQ0g7QUFFRztBQUNIO0FBQ0Q7QUFDSDs7QUFFRDtBQUNJOztBQUVBOztBQUdBO0FBQ0k7QUFDQTtBQUNIOztBQUVEO0FBQ0k7QUFDSDs7QUFFRDtBQUNJO0FBQ0g7QUFqQkk7Ozs7Ozs7Ozs7QUNWVDtBQUNJOztBQUVBO0FBQ0k7QUFDSTtBQUNBO0FBRlc7QUFJZjtBQUNJO0FBQ0E7QUFGVztBQUlmO0FBQ0k7QUFDQTtBQUZhO0FBVFQ7QUFzQlo7QUFDSTtBQUNJO0FBQ0k7QUFDQTtBQUNKO0FBQ0k7QUFDQTtBQUNKO0FBQ0k7QUFDQTtBQUNKO0FBQ0k7QUFDQTtBQUNKO0FBQ0k7QUFDQTtBQUNKO0FBQVM7QUFoQmI7QUFrQkg7QUFDRDtBQUNJO0FBQ0k7QUFDSTtBQUNBO0FBQ0o7QUFDSTtBQUNBO0FBQ0o7QUFDSTtBQUNBO0FBQ0o7QUFDSTtBQUNBO0FBQ0o7QUFDSTtBQUNBO0FBQ0o7QUFBUztBQWhCYjtBQWtCSDtBQUNEO0FBQ0k7QUFFSTtBQUNBO0FBQ0g7QUFDRztBQUNBO0FBQ0g7QUFDSjtBQUNEO0FBQ0E7QUFFSTtBQUNIO0FBQ0Q7QUFDSTtBQUNBO0FBQ0E7QUFDQTtBQUNIO0FBQ0c7QUFDQTtBQUNBO0FBQ0o7QUFDSTtBQUNBO0FBQ0k7QUFDSDtBQUNKOztBQTlGSTs7Ozs7Ozs7OztBQ0FUO0FBQ0E7QUFDSTs7QUFFQTtBQUNJO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNJO0FBQ0k7QUFDQTtBQUNBO0FBSFU7QUFLZDtBQU5LOztBQVNUO0FBQ0E7QUFoQlE7O0FBNkJaO0FBQ0E7QUFDSTtBQUNIO0FBQ0Q7QUFDSTtBQUNBO0FBQ0E7QUFDSTtBQUNIO0FBQ0c7QUFDSDtBQUdKO0FBQ0Q7QUFDSTtBQUNBO0FBQ0E7QUFDQTtBQUNJO0FBQ0k7QUFDSDtBQUNHO0FBQ0g7QUFDSjtBQUNKO0FBQ0Q7QUFDSTtBQUNJO0FBQ0k7QUFDSDtBQUNHO0FBQ0g7QUFHSjtBQUNHO0FBQ0k7QUFDSTtBQUNIO0FBQ0c7QUFDSDtBQUNKO0FBQ0c7QUFDSTtBQUNIO0FBQ0c7QUFDSDtBQUNKO0FBSUo7QUFDSjtBQUNEO0FBQ0k7QUFDQTtBQUNIOztBQUVEO0FBQ0E7QUFDSTtBQUNBO0FBQ0g7O0FBaEdJOzs7Ozs7Ozs7O0FDRFQ7Ozs7QUFJQTtBQUNJOztBQUVBO0FBQ0k7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBTlE7O0FBU1o7QUFDSTtBQUNIOztBQUdEOzs7O0FBSUE7QUFDSTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDSDtBQUNEO0FBQ0k7QUFDQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0g7O0FBRUQ7Ozs7O0FBS0E7QUFDSTtBQUNBO0FBQ0k7QUFDQTtBQUNJO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDSDtBQUNKOztBQUVEO0FBQ0E7QUFFSDs7QUF2RW1COzs7Ozs7Ozs7O0FDSnhCO0FBQ0k7O0FBRUE7QUFDSTtBQURROztBQWNaO0FBQ0k7QUFDSDtBQUNEO0FBQ0E7O0FBSUE7QUFDQTs7QUFFQTtBQTVCSzs7Ozs7Ozs7OztBQ0FUO0FBQ0k7O0FBRUE7QUFDSTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBWFE7O0FBY1o7QUFDSTtBQUNIO0FBQ0Q7QUFDQTs7QUFJQTtBQUNBOztBQUVBO0FBNUJLOzs7Ozs7Ozs7O0FDQVQ7QUFDQTtBQUNBO0FBQ0k7O0FBRUE7O0FBRUk7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBekJROztBQTRCWjtBQUNBO0FBQ0k7QUFDSDtBQUNEO0FBQ0k7QUFDQTs7QUFFQTtBQUNJO0FBQ0g7QUFDRztBQUNIO0FBQ0Q7QUFHQTtBQUdIO0FBQ0Q7Ozs7Ozs7QUFPQTtBQUNJO0FBQ0E7QUFDQTtBQUNIO0FBQ0Q7Ozs7Ozs7QUFPQTtBQUNJO0FBQ0E7QUFDSDtBQUNEOzs7Ozs7O0FBT0E7QUFDSTtBQUNJO0FBQ0E7QUFDQTtBQUNIO0FBQ0c7QUFDQTtBQUNBO0FBQ0g7QUFDSjtBQUNEOzs7Ozs7O0FBT0E7QUFDSTtBQUNJO0FBQ0E7QUFDQTtBQUNIO0FBQ0c7QUFDQTtBQUNBO0FBQ0g7QUFDSjtBQUNEOzs7Ozs7O0FBT0E7QUFDSTs7QUFFQTtBQUNBOztBQUVBO0FBQ0k7QUFDQTtBQUNBO0FBQ0g7QUFDRDtBQUNJO0FBQ0E7QUFDQTtBQUNIO0FBQ0o7QUFDRDtBQUNBOztBQUVBO0FBeklLOzs7Ozs7Ozs7O0FDRlQ7QUFDSTs7QUFFQTtBQUNJO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFqQlE7O0FBb0JaO0FBQ0E7QUFDSTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0g7O0FBRUQ7QUFDSTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDSDtBQUNEO0FBQ0k7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0g7O0FBRUQ7QUFDSTtBQUNBO0FBQ0k7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNIOztBQUVEO0FBQ0g7O0FBdkVJOzs7Ozs7Ozs7O0FDQVQ7QUFDSTs7QUFFQTs7QUFFSTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFwQlE7O0FBd0JaO0FBQ0E7QUFDSTtBQUNBO0FBQ0g7O0FBRUQ7QUFDSTtBQUNBO0FBQ0E7QUFDSTtBQUNIO0FBQ0c7QUFDSDs7QUFFRDtBQUNJO0FBQ0g7QUFDRztBQUNIO0FBQ0o7QUFDRDtBQUNJOztBQUVBO0FBQ0E7QUFDSzs7QUFFTDtBQUNBOztBQUVBO0FBQ0g7QUFDRDtBQUNJO0FBQ0E7QUFDQTtBQUNIOztBQUVEO0FBQ0k7O0FBRUE7QUFDSTtBQUNBO0FBQ0E7QUFDSDtBQUNKOztBQTFFSTs7Ozs7Ozs7OztBQ0FUO0FBQ0k7O0FBRUE7QUFDSTtBQUNBO0FBQ0E7QUFDSTtBQUNJO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQU5VO0FBUWQ7QUFURTtBQVdOO0FBQ0E7O0FBRUE7QUFqQlE7O0FBOEJaO0FBQ0E7QUFDSTtBQUNIO0FBQ0Q7QUFDSTs7QUFFQTtBQUNJO0FBQ0E7QUFDQTtBQUNIO0FBQ0o7QUFDRDtBQUNBO0FBQ0E7QUFDQTtBQUNDO0FBQ0Q7QUFDSTtBQUNIO0FBQ0Q7QUFDSTtBQUNIO0FBeERJOzs7Ozs7Ozs7O0FDQVQ7QUFDSTs7QUFFQTtBQUNJO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBVlE7O0FBYVo7QUFDQTtBQUNJOzs7QUFHSDtBQUNEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQzs7QUFHRDtBQUNBOztBQUVBO0FBakNLOzs7Ozs7Ozs7O0FDQVQ7QUFDSTs7QUFFQTtBQUNJO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTs7QUFFQTs7QUFFQTtBQWZROztBQTRCWjtBQUNBOztBQUdJO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0k7QUFDSDtBQUNEO0FBQ0E7QUFDSTtBQUNIO0FBQ0Q7QUFDQTtBQUNJO0FBQ0E7QUFDSDtBQUNEO0FBQ0E7QUFDSTtBQUNIOztBQUlEO0FBQ0k7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNJO0FBQ0E7QUFDQTtBQUNIO0FBQ0Q7QUFDQTtBQUNJO0FBQ0g7QUFDRDtBQUNBO0FBQ0k7QUFDSTtBQUNBO0FBQ0g7QUFDRDtBQUNIO0FBQ0Q7QUFDQTtBQUNJO0FBQ0E7QUFDSTtBQUNIO0FBQ0o7QUFDRDtBQUNBO0FBQ0k7QUFDSDtBQUNEO0FBQ0E7QUFDSTtBQUNIO0FBQ0Q7QUFDQTtBQUNJO0FBQ0E7QUFDSTtBQUNIO0FBQ0c7QUFDSDtBQUNHO0FBQ0g7QUFDRztBQUNIO0FBQ0c7QUFDSDtBQUNHO0FBQ0g7QUFDSjtBQUNKOztBQUdEO0FBQ0E7QUFFSDs7QUF2SEkiLCJzb3VyY2VzQ29udGVudCI6WyIvKipcclxuICogQOS4u+imgeWKn+iDvTogICDmlLvlh7vooYzkuLpcclxuICogQGF1dGhvciBrZW5hblxyXG4gKiBARGF0ZSAyMDE3LzcvMjMgMjo0MVxyXG4gKiBAdHlwZSB7RnVuY3Rpb259XHJcbiAqL1xyXG52YXIgYXR0YWNrQmVoYXZpb3IgPSBjYy5DbGFzcyh7XHJcbiAgICBleHRlbmRzOiBjYy5Db21wb25lbnQsXHJcblxyXG4gICAgcHJvcGVydGllczoge1xyXG4gICAgICAgIGF0azowLCAvL+eJqeeQhlxyXG5cdFx0bWF0azoxICAvL+mtlOazlVx0XHRcclxuICAgIH0sXHJcblxyXG4gICAgLyoqIOaUu+WHu+ihjOS4uiAxdjEg5Y2V5L2TXHJcbiAgICAgKiBAcGFyYW0gYXR0Y05vZGUgIOaUu+WHu+iKgueCuVxyXG4gICAgICogQHBhcmFtIG5vZGUgIOiiq+aUu+WHu+iKgueCuVxyXG4gICAgICogQHBhcmFtIG5vZGVUeXBlICDooqvmlLvlh7voioLngrnnsbvlnotcclxuICAgICAqL1xyXG4gICAgYXR0YWNrOiBmdW5jdGlvbiAoYXR0Y05vZGUsIE5vZGUsIG5vZGVUeXBlKXsgIFxyXG5cclxuICAgICAgICAvL+ebruagh+iiq+mUgOavgSAg5oiW6ICF5Li6bnVsbCAg5LiN5omn6KGMXHJcbiAgICAgICAgaWYoTm9kZSA9PSBudWxsIHx8ICFOb2RlLmlzVmFsaWQpe1xyXG4gICAgICAgICAgICByZXR1cm4gO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgLy/nlLPor7fohJrmnKxcclxuICAgICAgICB2YXIgc2NyaXB0ID0gbnVsbCxhdHRhY2tTY3JpcHQgPSBudWxsO1xyXG4gICAgICAgIC8v6KKr5pS75Ye76IqC54K557G75Z6L5LiN5ZCMXHJcbiAgICBcdGlmKG5vZGVUeXBlID09PSAxKXtcclxuICAgIFx0ICAgIHNjcmlwdCA9IE5vZGUuZ2V0Q29tcG9uZW50KCdQbGF5ZXInKTtcclxuICAgIFx0fWVsc2UgaWYobm9kZVR5cGUgPT09IDApe1xyXG4gICAgXHQgICAgc2NyaXB0ID0gTm9kZS5nZXRDb21wb25lbnQoJ0NyZWF0dXJlJyk7XHJcbiAgICBcdH1lbHNle1xyXG4gICAgICAgICAgICBzY3JpcHQgPSBOb2RlLmdldENvbXBvbmVudCgnQmFzZScpO1xyXG4gICAgICAgIH1cclxuICAgICAgICAvL+iOt+WPluWPkei1t+aUu+WHu+iAheeahOiEmuacrFxyXG4gICAgXHRhdHRhY2tTY3JpcHQgPSBhdHRjTm9kZS5nZXRDb21wb25lbnQoJ0NyZWF0dXJlJyk7XHJcbiAgICAgICAgXHJcbiAgICBcdC8vMeS8pOWus+iuoeeul1xyXG4gICAgICBcdC8vIHZhciBoaXRWYWx1ZSA9IGhpdFRyYW5zZm9ybShhdHRhY2tTY3JpcHQuYXR0YWNrLCBhdHRjTm9kZS5hdGtUeXBlLCBub2RlLmRlZlZhbHVlKTsgICAgIC8vYXRr5pS75Ye75YqbICAg5pS75Ye757G75Z6LICAgbm9kZeivpeexu+Wei+mYsuW+oeWAvFxyXG5cclxuICAgICAgICAvLzLkvKTlrrPlj43ppojnu5lub2RlICAga2VuYW4gIOWmguaenOiiq+aUu+WHu+WvueixoeW3suatu+S6oSDmuIXnqbrmlLvlh7vlr7nosaHnmoTnm67moIdcclxuICAgIFx0dmFyIGRlYWRGbGFnID0gc2NyaXB0LmNoYW5nZUhlYWx0aCgtIGF0dGFja1NjcmlwdC5hdHRhY2ssdGhpcy5ub2RlLnBhcmVudCk7XHJcbiAgICBcdGlmKGRlYWRGbGFnICE9IG51bGwgJiYgZGVhZEZsYWcgPT0gMSl7XHJcbiAgICAgICAgICAgIHNjcmlwdC5yZWxlYXNlVGFyZ2V0KCk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG59KTtcclxuIiwiY2MuQ2xhc3Moe1xyXG4gICAgZXh0ZW5kczogY2MuQ29tcG9uZW50LFxyXG5cclxuICAgIHByb3BlcnRpZXM6IHtcclxuICAgICAgICBmb2xsb3c6Y2MuTm9kZSxcclxuXHJcbiAgICAgICAgaGVybzogY2MuTm9kZSxcclxuICAgICAgICBjYW1lcmE6Y2MuTm9kZSxcclxuICAgICAgICAvLyBmb286IHtcclxuICAgICAgICAvLyAgICBkZWZhdWx0OiBudWxsLCAgICAgIC8vIFRoZSBkZWZhdWx0IHZhbHVlIHdpbGwgYmUgdXNlZCBvbmx5IHdoZW4gdGhlIGNvbXBvbmVudCBhdHRhY2hpbmdcclxuICAgICAgICAvLyAgICAgICAgICAgICAgICAgICAgICAgICAgIHRvIGEgbm9kZSBmb3IgdGhlIGZpcnN0IHRpbWVcclxuICAgICAgICAvLyAgICB1cmw6IGNjLlRleHR1cmUyRCwgIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIHR5cGVvZiBkZWZhdWx0XHJcbiAgICAgICAgLy8gICAgc2VyaWFsaXphYmxlOiB0cnVlLCAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyB0cnVlXHJcbiAgICAgICAgLy8gICAgdmlzaWJsZTogdHJ1ZSwgICAgICAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyB0cnVlXHJcbiAgICAgICAgLy8gICAgZGlzcGxheU5hbWU6ICdGb28nLCAvLyBvcHRpb25hbFxyXG4gICAgICAgIC8vICAgIHJlYWRvbmx5OiBmYWxzZSwgICAgLy8gb3B0aW9uYWwsIGRlZmF1bHQgaXMgZmFsc2VcclxuICAgICAgICAvLyB9LFxyXG4gICAgICAgIC8vIC4uLlxyXG4gICAgfSxcclxuXHJcbiAgICAvLyB1c2UgdGhpcyBmb3IgaW5pdGlhbGl6YXRpb25cclxuICAgIG9uTG9hZDogZnVuY3Rpb24gKCkge1xyXG4gICAgICAgIHRoaXMuZm9sbG93ID0gdGhpcy5oZXJvO1xyXG4gICAgfSxcclxuICAgIHVwZGF0ZTogZnVuY3Rpb24oKXtcclxuICAgICAgICBpZih0aGlzLmZvbGxvdy54IDwgY2MuZGlyZWN0b3IuZ2V0V2luU2l6ZSgpLndpZHRoIC8gMilcclxuICAgICAgICB7XHJcbiAgICAgICAgICAgIHRoaXMubm9kZS54ID0gLSBjYy5kaXJlY3Rvci5nZXRXaW5TaXplKCkud2lkdGggLyAyO1xyXG4gICAgICAgIH1lbHNlIGlmKHRoaXMuZm9sbG93LnggPiBjYy5kaXJlY3Rvci5nZXRXaW5TaXplKCkud2lkdGggKiAyLjUpe1xyXG4gICAgICAgICAgICB0aGlzLm5vZGUueCA9IC0gY2MuZGlyZWN0b3IuZ2V0V2luU2l6ZSgpLndpZHRoICogMi41O1xyXG4gICAgICAgIH1lbHNle1xyXG4gICAgICAgICAgICB0aGlzLm5vZGUueCA9IC0gdGhpcy5mb2xsb3cueDtcclxuICAgICAgICB9XHJcbiAgICB9LFxyXG5cclxuICAgIC8vIGNhbGxlZCBldmVyeSBmcmFtZSwgdW5jb21tZW50IHRoaXMgZnVuY3Rpb24gdG8gYWN0aXZhdGUgdXBkYXRlIGNhbGxiYWNrXHJcbiAgICAvLyB1cGRhdGU6IGZ1bmN0aW9uIChkdCkge1xyXG5cclxuICAgIC8vIH0sXHJcbn0pO1xyXG4iLCJ2YXIgZ2xvYmFsQ29uc3RhbnQgPSByZXF1aXJlKFwiQ29uc3RhbnRcIik7XHJcbmNjLkNsYXNzKHtcclxuICAgIGV4dGVuZHM6IGNjLkNvbXBvbmVudCxcclxuXHJcbiAgICBwcm9wZXJ0aWVzOiB7XHJcbiAgICAgICAgdGVhbTowLFxyXG4gICAgICAgIGhlYWx0aDowLFxyXG4gICAgICAgIGVsZW1lbnQ6W2NjLk5vZGVdLFxyXG5cclxuICAgICAgICBoZWFsdGhMYWJlbDpjYy5MYWJlbCxcclxuXHJcbiAgICAgICAgYXVkaW9Tb3VyY2U6IGNjLkF1ZGlvQ2xpcCxcclxuXHJcbiAgICAgICAgLy8gZm9vOiB7XHJcbiAgICAgICAgLy8gICAgZGVmYXVsdDogbnVsbCwgICAgICAvLyBUaGUgZGVmYXVsdCB2YWx1ZSB3aWxsIGJlIHVzZWQgb25seSB3aGVuIHRoZSBjb21wb25lbnQgYXR0YWNoaW5nXHJcbiAgICAgICAgLy8gICAgICAgICAgICAgICAgICAgICAgICAgICB0byBhIG5vZGUgZm9yIHRoZSBmaXJzdCB0aW1lXHJcbiAgICAgICAgLy8gICAgdXJsOiBjYy5UZXh0dXJlMkQsICAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyB0eXBlb2YgZGVmYXVsdFxyXG4gICAgICAgIC8vICAgIHNlcmlhbGl6YWJsZTogdHJ1ZSwgLy8gb3B0aW9uYWwsIGRlZmF1bHQgaXMgdHJ1ZVxyXG4gICAgICAgIC8vICAgIHZpc2libGU6IHRydWUsICAgICAgLy8gb3B0aW9uYWwsIGRlZmF1bHQgaXMgdHJ1ZVxyXG4gICAgICAgIC8vICAgIGRpc3BsYXlOYW1lOiAnRm9vJywgLy8gb3B0aW9uYWxcclxuICAgICAgICAvLyAgICByZWFkb25seTogZmFsc2UsICAgIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIGZhbHNlXHJcbiAgICAgICAgLy8gfSxcclxuICAgICAgICAvLyAuLi5cclxuICAgIH0sXHJcblxyXG4gICAgLy8gdXNlIHRoaXMgZm9yIGluaXRpYWxpemF0aW9uXHJcbiAgICBvbkxvYWQ6IGZ1bmN0aW9uICgpIHtcclxuICAgICAgICB0aGlzLmhlYWx0aCA9IDIwMDtcclxuICAgICAgICB0aGlzLmhlYWx0aExhYmVsLnN0cmluZyA9IHRoaXMuaGVhbHRoO1xyXG4gICAgfSxcclxuICAgIGluaXQ6ZnVuY3Rpb24oZWxlbWVudCxvZmZzZXQsdGVhbSl7XHJcbiAgICAgICAgdGhpcy50ZWFtID0gdGVhbTtcclxuICAgICAgICB0aGlzLm5vZGUueCA9IG9mZnNldCArIGNjLmRpcmVjdG9yLmdldFdpblNpemUoKS53aWR0aCpnbG9iYWxDb25zdGFudC5zY2VuZVdpZHRoLzI7XHJcbiAgICAgICAgdGhpcy5pbml0RWxlbWVudChlbGVtZW50KTtcclxuICAgIH0sXHJcbiAgICBpbml0RWxlbWVudDpmdW5jdGlvbihlbGVtZW50KXtcclxuICAgICAgICB2YXIgaTtcclxuICAgICAgICBmb3IoaSA9IDA7aTwzO2krKyl7XHJcbiAgICAgICAgICAgIGlmKGkgIT09IGVsZW1lbnQpe1xyXG4gICAgICAgICAgICAgICAgdGhpcy5lbGVtZW50W2ldLmFjdGl2ZSA9IGZhbHNlO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgfSxcclxuXHJcbiAgICBjaGFuZ2VIZWFsdGg6ZnVuY3Rpb24odmFsdWUpe1xyXG4gICAgICAgIHRoaXMuaGVhbHRoICs9IHZhbHVlO1xyXG4gICAgICAgIHRoaXMuaGVhbHRoTGFiZWwuc3RyaW5nID0gdGhpcy5oZWFsdGg7XHJcbiAgICAgICAgaWYodGhpcy5oZWFsdGggPD0gMCl7XHJcbiAgICAgICAgICAgIHJldHVybiAxO1xyXG4gICAgICAgIH1cclxuICAgIH0sXHJcblxyXG4gICAgcmVsZWFzZVRhcmdldDpmdW5jdGlvbigpe1xyXG5cclxuICAgICAgICB2YXIgZXZlbnRzZW5kID0gbmV3IGNjLkV2ZW50LkV2ZW50Q3VzdG9tKCdpc1dpbicsdHJ1ZSk7XHJcblxyXG5cclxuICAgICAgICBpZih0aGlzLnRlYW0gPT09IHRoaXMuaGVyby50ZWFtKXtcclxuICAgICAgICAgICAgZXZlbnRzZW5kLnNldFVzZXJEYXRhKHt3aW46MH0pO1xyXG4gICAgICAgIH1lbHNle1xyXG4gICAgICAgICAgICBjYy5sb2coXCJ5b3Ugd2luISEhISEhISEhISEhISEhXCIpO1xyXG4gICAgICAgICAgICBldmVudHNlbmQuc2V0VXNlckRhdGEoe3dpbjoxfSk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICB0aGlzLm5vZGUuZGlzcGF0Y2hFdmVudChldmVudHNlbmQpO1xyXG4gICAgfVxyXG5cclxuICAgIC8vIGNhbGxlZCBldmVyeSBmcmFtZSwgdW5jb21tZW50IHRoaXMgZnVuY3Rpb24gdG8gYWN0aXZhdGUgdXBkYXRlIGNhbGxiYWNrXHJcbiAgICAvLyB1cGRhdGU6IGZ1bmN0aW9uIChkdCkge1xyXG5cclxuICAgIC8vIH0sXHJcbn0pO1xyXG4iLCIvKipcclxuICogQOS4u+imgeWKn+iDvTogICDliJvlu7pucGPnsbtcclxuICogQHR5cGUge0Z1bmN0aW9ufVxyXG4gKi9cclxudmFyIGJ1dHRvbkNsYXNzID0gY2MuQ2xhc3Moe1xyXG4gICAgZXh0ZW5kczogY2MuQ29tcG9uZW50LFxyXG5cclxuICAgIHByb3BlcnRpZXM6IHtcclxuICAgICAgICBidXR0b246IGNjLkJ1dHRvbixcclxuICAgICAgICBlbmVteTogY2MuTm9kZSxcclxuICAgICAgICB0ZWFtOiAwLFxyXG4gICAgICAgIFxyXG4gICAgICAgIGRlbGF5OjAsXHJcbiAgICB9LFxyXG5cclxuXHJcbiAgICBvbkxvYWQ6IGZ1bmN0aW9uKCl7XHJcbiAgICAgICAgdGhpcy5kZWxheSA9IDUwO1xyXG4gICAgfSxcclxuXHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBA5Li76KaB5Yqf6IO9OiAg54K55Ye75LqL5Lu2ICBucGPliJvlu7rkuovku7YgICAgIOmcgOimgeivtOaYjueahOaYr25wY+WxnuaAp+S7peWQjumcgOimgeS4k+mXqOeahGJ1ZmblsZ7mgKfnrqHnkIblmahqc+euoeeQhiAg5bm25o+Q5L6b5Zue6LCD5Ye95pWw77yM5bm25LiU5pyA5aW95Lqk55Sx5Yib5bu657G75Y676LCD55So5aSE55CG44CCXHJcbiAgICAgKiBAcGFyYW0gZXZlbnRcclxuICAgICAqIEBwYXJhbSBjdXN0b21FdmVudERhdGFcclxuICAgICAqL1xyXG4gICAgb25CdXR0b25Ub3VjaEV2ZW50OiBmdW5jdGlvbiAoZXZlbnQsY3VzdG9tRXZlbnREYXRhKSB7XHJcbiAgICAgICAgdmFyIGV2ZW50c2VuZCA9IG5ldyBjYy5FdmVudC5FdmVudEN1c3RvbSgnY3JlYXR1cmVDcmVhdGUnLHRydWUpO1xyXG4gICAgICAgIGlmKHRoaXMudGVhbSA9PT0gLTEpe1xyXG4gICAgICAgICAgICBldmVudHNlbmQuc2V0VXNlckRhdGEoe1g6KDUxMiArIHRoaXMudGVhbSoyMDApLFk6LTk1LGF0dGFjazoyLGhlYWx0aDoyMCx0ZWFtOnRoaXMudGVhbSx2ZWxvY2l0eToyLGlkOjB9KTtcclxuICAgICAgICB9ZWxzZXtcclxuICAgICAgICAgICAgZXZlbnRzZW5kLnNldFVzZXJEYXRhKHtYOig1MTIgKyB0aGlzLnRlYW0qMjAwKSxZOi05NSxhdHRhY2s6MixoZWFsdGg6MTAsdGVhbTp0aGlzLnRlYW0sdmVsb2NpdHk6MyxpZDoxfSk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIC8vY2MuZXZlbnRNYW5hZ2VyLmRpc3BhdGNoRXZlbnQoZXZlbnQpOyAgXHJcbiAgICAgICAgdGhpcy5ub2RlLmRpc3BhdGNoRXZlbnQoZXZlbnRzZW5kKTtcclxuXHJcbiAgICAgICAgLy8gY2MubG9nKFwib25CdXR0b25Ub3VjaEV2ZW505LqL5Lu25Y+R5bCE5ZCOXCIpXHJcbiAgICB9LFxyXG5cclxuICAgIFxyXG59KTtcclxuIiwiLy/mnIjlhYnomasgMei0ueeUn+eJqSAx5pS7LTfooYDvvIhpZCAwMDAw55Sf54mp77yJXHJcbi8v5peg5pWI5p6c44CCXHJcbnZhciBnbG9iYWxDb25zdGFudCA9IHJlcXVpcmUoXCJDb25zdGFudFwiKTtcclxuXHJcbmNjLkNsYXNzKHtcclxuICAgIGV4dGVuZHM6IGNjLkNvbXBvbmVudCxcclxuXHJcbiAgICBwcm9wZXJ0aWVzOiB7XHJcblxyXG4gICAgfSxcclxuXHJcbiAgICAvLyB1c2UgdGhpcyBmb3IgaW5pdGlhbGl6YXRpb25cclxuICAgIG9uTG9hZDogZnVuY3Rpb24gKCkge1xyXG4gICAgICAgIHRoaXMuY3JlZXBTY3JpcHQgPSB0aGlzLm5vZGUuZ2V0Q29tcG9uZW50KCdDcmVlcENhcmQnKTtcclxuICAgICAgICB0aGlzLmNhcmRTY3JpcHQgPSB0aGlzLm5vZGUuZ2V0Q29tcG9uZW50KCdDYXJkJyk7XHJcbiAgICB9LFxyXG4gICAgXHJcblxyXG4gICAgXHJcbiAgICBnZXRVc2VTdGF0ZTogZnVuY3Rpb24oKXtcclxuICAgICAgICByZXR1cm4gdHJ1ZTtcclxuICAgIH0sXHJcbiAgICBcclxuICAgIHVzZUNhcmQ6IGZ1bmN0aW9uKCl7XHJcbiAgICAgICAgdmFyIGV2ZW50c2VuZCA9IG5ldyBjYy5FdmVudC5FdmVudEN1c3RvbSgnY3JlYXR1cmVDcmVhdGUnLHRydWUpO1xyXG4gICAgICAgIHZhciBwb3NpdGlvbiA9IHRoaXMubm9kZS54ICsgZ2xvYmFsQ29uc3RhbnQuY2FtZXJhT2Zmc2V0ICsgY2MuZGlyZWN0b3IuZ2V0V2luU2l6ZSgpLndpZHRoICogZ2xvYmFsQ29uc3RhbnQuc2NlbmVFZGdlO1xyXG4gICAgICAgICAgICBldmVudHNlbmQuc2V0VXNlckRhdGEoe1xyXG4gICAgICAgICAgICAgICAgWDowLFxyXG4gICAgICAgICAgICAgICAgWTpudWxsLFxyXG4gICAgICAgICAgICAgICAgYXR0YWNrOnRoaXMuY3JlZXBTY3JpcHQuYXR0YWNrLFxyXG4gICAgICAgICAgICAgICAgaGVhbHRoOnRoaXMuY3JlZXBTY3JpcHQuaGVhbHRoLFxyXG4gICAgICAgICAgICAgICAgdGVhbTp0aGlzLmNhcmRTY3JpcHQudGVhbSxcclxuICAgICAgICAgICAgICAgIGlkOnRoaXMuY2FyZFNjcmlwdC5jYXJkSUQsXHJcbiAgICAgICAgICAgICAgICB2ZWxvY2l0eTp0aGlzLmNyZWVwU2NyaXB0LnZlbG9jaXR5XHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgIHRoaXMubm9kZS5kaXNwYXRjaEV2ZW50KGV2ZW50c2VuZCk7XHJcblxyXG4gICAgICAgIHRoaXMuY2FyZFNjcmlwdC5kcmF3Q2FyZFNjcmlwdC5kZWxldGVDYXJkKHRoaXMubm9kZSk7XHJcbiAgICB9XHJcbiAgICAvLyBjYWxsZWQgZXZlcnkgZnJhbWUsIHVuY29tbWVudCB0aGlzIGZ1bmN0aW9uIHRvIGFjdGl2YXRlIHVwZGF0ZSBjYWxsYmFja1xyXG4gICAgLy8gdXBkYXRlOiBmdW5jdGlvbiAoZHQpIHtcclxuXHJcbiAgICAvLyB9LFxyXG59KTsiLCJ2YXIgZ2xvYmFsQ29uc3RhbnQgPSByZXF1aXJlKFwiQ29uc3RhbnRcIik7XHJcblxyXG5jYy5DbGFzcyh7XHJcbiAgICBleHRlbmRzOiBjYy5Db21wb25lbnQsXHJcblxyXG4gICAgcHJvcGVydGllczoge1xyXG4gICAgICAgIFxyXG4gICAgfSxcclxuXHJcbiAgICAvLyB1c2UgdGhpcyBmb3IgaW5pdGlhbGl6YXRpb25cclxuICAgIG9uTG9hZDogZnVuY3Rpb24gKCkge1xyXG4gICAgICAgIHZhciBzZWxmID0gdGhpcztcclxuICAgICAgICBzZWxmLmNyZWVwU2NyaXB0ID0gdGhpcy5ub2RlLmdldENvbXBvbmVudCgnQ3JlZXBDYXJkJyk7XHJcbiAgICAgICAgc2VsZi5jYXJkU2NyaXB0ID0gc2VsZi5ub2RlLmdldENvbXBvbmVudCgnQ2FyZCcpO1xyXG4gICAgfSxcclxuXHJcbiAgICBcclxuICAgIGdldFVzZVN0YXRlOiBmdW5jdGlvbigpe1xyXG4gICAgICAgIHZhciBzdGF0ZTtcclxuICAgICAgICB2YXIgc2VsZiA9IHRoaXM7XHJcbiAgICAgICAgaWYoc2VsZi5jYXJkU2NyaXB0Lmhlcm8ueCAtIDIwMCA8IHRoaXMubm9kZS54ICsgdGhpcy5ub2RlLnBhcmVudC54IC0gdGhpcy5yb2xsLnggJiZcclxuICAgICAgICAgICBzZWxmLmNhcmRTY3JpcHQuaGVyby54ICsgMjAwID4gdGhpcy5ub2RlLnggKyB0aGlzLm5vZGUucGFyZW50LnggLSB0aGlzLnJvbGwueCApe1xyXG4gICAgICAgICAgICAgICBzdGF0ZSA9IHRydWU7XHJcbiAgICAgICAgICAgfWVsc2V7XHJcbiAgICAgICAgICAgICAgIHN0YXRlID0gZmFsc2U7XHJcbiAgICAgICAgICAgfVxyXG4gICAgICAgIHJldHVybiBzdGF0ZTtcclxuICAgIH0sXHJcbiAgICBcclxuICAgIHVzZUNhcmQ6IGZ1bmN0aW9uKCl7XHJcbiAgICAgICAgdmFyIGV2ZW50c2VuZCA9IG5ldyBjYy5FdmVudC5FdmVudEN1c3RvbSgnY3JlYXR1cmVDcmVhdGUnLHRydWUpO1xyXG4gICAgICAgIHZhciBwb3NpdGlvbiA9IHRoaXMubm9kZS54ICsgZ2xvYmFsQ29uc3RhbnQuY2FtZXJhT2Zmc2V0ICsgY2MuZGlyZWN0b3IuZ2V0V2luU2l6ZSgpLndpZHRoICogZ2xvYmFsQ29uc3RhbnQuc2NlbmVFZGdlO1xyXG4gICAgICAgICAgICBldmVudHNlbmQuc2V0VXNlckRhdGEoe1xyXG4gICAgICAgICAgICAgICAgWDpwb3NpdGlvbixcclxuICAgICAgICAgICAgICAgIFk6bnVsbCxcclxuICAgICAgICAgICAgICAgIGF0dGFjazp0aGlzLmNyZWVwU2NyaXB0LmF0dGFjayxcclxuICAgICAgICAgICAgICAgIGhlYWx0aDp0aGlzLmNyZWVwU2NyaXB0LmhlYWx0aCxcclxuICAgICAgICAgICAgICAgIHRlYW06dGhpcy5jYXJkU2NyaXB0LnRlYW0sXHJcbiAgICAgICAgICAgICAgICBpZDp0aGlzLmNhcmRTY3JpcHQuY2FyZElELFxyXG4gICAgICAgICAgICAgICAgdmVsb2NpdHk6dGhpcy5jcmVlcFNjcmlwdC52ZWxvY2l0eVxyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICB0aGlzLm5vZGUuZGlzcGF0Y2hFdmVudChldmVudHNlbmQpO1xyXG5cclxuICAgICAgICB0aGlzLmNhcmRTY3JpcHQuZHJhd0NhcmRTY3JpcHQuZGVsZXRlQ2FyZCh0aGlzLm5vZGUpO1xyXG4gICAgfVxyXG4gICAgLy8gY2FsbGVkIGV2ZXJ5IGZyYW1lLCB1bmNvbW1lbnQgdGhpcyBmdW5jdGlvbiB0byBhY3RpdmF0ZSB1cGRhdGUgY2FsbGJhY2tcclxuICAgIC8vIHVwZGF0ZTogZnVuY3Rpb24gKGR0KSB7XHJcblxyXG4gICAgLy8gfSxcclxufSk7IiwiLy/vv73Cue+/ve+/ve+/vSAx77+977+977+977+977+977+9IDHvv73vv70tN9Gq77+977+9aWQgMDAwMO+/ve+/ve+/ve+jqVxyXG4vL++/ve+/vdCn77+977+977+977+9XHJcbnZhciBnbG9iYWxDb25zdGFudCA9IHJlcXVpcmUoXCJDb25zdGFudFwiKTtcclxuXHJcbmNjLkNsYXNzKHtcclxuICAgIGV4dGVuZHM6IGNjLkNvbXBvbmVudCxcclxuXHJcbiAgICBwcm9wZXJ0aWVzOiB7XHJcblxyXG4gICAgfSxcclxuXHJcbiAgICAvLyB1c2UgdGhpcyBmb3IgaW5pdGlhbGl6YXRpb25cclxuICAgIG9uTG9hZDogZnVuY3Rpb24gKCkge1xyXG4gICAgICAgIHRoaXMuY3JlZXBTY3JpcHQgPSB0aGlzLm5vZGUuZ2V0Q29tcG9uZW50KCdDcmVlcENhcmQnKTtcclxuICAgICAgICB0aGlzLmNhcmRTY3JpcHQgPSB0aGlzLm5vZGUuZ2V0Q29tcG9uZW50KCdDYXJkJyk7XHJcbiAgICB9LFxyXG5cclxuXHJcblxyXG4gICAgZ2V0VXNlU3RhdGU6IGZ1bmN0aW9uKCl7XHJcbiAgICAgICAgcmV0dXJuIHRydWU7XHJcbiAgICB9LFxyXG5cclxuICAgIHVzZUNhcmQ6IGZ1bmN0aW9uKCl7XHJcbiAgICAgICAgdmFyIGV2ZW50c2VuZCA9IG5ldyBjYy5FdmVudC5FdmVudEN1c3RvbSgnY3JlYXR1cmVDcmVhdGUnLHRydWUpO1xyXG4gICAgICAgIHZhciBwb3NpdGlvbiA9IHRoaXMubm9kZS54ICsgZ2xvYmFsQ29uc3RhbnQuY2FtZXJhT2Zmc2V0ICsgY2MuZGlyZWN0b3IuZ2V0V2luU2l6ZSgpLndpZHRoICogZ2xvYmFsQ29uc3RhbnQuc2NlbmVFZGdlO1xyXG4gICAgICAgIGV2ZW50c2VuZC5zZXRVc2VyRGF0YSh7XHJcbiAgICAgICAgICAgIFg6MCxcclxuICAgICAgICAgICAgWTpudWxsLFxyXG4gICAgICAgICAgICBhdHRhY2s6dGhpcy5jcmVlcFNjcmlwdC5hdHRhY2ssXHJcbiAgICAgICAgICAgIGhlYWx0aDp0aGlzLmNyZWVwU2NyaXB0LmhlYWx0aCxcclxuICAgICAgICAgICAgdGVhbTp0aGlzLmNhcmRTY3JpcHQudGVhbSxcclxuICAgICAgICAgICAgaWQ6dGhpcy5jYXJkU2NyaXB0LmNhcmRJRCxcclxuICAgICAgICAgICAgdmVsb2NpdHk6dGhpcy5jcmVlcFNjcmlwdC52ZWxvY2l0eVxyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIHRoaXMubm9kZS5kaXNwYXRjaEV2ZW50KGV2ZW50c2VuZCk7XHJcblxyXG4gICAgICAgIHRoaXMuY2FyZFNjcmlwdC5kcmF3Q2FyZFNjcmlwdC5kZWxldGVDYXJkKHRoaXMubm9kZSk7XHJcbiAgICB9XHJcbiAgICAvLyBjYWxsZWQgZXZlcnkgZnJhbWUsIHVuY29tbWVudCB0aGlzIGZ1bmN0aW9uIHRvIGFjdGl2YXRlIHVwZGF0ZSBjYWxsYmFja1xyXG4gICAgLy8gdXBkYXRlOiBmdW5jdGlvbiAoZHQpIHtcclxuXHJcbiAgICAvLyB9LFxyXG59KTsiLCJ2YXIgZ2xvYmFsQ29uc3RhbnQgPSByZXF1aXJlKFwiQ29uc3RhbnRcIik7XHJcblxyXG5jYy5DbGFzcyh7XHJcbiAgICBleHRlbmRzOiBjYy5Db21wb25lbnQsXHJcblxyXG4gICAgcHJvcGVydGllczoge1xyXG4gICAgICAgIHRhcmdldDoge1xyXG4gICAgICAgICAgICBkZWZhdWx0OiBudWxsLFxyXG4gICAgICAgICAgICB0eXBlOiBjYy5Ob2RlXHJcbiAgICAgICAgfSxcclxuXHJcbiAgICAgICAgdGFyZ2V0czoge1xyXG4gICAgICAgICAgICBkZWZhdWx0OiBbXSxcclxuICAgICAgICAgICAgdHlwZTogW2NjLk5vZGVdLFxyXG4gICAgICAgIH0sXHJcbiAgICAgICAgLy/vv73vv73vv73vv73vv73Gtu+/ve+/ve+/vc6n77+977+977+977+9XHJcbiAgICAgICAgYXJlYUxlZnQ6MCxcclxuICAgICAgICBhcmVhUmlnaHQ6MCxcclxuXHJcbiAgICAgICAgbWFpblNjZW5lOmZhbHNlLFxyXG4gICAgICAgIC8vIGZvbzoge1xyXG4gICAgICAgIC8vICAgIGRlZmF1bHQ6IG51bGwsICAgICAgLy8gVGhlIGRlZmF1bHQgdmFsdWUgd2lsbCBiZSB1c2VkIG9ubHkgd2hlbiB0aGUgY29tcG9uZW50IGF0dGFjaGluZ1xyXG4gICAgICAgIC8vICAgICAgICAgICAgICAgICAgICAgICAgICAgdG8gYSBub2RlIGZvciB0aGUgZmlyc3QgdGltZVxyXG4gICAgICAgIC8vICAgIHVybDogY2MuVGV4dHVyZTJELCAgLy8gb3B0aW9uYWwsIGRlZmF1bHQgaXMgdHlwZW9mIGRlZmF1bHRcclxuICAgICAgICAvLyAgICBzZXJpYWxpemFibGU6IHRydWUsIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIHRydWVcclxuICAgICAgICAvLyAgICB2aXNpYmxlOiB0cnVlLCAgICAgIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIHRydWVcclxuICAgICAgICAvLyAgICBkaXNwbGF5TmFtZTogJ0ZvbycsIC8vIG9wdGlvbmFsXHJcbiAgICAgICAgLy8gICAgcmVhZG9ubHk6IGZhbHNlLCAgICAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyBmYWxzZVxyXG4gICAgICAgIC8vIH0sXHJcbiAgICAgICAgLy8gLi4uXHJcbiAgICB9LFxyXG5cclxuICAgIC8vIHVzZSB0aGlzIGZvciBpbml0aWFsaXphdGlvblxyXG4gICAgb25Mb2FkOiBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgdGhpcy5jYW1lcmEgPSB0aGlzLmdldENvbXBvbmVudChjYy5DYW1lcmEpO1xyXG4gICAgICAgIGlmKHRoaXMubWFpblNjZW5lID09PSBmYWxzZSl7XHJcbiAgICAgICAgICAgIHRoaXMuYXJlYVJpZ2h0ID0gZ2xvYmFsQ29uc3RhbnQuc2NlbmVXaWR0aDtcclxuICAgICAgICB9XHJcbiAgICB9LFxyXG5cclxuICAgIC8vIGNhbGxlZCBldmVyeSBmcmFtZSwgdW5jb21tZW50IHRoaXMgZnVuY3Rpb24gdG8gYWN0aXZhdGUgdXBkYXRlIGNhbGxiYWNrXHJcbiAgICBsYXRlVXBkYXRlOiBmdW5jdGlvbiAoZHQpIHtcclxuICAgICAgICB2YXIgdGFyZ2V0UG9zID0gdGhpcy50YXJnZXQuY29udmVydFRvV29ybGRTcGFjZUFSKGNjLlZlYzIuWkVSTyk7XHJcbiAgICAgICAgdmFyIHBvc2l0aW9uID0gdGhpcy5ub2RlLnBhcmVudC5jb252ZXJ0VG9Ob2RlU3BhY2VBUih0YXJnZXRQb3MpO1xyXG5cclxuICAgICAgICBpZihwb3NpdGlvbi54ID4gY2MuZGlyZWN0b3IuZ2V0V2luU2l6ZSgpLndpZHRoICogKHRoaXMuYXJlYVJpZ2h0IC0gZ2xvYmFsQ29uc3RhbnQuc2NlbmVFZGdlKSl7XHJcbiAgICAgICAgICAgIHRoaXMubm9kZS54ID0gY2MuZGlyZWN0b3IuZ2V0V2luU2l6ZSgpLndpZHRoICogKHRoaXMuYXJlYVJpZ2h0IC0gZ2xvYmFsQ29uc3RhbnQuc2NlbmVFZGdlKTtcclxuICAgICAgICB9ZWxzZSBpZihwb3NpdGlvbi54IDwgY2MuZGlyZWN0b3IuZ2V0V2luU2l6ZSgpLndpZHRoICogZ2xvYmFsQ29uc3RhbnQuc2NlbmVFZGdlKXtcclxuICAgICAgICAgICAgdGhpcy5ub2RlLnggPSBjYy5kaXJlY3Rvci5nZXRXaW5TaXplKCkud2lkdGggKiBnbG9iYWxDb25zdGFudC5zY2VuZUVkZ2U7XHJcbiAgICAgICAgfWVsc2Uge1xyXG4gICAgICAgICAgICB0aGlzLm5vZGUueCA9IHBvc2l0aW9uLng7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICB2YXIgcmF0aW8gPSB0YXJnZXRQb3MueSAvIGNjLndpblNpemUuaGVpZ2h0O1xyXG4gICAgICAgIHRoaXMuY2FtZXJhLnpvb21SYXRpbyA9IDEgKyAoMC41IC0gcmF0aW8pICogMC41O1xyXG4gICAgfSxcclxufSk7XHJcbiIsImNjLkNsYXNzKHtcclxuICAgIGV4dGVuZHM6IGNjLkNvbXBvbmVudCxcclxuXHJcbiAgICBwcm9wZXJ0aWVzOiB7XHJcbiAgICAgICAgdGFyZ2V0OiB7XHJcbiAgICAgICAgICAgIGRlZmF1bHQ6IG51bGwsXHJcbiAgICAgICAgICAgIHR5cGU6IGNjLk5vZGVcclxuICAgICAgICB9XHJcbiAgICB9LFxyXG5cclxuICAgIC8vIHVzZSB0aGlzIGZvciBpbml0aWFsaXphdGlvblxyXG4gICAgb25Mb2FkOiBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgLy8g55Sx5LqO6ZyA6KaB6ZSu55uY5pON5L2c5omA5Lul5Y+q6IO95ZyoIFBDIOaJjeWPr+eUqFxyXG4gICAgICAgIHRoaXMubm9kZS5hY3RpdmUgPSAhY2Muc3lzLmlzTW9iaWxlO1xyXG5cclxuICAgICAgICBpZiAoIXRoaXMudGFyZ2V0KSB7XHJcbiAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICB9XHJcbiAgICAgICAgdmFyIGZvbGxvdyA9IGNjLmZvbGxvdyh0aGlzLnRhcmdldCwgY2MucmVjdCgwLDAsIDMwNzIsNjQwKSk7XHJcbiAgICAgICAgdGhpcy5ub2RlLnJ1bkFjdGlvbihmb2xsb3cpO1xyXG4gICAgfVxyXG59KTtcclxuIiwiLyoqXHJcbmNjLkNsYXNzKHtcclxuICAgIGV4dGVuZHM6IGNjLkNvbXBvbmVudCxcclxuXHJcbiAgICBwcm9wZXJ0aWVzOiB7XHJcbiAgICAgICAgLy/vv73vv73vv73vv73Ipe+/ve+/ve+/ve+/ve+/vcO1xLbvv73vv73vv71cclxuICAgICAgICBjYW1lcmE6Y2MuTm9kZSxcclxuICAgICAgICAvL++/ve+/ve+/vdq1xL7vv73Nt1xyXG4gICAgICAgIHZpZXdGaWVsZDpjYy5Ob2RlLFxyXG5cclxuICAgICAgICBoZXJvOmNjLk5vZGUsXHJcblxyXG4gICAgICAgIHZpZXdPYmplY3Q6Y2MuTm9kZSxcclxuXHJcbiAgICAgICAgYmFja1JvbGw6Y2MuTm9kZSxcclxuICAgICAgICAvLyBmb286IHtcclxuICAgICAgICAvLyAgICBkZWZhdWx0OiBudWxsLCAgICAgIC8vIFRoZSBkZWZhdWx0IHZhbHVlIHdpbGwgYmUgdXNlZCBvbmx5IHdoZW4gdGhlIGNvbXBvbmVudCBhdHRhY2hpbmdcclxuICAgICAgICAvLyAgICAgICAgICAgICAgICAgICAgICAgICAgIHRvIGEgbm9kZSBmb3IgdGhlIGZpcnN0IHRpbWVcclxuICAgICAgICAvLyAgICB1cmw6IGNjLlRleHR1cmUyRCwgIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIHR5cGVvZiBkZWZhdWx0XHJcbiAgICAgICAgLy8gICAgc2VyaWFsaXphYmxlOiB0cnVlLCAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyB0cnVlXHJcbiAgICAgICAgLy8gICAgdmlzaWJsZTogdHJ1ZSwgICAgICAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyB0cnVlXHJcbiAgICAgICAgLy8gICAgZGlzcGxheU5hbWU6ICdGb28nLCAvLyBvcHRpb25hbFxyXG4gICAgICAgIC8vICAgIHJlYWRvbmx5OiBmYWxzZSwgICAgLy8gb3B0aW9uYWwsIGRlZmF1bHQgaXMgZmFsc2VcclxuICAgICAgICAvLyB9LFxyXG4gICAgICAgIC8vIC4uLlxyXG4gICAgfSxcclxuXHJcbiAgICAvLyB1c2UgdGhpcyBmb3IgaW5pdGlhbGl6YXRpb25cclxuICAgIG9uTG9hZDogZnVuY3Rpb24gKCkge1xyXG4gICAgICAgIHZhciBzZWxmID0gdGhpcztcclxuICAgICAgICBzZWxmLmNhbWVyYSA9IHNlbGYuaGVybztcclxuICAgICAgICBzZWxmLmJhY2tSb2xsU2NyaXB0ID0gc2VsZi5iYWNrUm9sbC5nZXRDb21wb25lbnQoXCJCYWNrUm9sbFwiKTtcclxuXHJcbiAgICAgICAgc2VsZi5ub2RlLm9uKGNjLk5vZGUuRXZlbnRUeXBlLk1PVVNFX0RPV04sIHNlbGYuc3RhcnRMaXN0ZW4sIHNlbGYpO1xyXG5cclxuICAgICAgICBzZWxmLm5vZGUub24oY2MuTm9kZS5FdmVudFR5cGUuTU9VU0VfVVAsIHNlbGYuZW5kTGlzdGVuLCBzZWxmKTtcclxuICAgIH0sXHJcblxyXG4gICAgc3RhcnRMaXN0ZW46ZnVuY3Rpb24oZXZlbnQpe1xyXG4gICAgICAgIHZhciBzZWxmID0gdGhpcztcclxuICAgICAgICBzZWxmLnZpZXdPYmplY3QueCA9ICgoZXZlbnQuZ2V0TG9jYXRpb25YKCkgLSAoc2VsZi5ub2RlLnBhcmVudC54ICsgY2MuZGlyZWN0b3IuZ2V0V2luU2l6ZSgpLndpZHRoIC8gMikpXHJcbiAgICAgICAgLyA0NDBcclxuICAgICAgICAqIChjYy5kaXJlY3Rvci5nZXRXaW5TaXplKCkud2lkdGggKiAzKSk7XHJcblxyXG4gICAgICAgIGlmKHNlbGYudmlld09iamVjdC54ID4gY2MuZGlyZWN0b3IuZ2V0V2luU2l6ZSgpLndpZHRoICogMi41KXtcclxuICAgICAgICAgICAgc2VsZi52aWV3T2JqZWN0LnggPSBjYy5kaXJlY3Rvci5nZXRXaW5TaXplKCkud2lkdGggKiAyLjU7XHJcbiAgICAgICAgfWVsc2UgaWYoc2VsZi52aWV3T2JqZWN0LnggPCBjYy5kaXJlY3Rvci5nZXRXaW5TaXplKCkud2lkdGggLyAyKXtcclxuICAgICAgICAgICAgc2VsZi52aWV3T2JqZWN0LnggPSBjYy5kaXJlY3Rvci5nZXRXaW5TaXplKCkud2lkdGggLyAyO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgc2VsZi5jYW1lcmEgPSBzZWxmLnZpZXdPYmplY3Q7XHJcbiAgICAgICAgc2VsZi5iYWNrUm9sbFNjcmlwdC5mb2xsb3cgPSBzZWxmLmJhY2tSb2xsU2NyaXB0LmNhbWVyYTtcclxuXHJcbiAgICAgICAgc2VsZi5ub2RlLm9uKGNjLk5vZGUuRXZlbnRUeXBlLk1PVVNFX01PVkUsIHNlbGYubW92ZUxpc3Rlbiwgc2VsZik7XHJcbiAgICB9LFxyXG4gICAgbW92ZUxpc3RlbjpmdW5jdGlvbihldmVudCl7XHJcbiAgICAgICAgdmFyIHNlbGYgPSB0aGlzO1xyXG4gICAgICAgIHNlbGYudmlld09iamVjdC54ID0gKChldmVudC5nZXRMb2NhdGlvblgoKSAtIChzZWxmLm5vZGUucGFyZW50LnggKyBjYy5kaXJlY3Rvci5nZXRXaW5TaXplKCkud2lkdGggLyAyKSlcclxuICAgICAgICAvIDQ0MFxyXG4gICAgICAgICogKGNjLmRpcmVjdG9yLmdldFdpblNpemUoKS53aWR0aCAqIDMpKTtcclxuICAgICAgICBpZihzZWxmLnZpZXdPYmplY3QueCA+IGNjLmRpcmVjdG9yLmdldFdpblNpemUoKS53aWR0aCAqIDIuNSl7XHJcbiAgICAgICAgICAgIHNlbGYudmlld09iamVjdC54ID0gY2MuZGlyZWN0b3IuZ2V0V2luU2l6ZSgpLndpZHRoICogMi41O1xyXG4gICAgICAgIH1lbHNlIGlmKHNlbGYudmlld09iamVjdC54IDwgY2MuZGlyZWN0b3IuZ2V0V2luU2l6ZSgpLndpZHRoIC8gMil7XHJcbiAgICAgICAgICAgIHNlbGYudmlld09iamVjdC54ID0gY2MuZGlyZWN0b3IuZ2V0V2luU2l6ZSgpLndpZHRoIC8gMjtcclxuICAgICAgICB9XHJcbiAgICAgICAgc2VsZi5jYW1lcmEgPSBzZWxmLnZpZXdPYmplY3Q7XHJcbiAgICAgICAgc2VsZi5iYWNrUm9sbFNjcmlwdC5mb2xsb3cgPSBzZWxmLmJhY2tSb2xsU2NyaXB0LmNhbWVyYTtcclxuICAgIH0sXHJcbiAgICBlbmRMaXN0ZW46ZnVuY3Rpb24oZXZlbnQpe1xyXG4gICAgICAgIHZhciBzZWxmID0gdGhpcztcclxuICAgICAgICBzZWxmLm5vZGUub2ZmKGNjLk5vZGUuRXZlbnRUeXBlLk1PVVNFX01PVkUsIHNlbGYubW92ZUxpc3Rlbiwgc2VsZik7XHJcbiAgICB9LFxyXG4gICAgLy8gY2FsbGVkIGV2ZXJ5IGZyYW1lLCB1bmNvbW1lbnQgdGhpcyBmdW5jdGlvbiB0byBhY3RpdmF0ZSB1cGRhdGUgY2FsbGJhY2tcclxuICAgIHVwZGF0ZTogZnVuY3Rpb24gKGR0KSB7XHJcbiAgICAgICAgICAgIHRoaXMuY2FtZXJhID0gdGhpcy5iYWNrUm9sbFNjcmlwdC5mb2xsb3c7XHJcbiAgICAgICAgICAgIGlmKHRoaXMuY2FtZXJhLnggPiBjYy5kaXJlY3Rvci5nZXRXaW5TaXplKCkud2lkdGggKiAyLjUpe1xyXG4gICAgICAgICAgICAgICAgdGhpcy52aWV3RmllbGQueCA9IChjYy5kaXJlY3Rvci5nZXRXaW5TaXplKCkud2lkdGggKiAyLjUpIC8gKGNjLmRpcmVjdG9yLmdldFdpblNpemUoKS53aWR0aCAqIDMpICogNDQwO1xyXG4gICAgICAgICAgICB9ZWxzZSBpZih0aGlzLmNhbWVyYS54IDwgY2MuZGlyZWN0b3IuZ2V0V2luU2l6ZSgpLndpZHRoIC8gMil7XHJcbiAgICAgICAgICAgICAgICB0aGlzLnZpZXdGaWVsZC54ID0gKGNjLmRpcmVjdG9yLmdldFdpblNpemUoKS53aWR0aCAvIDIpIC8gKGNjLmRpcmVjdG9yLmdldFdpblNpemUoKS53aWR0aCAqIDMpICogNDQwO1xyXG4gICAgICAgICAgICB9ZWxzZSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLnZpZXdGaWVsZC54ID0gdGhpcy5jYW1lcmEueCAvIChjYy5kaXJlY3Rvci5nZXRXaW5TaXplKCkud2lkdGggKiAzKSAqIDQ0MDtcclxuICAgICAgICAgICAgfVxyXG4gICAgfSxcclxufSk7Ki9cclxudmFyIGdsb2JhbENvbnN0YW50ID0gcmVxdWlyZShcIkNvbnN0YW50XCIpO1xyXG5jYy5DbGFzcyh7XHJcbiAgICBleHRlbmRzOiBjYy5Db21wb25lbnQsXHJcblxyXG4gICAgcHJvcGVydGllczoge1xyXG4gICAgICAgIC8v77+977+977+977+9yKXvv73vv73vv73vv73vv73DtcS277+977+977+9XHJcbiAgICAgICAgY2FtZXJhOmNjLk5vZGUsXHJcblxyXG4gICAgICAgIC8v0KHvv73vv73NvO+/ve+/ve+/ve+/ve+/ve+/vcq+77+9xLfvv73Op++/ve+/ve+/ve+/vVxyXG4gICAgICAgIHZpZXdGaWVsZDpjYy5Ob2RlLFxyXG5cclxuICAgICAgICBoZXJvOmNjLk5vZGUsXHJcbiAgICAgICAgLy/vv73vv73vv73auO+/ve+/ve+/ve+/ve+/ve+/ve+/ve+/ve+/vVxyXG4gICAgICAgIHZpZXdPYmplY3Q6Y2MuTm9kZSxcclxuXHJcbiAgICAgICAgY2FtZXJhQ29udHJvbDpjYy5Ob2RlLFxyXG5cclxuICAgICAgICB0YXJnZXRzOltjYy5Ob2RlXSxcclxuICAgICAgICAvLyBmb286IHtcclxuICAgICAgICAvLyAgICBkZWZhdWx0OiBudWxsLCAgICAgIC8vIFRoZSBkZWZhdWx0IHZhbHVlIHdpbGwgYmUgdXNlZCBvbmx5IHdoZW4gdGhlIGNvbXBvbmVudCBhdHRhY2hpbmdcclxuICAgICAgICAvLyAgICAgICAgICAgICAgICAgICAgICAgICAgIHRvIGEgbm9kZSBmb3IgdGhlIGZpcnN0IHRpbWVcclxuICAgICAgICAvLyAgICB1cmw6IGNjLlRleHR1cmUyRCwgIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIHR5cGVvZiBkZWZhdWx0XHJcbiAgICAgICAgLy8gICAgc2VyaWFsaXphYmxlOiB0cnVlLCAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyB0cnVlXHJcbiAgICAgICAgLy8gICAgdmlzaWJsZTogdHJ1ZSwgICAgICAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyB0cnVlXHJcbiAgICAgICAgLy8gICAgZGlzcGxheU5hbWU6ICdGb28nLCAvLyBvcHRpb25hbFxyXG4gICAgICAgIC8vICAgIHJlYWRvbmx5OiBmYWxzZSwgICAgLy8gb3B0aW9uYWwsIGRlZmF1bHQgaXMgZmFsc2VcclxuICAgICAgICAvLyB9LFxyXG4gICAgICAgIC8vIC4uLlxyXG4gICAgfSxcclxuXHJcbiAgICAvLyB1c2UgdGhpcyBmb3IgaW5pdGlhbGl6YXRpb25cclxuICAgIG9uTG9hZDogZnVuY3Rpb24gKCkge1xyXG4gICAgICAgIHZhciBzZWxmID0gdGhpcztcclxuICAgICAgICBzZWxmLmNhbWVyYSA9IHNlbGYuaGVybztcclxuICAgICAgICBzZWxmLmNhbWVyYUNvbnRyb2xTY3JpcHQgPSBzZWxmLmNhbWVyYUNvbnRyb2wuZ2V0Q29tcG9uZW50KFwiQ2FtZXJhQ29udHJvbFwiKTtcclxuXHJcbiAgICAgICAgc2VsZi5ub2RlLm9uKGNjLk5vZGUuRXZlbnRUeXBlLk1PVVNFX0RPV04sIHNlbGYuc3RhcnRMaXN0ZW4sIHNlbGYpO1xyXG5cclxuICAgICAgICBzZWxmLm5vZGUub24oY2MuTm9kZS5FdmVudFR5cGUuTU9VU0VfVVAsIHNlbGYuZW5kTGlzdGVuLCBzZWxmKTtcclxuXHJcbiAgICB9LFxyXG5cclxuICAgIHN0YXJ0TGlzdGVuOmZ1bmN0aW9uKGV2ZW50KXtcclxuICAgICAgICB2YXIgc2VsZiA9IHRoaXM7XHJcbiAgICAgICAgLy9zZWxmLnZpZXdPYmplY3QueCA9ICgoZXZlbnQuZ2V0TG9jYXRpb25YKCkgLSAoc2VsZi5ub2RlLnBhcmVudC54ICsgY2MuZGlyZWN0b3IuZ2V0V2luU2l6ZSgpLndpZHRoICogZ2xvYmFsQ29uc3RhbnQuc2NlbmVFZGdlKSlcclxuICAgICAgICAvLy8gNDQwXHJcbiAgICAgICAgLy8qIChjYy5kaXJlY3Rvci5nZXRXaW5TaXplKCkud2lkdGggKiBnbG9iYWxDb25zdGFudC5zY2VuZVdpZHRoKSk7XHJcbiAgICAgICAgc2VsZi52aWV3T2JqZWN0LnggPSAoKGV2ZW50LmdldExvY2F0aW9uWCgpIC0gKHNlbGYubm9kZS5wYXJlbnQueCArIGNjLmRpcmVjdG9yLmdldFdpblNpemUoKS53aWR0aCAqIGdsb2JhbENvbnN0YW50LnNjZW5lRWRnZSkpXHJcbiAgICAgICAgLyA0NDBcclxuICAgICAgICAqIChjYy5kaXJlY3Rvci5nZXRXaW5TaXplKCkud2lkdGggKiBnbG9iYWxDb25zdGFudC5zY2VuZVdpZHRoKSk7XHJcblxyXG4gICAgICAgIGlmKHNlbGYudmlld09iamVjdC54ID4gY2MuZGlyZWN0b3IuZ2V0V2luU2l6ZSgpLndpZHRoICogKGdsb2JhbENvbnN0YW50LnNjZW5lV2lkdGggLSBnbG9iYWxDb25zdGFudC5zY2VuZUVkZ2UpKXtcclxuICAgICAgICAgICAgc2VsZi52aWV3T2JqZWN0LnggPSBjYy5kaXJlY3Rvci5nZXRXaW5TaXplKCkud2lkdGggKiAoZ2xvYmFsQ29uc3RhbnQuc2NlbmVXaWR0aCAtIGdsb2JhbENvbnN0YW50LnNjZW5lRWRnZSk7XHJcbiAgICAgICAgfWVsc2UgaWYoc2VsZi52aWV3T2JqZWN0LnggPCBjYy5kaXJlY3Rvci5nZXRXaW5TaXplKCkud2lkdGggKiBnbG9iYWxDb25zdGFudC5zY2VuZUVkZ2Upe1xyXG4gICAgICAgICAgICBzZWxmLnZpZXdPYmplY3QueCA9IGNjLmRpcmVjdG9yLmdldFdpblNpemUoKS53aWR0aCAqIGdsb2JhbENvbnN0YW50LnNjZW5lRWRnZTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHNlbGYuY2FtZXJhQ29udHJvbFNjcmlwdC50YXJnZXQgPSBzZWxmLmNhbWVyYUNvbnRyb2xTY3JpcHQudGFyZ2V0c1sxXTtcclxuXHJcbiAgICAgICAgc2VsZi5ub2RlLm9uKGNjLk5vZGUuRXZlbnRUeXBlLk1PVVNFX01PVkUsIHNlbGYubW92ZUxpc3Rlbiwgc2VsZik7XHJcbiAgICB9LFxyXG4gICAgbW92ZUxpc3RlbjpmdW5jdGlvbihldmVudCl7XHJcbiAgICAgICAgdmFyIHNlbGYgPSB0aGlzO1xyXG4gICAgICAgIHNlbGYudmlld09iamVjdC54ID0gKChldmVudC5nZXRMb2NhdGlvblgoKSAtIChzZWxmLm5vZGUucGFyZW50LnggKyBjYy5kaXJlY3Rvci5nZXRXaW5TaXplKCkud2lkdGggKiBnbG9iYWxDb25zdGFudC5zY2VuZUVkZ2UpKVxyXG4gICAgICAgIC8gNDQwXHJcbiAgICAgICAgKiAoY2MuZGlyZWN0b3IuZ2V0V2luU2l6ZSgpLndpZHRoICogZ2xvYmFsQ29uc3RhbnQuc2NlbmVXaWR0aCkpO1xyXG5cclxuICAgICAgICBpZihzZWxmLnZpZXdPYmplY3QueCA+IGNjLmRpcmVjdG9yLmdldFdpblNpemUoKS53aWR0aCAqIChnbG9iYWxDb25zdGFudC5zY2VuZVdpZHRoIC0gZ2xvYmFsQ29uc3RhbnQuc2NlbmVFZGdlKSl7XHJcbiAgICAgICAgICAgIHNlbGYudmlld09iamVjdC54ID0gY2MuZGlyZWN0b3IuZ2V0V2luU2l6ZSgpLndpZHRoICogKGdsb2JhbENvbnN0YW50LnNjZW5lV2lkdGggLSBnbG9iYWxDb25zdGFudC5zY2VuZUVkZ2UpO1xyXG4gICAgICAgIH1lbHNlIGlmKHNlbGYudmlld09iamVjdC54IDwgY2MuZGlyZWN0b3IuZ2V0V2luU2l6ZSgpLndpZHRoICogZ2xvYmFsQ29uc3RhbnQuc2NlbmVFZGdlKXtcclxuICAgICAgICAgICAgc2VsZi52aWV3T2JqZWN0LnggPSBjYy5kaXJlY3Rvci5nZXRXaW5TaXplKCkud2lkdGggKiBnbG9iYWxDb25zdGFudC5zY2VuZUVkZ2U7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBzZWxmLmNhbWVyYUNvbnRyb2xTY3JpcHQudGFyZ2V0ID0gc2VsZi5jYW1lcmFDb250cm9sU2NyaXB0LnRhcmdldHNbMV07XHJcbiAgICB9LFxyXG4gICAgZW5kTGlzdGVuOmZ1bmN0aW9uKGV2ZW50KXtcclxuICAgICAgICB2YXIgc2VsZiA9IHRoaXM7XHJcbiAgICAgICAgc2VsZi5ub2RlLm9mZihjYy5Ob2RlLkV2ZW50VHlwZS5NT1VTRV9NT1ZFLCBzZWxmLm1vdmVMaXN0ZW4sIHNlbGYpO1xyXG4gICAgfSxcclxuICAgIC8vIGNhbGxlZCBldmVyeSBmcmFtZSwgdW5jb21tZW50IHRoaXMgZnVuY3Rpb24gdG8gYWN0aXZhdGUgdXBkYXRlIGNhbGxiYWNrXHJcbiAgICBsYXRlVXBkYXRlOiBmdW5jdGlvbiAoZHQpIHtcclxuICAgICAgICAvL3RoaXMudmlld09iamVjdC54ID0gdGhpcy5iYWNrUm9sbFNjcmlwdC5mb2xsb3c7XHJcblxyXG5cclxuICAgICAgICBpZih0aGlzLmNhbWVyYUNvbnRyb2wueCA+PSBjYy5kaXJlY3Rvci5nZXRXaW5TaXplKCkud2lkdGggKiAoZ2xvYmFsQ29uc3RhbnQuc2NlbmVXaWR0aCAtIGdsb2JhbENvbnN0YW50LnNjZW5lRWRnZSkpe1xyXG4gICAgICAgICAgICAvL3RoaXMudmlld0ZpZWxkLnggPSAoY2MuZGlyZWN0b3IuZ2V0V2luU2l6ZSgpLndpZHRoICogKGdsb2JhbENvbnN0YW50LnNjZW5lV2lkdGggLSBnbG9iYWxDb25zdGFudC5zY2VuZUVkZ2UpKVxyXG4gICAgICAgICAgICAvLyAgICAvIChjYy5kaXJlY3Rvci5nZXRXaW5TaXplKCkud2lkdGggKiBnbG9iYWxDb25zdGFudC5zY2VuZVdpZHRoKSAqIDQ0MDtcclxuICAgICAgICAgICAgZ2xvYmFsQ29uc3RhbnQuY2FtZXJhT2Zmc2V0ID0gY2MuZGlyZWN0b3IuZ2V0V2luU2l6ZSgpLndpZHRoICogKGdsb2JhbENvbnN0YW50LnNjZW5lV2lkdGggLSAxKTtcclxuICAgICAgICB9ZWxzZSBpZih0aGlzLmNhbWVyYUNvbnRyb2wueCA8PSBjYy5kaXJlY3Rvci5nZXRXaW5TaXplKCkud2lkdGggKiBnbG9iYWxDb25zdGFudC5zY2VuZUVkZ2Upe1xyXG4gICAgICAgICAgICAvL3RoaXMudmlld0ZpZWxkLnggPSAoY2MuZGlyZWN0b3IuZ2V0V2luU2l6ZSgpLndpZHRoICogZ2xvYmFsQ29uc3RhbnQuc2NlbmVFZGdlKVxyXG4gICAgICAgICAgICAvLyAgICAvIChjYy5kaXJlY3Rvci5nZXRXaW5TaXplKCkud2lkdGggKiBnbG9iYWxDb25zdGFudC5zY2VuZVdpZHRoKSAqIDQ0MDtcclxuICAgICAgICAgICAgZ2xvYmFsQ29uc3RhbnQuY2FtZXJhT2Zmc2V0ID0gMDtcclxuICAgICAgICB9ZWxzZSB7XHJcbiAgICAgICAgICAgIC8vdGhpcy52aWV3RmllbGQueCA9IHRoaXMuY2FtZXJhQ29udHJvbFNjcmlwdC50YXJnZXQueCAvIChjYy5kaXJlY3Rvci5nZXRXaW5TaXplKCkud2lkdGggKiBnbG9iYWxDb25zdGFudC5zY2VuZVdpZHRoKSAqIDQ0MDtcclxuICAgICAgICAgICAgZ2xvYmFsQ29uc3RhbnQuY2FtZXJhT2Zmc2V0ID0gdGhpcy5jYW1lcmFDb250cm9sU2NyaXB0LnRhcmdldC54IC0gY2MuZGlyZWN0b3IuZ2V0V2luU2l6ZSgpLndpZHRoIC8gMjtcclxuICAgICAgICB9XHJcbiAgICAgICAgdGhpcy52aWV3RmllbGQueCA9IHRoaXMuY2FtZXJhQ29udHJvbC54IC8gKGNjLmRpcmVjdG9yLmdldFdpblNpemUoKS53aWR0aCAqIGdsb2JhbENvbnN0YW50LnNjZW5lV2lkdGgpICogNDQwO1xyXG4gICAgfSxcclxufSk7XHJcbiIsIi8v5pys6ISa5pys55So5LqO5L2/55So5Luj56CB5om56YeP6LCD5pW05Y2h54mM54mM6Z2i5biD5bGAXHJcbmNjLkNsYXNzKHtcclxuICAgIGV4dGVuZHM6IGNjLkNvbXBvbmVudCxcclxuXHJcbiAgICBwcm9wZXJ0aWVzOiB7XHJcbiAgICAgICAgLy/mmK/lkKbmmK/nlJ/nianniYxcclxuICAgICAgICBjcmVhdHVyZUNhcmQ6dHJ1ZSxcclxuICAgICAgICAvL+WNoeeJjOaVsOWAvOaUvue9ruiKgueCue+8iOW4g+WxgO+8ie+8jOWHhuWkh+S4gOS4i+WdkOagh1xyXG4gICAgICAgIGNhcmROdW1Ob2RlOmNjLk5vZGUsXHJcbiAgICAgICAgLy/ljaHniYzlkI3np7DoioLngrlcclxuICAgICAgICBjYXJkTmFtZU5vZGU6Y2MuTm9kZSxcclxuICAgICAgICAvL+WNoeeJjOe7huiKgu+8iOaPj+i/sOiKgueCue+8iVxyXG4gICAgICAgIGNhcmREZXRhaWxOb2RlOmNjLk5vZGUsXHJcbiAgICAgICAgLy/ljaHniYznu4boioLvvIjmj4/ov7DoioLngrnvvIlcclxuICAgICAgICBjYXJkRGV0YWlsTGFiZWw6Y2MuTGFiZWwsXHJcbiAgICAgICAgLy/ljaHniYzlsLrlr7joioLngrlcclxuICAgICAgICBjYXJkU2l6ZU5vZGU6Y2MuTm9kZSxcclxuICAgICAgICAvL+WNoeeJjOeahOWbvueJh+mBrue9qeWwuuWvuFxyXG4gICAgICAgIGNhcmRNYXNrTm9kZTpjYy5Ob2RlLFxyXG4gICAgICAgIC8v5Y2h54mM55qE5rOV5Yqb5raI6ICX6IqC54K5XHJcbiAgICAgICAgY2FyZE1hbmFOb2RlOmNjLk5vZGUsXHJcbiAgICAgICAgLy/ljaHniYznmoTms5XlipvmtojogJfoioLngrlcclxuICAgICAgICBjYXJkTWFuYUxhYmVsOmNjLkxhYmVsLFxyXG5cclxuICAgICAgICAvL+WFt+S9k+WNoeeJjOaUu+WHu+WKm+eUn+WRveWAvOetieetieeahOagh+etvu+8jOS4u+imgeeUqOS6juaUueWtl+S9k+Wkp+Wwj1xyXG4gICAgICAgIGNhcmREYXRMYWJlbDpbY2MuTGFiZWxdLFxyXG4gICAgICAgIC8v5YW35L2T5Y2h54mM5pS75Ye75Yqb55Sf5ZG95YC8562J562J55qE6IqC54K5XHJcbiAgICAgICAgY2FyZERhdE5vZGU6W2NjLk5vZGVdXHJcbiAgICB9LFxyXG5cclxuICAgIC8vIHVzZSB0aGlzIGZvciBpbml0aWFsaXphdGlvblxyXG4gICAgb25Mb2FkOiBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgLy/liJ3lp4vljJbljaHniYznmoTluIPlsYDvvIzlrp7njrDlj6ropoHkv67mlLnohJrmnKzlsLHlj6/ku6XlrozmiJDnmoTmk43kvZxcclxuXHJcbiAgICAgICAgLy/ljaHniYzlkI3lrZfnmoToioLngrnkvY3nva5cclxuICAgICAgICB0aGlzLmNhcmROYW1lTm9kZS54ID0gMDtcclxuICAgICAgICB0aGlzLmNhcmROYW1lTm9kZS55ID0gNzU7XHJcbiAgICAgICAgLy/ljaHniYznu4boioLvvIjmj4/ov7DvvInnmoToioLngrnkvY3nva5cclxuICAgICAgICB0aGlzLmNhcmREZXRhaWxOb2RlLnggPSAtNDM7XHJcbiAgICAgICAgdGhpcy5jYXJkRGV0YWlsTm9kZS55ID0gLTUyO1xyXG4gICAgICAgIC8v5Y2h54mM57uG6IqC77yI5o+P6L+w77yJ55qE6IqC54K55L2N572uXHJcbiAgICAgICAgdGhpcy5jYXJkU2l6ZU5vZGUud2lkdGggPSA5MjtcclxuICAgICAgICB0aGlzLmNhcmRTaXplTm9kZS5oZWlnaHQgPSAxNzc7XHJcbiAgICAgICAgLy/ljaHniYzmtojogJfnmoToioLngrnkvY3nva5cclxuICAgICAgICB0aGlzLmNhcmRNYW5hTm9kZS54ID0gLTQ3O1xyXG4gICAgICAgIHRoaXMuY2FyZE1hbmFOb2RlLnkgPSA4NztcclxuICAgICAgICB0aGlzLmNhcmRNYW5hTm9kZS53aWR0aCA9IDIwO1xyXG4gICAgICAgIHRoaXMuY2FyZE1hbmFOb2RlLmhlaWdodCA9IDIwO1xyXG4gICAgICAgIC8v5Y2h54mM6YGu572p55qE5a695bqm6auY5bqm77yM5Lul5Y+K6IqC54K555qEWeWdkOagh1xyXG4gICAgICAgIHRoaXMuY2FyZE1hc2tOb2RlLnkgPSA4O1xyXG4gICAgICAgIHRoaXMuY2FyZE1hc2tOb2RlLndpZHRoID0gODY7XHJcbiAgICAgICAgdGhpcy5jYXJkTWFza05vZGUuaGVpZ2h0ID0gMTA5O1xyXG5cclxuICAgICAgICB0aGlzLmNhcmRNYW5hTGFiZWwuZm9udFNpemUgPSAyMDtcclxuXHJcbiAgICAgICAgdGhpcy5jYXJkRGV0YWlsTGFiZWwuZm9udFNpemUgPSAxMjtcclxuICAgICAgICB0aGlzLmNhcmREZXRhaWxMYWJlbC5saW5lSGVpZ2h0ID0gMTI7XHJcbiAgICAgICAgdGhpcy5jYXJkRGV0YWlsTGFiZWwubm9kZS53aWR0aCA9IDc0O1xyXG5cclxuICAgICAgICBpZih0aGlzLmNyZWF0dXJlQ2FyZCA9PT0gdHJ1ZSkge1xyXG4gICAgICAgICAgICAvL+WNoeeJjOaVsOaNruiKgueCue+8iOW4g+WxgO+8ieeahOS9jee9ruWdkOagh1xyXG4gICAgICAgICAgICB0aGlzLmNhcmROdW1Ob2RlLnggPSA0MjtcclxuICAgICAgICAgICAgdGhpcy5jYXJkTnVtTm9kZS55ID0gMTA7XHJcbiAgICAgICAgICAgIC8v5pS75Ye75Yqb6IqC54K55a695bqm6auY5bqmXHJcbiAgICAgICAgICAgIHRoaXMuY2FyZERhdE5vZGVbMF0ud2lkdGggPSAyODtcclxuICAgICAgICAgICAgdGhpcy5jYXJkRGF0Tm9kZVswXS5oZWlnaHQgPSA1MDtcclxuICAgICAgICAgICAgLy/nlJ/lkb3lgLzoioLngrnlrr3luqbpq5jluqZcclxuICAgICAgICAgICAgdGhpcy5jYXJkRGF0Tm9kZVsxXS53aWR0aCA9IDI4O1xyXG4gICAgICAgICAgICB0aGlzLmNhcmREYXROb2RlWzFdLmhlaWdodCA9IDMyO1xyXG4gICAgICAgICAgICAvL+mAn+W6puiKgueCueWuveW6pumrmOW6plxyXG4gICAgICAgICAgICB0aGlzLmNhcmREYXROb2RlWzJdLndpZHRoID0gMjg7XHJcbiAgICAgICAgICAgIHRoaXMuY2FyZERhdE5vZGVbMl0uaGVpZ2h0ID0gMzI7XHJcblxyXG4gICAgICAgICAgICBmb3IgKHZhciBpID0gMDsgaSA8IDM7IGkrKylcclxuICAgICAgICAgICAgICAgIHRoaXMuY2FyZERhdExhYmVsW2ldLmZvbnRTaXplID0gMjA7XHJcblxyXG4gICAgICAgIH1cclxuICAgIH0sXHJcblxyXG4gICAgLy8gY2FsbGVkIGV2ZXJ5IGZyYW1lLCB1bmNvbW1lbnQgdGhpcyBmdW5jdGlvbiB0byBhY3RpdmF0ZSB1cGRhdGUgY2FsbGJhY2tcclxuICAgIC8vIHVwZGF0ZTogZnVuY3Rpb24gKGR0KSB7XHJcblxyXG4gICAgLy8gfSxcclxufSk7XHJcbiIsInZhciBHbG9iYWwgPSByZXF1aXJlKCdHbG9iYWwnKTtcclxuXHJcbmNjLkNsYXNzKHtcclxuICAgIGV4dGVuZHM6IGNjLkNvbXBvbmVudCxcclxuXHJcbiAgICBwcm9wZXJ0aWVzOiB7XHJcbiAgICAgICAgLyptb29uTGlnaHRXb3JtOntcclxuICAgICAgICAgZGVmYXVsdDogbnVsbCxcclxuICAgICAgICAgdHlwZTogY2MuUHJlZmFiLFxyXG4gICAgICAgICB9LFxyXG4gICAgICAgICB1bmRlYWRCaXJkRGlydDp7XHJcbiAgICAgICAgIGRlZmF1bHQ6IG51bGwsXHJcbiAgICAgICAgIHR5cGU6Y2MuUHJlZmFiLFxyXG4gICAgICAgICB9LCovXHJcbiAgICAgICAgY2FyZEdyb3VwOiB7XHJcbiAgICAgICAgICAgIGRlZmF1bHQ6IFtdLFxyXG4gICAgICAgICAgICB0eXBlOiBjYy5QcmVmYWIsXHJcbiAgICAgICAgfSxcclxuXHJcbiAgICAgICAgLy9sYXN0UGFnZToge1xyXG4gICAgICAgIC8vICAgIGRlZmF1bHQ6IG51bGwsXHJcbiAgICAgICAgLy8gICAgdHlwZTogY2MuQnV0dG9uLFxyXG4gICAgICAgIC8vfSxcclxuICAgICAgICAvL1xyXG4gICAgICAgIC8vbmV4dFBhZ2U6IHtcclxuICAgICAgICAvLyAgICBkZWZhdWx0OiBudWxsLFxyXG4gICAgICAgIC8vICAgIHR5cGU6IGNjLkJ1dHRvbixcclxuICAgICAgICAvL30sXHJcblxyXG4gICAgICAgIGNhcmRCb2FyZDoge1xyXG4gICAgICAgICAgICBkZWZhdWx0OiBudWxsLFxyXG4gICAgICAgICAgICB0eXBlOiBjYy5Ob2RlXHJcbiAgICAgICAgfSxcclxuXHJcbiAgICAgICAgaW5mb0JvYXJkOiB7XHJcbiAgICAgICAgICAgIGRlZmF1bHQ6IG51bGwsXHJcbiAgICAgICAgICAgIHR5cGU6IGNjLk5vZGVcclxuICAgICAgICB9LFxyXG5cclxuICAgICAgICBkZWNrOiB7XHJcbiAgICAgICAgICAgIGRlZmF1bHQ6IFtdLFxyXG4gICAgICAgICAgICB0eXBlOiBjYy5Ob2RlXHJcbiAgICAgICAgfSxcclxuICAgICAgICBsYXlvdXQ6IHtcclxuICAgICAgICAgICAgZGVmYXVsdDogbnVsbCxcclxuICAgICAgICAgICAgdHlwZTogY2MuTGF5b3V0XHJcbiAgICAgICAgfSxcclxuXHJcbiAgICAgICAgbW9kZToge1xyXG4gICAgICAgICAgICB0eXBlOiBjYy5FbnVtKHtcclxuICAgICAgICAgICAgICAgIC8v5pmu6YCa5rWP6KeI5qih5byPXHJcbiAgICAgICAgICAgICAgICBOb3JtYWw6IDAsXHJcbiAgICAgICAgICAgICAgICAvL+W9k+WJjeWQiOaIkOWIhuino+aooeW8j1xyXG4gICAgICAgICAgICAgICAgQ3JhZnQ6IDEsXHJcbiAgICAgICAgICAgICAgICAvL+e7hOWNoee7hOaooeW8j1xyXG4gICAgICAgICAgICAgICAgRWRpdDogMixcclxuICAgICAgICAgICAgICAgIC8v5YWo6YOo5pi+56S677yM5ZCI5oiQ5YiG6Kej5qih5byPXHJcbiAgICAgICAgICAgICAgICBUb3RhbDogM1xyXG4gICAgICAgICAgICB9KSxcclxuICAgICAgICAgICAgZGVmYXVsdDogMFxyXG4gICAgICAgIH0sXHJcbiAgICAgICAgLy/mmK/lkKbmmL7npLrlhajpg6jnmoTljaHniYdcclxuICAgICAgICBhbGxDYXJkRW5hYmxlOmZhbHNlLFxyXG4gICAgICAgIC8v5Y2h57uE6YeM6Z2i55qET0vmjInpkq5cclxuICAgICAgICBvamJrOmNjLk5vZGUsXHJcbiAgICAgICAgLy/ljaHnu4Tph4zpnaLnmoTmlLnlkI3lrZfmoYbmoYZcclxuICAgICAgICBjaGFuZ2VOYW1lOmNjLlByZWZhYixcclxuXHJcbiAgICAgICAgLy/nlKjkuo7lsIbmt7vliqDliLDpga7nvannmoToioLngrlcclxuICAgICAgICBjYXJkTGF5b3V0OmNjLk5vZGUsXHJcbiAgICAgICAgcGFnZVByZWZhYjpjYy5QcmVmYWIsXHJcblxyXG4gICAgICAgIGRlY2tQcmVmYWI6Y2MuUHJlZmFiLFxyXG5cclxuICAgICAgICBidXR0b25zOmNjLk5vZGUsXHJcbiAgICAgICAgLy/osIPmlbTlkIjmiJDliIbop6PljaHniYznmoTpgInpobnmjInpkq5cclxuICAgICAgICB0b2dnbGVzOltjYy5Ub2dnbGVdLFxyXG5cclxuICAgICAgICBtYWluU2NlbmNlOmNjLk5vZGUsXHJcbiAgICAgICAgZGVja051bTowLFxyXG4gICAgICAgIHBvc2l0aW9uWDogLTEsXHJcbiAgICAgICAgcG9zaXRpb25ZOiAxLFxyXG4gICAgICAgIGNhcmRJbmRleDogMFxyXG4gICAgfSxcclxuXHJcbiAgICAvLyB1c2UgdGhpcyBmb3IgaW5pdGlhbGl6YXRpb25cclxuICAgIG9uTG9hZDogZnVuY3Rpb24gKCkge1xyXG4gICAgICAgIHZhciBhc3NXZUNhbiA9IGZhbHNlO1xyXG4gICAgICAgIHRoaXMubWFpblNjcmlwdCA9IHRoaXMubWFpblNjZW5jZS5nZXRDb21wb25lbnQoJ01haW5TY2VuZU1hbmFnZXInKTtcclxuICAgICAgICB0aGlzLmluZm9Cb2FyZFNjcmlwdCA9IG51bGw7XHJcbiAgICAgICAgdGhpcy5idXR0b25zLmFjdGl2ZSA9IGZhbHNlO1xyXG4gICAgICAgIHRoaXMub2piay5hY3RpdmUgPSBmYWxzZTtcclxuICAgICAgICB0aGlzLnJlbmV3U2hvd0NhcmRHcm91cCgpO1xyXG4gICAgICAgIGlmKHRoaXMubW9kZSA9PT0gMil0aGlzLmNhcmREZWNrSW5pdCgpO1xyXG4gICAgICAgIHRoaXMucmVuZXdEZWNrVmlldygpO1xyXG4gICAgICAgIHRoaXMuaW5pdExpc3RlbkV2ZW50KCk7XHJcbiAgICAgICAgLy8gdGhpcy5pbnNlcnRDYXJkRWxlbWVudCh0aGlzLm1vb25MaWdodFdvcm0pO1xyXG4gICAgICAgIC8vIHRoaXMuaW5zZXJ0Q2FyZEVsZW1lbnQodGhpcy51bmRlYWRCaXJkRGlydCk7XHJcbiAgICAgICAgLy8gd2hpbGUodGhpcy5jYXJkSW5kZXggPCAyKXtcclxuICAgICAgICAvLyAgICAgdGhpcy5zaG93Q2FyZEdyb3VwKHRoaXMuY2FyZEdyb3VwW3RoaXMuY2FyZEluZGV4XSk7XHJcbiAgICAgICAgLy8gICAgIHRoaXMuY2FyZEluZGV4Kys7XHJcbiAgICAgICAgLy8gfVxyXG4gICAgfSxcclxuXHJcbiAgICBjaGFuZ2VBbGxDYXJkRW5hYmxlOmZ1bmN0aW9uKCl7XHJcbiAgICAgICAgdGhpcy5hbGxDYXJkRW5hYmxlID0gIXRoaXMuYWxsQ2FyZEVuYWJsZTtcclxuICAgICAgICB0aGlzLnJlbmV3U2hvd0NhcmRHcm91cCgpO1xyXG4gICAgfSxcclxuICAgIG1vZGVDaGFuZ2UwOiBmdW5jdGlvbigpe1xyXG4gICAgICAgIHRoaXMubW9kZSA9IDA7XHJcbiAgICAgICAgdGhpcy50b2dnbGVzWzBdLmludGVyYWN0YWJsZSA9IHRydWU7XHJcbiAgICAgICAgdGhpcy50b2dnbGVzWzFdLmludGVyYWN0YWJsZSA9IHRydWU7XHJcbiAgICAgICAgdGhpcy50b2dnbGVzWzFdLm5vZGUuYWN0aXZlID0gdHJ1ZTtcclxuICAgICAgICBpZiAodGhpcy5pbmZvQm9hcmQgIT09IG51bGwpIHtcclxuICAgICAgICAgICAgdGhpcy5pbmZvQm9hcmQucmVtb3ZlRnJvbVBhcmVudCgpO1xyXG4gICAgICAgIH1cclxuICAgICAgICB0aGlzLmJ1dHRvbnMuYWN0aXZlID0gZmFsc2U7XHJcbiAgICB9LFxyXG4gICAgbW9kZUNoYW5nZTE6IGZ1bmN0aW9uKCl7XHJcbiAgICAgICAgdGhpcy5tb2RlID0gMTtcclxuICAgICAgICB0aGlzLnRvZ2dsZXNbMF0uaW50ZXJhY3RhYmxlID0gdHJ1ZTtcclxuICAgICAgICB0aGlzLnRvZ2dsZXNbMV0uaW50ZXJhY3RhYmxlID0gdHJ1ZTtcclxuICAgICAgICB0aGlzLnRvZ2dsZXNbMV0ubm9kZS5hY3RpdmUgPSB0cnVlO1xyXG4gICAgfSxcclxuICAgIG1vZGVDaGFuZ2UyOiBmdW5jdGlvbigpe1xyXG4gICAgICAgIHRoaXMubW9kZSA9IDI7XHJcbiAgICAgICAgdGhpcy50b2dnbGVzWzBdLmludGVyYWN0YWJsZSA9IGZhbHNlO1xyXG4gICAgICAgIHRoaXMudG9nZ2xlc1sxXS5pbnRlcmFjdGFibGUgPSBmYWxzZTtcclxuICAgICAgICB0aGlzLnRvZ2dsZXNbMV0ubm9kZS5hY3RpdmUgPSBmYWxzZTtcclxuICAgICAgICBpZiAodGhpcy5pbmZvQm9hcmQgIT09IG51bGwpIHtcclxuICAgICAgICAgICAgdGhpcy5pbmZvQm9hcmQucmVtb3ZlRnJvbVBhcmVudCgpO1xyXG4gICAgICAgIH1cclxuICAgICAgICB0aGlzLmJ1dHRvbnMuYWN0aXZlID0gZmFsc2U7XHJcbiAgICAgICAgY2MubG9nKHRoaXMubW9kZSk7XHJcbiAgICB9LFxyXG4gICAgbW9kZUNoYW5nZTM6IGZ1bmN0aW9uKCl7XHJcbiAgICAgICAgdGhpcy5tb2RlID0gMztcclxuICAgICAgICB0aGlzLnRvZ2dsZXNbMF0uaW50ZXJhY3RhYmxlID0gZmFsc2U7XHJcbiAgICAgICAgdGhpcy50b2dnbGVzWzFdLmludGVyYWN0YWJsZSA9IGZhbHNlO1xyXG4gICAgICAgIHRoaXMudG9nZ2xlc1sxXS5ub2RlLmFjdGl2ZSA9IGZhbHNlO1xyXG4gICAgICAgIGlmICh0aGlzLmluZm9Cb2FyZCAhPT0gbnVsbCkge1xyXG4gICAgICAgICAgICB0aGlzLmluZm9Cb2FyZC5yZW1vdmVGcm9tUGFyZW50KCk7XHJcbiAgICAgICAgfVxyXG4gICAgfSxcclxuXHJcbiAgICBkaXNwb3NlOiBmdW5jdGlvbigpe1xyXG4gICAgICAgIGlmKHRoaXMuaW5mb0JvYXJkU2NyaXB0LmNhcmRUeXBlID09PSAwKSB7XHJcbiAgICAgICAgICAgIGlmKHRoaXMubWFpblNjcmlwdC5teU1DYXJkc1t0aGlzLmluZm9Cb2FyZFNjcmlwdC5jYXJkSURdID4gMCkge1xyXG4gICAgICAgICAgICAgICAgaWYoLS10aGlzLm1haW5TY3JpcHQubXlNQ2FyZHNbdGhpcy5pbmZvQm9hcmRTY3JpcHQuY2FyZElEXSA9PT0gMCl7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMuaW5mb0JvYXJkICE9PSBudWxsKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuaW5mb0JvYXJkLnJlbW92ZUZyb21QYXJlbnQoKTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5idXR0b25zLmFjdGl2ZSA9IGZhbHNlO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfWVsc2V7XHJcbiAgICAgICAgICAgIGlmKHRoaXMubWFpblNjcmlwdC5teUNDYXJkc1t0aGlzLmluZm9Cb2FyZFNjcmlwdC5jYXJkSURdID4gMCkge1xyXG4gICAgICAgICAgICAgICAgaWYoIC0tdGhpcy5tYWluU2NyaXB0Lm15Q0NhcmRzW3RoaXMuaW5mb0JvYXJkU2NyaXB0LmNhcmRJRF0gPT09IDApe1xyXG4gICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLmluZm9Cb2FyZCAhPT0gbnVsbCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmluZm9Cb2FyZC5yZW1vdmVGcm9tUGFyZW50KCk7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuYnV0dG9ucy5hY3RpdmUgPSBmYWxzZTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICB0aGlzLnJlbmV3U2hvd0NhcmRHcm91cCgpO1xyXG4gICAgfSxcclxuICAgIGNyYWZ0OmZ1bmN0aW9uKCl7XHJcbiAgICAgICAgaWYodGhpcy5pbmZvQm9hcmRTY3JpcHQuY2FyZFR5cGUgPT09IDApIHtcclxuICAgICAgICAgICAgICAgIHRoaXMubWFpblNjcmlwdC5teU1DYXJkc1t0aGlzLmluZm9Cb2FyZFNjcmlwdC5jYXJkSURdICsrO1xyXG4gICAgICAgIH1lbHNle1xyXG4gICAgICAgICAgICAgICAgdGhpcy5tYWluU2NyaXB0Lm15Q0NhcmRzW3RoaXMuaW5mb0JvYXJkU2NyaXB0LmNhcmRJRF0gKys7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHRoaXMucmVuZXdTaG93Q2FyZEdyb3VwKCk7XHJcbiAgICB9LFxyXG5cclxuICAgIC8qKlxyXG4gICAgICogQOS4u+imgeWKn+iDvSDmm7TmlrDkuIDmrKHnjrDlnKjnmoTmgLvljaHnu4TmtY/op4hcclxuICAgICAqIEBhdXRob3IgQzE0XHJcbiAgICAgKiBARGF0ZSAyMDE3LzEwLzIxXHJcbiAgICAgKiBAcGFyYW1ldGVyc1xyXG4gICAgICogQHJldHVybnNcclxuICAgICAqL1xyXG4gICAgcmVuZXdEZWNrVmlldzogZnVuY3Rpb24oKXtcclxuICAgICAgICB2YXIgaSA9IDA7XHJcbiAgICAgICAgdGhpcy5sYXlvdXQubm9kZS5yZW1vdmVBbGxDaGlsZHJlbigpO1xyXG4gICAgICAgICAgICBmb3IoaSA9IDA7aTxHbG9iYWwudG90YWxEZWNrRGF0YS5sZW5ndGg7aSsrKXtcclxuICAgICAgICAgICAgICAgIHZhciBkZWNrcyA9IGNjLmluc3RhbnRpYXRlKHRoaXMuZGVja1ByZWZhYik7XHJcbiAgICAgICAgICAgICAgICB2YXIgZGVja1NjcmlwdCA9IGRlY2tzLmdldENvbXBvbmVudChcIlZpZXdEZWNrXCIpO1xyXG4gICAgICAgICAgICAgICAgaWYoR2xvYmFsLnRvdGFsRGVja0RhdGFbaV0udXNhYmxlID09PSBmYWxzZSlkZWNrcy5vcGFjaXR5ID0gMTAwO1xyXG4gICAgICAgICAgICAgICAgZGVja1NjcmlwdC5udW0gPSBpO1xyXG4gICAgICAgICAgICAgICAgZGVja1NjcmlwdC5jaGFuZ2VUeXBlKEdsb2JhbC50b3RhbERlY2tEYXRhW2ldLnR5cGUpO1xyXG4gICAgICAgICAgICAgICAgZGVja1NjcmlwdC5jaGFuZ2VOYW1lKEdsb2JhbC50b3RhbERlY2tEYXRhW2ldLm5hbWUpO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5sYXlvdXQubm9kZS5hZGRDaGlsZChkZWNrcyk7XHJcbiAgICAgICAgICAgIH1cclxuICAgIH0sXHJcblxyXG4gICAgLy/mm7TmlrDkuIDmrKHnjrDlnKjnmoTljaHniYfmtY/op4hcclxuICAgIHJlbmV3U2hvd0NhcmRHcm91cDogZnVuY3Rpb24oKXtcclxuICAgICAgICB0aGlzLmNhcmRHcm91cCA9IFtdO1xyXG4gICAgICAgIC8vdGhpcy5jYXJkTGF5b3V0LnJlbW92ZUFsbENoaWxkcmVuKGZhbHNlKTtcclxuICAgICAgICBmb3IodmFyIGk9MDtpPHRoaXMubWFpblNjcmlwdC5teUNDYXJkcy5sZW5ndGg7aSsrKXtcclxuICAgICAgICAgICAgLy9pZih0aGlzLm1vZGUgPT09IDEgJiYgdGhpcy5tYWluU2NyaXB0Lm15Q0NhcmRzW2ldID09PSAwKXtcclxuICAgICAgICAgICAgICAgIHRoaXMuc2hvd0NhcmRHcm91cChpLHRoaXMubWFpblNjcmlwdC5teUNDYXJkc1tpXSwxKTtcclxuICAgICAgICAgICAgLy99ZWxzZSBpZih0aGlzLm1haW5TY3JpcHQubXlDQ2FyZHNbaV0gIT09IDApe1xyXG4gICAgICAgICAgICAvLyAgICB0aGlzLnNob3dDYXJkR3JvdXAoaSx0aGlzLm1haW5TY3JpcHQubXlDQ2FyZHNbaV0sMSk7XHJcbiAgICAgICAgICAgIC8vfVxyXG4gICAgICAgIH1cclxuICAgICAgICBmb3IodmFyIGo9MDtqPHRoaXMubWFpblNjcmlwdC5teU1DYXJkcy5sZW5ndGg7aisrKXtcclxuICAgICAgICAgICAgLy9pZih0aGlzLm1vZGUgPT09IDEgJiYgdGhpcy5tYWluU2NyaXB0Lm15TUNhcmRzW2pdID09PSAwKXtcclxuICAgICAgICAgICAgICAgIHRoaXMuc2hvd0NhcmRHcm91cChqLHRoaXMubWFpblNjcmlwdC5teU1DYXJkc1tqXSwwKTtcclxuICAgICAgICAgICAgLy99ZWxzZSBpZih0aGlzLm1haW5TY3JpcHQubXlNQ2FyZHNbal0gIT09IDApe1xyXG4gICAgICAgICAgICAvLyAgICB0aGlzLnNob3dDYXJkR3JvdXAoaix0aGlzLm1haW5TY3JpcHQubXlNQ2FyZHNbal0sMCk7XHJcbiAgICAgICAgICAgIC8vfVxyXG4gICAgICAgIH1cclxuICAgICAgICB0aGlzLmNhcmRHcm91cCA9IHRoaXMuc29ydFNob3dDYXJkR3JvdXAoKTtcclxuICAgICAgICB0aGlzLnNvcnRDYXJkR3JvdXBMYXlvdXQoKTtcclxuICAgIH0sXHJcblxyXG4gICAgLy/ph43mlrDmm7TmlrDljaHnu4TnmoTpobrluo9cclxuICAgIHNvcnRTaG93Q2FyZEdyb3VwOiBmdW5jdGlvbigpe1xyXG4gICAgICAgIHZhciBpID0gMCxqID0gMDtcclxuICAgICAgICB2YXIgb3V0ID0gW107XHJcbiAgICAgICAgdmFyIHNjcmlwdCA9IG51bGw7XHJcbiAgICAgICAgZm9yKGogPSAwIDtqIDw9IDEwOyBqKyspe1xyXG4gICAgICAgICAgICBmb3IoaSA9IDAgO2kgPCB0aGlzLmNhcmRHcm91cC5sZW5ndGg7IGkrKyl7XHJcbiAgICAgICAgICAgICAgICBzY3JpcHQgPSB0aGlzLmNhcmRHcm91cFtpXS5nZXRDb21wb25lbnQoJ01pbmlDYXJkJyk7XHJcbiAgICAgICAgICAgICAgICBpZihzY3JpcHQubWFuYUNvbnN1bWUgPT09IGope1xyXG4gICAgICAgICAgICAgICAgICAgIG91dC5wdXNoKHRoaXMuY2FyZEdyb3VwW2ldKTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgcmV0dXJuIG91dDtcclxuICAgIH0sXHJcblxyXG4gICAgLy/mlbTnkIbljaHnu4TnlKjnmoTluIPlsYBcclxuICAgIHNvcnRDYXJkR3JvdXBMYXlvdXQ6IGZ1bmN0aW9uKCl7XHJcbiAgICAgICAgdmFyIGkgPSAwLGogPSAwO1xyXG4gICAgICAgIHZhciBwYWdlTm9kZSA9IFtdO1xyXG4gICAgICAgIHRoaXMuY2FyZExheW91dC5yZW1vdmVBbGxDaGlsZHJlbihmYWxzZSk7XHJcbiAgICAgICAgdmFyIHBhZ2VOdW0gPSBNYXRoLmNlaWwodGhpcy5jYXJkR3JvdXAubGVuZ3RoIC8gOSk7XHJcbiAgICAgICAgY2MubG9nKHBhZ2VOdW0pO1xyXG4gICAgICAgIGZvcihqID0gMCA7aiA8IHBhZ2VOdW0gKyAxOyBqKyspe1xyXG4gICAgICAgICAgICB2YXIgbm9kZURhdGEgPSBjYy5pbnN0YW50aWF0ZSh0aGlzLnBhZ2VQcmVmYWIpO1xyXG4gICAgICAgICAgICBwYWdlTm9kZS5wdXNoKG5vZGVEYXRhKTtcclxuXHJcbiAgICAgICAgICAgIHRoaXMuY2FyZExheW91dC5hZGRDaGlsZChwYWdlTm9kZVtqXSk7XHJcbiAgICAgICAgICAgIC8vaWYoaiA9PT0gMSl7XHJcbiAgICAgICAgICAgIC8vICAgIHBhZ2VOb2RlW2pdLmFkZENoaWxkKHRoaXMuY2FyZEdyb3VwWzFdKTtcclxuICAgICAgICAgICAgLy99XHJcbiAgICAgICAgICAgIGZvciAoaSA9IGogKiA5OyBpIDwgdGhpcy5jYXJkR3JvdXAubGVuZ3RoICYmIGkgPCBqICogOSArIDk7IGkrKykge1xyXG4gICAgICAgICAgICAgICAgcGFnZU5vZGVbal0uYWRkQ2hpbGQodGhpcy5jYXJkR3JvdXBbaV0pO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICAvL2ZvcihpID0gMCA7aSA8IHRoaXMuY2FyZEdyb3VwLmxlbmd0aDsgaSsrKXtcclxuICAgICAgICAvLyAgICB0aGlzLmNhcmRMYXlvdXQuYWRkQ2hpbGQodGhpcy5jYXJkR3JvdXBbaV0pO1xyXG4gICAgICAgIC8vfVxyXG4gICAgfSxcclxuXHJcbiAgICAvL+WwhuWxleekuueUqOeahOWFqOS9k+WNoee7hOWxleekuuWHuuadpVxyXG4gICAgc2hvd0NhcmRHcm91cDogZnVuY3Rpb24oaW5kaWNhdGlvbixudW0sY2FyZFR5cGVJZCkge1xyXG4gICAgICAgIHZhciBuZXdDYXJkID0gbnVsbDtcclxuICAgICAgICBpZihjYXJkVHlwZUlkID09PSAxKXtcclxuICAgICAgICAgICAgbmV3Q2FyZCA9IGNjLmluc3RhbnRpYXRlKHRoaXMubWFpblNjcmlwdC5taW5pQ3JlYXR1cmVQcmVmYWJbaW5kaWNhdGlvbl0pO1xyXG4gICAgICAgIH1lbHNle1xyXG4gICAgICAgICAgICBuZXdDYXJkID0gY2MuaW5zdGFudGlhdGUodGhpcy5tYWluU2NyaXB0Lm1pbmlNYWdpY1ByZWZhYltpbmRpY2F0aW9uXSk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHZhciBzY3JpcHQgPSBuZXdDYXJkLmdldENvbXBvbmVudCgnTWluaUNhcmQnKTtcclxuICAgICAgICBzY3JpcHQubnVtID0gbnVtO1xyXG4gICAgICAgIHNjcmlwdC5sYWJlbCA9ICd4JyArIG51bTtcclxuICAgICAgICBpZihudW0gPT09IDApe1xyXG4gICAgICAgICAgICBpZih0aGlzLmFsbENhcmRFbmFibGUgPT09IHRydWUpIHtcclxuICAgICAgICAgICAgICAgIG5ld0NhcmQub3BhY2l0eSA9IDEwMDtcclxuICAgICAgICAgICAgfWVsc2V7XHJcbiAgICAgICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgICAgbmV3Q2FyZC54ID0gMDtcclxuICAgICAgICBuZXdDYXJkLnkgPSAwO1xyXG4gICAgICAgIC8vaWYoc2NyaXB0Lm1hbmFDb25zdW1lID09PSB0aGlzLm1haW5TY3JpcHQuZmlsdGVyVHlwZVsyXSB8fCB0aGlzLm1haW5TY3JpcHQuZmlsdGVyVHlwZVsyXSA9PT0gOSkge1xyXG4gICAgICAgIC8vICAgIHRoaXMuY2FyZEdyb3VwLnB1c2gobmV3Q2FyZCk7XHJcbiAgICAgICAgLy99XHJcblxyXG4gICAgICAgIGlmKCgoKHRoaXMubWFpblNjcmlwdC5maWx0ZXJUeXBlWzBdIC0gMSkqMTAwIDw9IHNjcmlwdC5jYXJkSUQgJiZcclxuICAgICAgICAgICAgKHRoaXMubWFpblNjcmlwdC5maWx0ZXJUeXBlWzBdIC0gMSkqMTAwICsgMTAwID4gc2NyaXB0LmNhcmRJRCkgfHwgdGhpcy5tYWluU2NyaXB0LmZpbHRlclR5cGVbMF0gPT09IDApICYmXHJcbiAgICAgICAgICAgIChzY3JpcHQucmFyaXR5ICsgMSA9PT0gdGhpcy5tYWluU2NyaXB0LmZpbHRlclR5cGVbMV0gfHwgdGhpcy5tYWluU2NyaXB0LmZpbHRlclR5cGVbMV0gPT09IDApICYmXHJcbiAgICAgICAgKHNjcmlwdC5tYW5hQ29uc3VtZSA9PT0gdGhpcy5tYWluU2NyaXB0LmZpbHRlclR5cGVbMl0gfHwgdGhpcy5tYWluU2NyaXB0LmZpbHRlclR5cGVbMl0gPT09IDkpKVxyXG4gICAgICAgIHtcclxuICAgICAgICAgICAgdGhpcy5jYXJkR3JvdXAucHVzaChuZXdDYXJkKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgLy90aGlzLmluc2VydENhcmRFbGVtZW50KG5ld0NhcmQpO1xyXG4gICAgICAgIHJldHVybiB0cnVlO1xyXG4gICAgfSxcclxuXHJcblxyXG5cclxuICAgIGNsZWFuQ2FyZEJvYXJkOiBmdW5jdGlvbigpe1xyXG4gICAgICAgIGZvcih2YXIgaT0wO2k8dGhpcy5jYXJkR3JvdXAubGVuZ3RoO2krKyl7XHJcbiAgICAgICAgICAgIHRoaXMuY2FyZEdyb3VwW2ldLmFjdGl2ZSA9IGZhbHNlOy8vcmVtb3ZlRnJvbVBhcmVudCgpOyAgICBcclxuICAgICAgICB9XHJcbiAgICB9LFxyXG4gICAgXHJcbiAgICBpbml0TGlzdGVuRXZlbnQ6IGZ1bmN0aW9uKCl7XHJcbiAgICAgICAgXHJcbiAgICB0aGlzLm5vZGUub24oXCJ3aGVuTW91c2VFbnRlclRoZU1pbmlDYXJkXCIsbW91c2VFbnRlck1pbmlDYXJkLHRoaXMpO1xyXG4gICAgdGhpcy5ub2RlLm9uKFwid2hlbk1vdXNlTGVhdmVUaGVNaW5pQ2FyZFwiLG1vdXNlTGVhdmVNaW5pQ2FyZCx0aGlzKTtcclxuICAgIHRoaXMubm9kZS5vbihcIndoZW5Nb3VzZVVwVGhlTWluaUNhcmRcIixtb3VzZVVwTWluaUNhcmQsdGhpcyk7XHJcbiAgICAgICAgXHJcbiAgICAgICBmdW5jdGlvbiBtb3VzZUVudGVyTWluaUNhcmQoZXZlbnQpe1xyXG4gICAgICAgICAgIGlmKHRoaXMubW9kZSAhPT0gMSl7XHJcbiAgICAgICAgICAgICAgIHRoaXMuYnV0dG9ucy5hY3RpdmUgPSBmYWxzZTtcclxuICAgICAgICAgICB9XHJcbiAgICAgICAgICAgaWYodGhpcy5tb2RlID09PSAyKSB7XHJcbiAgICAgICAgICAgICAgIGlmIChldmVudC5kZXRhaWwudHlwZUlkID09PSAxKSB7XHJcbiAgICAgICAgICAgICAgICAgICB0aGlzLmluZm9Cb2FyZCA9IGNjLmluc3RhbnRpYXRlKHRoaXMubWFpblNjcmlwdC5zaG93Q1ByZWZhYltldmVudC5kZXRhaWwuaWRdKTtcclxuICAgICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgIHRoaXMuaW5mb0JvYXJkID0gY2MuaW5zdGFudGlhdGUodGhpcy5tYWluU2NyaXB0LnNob3dNUHJlZmFiW2V2ZW50LmRldGFpbC5pZF0pO1xyXG4gICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgIHRoaXMuaW5mb0JvYXJkLnggPSAzMDA7XHJcbiAgICAgICAgICAgICAgIHRoaXMuaW5mb0JvYXJkLnkgPSAyMDA7XHJcbiAgICAgICAgICAgICAgIHRoaXMuaW5mb0JvYXJkU2NyaXB0ID0gZXZlbnQuZGV0YWlsLmNhcmRTY3JpcHQ7XHJcbiAgICAgICAgICAgICAgIHRoaXMubm9kZS5hZGRDaGlsZCh0aGlzLmluZm9Cb2FyZCk7XHJcbiAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgIGZ1bmN0aW9uIG1vdXNlTGVhdmVNaW5pQ2FyZChldmVudCl7XHJcbiAgICAgICAgICAgaWYodGhpcy5tb2RlID09PSAyKSB7XHJcbiAgICAgICAgICAgICAgIGlmICh0aGlzLmluZm9Cb2FyZCAhPT0gbnVsbCkge1xyXG4gICAgICAgICAgICAgICAgICAgdGhpcy5pbmZvQm9hcmQucmVtb3ZlRnJvbVBhcmVudCgpO1xyXG4gICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICBmdW5jdGlvbiBtb3VzZVVwTWluaUNhcmQoZXZlbnQpIHtcclxuICAgICAgICAgICAvLy8v55So6aKE5Yi25Yib5bu65LiA5Liq6aKE6KeI55So55qE5bCP5pa55Z2X55qE6IqC54K5XHJcbiAgICAgICAgICAgLy92YXIgdmlldyA9IGNjLmluc3RhbnRpYXRlKHRoaXMubWFpblNjcmlwdC5kZWNrQnVpbGRQcmVmYWIpO1xyXG4gICAgICAgICAgIC8vdmFyIHNjcmlwdCA9IHZpZXcuZ2V0Q29tcG9uZW50KCdWaWV3Q2FyZCcpO1xyXG4gICAgICAgICAgIC8vdmFyIGRlY2tTY3JpcHQgPSBudWxsO1xyXG4gICAgICAgICAgIC8vdmFyIGkgPSAwO1xyXG4gICAgICAgICAgIC8vc2NyaXB0LmFkZFZpZXdDYXJkKGV2ZW50LmRldGFpbCk7XHJcblxyXG4gICAgICAgICAgIGlmICh0aGlzLm1vZGUgPT09IDIpIHtcclxuICAgICAgICAgICAgICAgaWYgKHRoaXMubWFpblNjcmlwdC5tYXhEZWNrTnVtID4gdGhpcy5kZWNrTnVtKSB7XHJcbiAgICAgICAgICAgICAgICAgICBpZiAoZXZlbnQuZGV0YWlsLnR5cGVJZCA9PT0gMSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLm1haW5TY3JpcHQubXlDRGVja1tldmVudC5kZXRhaWwuaWRdIDwgZXZlbnQuZGV0YWlsLm51bSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzLm1haW5TY3JpcHQubXlDRGVja1tldmVudC5kZXRhaWwuaWRdKys7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuZGVja051bSsrO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmNhcmREZWNrSW5pdCgpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMubWFpblNjcmlwdC5teU1EZWNrW2V2ZW50LmRldGFpbC5pZF0gPCBldmVudC5kZXRhaWwubnVtKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMubWFpblNjcmlwdC5teU1EZWNrW2V2ZW50LmRldGFpbC5pZF0rKztcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5kZWNrTnVtKys7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuY2FyZERlY2tJbml0KCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgfWVsc2UgaWYodGhpcy5tb2RlID09PSAxKXtcclxuICAgICAgICAgICAgICAgaWYgKHRoaXMuaW5mb0JvYXJkICE9PSBudWxsKSB7XHJcbiAgICAgICAgICAgICAgICAgICB0aGlzLmluZm9Cb2FyZC5yZW1vdmVGcm9tUGFyZW50KCk7XHJcbiAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgaWYgKGV2ZW50LmRldGFpbC50eXBlSWQgPT09IDEpIHtcclxuICAgICAgICAgICAgICAgICAgIHRoaXMuaW5mb0JvYXJkID0gY2MuaW5zdGFudGlhdGUodGhpcy5tYWluU2NyaXB0LnNob3dDUHJlZmFiW2V2ZW50LmRldGFpbC5pZF0pO1xyXG4gICAgICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgdGhpcy5pbmZvQm9hcmQgPSBjYy5pbnN0YW50aWF0ZSh0aGlzLm1haW5TY3JpcHQuc2hvd01QcmVmYWJbZXZlbnQuZGV0YWlsLmlkXSk7XHJcbiAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgdGhpcy5pbmZvQm9hcmQueCA9IDMwMDtcclxuICAgICAgICAgICAgICAgdGhpcy5pbmZvQm9hcmQueSA9IDIwMDtcclxuICAgICAgICAgICAgICAgdGhpcy5pbmZvQm9hcmRTY3JpcHQgPSBldmVudC5kZXRhaWwuY2FyZFNjcmlwdDtcclxuICAgICAgICAgICAgICAgdGhpcy5ub2RlLmFkZENoaWxkKHRoaXMuaW5mb0JvYXJkKTtcclxuXHJcbiAgICAgICAgICAgICAgIHRoaXMuYnV0dG9ucy5hY3RpdmUgPSB0cnVlO1xyXG4gICAgICAgICAgIH1cclxuICAgICAgIH1cclxuICAgIH0sXHJcbiAgICBcclxuICAgIHNvcnREZWNrOiBmdW5jdGlvbigpe1xyXG4gICAgdmFyIGkgPSAwLGogPSAwO1xyXG4gICAgdmFyIG91dCA9IFtdO1xyXG4gICAgdmFyIHNjcmlwdCA9IG51bGw7XHJcbiAgICAgICAgZm9yKGogPSAwIDtqIDw9IDEwOyBqKyspe1xyXG4gICAgICAgICAgICBmb3IoaSA9IDAgO2kgPCB0aGlzLmRlY2subGVuZ3RoOyBpKyspe1xyXG4gICAgICAgICAgICAgICAgc2NyaXB0ID0gdGhpcy5kZWNrW2ldLmdldENvbXBvbmVudCgnVmlld0NhcmQnKTtcclxuICAgICAgICAgICAgICAgIGlmKHNjcmlwdC5tYW5hQ29uc3VtZSA9PT0gail7XHJcbiAgICAgICAgICAgICAgICAgICAgb3V0LnB1c2godGhpcy5kZWNrW2ldKTtcclxuICAgICAgICAgICAgICAgIH0gICAgICAgICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIFxyXG4gICAgcmV0dXJuIG91dDtcclxuICAgIH0sXHJcblxyXG4gICAgLy/lsIbljaHnu4TnmoTlhbfkvZPljaHnmoTnu4TmiJDlkYjnjrDlh7rmnaVcclxuICAgIGNhcmREZWNrSW5pdDpmdW5jdGlvbigpe1xyXG4gICAgICAgIHZhciBpO1xyXG4gICAgICAgIHZhciBkZWNrU2NyaXB0ID0gbnVsbDtcclxuICAgICAgICAvL2lmKHRoaXMuZGVjayAhPT0gbnVsbCl0aGlzLmRlY2sgPSBbbnVsbF07XHJcbiAgICAgICAgdmFyIGRlY2sgPSBbXSxkZWNrTnVtID0gMDtcclxuXHJcbiAgICAgICAgZm9yKGkgPSAwIDtpIDwgdGhpcy5tYWluU2NyaXB0Lm15Q0RlY2subGVuZ3RoO2krKyl7XHJcbiAgICAgICAgICAgIHZhciB2aWV3ID0gY2MuaW5zdGFudGlhdGUodGhpcy5tYWluU2NyaXB0LmRlY2tCdWlsZFByZWZhYik7XHJcbiAgICAgICAgICAgIHZhciBzY3JpcHQgPSB2aWV3LmdldENvbXBvbmVudCgnVmlld0NhcmQnKTtcclxuICAgICAgICAgICAgaWYodGhpcy5tYWluU2NyaXB0Lm15Q0RlY2tbaV0gIT09IDAgKVxyXG4gICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICBkZWNrU2NyaXB0ID0gY2MuaW5zdGFudGlhdGUodGhpcy5tYWluU2NyaXB0Lm1pbmlDcmVhdHVyZVByZWZhYltpXSk7XHJcbiAgICAgICAgICAgICAgICBkZWNrU2NyaXB0ID0gZGVja1NjcmlwdC5nZXRDb21wb25lbnQoJ01pbmlDYXJkJyk7XHJcbiAgICAgICAgICAgICAgICB2aWV3LnggPSAwO1xyXG4gICAgICAgICAgICAgICAgc2NyaXB0Lm51bSA9IHRoaXMubWFpblNjcmlwdC5teUNEZWNrW2ldO1xyXG4gICAgICAgICAgICAgICAgc2NyaXB0LmNhcmRUeXBlID0gMTtcclxuICAgICAgICAgICAgICAgIHNjcmlwdC5jYXJkSWQgPSBkZWNrU2NyaXB0LmNhcmRJRDtcclxuICAgICAgICAgICAgICAgIHNjcmlwdC5jTmFtZSA9IGRlY2tTY3JpcHQuY05hbWU7XHJcbiAgICAgICAgICAgICAgICBzY3JpcHQubWFuYUNvbnN1bWUgPSBkZWNrU2NyaXB0Lm1hbmFDb25zdW1lO1xyXG5cclxuICAgICAgICAgICAgICAgIGRlY2sucHVzaCh2aWV3KTtcclxuXHJcbiAgICAgICAgICAgICAgICBkZWNrTnVtICs9IHRoaXMubWFpblNjcmlwdC5teUNEZWNrW2ldO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGZvcihpID0gMCA7aSA8IHRoaXMubWFpblNjcmlwdC5teU1EZWNrLmxlbmd0aDtpKyspe1xyXG4gICAgICAgICAgICB2YXIgdmlldyA9IGNjLmluc3RhbnRpYXRlKHRoaXMubWFpblNjcmlwdC5kZWNrQnVpbGRQcmVmYWIpO1xyXG4gICAgICAgICAgICB2YXIgc2NyaXB0ID0gdmlldy5nZXRDb21wb25lbnQoJ1ZpZXdDYXJkJyk7XHJcbiAgICAgICAgICAgIGlmKHRoaXMubWFpblNjcmlwdC5teU1EZWNrW2ldICE9PSAwICl7XHJcbiAgICAgICAgICAgICAgICBkZWNrU2NyaXB0ID0gY2MuaW5zdGFudGlhdGUodGhpcy5tYWluU2NyaXB0Lm1pbmlNYWdpY1ByZWZhYltpXSk7XHJcbiAgICAgICAgICAgICAgICBkZWNrU2NyaXB0ID0gZGVja1NjcmlwdC5nZXRDb21wb25lbnQoJ01pbmlDYXJkJyk7XHJcbiAgICAgICAgICAgICAgICB2aWV3LnggPSAwO1xyXG4gICAgICAgICAgICAgICAgc2NyaXB0Lm51bSA9IHRoaXMubWFpblNjcmlwdC5teU1EZWNrW2ldO1xyXG4gICAgICAgICAgICAgICAgc2NyaXB0LmNhcmRUeXBlID0gMDtcclxuICAgICAgICAgICAgICAgIHNjcmlwdC5jYXJkSWQgPSBkZWNrU2NyaXB0LmNhcmRJRDtcclxuICAgICAgICAgICAgICAgIHNjcmlwdC5jTmFtZSA9IGRlY2tTY3JpcHQuY05hbWU7XHJcbiAgICAgICAgICAgICAgICBzY3JpcHQubWFuYUNvbnN1bWUgPSBkZWNrU2NyaXB0Lm1hbmFDb25zdW1lO1xyXG4gICAgICAgICAgICAgICAgZGVjay5wdXNoKHZpZXcpO1xyXG5cclxuICAgICAgICAgICAgICAgIGRlY2tOdW0gKz0gdGhpcy5tYWluU2NyaXB0Lm15TURlY2tbaV07XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgICAgdGhpcy5kZWNrTnVtID0gZGVja051bTtcclxuICAgICAgICB0aGlzLmRlY2sgPSBkZWNrO1xyXG4gICAgICAgIGNjLmxvZyhkZWNrKTtcclxuICAgICAgICB0aGlzLmRlY2sgPSB0aGlzLnNvcnREZWNrKCk7XHJcblxyXG4gICAgICAgIHRoaXMuc29ydExheW91dCgpO1xyXG4gICAgICAgIGNjLmxvZyh0aGlzLm1haW5TY3JpcHQubXlDRGVjayk7XHJcbiAgICB9LFxyXG5cclxuICAgIHNvcnRMYXlvdXQ6IGZ1bmN0aW9uKCl7XHJcbiAgICB2YXIgaSA9IDA7XHJcbiAgICB0aGlzLmxheW91dC5ub2RlLnJlbW92ZUFsbENoaWxkcmVuKGZhbHNlKTtcclxuICAgICAgICB2YXIgZGF0ID0gY2MuaW5zdGFudGlhdGUodGhpcy5jaGFuZ2VOYW1lKTtcclxuICAgICAgICB2YXIgc2NyaXB0ID0gZGF0LmdldENvbXBvbmVudChjYy5FZGl0Qm94KTtcclxuICAgICAgICBzY3JpcHQuc3RyaW5nID0gR2xvYmFsLnRvdGFsRGVja0RhdGFbR2xvYmFsLmRlY2tWaWV3XS5uYW1lO1xyXG4gICAgICAgIGRhdC54ID0gMDtcclxuICAgICAgICB0aGlzLmxheW91dC5ub2RlLmFkZENoaWxkKGRhdCk7XHJcbiAgICAgICAgZm9yKGkgPSAwIDtpIDwgdGhpcy5kZWNrLmxlbmd0aDsgaSsrKXtcclxuICAgICAgICAgICAgdGhpcy5sYXlvdXQubm9kZS5hZGRDaGlsZCh0aGlzLmRlY2tbaV0pOyAgICAgICAgICAgICAgICAgICAgICBcclxuICAgICAgICB9XHJcbiAgICAgICAgLy90aGlzLmxheW91dC5ub2RlLmFkZENoaWxkKGNjLmluc3RhbnRpYXRlKHRoaXMub2piaykpO1xyXG4gICAgfSxcclxuICAgIFxyXG4gICAgLy90b0xhc3RQYWdlOiBmdW5jdGlvbigpe1xyXG4gICAgLy8gICAgaWYodGhpcy5jYXJkSW5kZXggIT09IDApe1xyXG4gICAgLy8gICAgICAgIHRoaXMuY2xlYW5DYXJkQm9hcmQoKTtcclxuICAgIC8vICAgICAgICB0aGlzLmNhcmRJbmRleCAtPSA5O1xyXG4gICAgLy8gICAgICAgIHZhciBpID0gdGhpcy5jYXJkSW5kZXg7XHJcbiAgICAvLyAgICAgICAgaWYodGhpcy5jYXJkSW5kZXggPj0gMCl7XHJcbiAgICAvLyAgICAgICAgICAgIGlmKHRoaXMuY2FyZEluZGV4ICsgOCA8PSB0aGlzLmNhcmRHcm91cC5sZW5ndGgpe1xyXG4gICAgLy8gICAgICAgICAgICAgICAgZm9yKGk7aTx0aGlzLmNhcmRJbmRleCArIDg7aSsrKXtcclxuICAgIC8vICAgICAgICAgICAgICAgICAgICB0aGlzLmNhcmRHcm91cFtpXS5hY3RpdmUgPSB0cnVlO1xyXG4gICAgLy8gICAgICAgICAgICAgICAgfVxyXG4gICAgLy8gICAgICAgICAgICB9ZWxzZXtcclxuICAgIC8vICAgICAgICAgICAgICAgIGZvcihpO2k8dGhpcy5jYXJkR3JvdXAubGVuZ3RoO2krKyl7XHJcbiAgICAvLyAgICAgICAgICAgICAgICAgICAgdGhpcy5jYXJkR3JvdXBbaV0uYWN0aXZlID0gdHJ1ZTtcclxuICAgIC8vICAgICAgICAgICAgICAgIH1cclxuICAgIC8vICAgICAgICAgICAgfVxyXG4gICAgLy8gICAgICAgIH1cclxuICAgIC8vICAgIH1cclxuICAgIC8vfSxcclxuICAgIC8vXHJcbiAgICAvL3RvTmV4dFBhZ2U6IGZ1bmN0aW9uKCl7XHJcbiAgICAvLyAgICBpZigodGhpcy5jYXJkR3JvdXAubGVuZ3RoIC0gdGhpcy5jYXJkSW5kZXgpID4gOSkge1xyXG4gICAgLy8gICAgdGhpcy5jbGVhbkNhcmRCb2FyZCgpO1xyXG4gICAgLy8gICAgLy/lpoLmnpzljaHnu4TnmoTplb/luqbopoHmr5TmiJHku6znmoTlvJXntKLopoHlsI/vvIzpgqPlsLHkuI3miafooYzkuoZcclxuICAgIC8vICAgICAgICB0aGlzLmNhcmRJbmRleCArPSA5O1xyXG4gICAgLy8gICAgICAgIHZhciBpID0gdGhpcy5jYXJkSW5kZXg7XHJcbiAgICAvLyAgICAgICAgaWYgKHRoaXMuY2FyZEluZGV4IDw9IHRoaXMuY2FyZEdyb3VwLmxlbmd0aCAmJiB0aGlzLmNhcmRHcm91cC5sZW5ndGggLSB0aGlzLmNhcmRJbmRleCA8PSA5KVxyXG4gICAgLy8gICAgICAgIHtcclxuICAgIC8vICAgICAgICAgICAgZm9yIChpOyBpIDwgdGhpcy5jYXJkR3JvdXAubGVuZ3RoOyBpKyspIHtcclxuICAgIC8vICAgICAgICAgICAgICAgIHRoaXMuY2FyZEdyb3VwW2ldLmFjdGl2ZSA9IHRydWU7XHJcbiAgICAvLyAgICAgICAgICAgIH1cclxuICAgIC8vICAgICAgICB9XHJcbiAgICAvLyAgICB9XHJcbiAgICAvL30sXHJcbiAgICBcclxuICAgIC8qY2FyZEJlaGF2aW9yOiBmdW5jdGlvbihjYXJkT2JqZWN0LGluZm9UeXBlKXtcclxuICAgICAgICBcclxuICAgICAgICB2YXIgbmV3SW5mb0JvYXJkID0gbnVsbDtcclxuICAgICAgICBjYXJkT2JqZWN0Lm9uKGNjLk5vZGUuRXZlbnRUeXBlLk1PVVNFX0VOVEVSLHNob3dJbmZvLCB0aGlzKTtcclxuICAgICAgICBjYXJkT2JqZWN0Lm9uKGNjLk5vZGUuRXZlbnRUeXBlLk1PVVNFX0xFQVZFLGNsZWFuSW5mbywgdGhpcyk7XHJcbiAgICAgICAgZnVuY3Rpb24gc2hvd0luZm8oKXtcclxuICAgICAgICAgICAgbmV3SW5mb0JvYXJkID0gY2MuaW5zdGFudGlhdGUoaW5mb1R5cGUpO1xyXG4gICAgICAgICAgICBuZXdJbmZvQm9hcmQueCA9IDMwMDtcclxuICAgICAgICAgICAgbmV3SW5mb0JvYXJkLnkgPSAyMDA7XHJcbiAgICAgICAgICAgIHRoaXMubm9kZS5hZGRDaGlsZChuZXdJbmZvQm9hcmQpO1xyXG4gICAgICAgIH1cclxuICAgICAgICBmdW5jdGlvbiBjbGVhbkluZm8oKXtcclxuICAgICAgICAgICAgbmV3SW5mb0JvYXJkLnJlbW92ZUZyb21QYXJlbnQoKTtcclxuICAgICAgICB9XHJcbiAgICB9Ki9cclxuICAgIFxyXG4gICAgXHJcbiAgICAvLyBjYWxsZWQgZXZlcnkgZnJhbWUsIHVuY29tbWVudCB0aGlzIGZ1bmN0aW9uIHRvIGFjdGl2YXRlIHVwZGF0ZSBjYWxsYmFja1xyXG4gICAgLy8gdXBkYXRlOiBmdW5jdGlvbiAoZHQpIHtcclxuXHJcbiAgICAvLyB9LFxyXG59KTtcclxuIiwiY2MuQ2xhc3Moe1xyXG4gICAgZXh0ZW5kczogY2MuQ29tcG9uZW50LFxyXG5cclxuICAgIHByb3BlcnRpZXM6IHtcclxuICAgICAgICAvL+mtlOazlea2iOiAl1xyXG4gICAgICAgIG1hbmFDb25zdW1lOiAwLFxyXG4gICAgICAgIC8v6a2U5rOV5raI6ICX5qCH562+XHJcbiAgICAgICAgbWFuYUNvbnN1bWVMYWJlbDogY2MuTGFiZWwsXHJcblxyXG4gICAgICAgIHRlYW06MCxcclxuICAgICAgICBcclxuICAgICAgICAvL+WNoeeJh+exu+Wei1xyXG4gICAgICAgIGNhcmRUeXBlOiB7XHJcbiAgICAgICAgICAgIHR5cGU6IGNjLkVudW0oe1xyXG4gICAgICAgICAgICAgICBNYWdpY0NhcmQ6IDAsXHJcbiAgICAgICAgICAgICAgIENyZWVwQ2FyZDogMSxcclxuICAgICAgICAgICAgfSksXHJcbiAgICAgICAgICAgIGRlZmF1bHQ6IDAsXHJcbiAgICAgICAgfSwgICAgIC8vMOazleacr+eJjO+8mzHnlJ/nianniYxcclxuICAgICAgICByYXJpdHk6e1xyXG4gICAgICAgICAgICB0eXBlOiBjYy5FbnVtKHtcclxuICAgICAgICAgICAgICAgIE46IDAsXHJcbiAgICAgICAgICAgICAgICBSOiAxLFxyXG4gICAgICAgICAgICAgICAgU1I6IDIsXHJcbiAgICAgICAgICAgICAgICBTU1I6IDMsXHJcbiAgICAgICAgICAgIH0pLFxyXG4gICAgICAgICAgICBkZWZhdWx0OiAwLFxyXG4gICAgICAgIH0sXHJcbiAgICAgICAgLy/ljaHniYdJRFxyXG4gICAgICAgIGNhcmRJRDogMCxcclxuICAgICAgICAvL+WNoeeJh+WQjeensFxyXG4gICAgICAgIGNOYW1lOiBjYy5TdHJpbmcsXHJcbiAgICAgICAgLy/ljaHniYflkI3np7DnmoTmoIfnrb5cclxuICAgICAgICBjTmFtZUxhYmVsOiBjYy5MYWJlbCxcclxuICAgICAgICAvKi8v5o+P6L+wXHJcbiAgICAgICAgZGVzY3JpYmU6IGNjLlN0cmluZywqL1xyXG4gICAgICAgIGRlc2NyaWJlOiBjYy5TdHJpbmcsXHJcbiAgICAgICAgLy/mj4/ov7DnmoTmoIfnrb5cclxuICAgICAgICBkZXNjcmliZUxhYmVsOiBjYy5MYWJlbCxcclxuICAgICAgICAvL+aJi+eJjOeahDLkuKrkvY3nva5cclxuICAgICAgICBjYXJkSGFuZDogY2MuTm9kZSxcclxuICAgICAgICBjYXJkVXNpbmc6IGNjLk5vZGUsXHJcblxyXG4gICAgICAgIC8v55So5LqO6K+75Y+W6Iux6ZuE55qE6IqC54K5XHJcbiAgICAgICAgaGVybzogY2MuTm9kZSxcclxuXHJcbiAgICAgICAgLy/kvb/nlKjkuobljaHniYzmkq3mlL7pn7PmlYjmiJbogIXmsqHmnInkvb/nlKjvvIzmlLblm57nmoTpn7PmlYhcclxuICAgICAgICBzdGFydENhcmRFZmZlY3Q6Y2MuQXVkaW9DbGlwLFxyXG4gICAgICAgIGVuZENhcmRFZmZlY3Q6Y2MuQXVkaW9DbGlwLFxyXG4gICAgfSxcclxuXHJcbiAgICAvLyB1c2UgdGhpcyBmb3IgaW5pdGlhbGl6YXRpb25cclxuICAgIG9uTG9hZDogZnVuY3Rpb24gKCkge1xyXG4gICAgICAgIHZhciBzZWxmID0gdGhpcztcclxuICAgICAgICBzZWxmLmhlcm9TY2lycHQgPSBzZWxmLmhlcm8uZ2V0Q29tcG9uZW50KFwiUGxheWVyXCIpO1xyXG4gICAgICAgIC8vIHRoaXMuY2FyZEhhbmQgPSByZXF1aXJlKFwiQ2FyZEhhbmRcIik7XHJcbiAgICAgICAgLy8gdGhpcy5jYXJkVXNpbmcgPSByZXF1aXJlKFwiQ2FyZFVzaW5nXCIpO1xyXG5cclxuICAgICAgICBzd2l0Y2ggKHNlbGYuY2FyZFR5cGUpIHtcclxuICAgICAgICAgICAgY2FzZSAwOlxyXG4gICAgICAgICAgICAgICAgc2VsZi50eXBlQ29tcG9uZW50ID0gc2VsZi5ub2RlLmdldENvbXBvbmVudChcIk1hZ2ljQ2FyZFwiKTtcclxuICAgICAgICAgICAgICAgIGlmIChzZWxmLnR5cGVDb21wb25lbnQpIHtcclxuICAgICAgICAgICAgICAgICAgICAvL2NvbnNvbGUubG9nKFwiVGhpcyBpcyBhIE1hZ2ljQ2FyZCFcIik7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgY2FzZSAxOlxyXG4gICAgICAgICAgICAgICAgc2VsZi50eXBlQ29tcG9uZW50ID0gc2VsZi5ub2RlLmdldENvbXBvbmVudChcIkNyZWVwQ2FyZFwiKTtcclxuICAgICAgICAgICAgICAgIGlmIChzZWxmLnR5cGVDb21wb25lbnQpIHtcclxuICAgICAgICAgICAgICAgICAgICAvL2NvbnNvbGUubG9nKFwiVGhpcyBpcyBhIENyZWVwQ2FyZCFcIik7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgZGVmYXVsdDpcclxuICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgdmFyIGNhcmRPYmplY3QgPSB0aGlzLm5vZGU7XHJcbiAgICAgICAgY2FyZE9iamVjdC5vbihjYy5Ob2RlLkV2ZW50VHlwZS5NT1VTRV9FTlRFUiwgdGhpcy5lbnRlck1vdXNlRXZlbnQsIHRoaXMpO1xyXG4gICAgICAgIGNhcmRPYmplY3Qub24oY2MuTm9kZS5FdmVudFR5cGUuTU9VU0VfTEVBVkUsIHRoaXMubGVhdmVNb3VzZUV2ZW50LCB0aGlzKTtcclxuXHJcbiAgICAgICAgc2VsZi5tYW5hQ29uc3VtZUxhYmVsLnN0cmluZyA9IHNlbGYubWFuYUNvbnN1bWU7XHJcbiAgICAgICAgc2VsZi5jTmFtZUxhYmVsLnN0cmluZyA9IHNlbGYuY05hbWU7XHJcbiAgICAgICAgc2VsZi5kZXNjcmliZUxhYmVsLnN0cmluZyA9IHNlbGYuZGVzY3JpYmU7XHJcbiAgICB9LFxyXG5cclxuICAgIC8v6I635b6X5L2/55So5oOF5Ya1IGZhbHNlIOaXoOazleS9v+eUqO+8m3RydWXlj6/ku6Xkvb/nlKhcclxuICAgIGdldFVzZVN0YXRlOiBmdW5jdGlvbigpe1xyXG4gICAgICAgIC8vIHZhciBzZWxmID0gdGhpcztcclxuICAgICAgICAvLyB2YXIgc2NyaXB0ID0gbnVsbDtcclxuICAgICAgICAvLyBpZihzZWxmLmNhcmRUeXBlID09PSAwKXtcclxuICAgICAgICAvLyAgICAgc2NyaXB0ID0gc2VsZi5ub2RlLmdldENvbXBvbmVudCgnTScgKyBzZWxmLmNhcmRJRCk7XHJcbiAgICAgICAgLy8gfWVsc2V7XHJcbiAgICAgICAgLy8gICAgIHNjcmlwdCA9IHNlbGYubm9kZS5nZXRDb21wb25lbnQoJ0MnICsgc2VsZi5jYXJkSUQpO1xyXG4gICAgICAgIC8vIH1cclxuICAgICAgICAvLyB2YXIgc3RhdGUgPSBzY3JpcHQuZ2V0VXNlU3RhdGUoKTtcclxuICAgICAgICAvLyByZXR1cm4gc3RhdGU7XHJcbiAgICAgICAgdmFyIHN0YXRlID0gdHJ1ZTtcclxuXHJcbiAgICAgICAgLy/ljaHniYznmoTliKTmlq1cclxuICAgICAgICAvL+iLpeecn++8jOWImeW+gOS4i+S4gOWxguWIpOaWrVxyXG4gICAgICAgIGlmIChzdGF0ZSkge1xyXG4gICAgICAgICAgICBzdGF0ZSA9IHRoaXMudHlwZUNvbXBvbmVudC5nZXRVc2VTdGF0ZSgpO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgcmV0dXJuIHN0YXRlO1xyXG4gICAgfSxcclxuICAgIHVzZUNhcmQ6IGZ1bmN0aW9uKCl7XHJcbiAgICAgICAgLy8gdmFyIHNlbGYgPSB0aGlzO1xyXG4gICAgICAgIC8vIHZhciBzY3JpcHQgPSBudWxsO1xyXG4gICAgICAgIC8vIGlmKHNlbGYuY2FyZFR5cGUgPT09IDApe1xyXG4gICAgICAgIC8vICAgICBzY3JpcHQgPSBzZWxmLm5vZGUuZ2V0Q29tcG9uZW50KCdNJyArIHNlbGYuY2FyZElEKTtcclxuICAgICAgICAvLyB9ZWxzZXtcclxuICAgICAgICAvLyAgICAgc2NyaXB0ID0gc2VsZi5ub2RlLmdldENvbXBvbmVudCgnQycgKyBzZWxmLmNhcmRJRCk7XHJcbiAgICAgICAgLy8gfVxyXG4gICAgICAgIC8vIHNjcmlwdC51c2VDYXJkKCk7XHJcbiAgICAgICAgaWYgKHRoaXMuZ2V0VXNlU3RhdGUoKSkge1xyXG4gICAgICAgICAgICAvL+WNoeeJjOWxgumdoueahOaTjeS9nFxyXG4gICAgICAgICAgICAvL+S4i+S4gOWxgueahOaTjeS9nFxyXG4gICAgICAgIH1cclxuXHJcbiAgICB9LFxyXG5cclxuICAgIGVudGVyTW91c2VFdmVudDogZnVuY3Rpb24gKGV2ZW50KSB7XHJcbiAgICAgICAgdmFyIGNhcmRPYmplY3QgPSB0aGlzLm5vZGU7XHJcbiAgICAgICAgY2FyZE9iamVjdC5ydW5BY3Rpb24oY2Muc3BlZWQoY2Muc2NhbGVCeSgxLjMsMS4zKSwgNykpO1xyXG5cclxuXHJcbiAgICAgICAgY2FyZE9iamVjdC5vbihjYy5Ob2RlLkV2ZW50VHlwZS5UT1VDSF9TVEFSVCx0aGlzLmRvd25Nb3VzZUV2ZW50LHRoaXMpO1xyXG5cclxuICAgICAgICBldmVudC5zdG9wUHJvcGFnYXRpb24oKTtcclxuICAgIH0sXHJcblxyXG4gICAgbGVhdmVNb3VzZUV2ZW50OiBmdW5jdGlvbiAoZXZlbnQpIHtcclxuICAgICAgICB2YXIgY2FyZE9iamVjdCA9IHRoaXMubm9kZTtcclxuICAgICAgICBjYXJkT2JqZWN0LnN0b3BBbGxBY3Rpb25zKCk7XHJcbiAgICAgICAgY2FyZE9iamVjdC5ydW5BY3Rpb24oY2Muc3BlZWQoY2Muc2NhbGVUbygxLDEpLDcpKTtcclxuXHJcbiAgICAgICAgZXZlbnQuc3RvcFByb3BhZ2F0aW9uKCk7XHJcbiAgICB9LFxyXG5cclxuICAgIGRvd25Nb3VzZUV2ZW50OiBmdW5jdGlvbiAoZXZlbnQpIHtcclxuICAgICAgICB2YXIgc2VsZiA9IHRoaXM7XHJcblxyXG4gICAgICAgIC8vIOWIpOaWremtlOazleWAvFxyXG4gICAgICAgIGlmIChzZWxmLmhlcm9TY2lycHQuY2hlY2tNYW5hKHNlbGYubWFuYUNvbnN1bWUpKSB7XHJcbiAgICAgICAgICAgIC8v5byA5aeL55uR5ZCs6byg5qCH56e75Yqo5LqL5Lu2XHJcblxyXG4gICAgICAgICAgICB2YXIgY2FyZE9iamVjdCA9IHRoaXMubm9kZTtcclxuICAgICAgICAgICAgdmFyIHNlbmRlciA9IG5ldyBjYy5FdmVudC5FdmVudEN1c3RvbSgnY2FyZFNlbGVjdCcsIHRydWUpO1xyXG4gICAgICAgICAgICBzZW5kZXIuc2V0VXNlckRhdGEoe2NhcmQ6IHRoaXMubm9kZSwgcG9zWDogZXZlbnQuZ2V0TG9jYXRpb25YKCksIHBvc1k6IGV2ZW50LmdldExvY2F0aW9uWSgpfSk7XHJcbiAgICAgICAgICAgIHRoaXMubm9kZS5kaXNwYXRjaEV2ZW50KHNlbmRlcik7XHJcbiAgICAgICAgICAgIC8vY29uc29sZS5sb2coXCJkb3duTW91c2UhXCIpO1xyXG5cclxuICAgICAgICAgICAgdGhpcy5ub2RlLnggPSBldmVudC5nZXRMb2NhdGlvblgoKSAtIGNjLmRpcmVjdG9yLmdldFdpblNpemUoKS53aWR0aCAvIDI7XHJcbiAgICAgICAgICAgIHRoaXMubm9kZS55ID0gZXZlbnQuZ2V0TG9jYXRpb25ZKCkgLSAoY2MuZGlyZWN0b3IuZ2V0V2luU2l6ZSgpLmhlaWdodCAvIDIgLSAyMjApO1xyXG5cclxuICAgICAgICAgICAgLy8g5byA5ZCv56e75Yqo55uR5ZCsXHJcbiAgICAgICAgICAgIGNhcmRPYmplY3Qub24oY2MuTm9kZS5FdmVudFR5cGUuVE9VQ0hfTU9WRSwgdGhpcy5tb3ZlTW91c2VFdmVudCwgdGhpcyk7XHJcbiAgICAgICAgICAgIGNhcmRPYmplY3Qub24oY2MuTm9kZS5FdmVudFR5cGUuVE9VQ0hfRU5ELHRoaXMudXBNb3VzZUV2ZW50LHRoaXMpO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcblxyXG4gICAgICAgICAgICB2YXIgc2VuZGVyMSA9IG5ldyBjYy5FdmVudC5FdmVudEN1c3RvbSgnZXJyb3JUaXBzJywgdHJ1ZSk7XHJcbiAgICAgICAgICAgIHNlbmRlcjEuc2V0VXNlckRhdGEoe3RleHQ6IFwiTm8gZW5vdWdoIG1hbmEhXCJ9KTtcclxuICAgICAgICAgICAgdGhpcy5ub2RlLmRpc3BhdGNoRXZlbnQoc2VuZGVyMSk7XHJcblxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgZXZlbnQuc3RvcFByb3BhZ2F0aW9uKCk7XHJcbiAgICB9LFxyXG5cclxuICAgIHVwTW91c2VFdmVudDogZnVuY3Rpb24gKGV2ZW50KSB7XHJcbiAgICAgICAgLy/lhbPpl63nm5HlkKzpvKDmoIfnp7vliqjkuovku7ZcclxuICAgICAgICB2YXIgY2FyZE9iamVjdCA9IHRoaXMubm9kZTtcclxuXHJcbiAgICAgICAgdmFyIHNlbmRlciA9IG5ldyBjYy5FdmVudC5FdmVudEN1c3RvbSgnY2FyZEV4aXQnLHRydWUpO1xyXG4gICAgICAgIHNlbmRlci5zZXRVc2VyRGF0YSh7Y2FyZDogdGhpcy5ub2RlfSk7XHJcbiAgICAgICAgdGhpcy5ub2RlLmRpc3BhdGNoRXZlbnQoc2VuZGVyKTtcclxuXHJcbiAgICAgICAgY29uc29sZS5sb2coXCJ1cE1vdXNlXCIpO1xyXG5cclxuICAgICAgICAvLyDlhbPpl63kuIDns7vliJfnm5HlkKxcclxuICAgICAgICBjYXJkT2JqZWN0Lm9mZihjYy5Ob2RlLkV2ZW50VHlwZS5UT1VDSF9NT1ZFLHRoaXMubW92ZU1vdXNlRXZlbnQsdGhpcyk7XHJcbiAgICAgICAgY2FyZE9iamVjdC5vZmYoY2MuTm9kZS5FdmVudFR5cGUuVE9VQ0hfU1RBUlQsdGhpcy5kb3duTW91c2VFdmVudCx0aGlzKTtcclxuICAgICAgICBjYXJkT2JqZWN0Lm9mZihjYy5Ob2RlLkV2ZW50VHlwZS5UT1VDSF9FTkQsdGhpcy51cE1vdXNlRXZlbnQsdGhpcyk7XHJcblxyXG4gICAgICAgIC8vIHRoaXMuZHJhd0NhcmRTY3JpcHQuZGVsZXRlQ2FyZCh0aGlzLmNhcmRJbmRleCk7XHJcblxyXG4gICAgICAgIGV2ZW50LnN0b3BQcm9wYWdhdGlvbigpO1xyXG4gICAgfSxcclxuXHJcbiAgICBtb3ZlTW91c2VFdmVudDogZnVuY3Rpb24gKGV2ZW50KSB7XHJcbiAgICAgICAgLy/pvKDmoIfnp7vliqjnm5HlkKxcclxuICAgICAgICB2YXIgY2FyZE9iamVjdCA9IHRoaXMubm9kZTtcclxuICAgICAgICBjYXJkT2JqZWN0LnggKz0gZXZlbnQuZ2V0RGVsdGFYKCk7XHJcbiAgICAgICAgY2FyZE9iamVjdC55ICs9IGV2ZW50LmdldERlbHRhWSgpO1xyXG5cclxuICAgICAgICBldmVudC5zdG9wUHJvcGFnYXRpb24oKTtcclxuICAgIH0sXHJcblxyXG4gICAgLy8gY2FsbGVkIGV2ZXJ5IGZyYW1lLCB1bmNvbW1lbnQgdGhpcyBmdW5jdGlvbiB0byBhY3RpdmF0ZSB1cGRhdGUgY2FsbGJhY2tcclxuICAgIC8vIHVwZGF0ZTogZnVuY3Rpb24gKGR0KSB7XHJcblxyXG4gICAgLy8gfSxcclxufSk7IiwiY2MuQ2xhc3Moe1xyXG4gICAgZXh0ZW5kczogY2MuQ29tcG9uZW50LFxyXG5cclxuICAgIHByb3BlcnRpZXM6IHtcclxuICAgICAgICAvL8qj77+977+977+9xLvYuu+/ve+/ve+/ve+/ve+/vcepXHJcbiAgICAgICAgcm91bmRMYWJlbDpjYy5MYWJlbCxcclxuICAgICAgICAvL8qj77+977+977+9xLvYuu+/ve+/ve+/vVxyXG4gICAgICAgIHJvdW5kOjAsXHJcbiAgICAgICAgLy/vv73vv73vv73vv73Ep++/ve+/ve+/ve+/ve+/ve+/ve+/ve+/vVxyXG4gICAgICAgIGNoYW50TmFtZTpjYy5MYWJlbCxcclxuICAgICAgICAvL++/ve+/ve+/ve+/ve+/ve+/ve+/ve+/ve+/ve+/vVxyXG4gICAgICAgIGlkOjAsXHJcbiAgICAgICAgLy/vv73Dt++/ve+/ve+/ve+/vcSw2bfWse+/vVxyXG4gICAgICAgIHBlcmNlbnQ6MCxcclxuICAgICAgICAvL++/ve+/ve+/ve+/vVxyXG4gICAgICAgIHRlYW06MCxcclxuICAgICAgICAvL++/ve+/vc6nXHJcbiAgICAgICAgYXJlYTowLFxyXG4gICAgICAgIC8v77+9x7bvv71cclxuICAgICAgICBhbmdlbDowLFxyXG4gICAgICAgIC8v77+92bbvv71cclxuICAgICAgICBzcGVlZDowLFxyXG5cclxuICAgICAgICAvLyBmb286IHtcclxuICAgICAgICAvLyAgICBkZWZhdWx0OiBudWxsLCAgICAgIC8vIFRoZSBkZWZhdWx0IHZhbHVlIHdpbGwgYmUgdXNlZCBvbmx5IHdoZW4gdGhlIGNvbXBvbmVudCBhdHRhY2hpbmdcclxuICAgICAgICAvLyAgICAgICAgICAgICAgICAgICAgICAgICAgIHRvIGEgbm9kZSBmb3IgdGhlIGZpcnN0IHRpbWVcclxuICAgICAgICAvLyAgICB1cmw6IGNjLlRleHR1cmUyRCwgIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIHR5cGVvZiBkZWZhdWx0XHJcbiAgICAgICAgLy8gICAgc2VyaWFsaXphYmxlOiB0cnVlLCAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyB0cnVlXHJcbiAgICAgICAgLy8gICAgdmlzaWJsZTogdHJ1ZSwgICAgICAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyB0cnVlXHJcbiAgICAgICAgLy8gICAgZGlzcGxheU5hbWU6ICdGb28nLCAvLyBvcHRpb25hbFxyXG4gICAgICAgIC8vICAgIHJlYWRvbmx5OiBmYWxzZSwgICAgLy8gb3B0aW9uYWwsIGRlZmF1bHQgaXMgZmFsc2VcclxuICAgICAgICAvLyB9LFxyXG4gICAgICAgIC8vIC4uLlxyXG4gICAgfSxcclxuICAgIGZuSW5pdENoYW50OmZ1bmN0aW9uKGRldGFpbCl7XHJcbiAgICAgICAgdGhpcy5jaGFudE5hbWUuc3RyaW5nID0gZGV0YWlsLm5hbWU7XHJcbiAgICAgICAgdGhpcy5yb3VuZCA9IGRldGFpbC5yb3VuZDtcclxuICAgICAgICB0aGlzLnJvdW5kTGFiZWwuc3RyaW5nID0gdGhpcy5yb3VuZDtcclxuICAgICAgICB0aGlzLnRlYW0gPSBkZXRhaWwudGVhbTtcclxuICAgICAgICAvL++/ve+/ve+/ve+/ve+/ve+/vXBvc2l0aW9uIHnvv73vv73WuO+/ve+/ve+/ve+/ve+/ve+/ve+/ve+/vcSn77+977+906bvv73Dte+/vc6777+977+9XHJcbiAgICAgICAgdGhpcy5wb3NpdGlvbiA9IGRldGFpbC5wb3NpdGlvbiAhPSBudWxsID8gZGV0YWlsLnBvc2l0aW9uIDogMDtcclxuICAgICAgICB0aGlzLnkgPSBkZXRhaWwueSAhPT0gbnVsbCA/IGRldGFpbC55IDogbnVsbDtcclxuICAgICAgICB0aGlzLmFuZ2VsID0gZGV0YWlsLmFuZ2VsICE9IG51bGwgPyBkZXRhaWwuYW5nZWwgOiAwO1xyXG4gICAgICAgIHRoaXMuc3BlZWQgPSBkZXRhaWwuc3BlZWQgIT0gbnVsbCA/IGRldGFpbC5zcGVlZCA6IDA7XHJcblxyXG4gICAgICAgIHRoaXMuaWQgPSBkZXRhaWwuaWQ7XHJcbiAgICAgICAgdGhpcy5hcmVhID0gZGV0YWlsLmFyZWEgIT0gbnVsbCA/IGRldGFpbC5hcmVhIDogMDtcclxuXHJcbiAgICAgICAgdGhpcy5ub2RlLnggPSBNYXRoLmNvcygtIHRoaXMucGVyY2VudCoyKk1hdGguUEkpKnRoaXMucjtcclxuICAgICAgICB0aGlzLm5vZGUueSA9IE1hdGguc2luKC0gdGhpcy5wZXJjZW50KjIqTWF0aC5QSSkqdGhpcy5yO1xyXG5cclxuICAgICAgICBpZih0aGlzLm5vZGUueCA+IDApIHtcclxuICAgICAgICAgICAgdGhpcy5jaGFudE5hbWUuYW5jaG9yID0gMDtcclxuICAgICAgICAgICAgdGhpcy5jaGFudE5hbWUubm9kZS54ID0gMzIwO1xyXG4gICAgICAgIH1lbHNle1xyXG4gICAgICAgICAgICB0aGlzLmNoYW50TmFtZS5hbmNob3IgPSAxO1xyXG4gICAgICAgICAgICB0aGlzLmNoYW50TmFtZS5ub2RlLnggPSAtIDMyMDtcclxuICAgICAgICB9XHJcbiAgICB9LFxyXG4gICAgZm5DaGFuZ2VSb3VuZDpmdW5jdGlvbihudW0pe1xyXG4gICAgICAgIHRoaXMucm91bmQgKz0gbnVtO1xyXG4gICAgICAgIHRoaXMucm91bmRMYWJlbC5zdHJpbmcgPSB0aGlzLnJvdW5kO1xyXG4gICAgICAgIGlmKHRoaXMucm91bmQgPD0gMCl7XHJcbiAgICAgICAgICAgIHZhciBldmVudHNlbmQgPSBuZXcgY2MuRXZlbnQuRXZlbnRDdXN0b20oJ21hZ2ljQ3JlYXRlJyx0cnVlKTtcclxuICAgICAgICAgICAgZXZlbnRzZW5kLnNldFVzZXJEYXRhKHtcclxuICAgICAgICAgICAgICAgIHRlYW06dGhpcy50ZWFtLFxyXG4gICAgICAgICAgICAgICAgaWQ6dGhpcy5pZCxcclxuICAgICAgICAgICAgICAgIHBvc2l0aW9uOnRoaXMucG9zaXRpb24sXHJcbiAgICAgICAgICAgICAgICB5OnRoaXMueSxcclxuICAgICAgICAgICAgICAgIGFyZWE6dGhpcy5hcmVhLFxyXG4gICAgICAgICAgICAgICAgYW5nZWw6dGhpcy5hbmdlbCxcclxuICAgICAgICAgICAgICAgIHNwZWVkOnRoaXMuc3BlZWQsXHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICB0aGlzLm5vZGUuZGlzcGF0Y2hFdmVudChldmVudHNlbmQpO1xyXG5cclxuICAgICAgICAgICAgdGhpcy5ub2RlLnJlbW92ZUZyb21QYXJlbnQoKTtcclxuICAgICAgICB9ZWxzZXtcclxuICAgICAgICAgICAgdmFyIGV2ZW50c2VuZCA9IG5ldyBjYy5FdmVudC5FdmVudEN1c3RvbSgnbWFnaWNDcmVhdGUnLHRydWUpO1xyXG4gICAgICAgICAgICBldmVudHNlbmQuc2V0VXNlckRhdGEoe1xyXG4gICAgICAgICAgICAgICAgdGVhbTp0aGlzLnRlYW0sXHJcbiAgICAgICAgICAgICAgICBpZDp0aGlzLmlkLFxyXG4gICAgICAgICAgICAgICAgcG9zaXRpb246dGhpcy5wb3NpdGlvbixcclxuICAgICAgICAgICAgICAgIHk6dGhpcy55LFxyXG4gICAgICAgICAgICAgICAgYXJlYTp0aGlzLmFyZWEsXHJcbiAgICAgICAgICAgICAgICBhbmdlbDp0aGlzLmFuZ2VsLFxyXG4gICAgICAgICAgICAgICAgc3BlZWQ6dGhpcy5zcGVlZCxcclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIHRoaXMubm9kZS5kaXNwYXRjaEV2ZW50KGV2ZW50c2VuZCk7XHJcbiAgICAgICAgfVxyXG4gICAgfSxcclxuICAgIC8vIHVzZSB0aGlzIGZvciBpbml0aWFsaXphdGlvblxyXG4gICAgb25Mb2FkOiBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgdGhpcy5wb3NpdGlvbiA9IDA7XHJcbiAgICAgICAgdGhpcy55ID0gMDtcclxuICAgICAgICB0aGlzLnIgPSA5MDtcclxuICAgICAgICB0aGlzLmZsYWcgPSB0cnVlO1xyXG4gICAgfSxcclxuXHJcbiAgICAvLyBjYWxsZWQgZXZlcnkgZnJhbWUsIHVuY29tbWVudCB0aGlzIGZ1bmN0aW9uIHRvIGFjdGl2YXRlIHVwZGF0ZSBjYWxsYmFja1xyXG4gICAgLy8gdXBkYXRlOiBmdW5jdGlvbiAoZHQpIHtcclxuXHJcbiAgICAvLyB9LFxyXG59KTtcclxuIiwiY2MuQ2xhc3Moe1xyXG4gICAgZXh0ZW5kczogY2MuQ29tcG9uZW50LFxyXG5cclxuICAgIHByb3BlcnRpZXM6IHtcclxuICAgICAgICBwYW5lbE5vZGU6Y2MuTm9kZSxcclxuICAgIH0sXHJcblxyXG4gICAgLy8gdXNlIHRoaXMgZm9yIGluaXRpYWxpemF0aW9uXHJcbiAgICBvbkxvYWQ6IGZ1bmN0aW9uICgpIHtcclxuICAgICAgICBcclxuICAgIH0sXHJcbiAgICBcclxuICAgIGNsb3NlOmZ1bmN0aW9uKCl7XHJcbiAgICAgICAgdGhpcy5wYW5lbE5vZGUuYWN0aXZlID0gZmFsc2U7XHJcbiAgICB9XHJcbiAgICAvLyBjYWxsZWQgZXZlcnkgZnJhbWUsIHVuY29tbWVudCB0aGlzIGZ1bmN0aW9uIHRvIGFjdGl2YXRlIHVwZGF0ZSBjYWxsYmFja1xyXG4gICAgLy8gdXBkYXRlOiBmdW5jdGlvbiAoZHQpIHtcclxuXHJcbiAgICAvLyB9LFxyXG59KTtcclxuIiwiLy8gQ29uc3RhbnQuanMs55So5LqO56Gu5a6a5p+Q5Lqb5YWo5bGA5bi46YePXG5cbm1vZHVsZS5leHBvcnRzID0ge1xuICAgIC8v5YWo5Zy65pmv5a695bqm77yI5Y2V5L2N5Liq5pWwICog5bGP5bmV5a69IOS4uiDlnLrmma/lrr3luqbvvIlcbiAgICBzY2VuZVdpZHRoOiAzLFxuICAgIC8v5Zy65pmv6L6555WM55qE5Y2V5L2N5Liq5pWwXG4gICAgc2NlbmVFZGdlOjAuNSxcblxuICAgIC8v5Y2h54mM5L2/55So55qEWeWdkOagh+S4iueVjO+8iOWIsOS6huatpOWdkOagh+WQjuWNoeeJh+iZmuWMlu+8iVxuICAgIGNhcmRVc2VMaW5lOjEwMCxcbiAgICAvL+WNleS9jeaXtumXtO+8jOWNleS9jemVv+W6pu+8jOWNleS9jemAn+W6plxuICAgIHVuaXRUaW1lOjgsXG4gICAgdW5pdExlbmd0aDoyMDAsXG4gICAgdW5pdFZlbG9jaXR5OjEsXG5cbiAgICAvL+eUn+eJqeWPrOWUpOeahOm7mOiupFnlnZDmoIdcbiAgICBzdW1tb25ZOi0xMzAsXG4gICAgLy/ms5XmnK/nmoTpu5jorqRZ5Z2Q5qCHXG4gICAgbWFnaWNZOi01MCxcblxuICAgIC8v5bCP5Zyw5Zu+55qE6ZW/5bqm77yI5YOP57Sg77yJXG4gICAgc21hbGxNYXBMZW5ndGg6NDQwLFxuICAgIC8v5bCR5pyJ55qE5YWo5bGA5Y+Y6YeP77yM55u45py65Z2Q5qCHXG4gICAgY2FtZXJhT2Zmc2V0OjAsXG5cbiAgICAvL+eUn+eJqeeKtuaAgeeahOaemuS4vlxuICAgIHN0YXRlRW51bTpjYy5FbnVtKHtcbiAgICAgICAgbm9uZTowLFxuICAgICAgICBmcmVlemU6MSxcbiAgICAgICAgY29uZmluZToyLFxuICAgICAgICBidXJuOjMsXG4gICAgICAgIHdlYWs6NCxcbiAgICAgICAgc3BlZWREb3duOjUsXG4gICAgICAgIGhlYWw6NlxuICAgIH0pLFxuICAgIC8v5pWF5LqL5qih5byP5omA6ZyA55qE55qE6YeR5biBXG4gICAgc3RvcnlNb2RlTmVlZE1vbmV5OjUwMCxcblxuICAgIGpmOltdLFxufTsiLCJjYy5DbGFzcyh7XHJcbiAgICBleHRlbmRzOiBjYy5Db21wb25lbnQsXHJcblxyXG4gICAgcHJvcGVydGllczoge1xyXG4gICAgICAgIGNyZWF0dXJlTm9kZTpjYy5Ob2RlLFxyXG4gICAgICAgIC8vIGZvbzoge1xyXG4gICAgICAgIC8vICAgIGRlZmF1bHQ6IG51bGwsICAgICAgLy8gVGhlIGRlZmF1bHQgdmFsdWUgd2lsbCBiZSB1c2VkIG9ubHkgd2hlbiB0aGUgY29tcG9uZW50IGF0dGFjaGluZ1xyXG4gICAgICAgIC8vICAgICAgICAgICAgICAgICAgICAgICAgICAgdG8gYSBub2RlIGZvciB0aGUgZmlyc3QgdGltZVxyXG4gICAgICAgIC8vICAgIHVybDogY2MuVGV4dHVyZTJELCAgLy8gb3B0aW9uYWwsIGRlZmF1bHQgaXMgdHlwZW9mIGRlZmF1bHRcclxuICAgICAgICAvLyAgICBzZXJpYWxpemFibGU6IHRydWUsIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIHRydWVcclxuICAgICAgICAvLyAgICB2aXNpYmxlOiB0cnVlLCAgICAgIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIHRydWVcclxuICAgICAgICAvLyAgICBkaXNwbGF5TmFtZTogJ0ZvbycsIC8vIG9wdGlvbmFsXHJcbiAgICAgICAgLy8gICAgcmVhZG9ubHk6IGZhbHNlLCAgICAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyBmYWxzZVxyXG4gICAgICAgIC8vIH0sXHJcbiAgICAgICAgLy8gLi4uXHJcbiAgICB9LFxyXG5cclxuICAgIC8vIHVzZSB0aGlzIGZvciBpbml0aWFsaXphdGlvblxyXG4gICAgb25Mb2FkOiBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgdGhpcy5jcmVhdHVyZVNjcmlwdCA9IHRoaXMuY3JlYXR1cmVOb2RlLmdldENvbXBvbmVudChcIkNyZWF0dXJlXCIpO1xyXG4gICAgfSxcclxuICAgIG9uQ29sbGlzaW9uRW50ZXI6IGZ1bmN0aW9uIChvdGhlciwgc2VsZikge1xyXG4gICAgICAgIHZhciBzY3JpcHQgPSBudWxsO1xyXG4gICAgICAgIGlmKHRoaXMuY3JlYXR1cmVTY3JpcHQuZGVhdGggPT09IGZhbHNlKSB7XHJcbiAgICAgICAgICAgIC8v77+90Lbvv71cclxuICAgICAgICAgICAgaWYgKG90aGVyLm5vZGUuZ3JvdXAgPT09IFwiQ3JlYXR1cmVcIikge1xyXG4gICAgICAgICAgICAgICAgLy9jYy5sb2coXCJ0b3VjaCB0aGUgQ3JlYXR1cmVcIik7XHJcbiAgICAgICAgICAgICAgICBzY3JpcHQgPSBvdGhlci5ub2RlLmdldENvbXBvbmVudCgnQ3JlYXR1cmUnKTtcclxuICAgICAgICAgICAgICAgIGlmIChzY3JpcHQudGVhbSAhPT0gdGhpcy5jcmVhdHVyZVNjcmlwdC50ZWFtICYmIHNjcmlwdC5kZWF0aCA9PT0gZmFsc2UpIHtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLmNyZWF0dXJlU2NyaXB0LnRhcmdldC5wdXNoKG90aGVyLm5vZGUpO1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuY3JlYXR1cmVTY3JpcHQudGFyZ2V0VHlwZS5wdXNoKDApO1xyXG4gICAgICAgICAgICAgICAgICAgIGlmICghdGhpcy5jcmVhdHVyZVNjcmlwdC5BVEtBY3Rpb25GbGFnKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuY3JlYXR1cmVTY3JpcHQuQVRLQWN0aW9uRmxhZyA9IDE7IC8v77+977+977+977+9XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcblxyXG5cclxuICAgICAgICAgICAgLy/vv73Qtu+/vVxyXG4gICAgICAgICAgICBpZiAob3RoZXIubm9kZS5ncm91cCA9PT0gXCJIZXJvXCIpIHtcclxuICAgICAgICAgICAgICAgIHNjcmlwdCA9IG90aGVyLm5vZGUuZ2V0Q29tcG9uZW50KCdQbGF5ZXInKTtcclxuXHJcbiAgICAgICAgICAgICAgICBpZiAoc2NyaXB0LnRlYW0gIT09IHRoaXMuY3JlYXR1cmVTY3JpcHQudGVhbSAmJiBzY3JpcHQuZGVhdGggPT09IGZhbHNlKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5jcmVhdHVyZVNjcmlwdC50YXJnZXQucHVzaChvdGhlci5ub2RlKTtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLmNyZWF0dXJlU2NyaXB0LnRhcmdldFR5cGUucHVzaCgxKTtcclxuICAgICAgICAgICAgICAgICAgICBpZiAoIXRoaXMuY3JlYXR1cmVTY3JpcHQuQVRLQWN0aW9uRmxhZykge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmNyZWF0dXJlU2NyaXB0LkFUS0FjdGlvbkZsYWcgPSAxOyAvL++/ve+/ve+/ve+/vVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgLy/vv73Qtu+/vVxyXG4gICAgICAgICAgICBpZiAob3RoZXIubm9kZS5ncm91cCA9PT0gXCJCYXNlXCIpIHtcclxuICAgICAgICAgICAgICAgIC8vY29uc29sZS5sb2coXCJ0b3VjaCB0aGUgQmFzZVwiKTtcclxuICAgICAgICAgICAgICAgIHNjcmlwdCA9IG90aGVyLm5vZGUuZ2V0Q29tcG9uZW50KCdCYXNlJyk7XHJcbiAgICAgICAgICAgICAgICBpZiAoc2NyaXB0LnRlYW0gIT09IHRoaXMuY3JlYXR1cmVTY3JpcHQudGVhbSkge1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuY3JlYXR1cmVTY3JpcHQudGFyZ2V0LnB1c2gob3RoZXIubm9kZSk7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5jcmVhdHVyZVNjcmlwdC50YXJnZXRUeXBlLnB1c2goMik7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKCF0aGlzLmNyZWF0dXJlU2NyaXB0LkFUS0FjdGlvbkZsYWcpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5jcmVhdHVyZVNjcmlwdC5BVEtBY3Rpb25GbGFnID0gMTsgLy/vv73vv73vv73vv71cclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9LFxyXG5cclxuICAgIG9uQ29sbGlzaW9uRXhpdDogZnVuY3Rpb24gKG90aGVyLCBzZWxmKSB7XHJcbiAgICAgICAgdmFyIGkgPSAwO1xyXG4gICAgICAgIC8v77+90Lbvv71cclxuICAgICAgICBpZiAob3RoZXIubm9kZS5ncm91cCA9PT0gXCJDcmVhdHVyZVwiIHx8IG90aGVyLm5vZGUuZ3JvdXAgPT09IFwiSGVyb1wiIHx8IG90aGVyLm5vZGUuZ3JvdXAgPT09IFwiQmFzZVwiKSB7XHJcbiAgICAgICAgICAgIGZvcihpO2k8dGhpcy5jcmVhdHVyZVNjcmlwdC50YXJnZXQubGVuZ3RoO2krKyl7XHJcbiAgICAgICAgICAgICAgICBpZihvdGhlci5ub2RlID09PSB0aGlzLmNyZWF0dXJlU2NyaXB0LnRhcmdldFtpXSl7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5jcmVhdHVyZVNjcmlwdC50YXJnZXQuc3BsaWNlKGksMSk7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5jcmVhdHVyZVNjcmlwdC50YXJnZXRUeXBlLnNwbGljZShpLDEpO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgfSxcclxuICAgIC8vIGNhbGxlZCBldmVyeSBmcmFtZSwgdW5jb21tZW50IHRoaXMgZnVuY3Rpb24gdG8gYWN0aXZhdGUgdXBkYXRlIGNhbGxiYWNrXHJcbiAgICAvLyB1cGRhdGU6IGZ1bmN0aW9uIChkdCkge1xyXG5cclxuICAgIC8vIH0sXHJcbn0pO1xyXG4iLCIvKipcclxuICogQO+/ve+/vdKq77+977+977+977+9IO+/ve+/ve+/vdq077+977+977+977+977+977+977+977+977+917TMrFxyXG4gKiBAYXV0aG9yIEM0XHJcbiAqIEBEYXRlIDIwMTcvMTIvMTBcclxuICovXHJcbnZhciBnbG9iYWxDb25zdGFudCA9IHJlcXVpcmUoXCJDb25zdGFudFwiKTtcclxuY2MuQ2xhc3Moe1xyXG4gICAgZXh0ZW5kczogY2MuQ29tcG9uZW50LFxyXG5cclxuICAgIHByb3BlcnRpZXM6IHtcclxuICAgICAgICBzdGF0ZTp7XHJcbiAgICAgICAgICAgIHR5cGU6W2NjLkJvb2xlYW5dLFxyXG4gICAgICAgICAgICBkZWZhdWx0OltdLFxyXG4gICAgICAgIH0sXHJcbiAgICAgICAgc3RhdGVQYXJhbTE6e1xyXG4gICAgICAgICAgICB0eXBlOltjYy5JbnRlZ2VyXSxcclxuICAgICAgICAgICAgZGVmYXVsdDpbXSxcclxuICAgICAgICB9LFxyXG4gICAgICAgIHN0YXRlUGFyYW0yOntcclxuICAgICAgICAgICAgdHlwZTpbY2MuSW50ZWdlcl0sXHJcbiAgICAgICAgICAgIGRlZmF1bHQ6W10sXHJcbiAgICAgICAgfSxcclxuICAgIH0sXHJcbiAgICAvKipcclxuICAgICAqIEDvv73vv73Squ+/ve+/ve+/ve+/vSDvv73vv73vv73vv73Su++/ve+/vde0zKzvv73vv73vv73StO+/ve+/ve+/ve+/vd+877+9XHJcbiAgICAgKiBAYXV0aG9yIEMxNFxyXG4gICAgICogQERhdGUgMjAxNy8xMi8xMFxyXG4gICAgICogQHBhcmFtIHN0YXRlLGRhdDEsZGF0MlxyXG4gICAgICogQHJldHVybnNcclxuICAgICAqL1xyXG4gICAgYWRkU3RhdGU6ZnVuY3Rpb24oc3RhdGUsZGF0MSxkYXQyKXtcclxuICAgICAgICB0aGlzLnN0YXRlW3N0YXRlXSA9IHRydWU7XHJcbiAgICAgICAgdGhpcy5zdGF0ZVBhcmFtMVtzdGF0ZV0gPSBkYXQxID09PSBudWxsID8gMCA6IGRhdDE7XHJcbiAgICAgICAgaWYoc3RhdGUgPT09IGdsb2JhbENvbnN0YW50LnN0YXRlRW51bS5idXJuKSB7XHJcbiAgICAgICAgICAgIHRoaXMuc3RhdGVQYXJhbTJbc3RhdGVdICs9IGRhdDIgPT09IG51bGwgPyAwIDogZGF0MjtcclxuICAgICAgICB9ZWxzZXtcclxuICAgICAgICAgICAgdGhpcy5zdGF0ZVBhcmFtMltzdGF0ZV0gPSBkYXQyID09PSBudWxsID8gMCA6IGRhdDI7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBpZihzdGF0ZSA9PT0gZ2xvYmFsQ29uc3RhbnQuc3RhdGVFbnVtLmZyZWV6ZSl7XHJcbiAgICAgICAgICAgIHRoaXMucmVtb3ZlU3RhdGUoZ2xvYmFsQ29uc3RhbnQuc3RhdGVFbnVtLmJ1cm4pO1xyXG4gICAgICAgIH1cclxuICAgICAgICBpZihzdGF0ZSA9PT0gZ2xvYmFsQ29uc3RhbnQuc3RhdGVFbnVtLmJ1cm4pe1xyXG4gICAgICAgICAgICB0aGlzLnJlbW92ZVN0YXRlKGdsb2JhbENvbnN0YW50LnN0YXRlRW51bS5mcmVlemUpO1xyXG4gICAgICAgIH1cclxuICAgICAgICB0aGlzLnJ1blN0YXRlKCk7XHJcbiAgICB9LFxyXG5cclxuICAgIC8qKlxyXG4gICAgICogQO+/ve+/vdKq77+977+977+977+9IO+/vcaz77+90rvvv73vv73XtMysXHJcbiAgICAgKiBAYXV0aG9yIEMxNFxyXG4gICAgICogQERhdGUgMjAxNy8xMi8xMFxyXG4gICAgICogQHBhcmFtIHN0YXRlXHJcbiAgICAgKiBAcmV0dXJuc1xyXG4gICAgICovXHJcbiAgICByZW1vdmVTdGF0ZTpmdW5jdGlvbihzdGF0ZSl7XHJcbiAgICAgICAgdGhpcy5zdGF0ZVtzdGF0ZV0gPSBmYWxzZTtcclxuICAgICAgICB0aGlzLnN0YXRlUGFyYW0xW3N0YXRlXSA9IDA7XHJcbiAgICAgICAgdGhpcy5zdGF0ZVBhcmFtMltzdGF0ZV0gPSAwO1xyXG4gICAgfSxcclxuICAgIC8qKlxyXG4gICAgICogQO+/ve+/vdKq77+977+977+977+9IO+/vcaz77+9yKvvv73vv73XtMysXHJcbiAgICAgKiBAYXV0aG9yIEMxNFxyXG4gICAgICogQERhdGUgMjAxNy8xMi8xMFxyXG4gICAgICogQHBhcmFtIHZvaWRcclxuICAgICAqIEByZXR1cm5zXHJcbiAgICAgKi9cclxuICAgIHJlbW92ZUFsbFN0YXRlOmZ1bmN0aW9uKCl7XHJcbiAgICAgICAgZm9yKHZhciBpID0gMDtpIDwgdGhpcy5zdGF0ZS5sZW5ndGg7aSsrKXtcclxuICAgICAgICAgICAgdGhpcy5zdGF0ZVtpXSA9IGZhbHNlO1xyXG4gICAgICAgICAgICB0aGlzLnN0YXRlUGFyYW0xW2ldID0gMDtcclxuICAgICAgICAgICAgdGhpcy5zdGF0ZVBhcmFtMltpXSA9IDA7XHJcbiAgICAgICAgfVxyXG4gICAgfSxcclxuICAgIC8qKlxyXG4gICAgICogQO+/ve+/vdKq77+977+977+977+9IMO/77+977+977+977+9zrvKse+/ve+/ve+/ve+/ve+/ve+/ve+/vd+877+977+977+977+977+977+977+9yrHIq++/ve+/ve+/ve+/vdK777+977+9zqow77+9xL7Nve+/ve+/ve+/vde0zKxcclxuICAgICAqIEBhdXRob3IgQzE0XHJcbiAgICAgKiBARGF0ZSAyMDE3LzEyLzEwXHJcbiAgICAgKiBAcGFyYW0gdm9pZFxyXG4gICAgICogQHJldHVybnNcclxuICAgICAqL1xyXG4gICAgYWRqdXN0TG9naWM6ZnVuY3Rpb24oKXtcclxuICAgICAgICBmb3IodmFyIGkgPSAwO2kgPCB0aGlzLnN0YXRlLmxlbmd0aDtpKyspe1xyXG4gICAgICAgICAgICAvL9e0zKzvv73Esu+/ve+/ve+/vTHvv73vv73vv73vv73vv73vv73vv73vv73vv73vv73Kse+/vcSy77+977+977+977+977+90rtcclxuICAgICAgICAgICAgaWYodGhpcy5zdGF0ZVBhcmFtMVtpXSA+IDApe1xyXG4gICAgICAgICAgICAgICAgdGhpcy5zdGF0ZVBhcmFtMVtpXSAtLTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAvL++/ve+/ve+/ve+/ve+/ve+/ve+/ve+/vcqx77+977+977+977+977+977+977+977+977+977+977+977+977+92LXvv73XtMysXHJcbiAgICAgICAgICAgIGlmKHRoaXMuc3RhdGVQYXJhbTFbaV0gPT09IDApe1xyXG4gICAgICAgICAgICAgICAgaWYoaSA9PT0gZ2xvYmFsQ29uc3RhbnQuc3RhdGVFbnVtLmZyZWV6ZSl7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5jcmVhdHVyZVNjcmlwdC5hdHRhY2tGcmVlemUgPSBmYWxzZTtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLmNyZWF0dXJlU2NyaXB0Lm1vdmVGcmVlemUgPSBmYWxzZTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGlmKGkgPT09IGdsb2JhbENvbnN0YW50LnN0YXRlRW51bS5jb25maW5lKXtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLmNyZWF0dXJlU2NyaXB0Lm1vdmVGcmVlemUgPSBmYWxzZTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGlmKGkgPT09IGdsb2JhbENvbnN0YW50LnN0YXRlRW51bS5idXJuKXtcclxuXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBpZihpID09PSBnbG9iYWxDb25zdGFudC5zdGF0ZUVudW0ud2Vhayl7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5jcmVhdHVyZVNjcmlwdC53ZWVrbmVzcyA9IGZhbHNlO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgaWYoaSA9PT0gZ2xvYmFsQ29uc3RhbnQuc3RhdGVFbnVtLnNwZWVkRG93bil7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5jcmVhdHVyZVNjcmlwdC5zcGVlZCArKztcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGlmKGkgPT09IGdsb2JhbENvbnN0YW50LnN0YXRlRW51bS5oZWFsKXtcclxuXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB0aGlzLnJlbW92ZVN0YXRlKGkpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgfSxcclxuICAgIC8qKlxyXG4gICAgICogQO+/ve+/vdKq77+977+977+977+9IO+/ve+/ve+/ve+/vde0zKzvv73fvO+/vVxyXG4gICAgICogQGF1dGhvciBDMTRcclxuICAgICAqIEBEYXRlIDIwMTcvMTIvMTBcclxuICAgICAqIEBwYXJhbVxyXG4gICAgICogQHJldHVybnNcclxuICAgICAqL1xyXG4gICAgcnVuU3RhdGU6ZnVuY3Rpb24oKXtcclxuICAgICAgICBpZih0aGlzLnN0YXRlW2dsb2JhbENvbnN0YW50LnN0YXRlRW51bS5mcmVlemVdID09PSB0cnVlKXtcclxuICAgICAgICAgICAgdGhpcy5jcmVhdHVyZVNjcmlwdC5hdHRhY2tGcmVlemUgPSB0cnVlO1xyXG4gICAgICAgICAgICB0aGlzLmNyZWF0dXJlU2NyaXB0Lm1vdmVGcmVlemUgPSB0cnVlO1xyXG4gICAgICAgIH1cclxuICAgICAgICBpZih0aGlzLnN0YXRlW2dsb2JhbENvbnN0YW50LnN0YXRlRW51bS5jb25maW5lXSA9PT0gdHJ1ZSl7XHJcbiAgICAgICAgICAgIHRoaXMuY3JlYXR1cmVTY3JpcHQubW92ZUZyZWV6ZSA9IHRydWU7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlmKHRoaXMuc3RhdGVbZ2xvYmFsQ29uc3RhbnQuc3RhdGVFbnVtLmJ1cm5dID09PSB0cnVlKXtcclxuXHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlmKHRoaXMuc3RhdGVbZ2xvYmFsQ29uc3RhbnQuc3RhdGVFbnVtLndlYWtdID09PSB0cnVlKXtcclxuICAgICAgICAgICAgdGhpcy5jcmVhdHVyZVNjcmlwdC53ZWFrbmVzcyA9IHRydWU7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlmKHRoaXMuc3RhdGVbZ2xvYmFsQ29uc3RhbnQuc3RhdGVFbnVtLnNwZWVkRG93bl0gPT09IHRydWUpe1xyXG4gICAgICAgICAgICB0aGlzLmNyZWF0dXJlU2NyaXB0LnNwZWVkIC0tO1xyXG4gICAgICAgIH1cclxuICAgIH0sXHJcbiAgICAvLyB1c2UgdGhpcyBmb3IgaW5pdGlhbGl6YXRpb25cclxuICAgIG9uTG9hZDogZnVuY3Rpb24gKCkge1xyXG4gICAgICAgIHRoaXMuY3JlYXR1cmVTY3JpcHQgPSB0aGlzLm5vZGUucGFyZW50LmdldENvbXBvbmVudChcIkNyZWF0dXJlXCIpO1xyXG4gICAgICAgIHRoaXMuc2NoZWR1bGUoZnVuY3Rpb24oKSB7XHJcbiAgICAgICAgICAgIHZhciBjaGFuZ2UgPSAwO1xyXG4gICAgICAgICAgICBpZih0aGlzLnN0YXRlW2dsb2JhbENvbnN0YW50LnN0YXRlRW51bS5idXJuXSA9PT0gdHJ1ZSkge1xyXG4gICAgICAgICAgICAgICAgY2hhbmdlICs9IC10aGlzLnN0YXRlUGFyYW0yW2dsb2JhbENvbnN0YW50LnN0YXRlRW51bS5idXJuXTtcclxuICAgICAgICAgICAgICAgIGlmICgtLSB0aGlzLnN0YXRlUGFyYW0yW2dsb2JhbENvbnN0YW50LnN0YXRlRW51bS5idXJuXSA9PT0gMCkge1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMucmVtb3ZlU3RhdGUodGhpcy5zdGF0ZVBhcmFtMltnbG9iYWxDb25zdGFudC5zdGF0ZUVudW0uYnVybl0pXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgaWYodGhpcy5zdGF0ZVtnbG9iYWxDb25zdGFudC5zdGF0ZUVudW0uaGVhbF0gPT09IHRydWUpIHtcclxuICAgICAgICAgICAgICAgIGNoYW5nZSArPSB0aGlzLnN0YXRlUGFyYW0yW2dsb2JhbENvbnN0YW50LnN0YXRlRW51bS5oZWFsXTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB0aGlzLmNyZWF0dXJlU2NyaXB0LmNoYW5nZUhlYWx0aChjaGFuZ2UpO1xyXG4gICAgICAgICAgICB0aGlzLmFkanVzdExvZ2ljKCk7XHJcbiAgICAgICAgfSxnbG9iYWxDb25zdGFudC51bml0VGltZSk7XHJcbiAgICB9LFxyXG5cclxuICAgIC8vIGNhbGxlZCBldmVyeSBmcmFtZSwgdW5jb21tZW50IHRoaXMgZnVuY3Rpb24gdG8gYWN0aXZhdGUgdXBkYXRlIGNhbGxiYWNrXHJcbiAgICAvLyB1cGRhdGU6IGZ1bmN0aW9uIChkdCkge1xyXG5cclxuICAgIC8vIH0sXHJcbn0pO1xyXG4iLCIvKipcclxuICogQOS4u+imgeWKn+iDvTogICDmgKrnianlj7LojrHlhYtcclxuICogQHR5cGUge0Z1bmN0aW9ufVxyXG4gKi9cclxudmFyIG1vbnN0ZXJTaHJlayA9IGNjLkNsYXNzKHtcclxuICAgIGV4dGVuZHM6IGNjLkNvbXBvbmVudCxcclxuXHJcbiAgICBwcm9wZXJ0aWVzOiB7XHJcbiAgICAgICAgLy/kuLvmuLjmiI/nrqHnkIblmajnu4Tku7ZcclxuICAgICAgICBHYW1lTWFuYWdlcjpjYy5Db21wb25lbnQsXHJcbiAgICAgICAgLy/mlLvlh7vooYzkuLrnu4Tku7ZcclxuICAgICAgICBBdHRhY2tCZWhhdmlvcjpjYy5Db21wb25lbnQsXHJcbiAgICAgICAgLy/plIHlrprnmoTnm67moIdcclxuICAgICAgICBmb2N1c1RhcmdldDpjYy5Ob2RlLFxyXG4gICAgICAgIC8v55uu5qCH5pWw57uEXHJcbiAgICAgICAgdGFyZ2V0OltjYy5Ob2RlXSxcclxuICAgICAgICAvL+ebruagh+aVsOe7hCAw55Sf54mpIDHoi7Hpm4QgMuWfuuWcsCAz6a2U5rOVXHJcbiAgICAgICAgdGFyZ2V0VHlwZTpbXSxcclxuICAgICAgICAvL+ebruagh+eahOWdkOagh1xyXG4gICAgICAgIHRhcmdldFg6IG51bGwsXHJcblxyXG4gICAgICAgIGlkOlwiXCIsXHJcbiAgICAgICAgLy/nm67moIfnmoTnsbvlnosw6Iux6ZuEOzHnlJ/niak7LTHml6BcclxuICAgICAgICBmb2N1c1R5cGU6MCxcclxuICAgICAgICAvL+eUn+WRveWAvFxyXG4gICAgICAgIGhlYWx0aDowLFxyXG4gICAgICAgIC8v55Sf5ZG95YC85qCH562+XHJcbiAgICAgICAgaGVhbHRoTGFiZWw6Y2MuTGFiZWwsXHJcbiAgICAgICAgLy/nlJ/lkb3lgLznmoToioLngrlcclxuICAgICAgICBoZWFsdGhOb2RlOltjYy5Ob2RlXSxcclxuICAgICAgICAvL+eUn+eJqeWuveW6plxyXG4gICAgICAgIHdpZHRoOjAsXHJcbiAgICAgICAgLy/mlLvlh7vliptcclxuICAgICAgICBhdHRhY2s6MCxcclxuICAgICAgICAvL+aUu+WHu+WKm+agh+etvlxyXG4gICAgICAgIGF0dGFja0xhYmVsOmNjLkxhYmVsLFxyXG4gICAgICAgIC8v5pS75Ye76IyD5Zu0XHJcbiAgICAgICAgYXR0YWNrQXJlYTowLFxyXG4gICAgICAgIC8v6YCf5bqmXHJcbiAgICAgICAgdmVsb2NpdHk6MCxcclxuICAgICAgICAvL+WPr+enu+WKqOagh+iusFxyXG4gICAgICAgIG1vdmU6IHRydWUsXHJcbiAgICAgICAgLy9cclxuXHJcbiAgICAgICAgLy/miYDlsZ7nmoTpmJ/kvI1cclxuICAgICAgICB0ZWFtOjAsXHJcbiAgICAgICAgLy/lu7bml7bnlKhcclxuICAgICAgICBkZWxheTowLFxyXG4gICAgICAgIC8v5piv5ZCm5q275LqhXHJcbiAgICAgICAgZGVhdGg6ZmFsc2UsXHJcbiAgICAgICAgLy/mmK/lkKblpITkuo7lj6zllKTnirbmgIFcclxuICAgICAgICBzdW1tb246dHJ1ZSxcclxuICAgICAgICAvL+aUu+WHu+i/m+ihjOeri0ZsYWdcclxuICAgICAgICBBVEtBY3Rpb25GbGFnOiAwLFxyXG4gICAgICAgIC8v5pS75Ye76Ze06ZqUXHJcbiAgICAgICAgYXR0YWNrU3BhY2U6IDAsXHJcbiAgICAgICAgLy/mlLvlh7vorqHml7blmagg5L2c5bqfXHJcbiAgICAgICAgLy8gYXR0YWNrVGltZXI6IDAsXHJcbiAgICAgICAgYm9keU5vZGU6Y2MuTm9kZSxcclxuXHJcbiAgICAgICAgc3RhdGVOb2RlOmNjLk5vZGUsXHJcblxyXG4gICAgICAgIC8v5Y+s5ZSk55Sf54mp55qE6Z+z5pWIXHJcbiAgICAgICAgc3VtbW9uRWZmZWN0OmNjLkF1ZGlvQ2xpcCxcclxuICAgICAgICAvL+WPrOWUpOWujOaIkOaXtueahOmfs+aViFxyXG4gICAgICAgIHN1bW1vbkVuZEVmZmVjdDpjYy5BdWRpb0NsaXAsXHJcbiAgICAgICAgLy/nlJ/niannp7vliqjnmoTpn7PmlYhcclxuICAgICAgICBtb3ZlRWZmZWN0OmNjLkF1ZGlvQ2xpcCxcclxuICAgICAgICAvL+eUn+eJqeaUu+WHu+eahOmfs+aViFxyXG4gICAgICAgIGF0dGFja0VmZmVjdDpjYy5BdWRpb0NsaXAsXHJcbiAgICAgICAgLy/mrbvkuqHml7bnmoTpn7PmlYhcclxuICAgICAgICBkaWVFZmZlY3Q6Y2MuQXVkaW9DbGlwLFxyXG4gICAgfSxcclxuXHJcblxyXG4gICAgb25Mb2FkOiBmdW5jdGlvbigpe1xyXG4gICAgICAgIHZhciBpO1xyXG4gICAgICAgIHRoaXMuQVRLQWN0aW9uRmxhZyA9IDA7ICAvL+aUu+WHu+ihjOS4uuagh+iusCAx5pS75Ye76L+b6KGM5LitXHJcbiAgICAgICAgdGhpcy5hdHRhY2tUaW1lciA9IDA7ICAgLy/mlLvlh7vorqHml7blmahcclxuXHJcbiAgICAgICAgdGhpcy5tb3ZlRnJlZXplID0gZmFsc2U7XHJcbiAgICAgICAgdGhpcy5hdHRhY2tGcmVlemUgPSBmYWxzZTtcclxuICAgICAgICB0aGlzLndlZWtuZXNzID0gZmFsc2U7XHJcblxyXG4gICAgICAgIC8qZm9yKGkgPSAwO2kgPCAzO2kgKyspe1xyXG4gICAgICAgICAgICB0aGlzLmhlYWx0aE5vZGVbaV0uYWN0aXZlID0gZmFsc2U7XHJcbiAgICAgICAgfSovXHJcblxyXG5cclxuICAgICAgICB0aGlzLmluaXRBY3Rpb24oKTtcclxuICAgIH0sXHJcblxyXG5cclxuICAgIC8qKlxyXG4gICAgICogQOS4u+imgeWKn+iDvTogICDliJ3lp4vljJbooYzkuLrmlrnms5VcclxuICAgICAqIEBhdXRob3Iga2VuYW5cclxuICAgICAqIEBEYXRlIDIwMTcvNy8yMyAzOjM5XHJcbiAgICAgKi9cclxuICAgIGluaXRBY3Rpb246IGZ1bmN0aW9uKCl7XHJcbiAgICAgICAgLy/lvIDlkK/mlLvlh7vova7or6LkvqbmtYsgICAgICAwLjXmiafooYzkuIDmrKEgICDnm7TliLDplIDmr4EgICAgIOebkeWQrEFUS0FjdGlvbkZsYWdcclxuICAgICAgICB0aGlzLnNjaGVkdWxlKGZ1bmN0aW9uKCl7XHJcbiAgICAgICAgICAgIC8vIGNjLmxvZyhcIuaUu+WHu+i9ruivolwiKVxyXG4gICAgICAgICAgICBpZih0aGlzLnRhcmdldC5sZW5ndGggPT09IDAgJiYgdGhpcy5tb3ZlRnJlZXplID09PSBmYWxzZSl7XHJcbiAgICAgICAgICAgICAgICB0aGlzLkFUS0FjdGlvbkZsYWcgPSBmYWxzZTtcclxuICAgICAgICAgICAgICAgIHRoaXMuYW5pbWF0aW9uQ2xpcC5yZXN1bWUodGhpcy5pZCArIFwiIFwiICsgXCJ3YWxrXCIpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGlmKHRoaXMuYXR0YWNrRnJlZXplID09PSB0cnVlKXtcclxuICAgICAgICAgICAgICAgIHRoaXMuYW5pbWF0aW9uQ2xpcC5wYXVzZSh0aGlzLmlkICsgXCIgXCIgKyBcIndhbGtcIik7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgaWYodGhpcy5BVEtBY3Rpb25GbGFnICYmIHRoaXMuZGVhdGggPT09IGZhbHNlICYmIHRoaXMuc3VtbW9uID09PSBmYWxzZSAmJiB0aGlzLmF0dGFja0ZyZWV6ZSA9PT0gZmFsc2Upe1xyXG4gICAgICAgICAgICAgICAgdGhpcy5hdHRhY2tBY3Rpb24oKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0sIDAuNSwgY2MubWFjcm8uUkVQRUFUX0ZPUkVWRVIpO1xyXG5cclxuXHJcblxyXG4gICAgICAgIC8v5byA5ZCv5pWM5a+555uu5qCH6L2u6K+i5L6m5rWLICAgICAgMC415omn6KGM5LiA5qyhICAg55u05Yiw6ZSA5q+BICAgICAgIOS4jeebkeWQrFxyXG4gICAgICAgIC8vdGhpcy5zY2hlZHVsZShmdW5jdGlvbigpe1xyXG4gICAgICAgIC8vICAgIC8vIGNjLmxvZyhcIuiOt+WPluaVjOWvueebruagh+i9ruivolwiKVxyXG4gICAgICAgIC8vICAgIHZhciBldmVudHNlbmQgPSBuZXcgY2MuRXZlbnQuRXZlbnRDdXN0b20oJ2RhdGFnZXQnLHRydWUpO1xyXG4gICAgICAgIC8vICAgIGV2ZW50c2VuZC5zZXRVc2VyRGF0YSh7dGFyZ2V0OnRoaXMubm9kZX0pO1xyXG4gICAgICAgIC8vICAgIHRoaXMubm9kZS5kaXNwYXRjaEV2ZW50KGV2ZW50c2VuZCk7XHJcbiAgICAgICAgLy99LCAwLjUsIGNjLm1hY3JvLlJFUEVBVF9GT1JFVkVSKTtcclxuICAgIH0sXHJcblxyXG5cclxuXHJcbiAgICB1cGRhdGU6IGZ1bmN0aW9uIChkdCkge1xyXG4gICAgICAgIHZhciBzZWxmID0gdGhpcztcclxuICAgICAgICBzZWxmLmRlbGF5ICsrO1xyXG4gICAgICAgIHNlbGYuaGVhbHRoTGFiZWwuc3RyaW5nID0gc2VsZi5oZWFsdGgudG9GaXhlZCgwKTtcclxuICAgICAgICBzZWxmLmF0dGFja0xhYmVsLnN0cmluZyA9IHNlbGYuYXR0YWNrLnRvRml4ZWQoMCk7XHJcblxyXG4gICAgICAgIC8v6Ieq6Lqr56e75Yqo5Yik5a6aICDlrZjlnKjnm67moIcr6Z2e5pS75Ye7K+WPr+S7peenu+WKqOagh+iusCvoh6rlt7HmsqHmrbtcclxuICAgICAgICBpZighc2VsZi5BVEtBY3Rpb25GbGFnICYmIHNlbGYubW92ZSA9PT0gdHJ1ZSAmJiBzZWxmLmRlYXRoID09PSBmYWxzZSAmJiB0aGlzLm1vdmVGcmVlemUgPT09IGZhbHNlKXtcclxuXHJcbiAgICAgICAgICAgIC8va2VuYW4g55Sx5LqO546w5Zyo6KGM5Li65bm25LiN5ZCM5q2lICDmiYDku6XkvJrmnInlnKjmiafooYzov4fnqIvkuK0g55uu5qCH6IqC54K55bey57uP6KKr5rOo6ZSA55qE5oOF5Ya1ICDmiYDku6Xov5nph4znlKjkuIrmrKHmm7TmlrDnmoTlnZDmoIflpITnkIZcclxuICAgICAgICAgICAgaWYodGhpcy50ZWFtID4gMCl7XHJcbiAgICAgICAgICAgICAgICBzZWxmLm5vZGUueCAtPSB0aGlzLnZlbG9jaXR5O1xyXG4gICAgICAgICAgICB9ZWxzZXtcclxuICAgICAgICAgICAgICAgIHNlbGYubm9kZS54ICs9IHRoaXMudmVsb2NpdHk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9LFxyXG5cclxuXHJcbiAgICAvKipcclxuICAgICAqIEDkuLvopoHlip/og706ICDmlLvlh7vooYzkuLpcclxuICAgICAqIEBhdXRob3Iga2VuYW5cclxuICAgICAqIEBEYXRlIDIwMTcvNy8yMyAxOjM5XHJcbiAgICAgKi9cclxuICAgIGF0dGFja0FjdGlvbjogZnVuY3Rpb24oKXtcclxuICAgICAgICAvL+ebruagh+S4uuepuiDmiJbogIXooqvplIDmr4EgIOS4jeaJp+ihjFxyXG4gICAgICAgIGlmKHRoaXMudGFyZ2V0Lmxlbmd0aCA9PT0gMCl7XHJcbiAgICAgICAgICAgIHRoaXMuQVRLQWN0aW9uRmxhZyA9IGZhbHNlO1xyXG4gICAgICAgICAgICB0aGlzLmFuaW1hdGlvbkNsaXAucmVzdW1lKHRoaXMuaWQgKyBcIiBcIiArIFwid2Fsa1wiKTtcclxuICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgdmFyIHNjcmlwdDtcclxuICAgICAgICBpZih0aGlzLnRhcmdldFR5cGVbMF0gPT09IDApe1xyXG4gICAgICAgICAgICBzY3JpcHQgPSB0aGlzLnRhcmdldFswXS5nZXRDb21wb25lbnQoXCJDcmVhdHVyZVwiKTtcclxuICAgICAgICB9ZWxzZSBpZih0aGlzLnRhcmdldFR5cGVbMF0gPT09IDEpe1xyXG4gICAgICAgICAgICBzY3JpcHQgPSB0aGlzLnRhcmdldFswXS5nZXRDb21wb25lbnQoXCJQbGF5ZXJcIik7XHJcbiAgICAgICAgfWVsc2UgaWYodGhpcy50YXJnZXRUeXBlWzBdID09PSAyKXtcclxuICAgICAgICAgICAgc2NyaXB0ID0gdGhpcy50YXJnZXRbMF0uZ2V0Q29tcG9uZW50KFwiQmFzZVwiKTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHdoaWxlKHNjcmlwdC5kZWF0aCA9PT0gdHJ1ZSl7XHJcbiAgICAgICAgICAgIHRoaXMucmVtb3ZlVGFyZ2V0KDApO1xyXG4gICAgICAgICAgICBpZiAodGhpcy50YXJnZXQubGVuZ3RoID09PSAwKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLkFUS0FjdGlvbkZsYWcgPSBmYWxzZTtcclxuICAgICAgICAgICAgICAgIHRoaXMuYW5pbWF0aW9uQ2xpcC5yZXN1bWUodGhpcy5pZCArIFwiIFwiICsgXCJ3YWxrXCIpO1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGlmKHRoaXMudGFyZ2V0VHlwZVswXSA9PT0gMCl7XHJcbiAgICAgICAgICAgICAgICBzY3JpcHQgPSB0aGlzLnRhcmdldFswXS5nZXRDb21wb25lbnQoXCJDcmVhdHVyZVwiKTtcclxuICAgICAgICAgICAgfWVsc2UgaWYodGhpcy50YXJnZXRUeXBlWzBdID09PSAxKXtcclxuICAgICAgICAgICAgICAgIHNjcmlwdCA9IHRoaXMudGFyZ2V0WzBdLmdldENvbXBvbmVudChcIlBsYXllclwiKTtcclxuICAgICAgICAgICAgfWVsc2UgaWYodGhpcy50YXJnZXRUeXBlWzBdID09PSAyKXtcclxuICAgICAgICAgICAgICAgIHNjcmlwdCA9IHRoaXMudGFyZ2V0WzBdLmdldENvbXBvbmVudChcIkJhc2VcIik7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcblxyXG5cclxuICAgICAgICAvL+WmguaenOacieaUu+WHu+WKqOeUu+aViOaenCAgIOWSjOWtkOW8uSAg5bCx6L+Z6YeM5omn6KGM5ZKM5Yib5bu65ZCnICAg5pS76YCf5Y+v5Lul55So5Yqo55S75pe26ZW/K+W7tui/n+WkhOeQhlxyXG4gICAgICAgIFxyXG4gICAgICAgIHRoaXMuYW5pbWF0aW9uQ2xpcC5wbGF5KHRoaXMuaWQgKyBcIiBcIiArIFwiYXR0YWNrXCIpO1xyXG4gICAgICAgIHRoaXMuYW5pbWF0aW9uQ2xpcC5zdG9wKHRoaXMuaWQgKyBcIiBcIiArIFwid2Fsa1wiKTtcclxuICAgICAgICB0aGlzLnNlbmRFdmVudCh0aGlzLmF0dGFja0VmZmVjdCk7XHJcbiAgICAgICAgdmFyIGFuaW0xID0gdGhpcy5hbmltYXRpb25DbGlwLmdldEFuaW1hdGlvblN0YXRlKHRoaXMuaWQgKyBcIiBcIiArIFwiYXR0YWNrXCIpO1xyXG4gICAgICAgIGFuaW0xLm9uKCdmaW5pc2hlZCcsZnVuY3Rpb24oKXtcclxuICAgICAgICAgICAgdGhpcy5hbmltYXRpb25DbGlwLnBsYXkodGhpcy5pZCArIFwiIFwiICsgXCJ3YWxrXCIpO1xyXG4gICAgICAgICAgICB0aGlzLmFuaW1hdGlvbkNsaXAucGF1c2UodGhpcy5pZCArIFwiIFwiICsgXCJ3YWxrXCIpO1xyXG4gICAgICAgIH0sdGhpcyk7XHJcbiAgICAgICAgLy8gdGhpcy5hdHRhY2tBbmltYXRpb24ucGxheSgpO1xyXG4gICAgICAgIC8vIHRoaXMud2Fsa0FuaW1hdGlvbi5zdG9wKCk7XHJcbiAgICAgICAgLy90aGlzLnNraWxsQW5pbWF0aW9uLm9uKCdmaW5pc2hlZCcsIGZ1bmN0aW9uKCl7XHJcbiAgICAgICAgLy8gICAgdGhpcy5hbmltYXRpb25bMF0uYWN0aXZlID0gdHJ1ZTtcclxuICAgICAgICAvLyAgICB0aGlzLmFuaW1hdGlvblsxXS5hY3RpdmUgPSBmYWxzZTtcclxuICAgICAgICAvLyAgICB0aGlzLmFuaW1hdGlvblsyXS5hY3RpdmUgPSBmYWxzZTtcclxuICAgICAgICAvL1xyXG4gICAgICAgIC8vfSwgICB0aGlzKTvlu7bml7blkI7osIPnlKjmlLvlh7vooYzkuLrmmK9cclxuXHJcbiAgICAgICAgLy/lu7bml7blkI7osIPnlKjmlLvlh7vooYzkuLpcclxuICAgICAgICAvL3NldFRpbWVvdXQoZnVuY3Rpb24oKXtcclxuICAgIFx0ICAgIGlmKHRoaXMuYXR0YWNrQXJlYSA9PT0gMCl7XHJcbiAgICBcdFx0ICAgIHRoaXMuQXR0YWNrQmVoYXZpb3IuYXR0YWNrKHRoaXMubm9kZSwgdGhpcy50YXJnZXRbMF0sIHRoaXMudGFyZ2V0VHlwZVswXSk7XHJcbiAgICBcdCAgICB9ZWxzZXtcclxuICAgIFx0XHQgICAgdGhpcy5BdHRhY2tCZWhhdmlvci5hcmVhQXR0YWNrKHRoaXMubm9kZSk7XHJcbiAgICBcdCAgICB9XHJcbiAgIFxyXG4gICAgICAgIC8vfS5iaW5kKHRoaXMpLDUwMCk7XHJcbiAgICAgICAgLy/ljZXkvZPmiJbogIXojIPlm7TmlLvlh7sgICAg6LCD55So5Lyk5a6z5Y+R55Sf5ZmoXHJcblxyXG4gICAgfSxcclxuXHJcbiAgICAvKipcclxuICAgICAqIEDkuLvopoHlip/og706ICAg55Sf5ZG95Y+Y5pu05Ye95pWw5pS55Y+Y5YC85Li6dmFsdWXvvIzlj5Hliqjov5nkuKrlh73mlbDnmoTlr7nmlrnnm67moIfkuLp0YXJnZXRcclxuICAgICAqIEBhdXRob3Iga2VuYW5cclxuICAgICAqIEBEYXRlIDIwMTcvNy8yMyAxOjQxXHJcbiAgICAgKiBAcGFyYW1ldGVycyB2YWx1ZSB0YXJnZXRcclxuICAgICAqIEByZXR1cm5zIHtudW1iZXJ9ICAg6Zi15Lqh5qCH6K6wIDDmtLvnnYAgIDHmrbvkuoZcclxuICAgICAqL1xyXG4gICAgY2hhbmdlSGVhbHRoOiBmdW5jdGlvbih2YWx1ZSx0YXJnZXQpe1xyXG4gICAgICAgIC8v55So5LqO5pS55Y+Y5Lyk5a6z5YCN5pWw55qE5Y+Y6YePXHJcbiAgICAgICAgdmFyIGFkZCA9IDE7XHJcbiAgICAgICAgaWYodGhpcy53ZWVrbmVzcyA9PT0gdHJ1ZSlhZGQgPSAyO1xyXG4gICAgICAgIGlmKHRoaXMuZGVhdGggPT09IGZhbHNlKSB7XHJcbiAgICAgICAgICAgIGlmICh0aGlzLmhlYWx0aCArIHZhbHVlID4gMCkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5oZWFsdGggPSB0aGlzLmhlYWx0aCArIHZhbHVlICogYWRkO1xyXG4gICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgLy/mrbvkuqFcclxuICAgICAgICAgICAgICAgIHRoaXMuZGVhdGggPSB0cnVlO1xyXG4gICAgICAgICAgICAgICAgaWYgKHRoaXMuZGVhdGggPT09IHRydWUpIHtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLnJlbGVhc2UoKTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAvL2lmKHRhcmdldCAhPT0gdW5kZWZpbmVkKXRhcmdldC54ICs9IC10aGlzLnRlYW0gKiAyMDA7XHJcbiAgICAgICAgfVxyXG5cdCAgICByZXR1cm4gdGhpcy5kZWF0aDsgLy/ov5Tlm57oh6rlt7HmmK/lkKblt7Lnu4/pmLXkuqFcclxuICAgIH0sXHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBA5Li76KaB5Yqf6IO9IOaUueWPmOeUn+eJqeeahOmYn+S8je+8jOW5tuS4lOabtOaWsOS7luS7rFxyXG4gICAgICogQGF1dGhvciBDMTRcclxuICAgICAqIEBEYXRlIDIwMTcvMTIvMTBcclxuICAgICAqIEBwYXJhbWV0ZXJzIHRlYW1cclxuICAgICAqIEByZXR1cm5zIG51bGxcclxuICAgICAqL1xyXG4gICAgY2hhbmdlVGVhbTogZnVuY3Rpb24odGVhbSl7XHJcbiAgICAgICAgdGhpcy5jbGVhblRhcmdldCgpO1xyXG4gICAgICAgIHRoaXMudGVhbSA9IHRlYW07XHJcbiAgICAgICAgdGhpcy5mblRlYW1SZW5ldygpO1xyXG4gICAgfSxcclxuXHJcbiAgICAvKipcclxuICAgICAqIEDkuLvopoHlip/og70g5riF6Zmk5omA5pyJ5pS75Ye755uu5qCHXHJcbiAgICAgKiBAYXV0aG9yIEMxNFxyXG4gICAgICogQERhdGUgMjAxNy8xMi8xMFxyXG4gICAgICogQHBhcmFtZXRlcnMgbnVsbFxyXG4gICAgICogQHJldHVybnMgbnVsbFxyXG4gICAgICovXHJcbiAgICByZW1vdmVBbGxUYXJnZXQ6ZnVuY3Rpb24oKXtcclxuICAgICAgICB0aGlzLnRhcmdldCA9IFtdO1xyXG4gICAgICAgIHRoaXMudGFyZ2V0VHlwZSA9IFtdO1xyXG4gICAgfSxcclxuICAgIC8qKlxyXG4gICAgICogQOS4u+imgeWKn+iDvSDmuIXpmaTkuIDkuKrmlLvlh7vnm67moIdcclxuICAgICAqIEBhdXRob3IgQzE0XHJcbiAgICAgKiBARGF0ZSAyMDE3LzEyLzEwXHJcbiAgICAgKiBAcGFyYW0gbnVsbFxyXG4gICAgICogQHJldHVybnMgbnVsbFxyXG4gICAgICovXHJcbiAgICByZW1vdmVUYXJnZXQ6ZnVuY3Rpb24obnVtKXtcclxuICAgICAgICB0aGlzLnRhcmdldC5zcGxpY2UobnVtLDEpO1xyXG4gICAgICAgIHRoaXMudGFyZ2V0VHlwZS5zcGxpY2UobnVtLDEpO1xyXG4gICAgfSxcclxuICAgIC8qKlxyXG4gICAgICogQOS4u+imgeWKn+iDvTogICDph4rmlL7mlYzkurrnm67moIdcclxuICAgICAqIEBhdXRob3Iga2VuYW5cclxuICAgICAqIEBEYXRlIDIwMTcvNy8yMyAyOjQ2XHJcbiAgICAgKi9cclxuICAgIHJlbGVhc2VUYXJnZXQ6IGZ1bmN0aW9uKCl7XHJcbiAgICAgICAgdGhpcy5mb2N1c1RhcmdldCA9IG51bGw7XHJcbiAgICAgICAgdGhpcy50YXJnZXRYID0gbnVsbDtcclxuICAgIH0sXHJcblxyXG5cclxuXHJcbiAgICAvL+mHiuaUvui1hOa6kFxyXG4gICAgcmVsZWFzZTpmdW5jdGlvbigpe1xyXG4gICAgICAgIHRoaXMuYW5pbWF0aW9uQ2xpcC5zdG9wKHRoaXMuaWQgKyBcIiBcIiArIFwid2Fsa1wiKTtcclxuICAgICAgICB0aGlzLmFuaW1hdGlvbkNsaXAucGxheSh0aGlzLmlkICsgXCIgXCIgKyBcImRlYXRoXCIpO1xyXG4gICAgICAgIHRoaXMuc2VuZEV2ZW50KHRoaXMuZGllRWZmZWN0KTtcclxuICAgICAgICB2YXIgYW5pbTEgPSB0aGlzLmFuaW1hdGlvbkNsaXAuZ2V0QW5pbWF0aW9uU3RhdGUodGhpcy5pZCArIFwiIFwiICsgXCJkZWF0aFwiKTtcclxuICAgICAgICBhbmltMS5vbignZmluaXNoZWQnLGZ1bmN0aW9uKCl7XHJcbiAgICAgICAgICAgIHRoaXMuR2FtZU1hbmFnZXIucmVtb3ZlQ3JlYXR1cmUodGhpcy5ub2RlKTtcclxuICAgICAgICAgICAgdGhpcy5ub2RlLnJlbW92ZUZyb21QYXJlbnQoKTtcclxuICAgICAgICB9LHRoaXMpO1xyXG4gICAgfSxcclxuXHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBA5Li76KaB5Yqf6IO9OiAgICDliJ3lp4vljJbln7rmnKzlj4LmlbAgICDkuLrllaXkuI3lj6tpbml05ZGi77yfXHJcbiAgICAgKiBAcGFyYW1ldGVycyBkYXRhXHJcbiAgICAgKi9cclxuICAgIGZuQ3JlYXRlQ3JlYXR1cmU6ZnVuY3Rpb24oZGF0YSl7XHJcbiAgICAgICAgdGhpcy5ub2RlLnggPSBkYXRhLlg7XHJcbiAgICAgICAgdGhpcy5ub2RlLnkgPSBkYXRhLlk7XHJcbiAgICAgICAgdGhpcy5hdHRhY2sgPSBkYXRhLmF0dGFjaztcclxuICAgICAgICB0aGlzLmhlYWx0aCA9IGRhdGEuaGVhbHRoO1xyXG4gICAgICAgIHRoaXMudmVsb2NpdHkgPSAwO1xyXG4gICAgICAgIHRoaXMudGVhbSA9IGRhdGEudGVhbTtcclxuXHJcbiAgICAgICAgXHJcbiAgICAgICAgdGhpcy5BdHRhY2tCZWhhdmlvciA9IHRoaXMuQXR0YWNrQmVoYXZpb3IuZ2V0Q29tcG9uZW50KFwiQXR0YWNrQmVoYXZpb3JcIik7XHJcbiAgICAgICAgdGhpcy5hbmltYXRpb25DbGlwID0gdGhpcy5ub2RlLmdldENvbXBvbmVudChjYy5BbmltYXRpb24pO1xyXG4gICAgICAgIFxyXG4gICAgICAgIHRoaXMuYW5pbWF0aW9uQ2xpcC5wbGF5KHRoaXMuaWQgKyBcIiBcIiArIFwiYXBwZWFyXCIpO1xyXG4gICAgICAgIHRoaXMuc3VtbW9uID0gdHJ1ZTtcclxuXHJcbiAgICAgICAgdGhpcy5zZW5kRXZlbnQodGhpcy5zdW1tb25FZmZlY3QpO1xyXG4gICAgICAgIHZhciBhbmltMSA9IHRoaXMuYW5pbWF0aW9uQ2xpcC5nZXRBbmltYXRpb25TdGF0ZSh0aGlzLmlkICsgXCIgXCIgKyBcImFwcGVhclwiKTtcclxuICAgICAgICBhbmltMS5vbignZmluaXNoZWQnLGZ1bmN0aW9uKCl7XHJcbiAgICAgICAgICAgIHRoaXMuc2VuZEV2ZW50KHRoaXMuc3VtbW9uRW5kRWZmZWN0KTtcclxuICAgICAgICAgICAgdGhpcy5hbmltYXRpb25DbGlwLnBsYXkodGhpcy5pZCArIFwiIFwiICsgXCJ3YWxrXCIpO1xyXG4gICAgICAgICAgICB0aGlzLnZlbG9jaXR5ID0gZGF0YS52ZWxvY2l0eTtcclxuICAgICAgICAgICAgdGhpcy5zdW1tb24gPSBmYWxzZTtcclxuICAgICAgICB9LHRoaXMpO1xyXG5cclxuXHJcbiAgICAgICAgdGhpcy5mblRlYW1SZW5ldygpO1xyXG4gICAgICAgIGNjLmxvZyh0aGlzLnRlYW0pO1xyXG4gICAgfSxcclxuXHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBA5Li76KaB5Yqf6IO9OiAgIOWIneWni+WMluazqOWFpeeuoeeQhuexu1xyXG4gICAgICogQHBhcmFtZXRlcnMgTWFuYWdlclxyXG4gICAgICovXHJcbiAgICBmbkdldE1hbmFnZXI6ZnVuY3Rpb24oTWFuYWdlcil7XHJcbiAgICAgICAgdGhpcy5HYW1lTWFuYWdlciA9IE1hbmFnZXI7XHJcbiAgICB9LFxyXG5cclxuICAgIC8qKlxyXG4gICAgICogQOS4u+imgeWKn+iDvSDlkJHkuIrnuqfoioLngrnkvKDpgJLmtojmga/vvIzkvb/kuYvmkq3mlL7pn7PmlYhcclxuICAgICAqIEBhdXRob3IgQzE0XHJcbiAgICAgKiBARGF0ZSAyMDE3LzEyLzEyXHJcbiAgICAgKiBAcGFyYW1ldGVycyBhdWRpb0NoaXAgdm9sdW1lXHJcbiAgICAgKiBAcmV0dXJucyBudWxsXHJcbiAgICAgKi9cclxuICAgIHNlbmRFdmVudDpmdW5jdGlvbihhdWRpb0NoaXAsZnVsbFZvbHVtZSx2b2x1bWUpIHtcclxuICAgICAgICB2YXIgZXZlbnRzZW5kID0gbmV3IGNjLkV2ZW50LkV2ZW50Q3VzdG9tKFwicGxheUVmZmVjdFwiLCB0cnVlKTtcclxuICAgICAgICBpZih2b2x1bWUgPT09IHVuZGVmaW5lZCB8fCB2b2x1bWUgPT09IG51bGwpe1xyXG4gICAgICAgICAgICB2b2x1bWUgPSAxO1xyXG4gICAgICAgIH1cclxuICAgICAgICBpZihmdWxsVm9sdW1lID09PSB1bmRlZmluZWQgfHwgZnVsbFZvbHVtZSA9PT0gbnVsbCB8fCBmdWxsVm9sdW1lID09PSBmYWxzZSl7XHJcbiAgICAgICAgICAgIGZ1bGxWb2x1bWUgPSBmYWxzZTtcclxuICAgICAgICB9ZWxzZXtcclxuICAgICAgICAgICAgZnVsbFZvbHVtZSA9IHRydWU7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGV2ZW50c2VuZC5zZXRVc2VyRGF0YSh7XHJcbiAgICAgICAgICAgIGVmZmVjdDphdWRpb0NoaXAsXHJcbiAgICAgICAgICAgIHZvbHVtZTp2b2x1bWUsXHJcbiAgICAgICAgICAgIGZ1bGxWb2x1bWU6ZnVsbFZvbHVtZSxcclxuICAgICAgICAgICAgdGFyZ2V0OnRoaXMubm9kZSxcclxuICAgICAgICB9KTtcclxuICAgICAgICB0aGlzLm5vZGUuZGlzcGF0Y2hFdmVudChldmVudHNlbmQpO1xyXG4gICAgfSxcclxuICAgIC8qKlxyXG4gICAgICogQOS4u+imgeWKn+iDvTogICDliJ3lp4vljJbpmLXokKXmmL7npLrlhoXlrrlcclxuICAgICAqL1xyXG4gICAgZm5UZWFtUmVuZXc6IGZ1bmN0aW9uKCl7XHJcbiAgICAgICAgdGhpcy5ib2R5Tm9kZS5zY2FsZVggPSAtIHRoaXMudGVhbTtcclxuICAgICAgICBpZih0aGlzLnRlYW0gPiAwKXtcclxuICAgICAgICAgICAgdGhpcy5oZWFsdGhOb2RlWzBdLmFjdGl2ZSA9IDA7XHJcbiAgICAgICAgICAgIHRoaXMuaGVhbHRoTm9kZVsxXS5hY3RpdmUgPSAwO1xyXG4gICAgICAgICAgICB0aGlzLmhlYWx0aE5vZGVbMl0uYWN0aXZlID0gMTtcclxuICAgICAgICB9ZWxzZSBpZih0aGlzLnRlYW0gPCAwKXtcclxuICAgICAgICAgICAgdGhpcy5oZWFsdGhOb2RlWzBdLmFjdGl2ZSA9IDE7XHJcbiAgICAgICAgICAgIHRoaXMuaGVhbHRoTm9kZVsxXS5hY3RpdmUgPSAwO1xyXG4gICAgICAgICAgICB0aGlzLmhlYWx0aE5vZGVbMl0uYWN0aXZlID0gMDtcclxuICAgICAgICB9ZWxzZXtcclxuICAgICAgICAgICAgdGhpcy5oZWFsdGhOb2RlWzBdLmFjdGl2ZSA9IDA7XHJcbiAgICAgICAgICAgIHRoaXMuaGVhbHRoTm9kZVsxXS5hY3RpdmUgPSAxO1xyXG4gICAgICAgICAgICB0aGlzLmhlYWx0aE5vZGVbMl0uYWN0aXZlID0gMDsgICAgICAgICAgICBcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG59KTtcclxuIiwidmFyIGdsb2JhbENvbnN0YW50ID0gcmVxdWlyZShcIkNvbnN0YW50XCIpO1xyXG5cclxuY2MuQ2xhc3Moe1xyXG4gICAgZXh0ZW5kczogY2MuQ29tcG9uZW50LFxyXG5cclxuICAgIGNhcmRJRDogMCxcclxuXHJcbiAgICBjYXJkVHlwZTogMCxcclxuXHJcbiAgICBwcm9wZXJ0aWVzOiB7XHJcbiAgICAgICAgLy8g6L+Z5Liq5piv5p6a5Li+77yM55u45b2T55qE5aW955So5ZWK77yM5Lul5ZCO6YO955So6L+Z5Liq5aW95LqGXHJcbiAgICAgICAgbWFnaWNUeXBlOiB7XHJcbiAgICAgICAgICAgIHR5cGU6IGNjLkVudW0oe1xyXG4gICAgICAgICAgICAgICAgTm9UYXJnZXQ6IDAsXHJcbiAgICAgICAgICAgICAgICBBcmVhVGFyZ2V0OiAxLFxyXG4gICAgICAgICAgICAgICAgRGlyZWN0aW9uVGFyZ2V0OiAyLFxyXG4gICAgICAgICAgICB9KSxcclxuICAgICAgICAgICAgZGVmYXVsdDogMFxyXG4gICAgICAgIH0sXHJcblxyXG4gICAgICAgIC8v5pS75Ye75YqbXHJcbiAgICAgICAgYXR0YWNrOiAwLFxyXG4gICAgICAgIC8v5pS75Ye75Yqb5qCH562+XHJcbiAgICAgICAgYXR0YWNrTGFiZWw6IGNjLkxhYmVsLFxyXG4gICAgICAgIC8v55Sf5ZG95YC8XHJcbiAgICAgICAgaGVhbHRoOiAwLFxyXG4gICAgICAgIC8v55Sf5ZG95YC85qCH562+XHJcbiAgICAgICAgaGVhbHRoTGFiZWw6IGNjLkxhYmVsLFxyXG4gICAgICAgIC8v6YCf5bqmXHJcbiAgICAgICAgdmVsb2NpdHk6IDAsXHJcbiAgICAgICAgLy/pgJ/luqZcclxuICAgICAgICB2ZWxvY2l0eUxhYmVsOiBjYy5MYWJlbCxcclxuXHJcbiAgICAgICAgYmFja1JvbGw6Y2MuTm9kZSxcclxuXHJcbiAgICB9LFxyXG5cclxuICAgIC8vIHVzZSB0aGlzIGZvciBpbml0aWFsaXphdGlvblxyXG4gICAgb25Mb2FkOiBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgdmFyIHNlbGYgPSB0aGlzO1xyXG4gICAgICAgIHNlbGYubWFnaWNUeXBlRW51bSA9IGNjLkVudW0oe1xyXG4gICAgICAgICAgICBOb1RhcmdldDogMCxcclxuICAgICAgICAgICAgQXJlYVRhcmdldDogMSxcclxuICAgICAgICAgICAgRGlyZWN0aW9uVGFyZ2V0OiAyLFxyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICBzZWxmLmNhcmRTY3JpcHQgPSBzZWxmLm5vZGUuZ2V0Q29tcG9uZW50KCdDYXJkJyk7XHJcbiAgICAgICAgdGhpcy5oZXJvU2NpcnB0ID0gdGhpcy5jYXJkU2NyaXB0Lmhlcm8uZ2V0Q29tcG9uZW50KCdQbGF5ZXInKTtcclxuXHJcbiAgICAgICAgdGhpcy5wcmVVc2UgPSBmYWxzZTtcclxuXHJcbiAgICAgICAgc2VsZi5hdHRhY2tMYWJlbC5zdHJpbmcgPSBzZWxmLmF0dGFjaztcclxuICAgICAgICBzZWxmLmhlYWx0aExhYmVsLnN0cmluZyA9IHNlbGYuaGVhbHRoO1xyXG4gICAgICAgIHNlbGYudmVsb2NpdHlMYWJlbC5zdHJpbmcgPSBzZWxmLnZlbG9jaXR5O1xyXG4gICAgICAgIC8vdGhpcy5jU2NyaXB0ID0gbnVsbDtcclxuICAgICAgICBpZihzZWxmLmNhcmRTY3JpcHQuY2FyZFR5cGUgPT09IDApe1xyXG4gICAgICAgICAgICB0aGlzLmNTY3JpcHQgPSBzZWxmLm5vZGUuZ2V0Q29tcG9uZW50KCdNJyArIHNlbGYuY2FyZFNjcmlwdC5jYXJkSUQpO1xyXG4gICAgICAgIH1lbHNle1xyXG4gICAgICAgICAgICB0aGlzLmNTY3JpcHQgPSBzZWxmLm5vZGUuZ2V0Q29tcG9uZW50KCdDJyArIHNlbGYuY2FyZFNjcmlwdC5jYXJkSUQpO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgdGhpcy5zdGFydExpc3RlbigpO1xyXG4gICAgICAgIC8vIOi/meS4qua3u+WKoOebkeWQrOS4uua1i+ivleeUqFxyXG4gICAgICAgIC8vIHNlbGYuc3RhcnRMaXN0ZW4oKTtcclxuICAgIH0sXHJcbiAgICBzZXRIZWFsdGhUbzogZnVuY3Rpb24oaGVhbHRoKXtcclxuICAgICAgICB2YXIgc2VsZiA9IHRoaXM7XHJcbiAgICAgICAgc2VsZi5oZWFsdGggPSBoZWFsdGg7XHJcbiAgICAgICAgc2VsZi5oZWFsdGhMYWJlbC5zdHJpbmcgPSBzZWxmLmhlYWx0aDtcclxuICAgIH0sXHJcbiAgICBzZXRIZWFsdGhCeTogZnVuY3Rpb24oZEhlYWx0aCl7XHJcbiAgICAgICAgdmFyIHNlbGYgPSB0aGlzO1xyXG4gICAgICAgIHNlbGYuaGVhbHRoICs9IGRIZWFsdGg7XHJcbiAgICAgICAgc2VsZi5oZWFsdGhMYWJlbC5zdHJpbmcgPSBzZWxmLmhlYWx0aDtcclxuICAgIH0sXHJcbiAgICBzZXRBdHRhY2tUbzogZnVuY3Rpb24oYXR0YWNrKXtcclxuICAgICAgICB2YXIgc2VsZiA9IHRoaXM7XHJcbiAgICAgICAgc2VsZi5hdHRhY2sgKz0gYXR0YWNrO1xyXG4gICAgICAgIHNlbGYuYXR0YWNrTGFiZWwuc3RyaW5nID0gc2VsZi5hdHRhY2s7XHJcbiAgICB9LFxyXG4gICAgc2V0QXR0YWNrQnk6IGZ1bmN0aW9uKGRBdHRhY2spe1xyXG4gICAgICAgIHZhciBzZWxmID0gdGhpcztcclxuICAgICAgICBzZWxmLmF0dGFja0xhYmVsLnN0cmluZyA9IHNlbGYuYXR0YWNrICs9IGRBdHRhY2s7XHJcbiAgICB9LFxyXG4gICAgLyoqXHJcbiAgICAgKlxyXG4gICAgICogQHBhcmFtIGV2ZW50XHJcbiAgICAgKiBAY29uc3RydWN0b3JcclxuICAgICAqL1xyXG4gICAgTm9UYXJnZXRNYWdpY1N0YXJ0TGlzdGVuOiBmdW5jdGlvbiAoZXZlbnQpIHtcclxuICAgICAgICBpZiAoZXZlbnQuZ2V0QnV0dG9uKCkgPT09IGNjLkV2ZW50LkV2ZW50TW91c2UuQlVUVE9OX0xFRlQpXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcIk5vVGFyZ2V0TWFnaWNTdGFydExpc3RlblwiICsgZXZlbnQuZ2V0TG9jYXRpb25YKCkudG9GaXhlZCgwKSk7XHJcbiAgICAgICAgfVxyXG4gICAgfSxcclxuICAgIC8qKlxyXG4gICAgICpcclxuICAgICAqIEBwYXJhbSBldmVudFxyXG4gICAgICogQGNvbnN0cnVjdG9yXHJcbiAgICAgKi9cclxuICAgIEFyZWFUYXJnZXRNYWdpY1N0YXJ0TGlzdGVuOiBmdW5jdGlvbiAoZXZlbnQpIHtcclxuICAgICAgICAvL2NvbnNvbGUubG9nKFwiQXJlYVRhcmdldE1hZ2ljU3RhcnRMaXN0ZW5cIik7XHJcbiAgICB9LFxyXG4gICAgLyoqXHJcbiAgICAgKlxyXG4gICAgICogQHBhcmFtIGV2ZW50XHJcbiAgICAgKiBAY29uc3RydWN0b3JcclxuICAgICAqL1xyXG4gICAgRGlyZWN0aW9uVGFyZ2V0TWFnaWNTdGFydExpc3RlbjogZnVuY3Rpb24gKGV2ZW50KSB7XHJcbiAgICAgICAgLy9jb25zb2xlLmxvZyhcIkRpcmVjdGlvblRhcmdldE1hZ2ljU3RhcnRMaXN0ZW5cIik7XHJcbiAgICB9LFxyXG4gICAgLyoqXHJcbiAgICAgKlxyXG4gICAgICogQHBhcmFtIGV2ZW50XHJcbiAgICAgKiBAY29uc3RydWN0b3JcclxuICAgICAqL1xyXG4gICAgTm9UYXJnZXRNYWdpY01vdmVMaXN0ZW46IGZ1bmN0aW9uIChldmVudCkge1xyXG4gICAgICAgIGlmKHRoaXMubm9kZS55ID4gZ2xvYmFsQ29uc3RhbnQuY2FyZFVzZUxpbmUgJiYgdGhpcy5wcmVVc2UgPT09IGZhbHNlKXtcclxuICAgICAgICAgICAgdGhpcy5ub2RlLm9wYWNpdHkgPSAyMDA7XHJcbiAgICAgICAgICAgIHRoaXMucHJlVXNlID0gdHJ1ZTtcclxuICAgICAgICB9XHJcbiAgICAgICAgaWYodGhpcy5ub2RlLnkgPD0gZ2xvYmFsQ29uc3RhbnQuY2FyZFVzZUxpbmUgJiYgdGhpcy5wcmVVc2UgPT09IHRydWUpe1xyXG4gICAgICAgICAgICB0aGlzLm5vZGUub3BhY2l0eSA9IDEwMDA7XHJcbiAgICAgICAgICAgIHRoaXMucHJlVXNlID0gZmFsc2U7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIC8vIGNvbnNvbGUubG9nKFwiTm9UYXJnZXRNYWdpY1N0YXJ0TGlzdGVuIFwiICsgZXZlbnQuZ2V0TG9jYXRpb25YKCkudG9GaXhlZCgwKSArIFwiLFwiICsgZXZlbnQuZ2V0TG9jYXRpb25ZKCkudG9GaXhlZCgwKSk7XHJcbiAgICB9LFxyXG4gICAgLyoqXHJcbiAgICAgKlxyXG4gICAgICogQHBhcmFtIGV2ZW50XHJcbiAgICAgKiBAY29uc3RydWN0b3JcclxuICAgICAqL1xyXG4gICAgQXJlYVRhcmdldE1hZ2ljTW92ZUxpc3RlbjogZnVuY3Rpb24gKGV2ZW50KSB7XHJcbiAgICAgICAgLy9jb25zb2xlLmxvZyhcIkFyZWFUYXJnZXRNYWdpY01vdmVMaXN0ZW5cIik7XHJcbiAgICB9LFxyXG4gICAgLyoqXHJcbiAgICAgKlxyXG4gICAgICogQHBhcmFtIGV2ZW50XHJcbiAgICAgKiBAY29uc3RydWN0b3JcclxuICAgICAqL1xyXG4gICAgRGlyZWN0aW9uVGFyZ2V0TWFnaWNNb3ZlTGlzdGVuOiBmdW5jdGlvbiAoZXZlbnQpIHtcclxuICAgICAgICAvL2NvbnNvbGUubG9nKFwiRGlyZWN0aW9uVGFyZ2V0TWFnaWNNb3ZlTGlzdGVuXCIpO1xyXG4gICAgfSxcclxuICAgIC8qKlxyXG4gICAgICpcclxuICAgICAqIEBwYXJhbSBldmVudFxyXG4gICAgICogQGNvbnN0cnVjdG9yXHJcbiAgICAgKi9cclxuICAgIE5vVGFyZ2V0TWFnaWNFbmRMaXN0ZW46IGZ1bmN0aW9uIChldmVudCkge1xyXG4gICAgICAgIC8vY29uc29sZS5sb2coXCJOb1RhcmdldE1hZ2ljRW5kTGlzdGVuXCIpO1xyXG4gICAgICAgIGlmKHRoaXMucHJlVXNlID09PSB0cnVlKSB7XHJcbiAgICAgICAgICAgIHRoaXMuaGVyb1NjaXJwdC5tYW5hIC09IHRoaXMuY2FyZFNjcmlwdC5tYW5hQ29uc3VtZTtcclxuICAgICAgICAgICAgdGhpcy5jU2NyaXB0LnVzZUNhcmQoKTtcclxuICAgICAgICB9XHJcbiAgICB9LFxyXG4gICAgLyoqXHJcbiAgICAgKlxyXG4gICAgICogQHBhcmFtIGV2ZW50XHJcbiAgICAgKiBAY29uc3RydWN0b3JcclxuICAgICAqL1xyXG4gICAgQXJlYVRhcmdldE1hZ2ljRW5kTGlzdGVuOiBmdW5jdGlvbiAoZXZlbnQpIHtcclxuICAgICAgICAvL2NvbnNvbGUubG9nKFwiQXJlYVRhcmdldE1hZ2ljRW5kTGlzdGVuXCIpO1xyXG4gICAgICAgIC8vIHRoaXMubm9kZS5yZW1vdmVGcm9tUGFyZW50KCk7XHJcbiAgICB9LFxyXG4gICAgLyoqXHJcbiAgICAgKlxyXG4gICAgICogQHBhcmFtIGV2ZW50XHJcbiAgICAgKiBAY29uc3RydWN0b3JcclxuICAgICAqL1xyXG4gICAgRGlyZWN0aW9uVGFyZ2V0TWFnaWNFbmRMaXN0ZW46IGZ1bmN0aW9uIChldmVudCkge1xyXG4gICAgICAgIC8vY29uc29sZS5sb2coXCJEaXJlY3Rpb25UYXJnZXRNYWdpY0VuZExpc3RlblwiKTtcclxuICAgIH0sXHJcblxyXG5cclxuICAgIC8vIOW8gOWQr+ebkeWQrOeahOS9jee9ru+8jOS4jei/h+WYm++8jOWQjumdoui/mOW+l+aUue+8jOi/memHjOWFiOaQreS4quaooeWtkO+8jOiHs+WwkeS/neivgeWKn+iDveato+W4uFxyXG4gICAgc3RhcnRMaXN0ZW46IGZ1bmN0aW9uICgpIHtcclxuICAgICAgICB2YXIgc2VsZiA9IHRoaXM7XHJcbiAgICAgICAgY29uc29sZS5sb2coXCJhZGQgbGlzdGVuXCIpO1xyXG4gICAgICAgIHN3aXRjaCAoc2VsZi5tYWdpY1R5cGUpIHtcclxuICAgICAgICAgICAgY2FzZSAwOlxyXG4gICAgICAgICAgICAgICAgc2VsZi5ub2RlLm9uKGNjLk5vZGUuRXZlbnRUeXBlLk1PVVNFX0RPV04sIHNlbGYuTm9UYXJnZXRNYWdpY1N0YXJ0TGlzdGVuLCBzZWxmKTtcclxuICAgICAgICAgICAgICAgIHNlbGYubm9kZS5vbihjYy5Ob2RlLkV2ZW50VHlwZS5NT1VTRV9NT1ZFLCBzZWxmLk5vVGFyZ2V0TWFnaWNNb3ZlTGlzdGVuLCBzZWxmKTtcclxuICAgICAgICAgICAgICAgIHNlbGYubm9kZS5vbihjYy5Ob2RlLkV2ZW50VHlwZS5NT1VTRV9VUCwgc2VsZi5Ob1RhcmdldE1hZ2ljRW5kTGlzdGVuLCBzZWxmKTtcclxuICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICBjYXNlIDE6XHJcbiAgICAgICAgICAgICAgICBzZWxmLm5vZGUub24oY2MuTm9kZS5FdmVudFR5cGUuTU9VU0VfRE9XTiwgc2VsZi5BcmVhVGFyZ2V0TWFnaWNTdGFydExpc3Rlbiwgc2VsZik7XHJcbiAgICAgICAgICAgICAgICBzZWxmLm5vZGUub24oY2MuTm9kZS5FdmVudFR5cGUuTU9VU0VfTU9WRSwgc2VsZi5BcmVhVGFyZ2V0TWFnaWNNb3ZlTGlzdGVuLCBzZWxmKTtcclxuICAgICAgICAgICAgICAgIHNlbGYubm9kZS5vbihjYy5Ob2RlLkV2ZW50VHlwZS5NT1VTRV9VUCwgc2VsZi5BcmVhVGFyZ2V0TWFnaWNFbmRMaXN0ZW4sIHNlbGYpO1xyXG4gICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgIGNhc2UgMjpcclxuICAgICAgICAgICAgICAgIHNlbGYubm9kZS5vbihjYy5Ob2RlLkV2ZW50VHlwZS5NT1VTRV9ET1dOLCBzZWxmLkRpcmVjdGlvblRhcmdldE1hZ2ljU3RhcnRMaXN0ZW4sIHNlbGYpO1xyXG4gICAgICAgICAgICAgICAgc2VsZi5ub2RlLm9uKGNjLk5vZGUuRXZlbnRUeXBlLk1PVVNFX01PVkUsIHNlbGYuRGlyZWN0aW9uVGFyZ2V0TWFnaWNNb3ZlTGlzdGVuLCBzZWxmKTtcclxuICAgICAgICAgICAgICAgIHNlbGYubm9kZS5vbihjYy5Ob2RlLkV2ZW50VHlwZS5NT1VTRV9VUCwgc2VsZi5EaXJlY3Rpb25UYXJnZXRNYWdpY0VuZExpc3Rlbiwgc2VsZik7XHJcbiAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICB9XHJcbiAgICB9LFxyXG5cclxuICAgIC8vIGNhbGxlZCBldmVyeSBmcmFtZSwgdW5jb21tZW50IHRoaXMgZnVuY3Rpb24gdG8gYWN0aXZhdGUgdXBkYXRlIGNhbGxiYWNrXHJcbiAgICAvLyB1cGRhdGU6IGZ1bmN0aW9uIChkdCkge1xyXG5cclxuICAgIC8vIH0sXHJcbn0pOyIsInZhciBHbG9iYWwgPSByZXF1aXJlKCdHbG9iYWwnKTtcclxuXHJcbmNjLkNsYXNzKHtcclxuICAgIGV4dGVuZHM6IGNjLkNvbXBvbmVudCxcclxuXHJcbiAgICBwcm9wZXJ0aWVzOiB7XHJcbiAgICAgICAgXHJcbiAgICAgICAgY2FyZEJvYXJkOiBjYy5Ob2RlLFxyXG4gICAgICAgIG1haW5TY2VuY2U6Y2MuTm9kZSxcclxuICAgICAgICBcclxuICAgICAgICBkZWNrTnVtOmNjLkxhYmVsLFxyXG5cclxuICAgICAgICBkZWNrQWRkQnV0dG9uOmNjLk5vZGUsXHJcbiAgICB9LFxyXG5cclxuICAgIC8vIHVzZSB0aGlzIGZvciBpbml0aWFsaXphdGlvblxyXG4gICAgb25Mb2FkOiBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgdGhpcy5kZWxheSA9IDA7XHJcbiAgICAgICAgdGhpcy5jYXJkTGlzdCA9IHRoaXMuY2FyZEJvYXJkLmdldENvbXBvbmVudCgnQ2FyZExpc3QnKTtcclxuICAgICAgICB0aGlzLm1haW5TY3JpcHQgPSB0aGlzLm1haW5TY2VuY2UuZ2V0Q29tcG9uZW50KCdNYWluU2NlbmVNYW5hZ2VyJyk7XHJcbiAgICAgICAgdGhpcy5kZWNrQWRkU2NyaXB0ID0gdGhpcy5kZWNrQWRkQnV0dG9uLmdldENvbXBvbmVudChjYy5CdXR0b24pO1xyXG5cclxuICAgICAgICB0aGlzLmluaXRMaXN0ZW5FdmVudCgpO1xyXG4gICAgfSxcclxuICAgIFxyXG4gICAgaW5pdExpc3RlbkV2ZW50OiBmdW5jdGlvbigpe1xyXG4gICAgICAgIFxyXG4gICAgICAgIHRoaXMubm9kZS5vbihcIm1vdXNlRG93blRoZVNob3dDYXJkXCIscmVtb3ZlQ2FyZCx0aGlzKTtcclxuICAgICAgICB0aGlzLm5vZGUub24oXCJtb3VzZURvd25UaGVEZWNrXCIsZ2V0SW5EZWNrLHRoaXMpO1xyXG4gICAgICAgIHRoaXMubm9kZS5vbihcIm5hbWVUaGVEZWNrXCIsY2hhbmdlRGVja05hbWUsdGhpcyk7XHJcbiAgICAgICAgdGhpcy5ub2RlLm9uKFwicmVtb3ZlVGhlRGVja1wiLHJlbW92ZURlY2ssdGhpcyk7XHJcblxyXG4gICAgICAgICAgICBmdW5jdGlvbiByZW1vdmVDYXJkKGV2ZW50KXtcclxuICAgICAgICAgICAgdmFyIGkgPSAwO1xyXG4gICAgICAgICAgICAgICAgZXZlbnQuZGV0YWlsLm9iamVjdC5hZGROdW1CeSgtMSk7XHJcbiAgICAgICAgICAgICAgICBpZihldmVudC5kZXRhaWwub2JqZWN0LmNhcmRUeXBlID09PSAxKXtcclxuICAgICAgICAgICAgICAgICAgICAvL3RoaXMubWFpblNjcmlwdC5teUNEZWNrW2V2ZW50LmRldGFpbC5vYmplY3QuY2FyZElkXS0tO1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuY2FyZExpc3QuZGVja051bS0tO1xyXG4gICAgICAgICAgICAgICAgICAgIGlmKC0tdGhpcy5tYWluU2NyaXB0Lm15Q0RlY2tbZXZlbnQuZGV0YWlsLm9iamVjdC5jYXJkSWRdID09PSAwKXtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5jYXJkTGlzdC5jYXJkRGVja0luaXQoKTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9ZWxzZXtcclxuICAgICAgICAgICAgICAgICAgICAvL3RoaXMubWFpblNjcmlwdC5teU1EZWNrW2V2ZW50LmRldGFpbC5vYmplY3QuY2FyZElkXS0tO1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuY2FyZExpc3QuZGVja051bS0tO1xyXG4gICAgICAgICAgICAgICAgICAgIGlmKC0tdGhpcy5tYWluU2NyaXB0Lm15TURlY2tbZXZlbnQuZGV0YWlsLm9iamVjdC5jYXJkSWRdID09PSAwKXtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5jYXJkTGlzdC5jYXJkRGVja0luaXQoKTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgLy9mb3IoaT0wO2k8dGhpcy5jYXJkTGlzdC5kZWNrLmxlbmd0aDtpKyspe1xyXG4gICAgICAgICAgICAvLyAgICBpZih0aGlzLmNhcmRMaXN0LmRlY2tbaV0gPT09IGV2ZW50LmRldGFpbC5vYmplY3Qubm9kZSl7XHJcbiAgICAgICAgICAgIC8vICAgICAgICB0aGlzLmNhcmRMaXN0LmRlY2suc3BsaWNlKGksMSk7XHJcbiAgICAgICAgICAgIC8vICAgICAgICBldmVudC5kZXRhaWwub2JqZWN0Lm5vZGUucmVtb3ZlRnJvbVBhcmVudCgpO1xyXG4gICAgICAgICAgICAvLyAgICB9ZWxzZXtcclxuICAgICAgICAgICAgLy8gICAgICAgIHRoaXMubWFpblNjcmlwdC5teU1EZWNrW2V2ZW50LmRldGFpbC5vYmplY3QuY2FyZElkXS0tO1xyXG4gICAgICAgICAgICAvLyAgICAgICAgdGhpcy5jYXJkTGlzdC5kZWNrTnVtLS07XHJcbiAgICAgICAgICAgIC8vICAgICAgICBpZih0aGlzLm1haW5TY3JpcHQubXlNRGVja1tldmVudC5kZXRhaWwub2JqZWN0LmNhcmRJZF0gPT09IDApe1xyXG4gICAgICAgICAgICAvLyAgICAgICAgICAgIGZvcihpPTA7aTx0aGlzLmNhcmRMaXN0LmRlY2subGVuZ3RoO2krKyl7XHJcbiAgICAgICAgICAgIC8vICAgICAgICAgICAgICAgIGlmKHRoaXMuY2FyZExpc3QuZGVja1tpXSA9PT0gZXZlbnQuZGV0YWlsLm9iamVjdC5ub2RlKXtcclxuICAgICAgICAgICAgLy8gICAgICAgICAgICAgICAgICAgIHRoaXMuY2FyZExpc3QuZGVjay5zcGxpY2UoaSwxKTtcclxuICAgICAgICAgICAgLy8gICAgICAgICAgICAgICAgICAgIGV2ZW50LmRldGFpbC5vYmplY3Qubm9kZS5yZW1vdmVGcm9tUGFyZW50KCk7XHJcbiAgICAgICAgICAgIC8vICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgLy8gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIC8vICAgICAgICB9XHJcbiAgICAgICAgICAgIC8vICAgIH1cclxuICAgICAgICAgICAgLy99XHJcbiAgICAgICAgICAgIGZ1bmN0aW9uIGNoYW5nZURlY2tOYW1lKGV2ZW50KXtcclxuICAgICAgICAgICAgICAgIEdsb2JhbC50b3RhbERlY2tEYXRhW0dsb2JhbC5kZWNrVmlld10ubmFtZSA9IGV2ZW50LmRldGFpbC5uYW1lO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGZ1bmN0aW9uIHJlbW92ZURlY2soZXZlbnQpe1xyXG4gICAgICAgICAgICAgICAgY2MubG9nKGV2ZW50LmRldGFpbC5vYmplY3QubnVtKTtcclxuICAgICAgICAgICAgICAgIEdsb2JhbC50b3RhbERlY2tEYXRhLnNwbGljZShldmVudC5kZXRhaWwub2JqZWN0Lm51bSwxKTtcclxuICAgICAgICAgICAgICAgIGZvcih2YXIgaT0wO2k8R2xvYmFsLnRvdGFsRGVja0RhdGEubGVuZ3RoO2krKylcclxuICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICBHbG9iYWwudG90YWxEZWNrRGF0YVtpXS5udW0gPSBpO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgZXZlbnQuZGV0YWlsLm9iamVjdC5ub2RlLnJlbW92ZUZyb21QYXJlbnQoKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBmdW5jdGlvbiBnZXRJbkRlY2soZXZlbnQpe1xyXG4gICAgICAgICAgICAgICAgdGhpcy5jYXJkTGlzdC5tb2RlQ2hhbmdlMigpO1xyXG4gICAgICAgICAgICAgICAgR2xvYmFsLmRlY2tWaWV3ID0gZXZlbnQuZGV0YWlsLm9iamVjdC5udW07XHJcblxyXG4gICAgICAgICAgICAgICAgdGhpcy5tYWluU2NyaXB0Lm15TURlY2sgPSBHbG9iYWwudG90YWxEZWNrRGF0YVtHbG9iYWwuZGVja1ZpZXddLm1hZ2ljRGVjaztcclxuICAgICAgICAgICAgICAgIHRoaXMubWFpblNjcmlwdC5teUNEZWNrID0gR2xvYmFsLnRvdGFsRGVja0RhdGFbR2xvYmFsLmRlY2tWaWV3XS5jcmVhdHVyZURlY2s7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmRlY2tBZGRTY3JpcHQuaW50ZXJhY3RhYmxlID0gZmFsc2U7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmNhcmRMaXN0Lm9qYmsuYWN0aXZlID0gdHJ1ZTtcclxuXHJcbiAgICAgICAgICAgICAgICB0aGlzLmNhcmRMaXN0LmNhcmREZWNrSW5pdCgpO1xyXG4gICAgICAgICAgICB9XHJcblxyXG5cclxuICAgIH0sXHJcbiAgICBnZXRPdXREZWNrOmZ1bmN0aW9uKGV2ZW50KSB7XHJcbiAgICAgICAgdGhpcy5jYXJkTGlzdC5tb2RlQ2hhbmdlMCgpO1xyXG4gICAgICAgIC8vR2xvYmFsLnRvdGFsRGVja0RhdGEuZGVja1ZpZXcgPSBldmVudC5kZXRhaWwub2JqZWN0Lm51bTtcclxuICAgICAgICBHbG9iYWwudG90YWxEZWNrRGF0YVtHbG9iYWwuZGVja1ZpZXddLm1hZ2ljRGVjayA9IHRoaXMubWFpblNjcmlwdC5teU1EZWNrO1xyXG4gICAgICAgIEdsb2JhbC50b3RhbERlY2tEYXRhW0dsb2JhbC5kZWNrVmlld10uY3JlYXR1cmVEZWNrID0gdGhpcy5tYWluU2NyaXB0Lm15Q0RlY2s7XHJcbiAgICAgICAgaWYodGhpcy5jYXJkTGlzdC5kZWNrTnVtID09PSAzMClHbG9iYWwudG90YWxEZWNrRGF0YVtHbG9iYWwuZGVja1ZpZXddLnVzYWJsZSA9IHRydWU7XHJcbiAgICAgICAgZWxzZSBHbG9iYWwudG90YWxEZWNrRGF0YVtHbG9iYWwuZGVja1ZpZXddLnVzYWJsZSA9IGZhbHNlO1xyXG4gICAgICAgIHRoaXMuZGVja0FkZFNjcmlwdC5pbnRlcmFjdGFibGUgPSB0cnVlO1xyXG4gICAgICAgIHRoaXMuY2FyZExpc3Qub2piay5hY3RpdmUgPSBmYWxzZTtcclxuXHJcbiAgICAgICAgdGhpcy5jYXJkTGlzdC5yZW5ld0RlY2tWaWV3KCk7XHJcbiAgICB9LFxyXG4gICAgYWRkRGVjazpmdW5jdGlvbigpe1xyXG4gICAgICAgIHZhciBkZWNrRGF0YSA9IHtcclxuICAgICAgICAgICAgbmFtZTpcIm5ldyBkZWNrXCIsXHJcbiAgICAgICAgICAgIC8vZGVja1ZpZXc6MCxcclxuICAgICAgICAgICAgbnVtOjAsXHJcbiAgICAgICAgICAgIG1hZ2ljRGVjazp7XHJcbiAgICAgICAgICAgICAgICBkZWZhdWx0OiBbXSxcclxuICAgICAgICAgICAgICAgIHR5cGU6IGNjLkludGVnZXJcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgY3JlYXR1cmVEZWNrOntcclxuICAgICAgICAgICAgICAgIGRlZmF1bHQ6W10sXHJcbiAgICAgICAgICAgICAgICB0eXBlOiBjYy5JbnRlZ2VyXHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIC8vPz8/Pz9cclxuICAgICAgICAgICAgdHlwZToge1xyXG4gICAgICAgICAgICAgICAgdHlwZTogY2MuRW51bSh7XHJcbiAgICAgICAgICAgICAgICAgICAgLy8/P1xyXG4gICAgICAgICAgICAgICAgICAgIC8vPz9cclxuICAgICAgICAgICAgICAgICAgICBTY2llbmNlOiAwLFxyXG4gICAgICAgICAgICAgICAgICAgIEZhbnRhc3k6IDEsXHJcbiAgICAgICAgICAgICAgICAgICAgLy8/P1xyXG4gICAgICAgICAgICAgICAgICAgIENoYW9zOiAyXHJcbiAgICAgICAgICAgICAgICB9KSxcclxuICAgICAgICAgICAgICAgIGRlZmF1bHQ6IDBcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgdXNhYmxlOmZhbHNlXHJcbiAgICAgICAgfTtcclxuXHJcbiAgICAgICAgdGhpcy5jYXJkTGlzdC5tb2RlQ2hhbmdlMigpO1xyXG4gICAgICAgIGRlY2tEYXRhLm51bSA9IEdsb2JhbC50b3RhbERlY2tEYXRhLmxlbmd0aDtcclxuICAgICAgICBkZWNrRGF0YS5tYWdpY0RlY2sgPSBbMCwwXTtcclxuICAgICAgICBkZWNrRGF0YS5jcmVhdHVyZURlY2sgPSBbMCwwXTtcclxuICAgICAgICBHbG9iYWwudG90YWxEZWNrRGF0YS5wdXNoKGRlY2tEYXRhKTtcclxuICAgICAgICBHbG9iYWwuZGVja1ZpZXcgPSBHbG9iYWwudG90YWxEZWNrRGF0YS5sZW5ndGggLSAxO1xyXG4gICAgICAgIHRoaXMubWFpblNjcmlwdC5teU1EZWNrID0gR2xvYmFsLnRvdGFsRGVja0RhdGFbR2xvYmFsLmRlY2tWaWV3XS5tYWdpY0RlY2s7XHJcbiAgICAgICAgdGhpcy5tYWluU2NyaXB0Lm15Q0RlY2sgPSBHbG9iYWwudG90YWxEZWNrRGF0YVtHbG9iYWwuZGVja1ZpZXddLmNyZWF0dXJlRGVjaztcclxuICAgICAgICB0aGlzLmRlY2tBZGRTY3JpcHQuaW50ZXJhY3RhYmxlID0gZmFsc2U7XHJcbiAgICAgICAgdGhpcy5jYXJkTGlzdC5vamJrLmFjdGl2ZSA9IHRydWU7XHJcblxyXG4gICAgICAgIHRoaXMuY2FyZExpc3QuY2FyZERlY2tJbml0KCk7XHJcbiAgICB9LFxyXG4gICAgLy8gY2FsbGVkIGV2ZXJ5IGZyYW1lLCB1bmNvbW1lbnQgdGhpcyBmdW5jdGlvbiB0byBhY3RpdmF0ZSB1cGRhdGUgY2FsbGJhY2tcclxuICAgIHVwZGF0ZTogZnVuY3Rpb24gKGR0KSB7XHJcbiAgICAgICAgdGhpcy5kZWxheSArKztcclxuICAgICAgICBpZih0aGlzLmRlbGF5ID49IDYpe1xyXG4gICAgICAgICAgICB0aGlzLmRlbGF5ID0gMDtcclxuICAgICAgICAgICAgaWYodGhpcy5jYXJkTGlzdC5tb2RlID09PSAyKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmRlY2tOdW0uc3RyaW5nID0gdGhpcy5jYXJkTGlzdC5kZWNrTnVtICsgJy8nICsgdGhpcy5tYWluU2NyaXB0Lm1heERlY2tOdW07XHJcbiAgICAgICAgICAgIH1lbHNle1xyXG4gICAgICAgICAgICAgICAgdGhpcy5kZWNrTnVtLnN0cmluZyA9IEdsb2JhbC50b3RhbERlY2tEYXRhLmxlbmd0aCArICcvJyArIDk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9XHJcbn0pO1xyXG4iLCJjYy5DbGFzcyh7XHJcbiAgICBleHRlbmRzOiBjYy5Db21wb25lbnQsXHJcblxyXG4gICAgcHJvcGVydGllczoge1xyXG4gICAgICAgIHN0b3JlTm9kZTpjYy5Ob2RlLFxyXG4gICAgICAgIC8vIGZvbzoge1xyXG4gICAgICAgIC8vICAgIGRlZmF1bHQ6IG51bGwsICAgICAgLy8gVGhlIGRlZmF1bHQgdmFsdWUgd2lsbCBiZSB1c2VkIG9ubHkgd2hlbiB0aGUgY29tcG9uZW50IGF0dGFjaGluZ1xyXG4gICAgICAgIC8vICAgICAgICAgICAgICAgICAgICAgICAgICAgdG8gYSBub2RlIGZvciB0aGUgZmlyc3QgdGltZVxyXG4gICAgICAgIC8vICAgIHVybDogY2MuVGV4dHVyZTJELCAgLy8gb3B0aW9uYWwsIGRlZmF1bHQgaXMgdHlwZW9mIGRlZmF1bHRcclxuICAgICAgICAvLyAgICBzZXJpYWxpemFibGU6IHRydWUsIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIHRydWVcclxuICAgICAgICAvLyAgICB2aXNpYmxlOiB0cnVlLCAgICAgIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIHRydWVcclxuICAgICAgICAvLyAgICBkaXNwbGF5TmFtZTogJ0ZvbycsIC8vIG9wdGlvbmFsXHJcbiAgICAgICAgLy8gICAgcmVhZG9ubHk6IGZhbHNlLCAgICAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyBmYWxzZVxyXG4gICAgICAgIC8vIH0sXHJcbiAgICAgICAgLy8gLi4uXHJcbiAgICB9LFxyXG5cclxuICAgIC8vIHVzZSB0aGlzIGZvciBpbml0aWFsaXphdGlvblxyXG4gICAgb25Mb2FkOiBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgdGhpcy5pbkRvb3IgPSBmYWxzZTtcclxuICAgICAgICBjYy5kaXJlY3Rvci5nZXRDb2xsaXNpb25NYW5hZ2VyKCkuZW5hYmxlZCA9IHRydWU7XHJcbiAgICAgICAgY2MuZXZlbnRNYW5hZ2VyLmFkZExpc3RlbmVyKHtcclxuICAgICAgICAgICAgZXZlbnQ6IGNjLkV2ZW50TGlzdGVuZXIuS0VZQk9BUkQsXHJcbiAgICAgICAgICAgIC8vb25LZXlQcmVzc2VkOiB0aGlzLm9uS2V5UHJlc3NlZC5iaW5kKHRoaXMpLFxyXG4gICAgICAgICAgICBvbktleVJlbGVhc2VkOiB0aGlzLm9uS2V5UmVsZWFzZWQuYmluZCh0aGlzKSxcclxuICAgICAgICB9LCB0aGlzLm5vZGUpO1xyXG4gICAgfSxcclxuXHJcbiAgICBvbktleVJlbGVhc2VkOiBmdW5jdGlvbiAoa2V5Q29kZSwgZXZlbnQpIHtcclxuICAgICAgICBpZih0aGlzLmluRG9vciA9PT0gdHJ1ZSkge1xyXG4gICAgICAgICAgICBzd2l0Y2ggKGtleUNvZGUpIHtcclxuICAgICAgICAgICAgICAgIGNhc2UgY2MuS0VZLmU6XHJcbiAgICAgICAgICAgICAgICBjYXNlIGNjLktFWS5zcGFjZTpcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLmluRG9vciA9IGZhbHNlO1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuc3RvcmVOb2RlLmFjdGl2ZSA9IHRydWU7XHJcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9LFxyXG4gICAgb25Db2xsaXNpb25FbnRlcjogZnVuY3Rpb24gKG90aGVyLCBzZWxmKSB7XHJcbiAgICAgICAgLy/vv73vv73vv73vv73vv73TtO+/ve+/vdC277+9XHJcbiAgICAgICAgaWYgKG90aGVyLm5vZGUuZ3JvdXAgPT09IFwiSGVyb1wiKSB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwidG91Y2ggdGhlIEhlcm9cIik7XHJcbiAgICAgICAgICAgIHRoaXMuaW5Eb29yID0gdHJ1ZTtcclxuICAgICAgICB9XHJcbiAgICB9LFxyXG4gICAgb25Db2xsaXNpb25FeGl0OiBmdW5jdGlvbiAob3RoZXIsIHNlbGYpIHtcclxuICAgICAgICBpZiAob3RoZXIubm9kZS5ncm91cCA9PT0gXCJIZXJvXCIpIHtcclxuICAgICAgICAgICAgdGhpcy5pbkRvb3IgPSBmYWxzZTtcclxuICAgICAgICB9XHJcbiAgICB9LFxyXG4gICAgYmF0dGxlU2NlbmU6IGZ1bmN0aW9uKCl7XHJcbiAgICAgICAgY2MuZGlyZWN0b3IubG9hZFNjZW5lKFwiZ2FtZVwiKTtcclxuICAgIH0sXHJcbiAgICAvLyBjYWxsZWQgZXZlcnkgZnJhbWUsIHVuY29tbWVudCB0aGlzIGZ1bmN0aW9uIHRvIGFjdGl2YXRlIHVwZGF0ZSBjYWxsYmFja1xyXG4gICAgLy8gdXBkYXRlOiBmdW5jdGlvbiAoZHQpIHtcclxuXHJcbiAgICAvLyB9LFxyXG59KTtcclxuIiwiLy/ojrflj5blhajlsYDlj5jph4/ohJrmnKxcclxudmFyIEdsb2JhbCA9IHJlcXVpcmUoJ0dsb2JhbCcpO1xyXG4vKipcclxuICogQOS4u+imgeWKn+iDvSDliqDovb3niYzlupPvvIzlrp7njrDmir3niYxcclxuICogQGF1dGhvciDlpKnpmYUv6ICB6buEL0MxNFxyXG4gKiBARGF0ZSAyMDE3LzgvMTJcclxuICovXHJcbmNjLkNsYXNzKHtcclxuICAgIGV4dGVuZHM6IGNjLkNvbXBvbmVudCxcclxuICAgIFxyXG4gICAgcHJvcGVydGllczoge1xyXG4gICAgICAgIC8v6a2U5rOV55Sf54mp54mM55qE6aKE5Yi2XHJcbiAgICAgICAgbWFnaWNDYXJkUHJlZmFiOiB7XHJcbiAgICAgICAgICAgIGRlZmF1bHQ6IFtdLFxyXG4gICAgICAgICAgICB0eXBlOiBbY2MuUHJlZmFiXVxyXG4gICAgICAgIH0sXHJcbiAgICAgICAgYmlvbG9neUNhcmRQcmVmYWI6IHtcclxuICAgICAgICAgICAgZGVmYXVsdDpbXSxcclxuICAgICAgICAgICAgdHlwZTogY2MuUHJlZmFiXHJcbiAgICAgICAgfSxcclxuXHJcblxyXG5cclxuICAgICAgICAvL+mtlOazleeJjOmihOWItue7hO+8jOaMieeFp+WNoee7hOeahOaVsOaNrui/m+ihjOWIneWni+WMllxyXG4gICAgICAgIG15TURlY2s6e1xyXG4gICAgICAgICAgICBkZWZhdWx0OltdLFxyXG4gICAgICAgICAgICB0eXBlOiBjYy5QcmVmYWIsXHJcbiAgICAgICAgfSxcclxuICAgICAgICAvL+eUn+eJqeeJjOmihOWItue7hO+8jOaMieeFp+WNoee7hOeahOaVsOaNrui/m+ihjOWIneWni+WMllxyXG4gICAgICAgIG15Q0RlY2s6e1xyXG4gICAgICAgICAgICBkZWZhdWx0OltdLFxyXG4gICAgICAgICAgICB0eXBlOiBjYy5QcmVmYWIsXHJcbiAgICAgICAgfSxcclxuICAgICAgICAvL+aAu+eJjOW6k++8jOiKgueCueW9ouW8j+WtmOaUvlxyXG4gICAgICAgIERlY2s6IHtcclxuICAgICAgICAgICAgZGVmYXVsdDogW10sXHJcbiAgICAgICAgICAgIHR5cGU6IGNjLk5vZGUsXHJcbiAgICAgICAgfSxcclxuICAgICAgICAvL+iLsembhOeahOiKgueCuVxyXG4gICAgICAgIGhlcm9Ob2RlOiBjYy5Ob2RlLFxyXG4gICAgICAgIFxyXG4gICAgICAgIC8v5oyH5a6a5Y2h54mH55Sf5oiQ55qEWOWdkOaghyAgICBcclxuICAgICAgICBwb3NpdGlvblg6IDAsXHJcbiAgICAgICAgLy/mjIflrprljaHniYfnlJ/miJDnmoTnsbvlnosgIFxyXG4gICAgICAgIGNhcmRUeXBlRmxhZzogMCxcclxuICAgICAgICAvL2hhbmRDYXJkTWF4TnVtOiAwLFxyXG4gICAgICAgIGRyYXdDYXJkRmxhZzogMCxcclxuICAgICAgICBcclxuICAgICAgICByb2xsOiBjYy5Ob2RlLFxyXG4gICAgfSxcclxuICAgIFxyXG4gICAgLy8gdXNlIHRoaXMgZm9yIGluaXRpYWxpemF0aW9uXHJcbiAgICBvbkxvYWQ6IGZ1bmN0aW9uICgpIHtcclxuICAgICAgICB2YXIgaSA9IDAsaiA9IDA7XHJcbiAgICAgICAgdGhpcy5yZXR1cm5Qb3N0aW9uID0gMDtcclxuICAgICAgICB0aGlzLmNhcmRUeXBlRmxhZyA9IGNjLnJhbmRvbU1pbnVzMVRvMSgpO1xyXG4gICAgICAgIHRoaXMuaGVyb1NjcmlwdCA9IHRoaXMuaGVyb05vZGUuZ2V0Q29tcG9uZW50KCdQbGF5ZXInKTtcclxuXHJcbiAgICAgICAgdmFyIGRlY2tEYXRhcyA9IHtcclxuICAgICAgICAgICAgbmFtZTpcIuaIkeeahOWNoee7hFwiLFxyXG4gICAgICAgICAgICBudW06MCxcclxuICAgICAgICAgICAgbWFnaWNEZWNrOntcclxuICAgICAgICAgICAgICAgIGRlZmF1bHQ6IFtdLFxyXG4gICAgICAgICAgICAgICAgdHlwZTogY2MuSW50ZWdlcixcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgY3JlYXR1cmVEZWNrOntcclxuICAgICAgICAgICAgICAgIGRlZmF1bHQ6W10sXHJcbiAgICAgICAgICAgICAgICB0eXBlOiBjYy5JbnRlZ2VyLFxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAvL+WNoee7hOeahOexu+Wei1xyXG4gICAgICAgICAgICB0eXBlOiB7XHJcbiAgICAgICAgICAgICAgICB0eXBlOiBjYy5FbnVtKHtcclxuICAgICAgICAgICAgICAgICAgICAvL+W5u+aDs1xyXG4gICAgICAgICAgICAgICAgICAgIC8v56eR5a2mXHJcbiAgICAgICAgICAgICAgICAgICAgU2NpZW5jZTogMCxcclxuICAgICAgICAgICAgICAgICAgICBGYW50YXN5OiAxLFxyXG4gICAgICAgICAgICAgICAgICAgIC8v5re35rKMXHJcbiAgICAgICAgICAgICAgICAgICAgQ2hhb3M6IDIsXHJcbiAgICAgICAgICAgICAgICB9KSxcclxuICAgICAgICAgICAgICAgIGRlZmF1bHQ6IDAsXHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIHVzYWJsZTp0cnVlLFxyXG4gICAgICAgIH1cclxuICAgICAgICBHbG9iYWwudG90YWxEZWNrRGF0YS5wdXNoKGRlY2tEYXRhcyk7XHJcbiAgICAgICAgR2xvYmFsLmRlY2tVc2FnZSA9IDA7XHJcbiAgICAgICAgR2xvYmFsLnRvdGFsRGVja0RhdGFbR2xvYmFsLmRlY2tVc2FnZV0ubWFnaWNEZWNrID0gWzMwLDMwXTtcclxuICAgICAgICBHbG9iYWwudG90YWxEZWNrRGF0YVtHbG9iYWwuZGVja1VzYWdlXS5jcmVhdHVyZURlY2sgPSBbMzAsMzBdO1xyXG4gICAgICAgIC8vdGhpcy5jYXJkTGlzdFNjcmlwdCA9IHRoaXMuY2FyZExpc3QuZ2V0Q29tcG9uZW50KCdDYXJkTGlzdCcpO1xyXG5cclxuXHJcbiAgICAgICAgZm9yKGkgPSAwIDtpIDwgR2xvYmFsLnRvdGFsRGVja0RhdGFbR2xvYmFsLmRlY2tVc2FnZV0ubWFnaWNEZWNrLmxlbmd0aCA7IGkrKyl7XHJcbiAgICAgICAgICAgIGlmKEdsb2JhbC50b3RhbERlY2tEYXRhW0dsb2JhbC5kZWNrVXNhZ2VdLm1hZ2ljRGVja1tpXSAhPT0gMCl7XHJcbiAgICAgICAgICAgICAgICBmb3IoaiA9IDAgO2ogPCBHbG9iYWwudG90YWxEZWNrRGF0YVtHbG9iYWwuZGVja1VzYWdlXS5tYWdpY0RlY2tbaV07aisrKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5teU1EZWNrLnB1c2godGhpcy5tYWdpY0NhcmRQcmVmYWJbaV0pO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGZvcihpID0gMCA7aSA8IEdsb2JhbC50b3RhbERlY2tEYXRhW0dsb2JhbC5kZWNrVXNhZ2VdLmNyZWF0dXJlRGVjay5sZW5ndGggOyBpKyspe1xyXG4gICAgICAgICAgICBpZihHbG9iYWwudG90YWxEZWNrRGF0YVtHbG9iYWwuZGVja1VzYWdlXS5jcmVhdHVyZURlY2tbaV0gIT09IDApe1xyXG4gICAgICAgICAgICAgICAgZm9yKGogPSAwIDtqIDwgR2xvYmFsLnRvdGFsRGVja0RhdGFbR2xvYmFsLmRlY2tVc2FnZV0uY3JlYXR1cmVEZWNrW2ldO2orKykge1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMubXlDRGVjay5wdXNoKHRoaXMuYmlvbG9neUNhcmRQcmVmYWJbaV0pO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIC8v5YWI5Y+RNuW8oOeJjOWGjeivtFxyXG4gICAgICAgIGZvcihpID0gMCA7aSA8IDYgOyBpKyspe1xyXG4gICAgICAgICAgICB0aGlzLnNob3dOZXdDYXJkKCk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIC8vNOenkuihpeWFheS4gOW8oOeJjFxyXG4gICAgICAgIHRoaXMuZGVsYXlUaW1lKDQpO1xyXG4gICAgfSxcclxuXHJcbiAgICBzaG93TmV3Q2FyZDogZnVuY3Rpb24oKXtcclxuICAgICAgICBpZih0aGlzLmhlcm9TY3JpcHQuaGFuZENhcmQubGVuZ3RoIDwgOSl7XHJcbiAgICAgICAgICAgIHRoaXMuY3JlYXRDYXJkVHlwZSgpO1xyXG4gICAgICAgIH1cclxuICAgIH0sXHJcbiAgICBjcmVhdENhcmRUeXBlOiBmdW5jdGlvbigpe1xyXG4gICAgICAgIHZhciByYW5kID0gMDtcclxuICAgICAgICBpZih0aGlzLm15Q0RlY2subGVuZ3RoICsgdGhpcy5teU1EZWNrLmxlbmd0aCA9PT0gMClyZXR1cm47XHJcblxyXG4gICAgICAgIHJhbmQgPSBNYXRoLmZsb29yKE1hdGgucmFuZG9tKCkgKiAodGhpcy5teUNEZWNrLmxlbmd0aCArIHRoaXMubXlNRGVjay5sZW5ndGggLSAxKSk7XHJcblxyXG4gICAgICAgIGlmKHJhbmQgPj0gdGhpcy5teU1EZWNrLmxlbmd0aCkge1xyXG4gICAgICAgICAgICBpZih0aGlzLmhlcm9TY3JpcHQuaGFuZENhcmQubGVuZ3RoIDwgOSkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5jcmVhdE5ld0NhcmQodGhpcy5teUNEZWNrW3JhbmQgLSB0aGlzLm15TURlY2subGVuZ3RoXSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgdGhpcy5teUNEZWNrLnNwbGljZShyYW5kIC0gdGhpcy5teU1EZWNrLmxlbmd0aCwgMSk7XHJcbiAgICAgICAgfWVsc2V7XHJcbiAgICAgICAgICAgIGlmKHRoaXMuaGVyb1NjcmlwdC5oYW5kQ2FyZC5sZW5ndGggPCA5KSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmNyZWF0TmV3Q2FyZCh0aGlzLm15TURlY2tbcmFuZF0pO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIHRoaXMubXlNRGVjay5zcGxpY2UocmFuZCwgMSk7XHJcbiAgICAgICAgfVxyXG4gICAgfSxcclxuICAgIGNyZWF0TmV3Q2FyZDogZnVuY3Rpb24oY2FyZE9iamVjdCl7XHJcbiAgICAgICAgdmFyIG5ld0NhcmQgPSBjYy5pbnN0YW50aWF0ZShjYXJkT2JqZWN0KTtcclxuICAgICAgICAvL3NjcmlwdOS9nOS4uuWIneWni+WMluS9v+eUqOeahOWNoeeJjOeahOiEmuacrFxyXG4gICAgICAgIHZhciBzY3JpcHQgPSBuZXdDYXJkLmdldENvbXBvbmVudCgnQ2FyZCcpO1xyXG4gICAgICAgIHNjcmlwdC5yb2xsID0gdGhpcy5yb2xsO1xyXG4gICAgICAgIHNjcmlwdC5oZXJvID0gdGhpcy5oZXJvTm9kZTtcclxuICAgICAgICBzY3JpcHQudGVhbSA9IHRoaXMuaGVyb1NjcmlwdC50ZWFtO1xyXG4gICAgICAgIG5ld0NhcmQueSA9IDA7XHJcblxyXG4gICAgICAgIHZhciBzY3JpcHQyID0gbnVsbDtcclxuICAgICAgICBpZihzY3JpcHQuY2FyZFR5cGUgPT09IDApe1xyXG4gICAgICAgICAgICBzY3JpcHQyID0gbmV3Q2FyZC5nZXRDb21wb25lbnQoJ01hZ2ljQ2FyZCcpO1xyXG4gICAgICAgIH1lbHNle1xyXG4gICAgICAgICAgICBzY3JpcHQyID0gbmV3Q2FyZC5nZXRDb21wb25lbnQoJ0NyZWVwQ2FyZCcpO1xyXG4gICAgICAgIH1cclxuICAgICAgICBzY3JpcHQyLmhlcm8gPSB0aGlzLmhlcm9Ob2RlO1xyXG4gICAgICAgIHNjcmlwdDIuYmFja1JvbGwgPSB0aGlzLnJvbGw7XHJcblxyXG4gICAgICAgIC8vbmV3Q2FyZC50YWcgPSB0aGlzLnBvc2l0aW9uWDtcclxuICAgICAgICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0gLy9cclxuICAgICAgICBzY3JpcHQuZHJhd0NhcmRTY3JpcHQgPSB0aGlzO1xyXG4gICAgICAgIC8vc2NyaXB0LmNhcmRJbmRleCA9IHRoaXMuY2FyZEdyb3VwLmxlbmd0aDtcclxuICAgICAgICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0gLy9cclxuICAgICAgICB0aGlzLmhlcm9TY3JpcHQuaGFuZENhcmQucHVzaChuZXdDYXJkKTtcclxuXHJcbiAgICAgICAgLy90aGlzLnBvc2l0aW9uWCsrO1xyXG4gICAgICAgIC8vdGhpcy5jYXJkVHlwZUZsYWcgPSBjYy5yYW5kb21NaW51czFUbzEoKTtcclxuICAgICAgICB0aGlzLm5vZGUuYWRkQ2hpbGQobmV3Q2FyZCwgc2NyaXB0LmNhcmRJbmRleCk7XHJcbiAgICAgICAgLy8gdGhpcy5jYXJkU2hhcGUobmV3Q2FyZCk7XHJcbiAgICAgICAgLy8gdGhpcy5jYXJkVXNlKG5ld0NhcmQpO1xyXG4gICAgfSxcclxuXHJcbiAgICAvLyDliKDpmaTniYxcclxuICAgIGRlbGV0ZUNhcmQ6IGZ1bmN0aW9uIChjYXJkKSB7XHJcbiAgICAgICAgZm9yKHZhciBpbmRleCA9IDA7aW5kZXggPCB0aGlzLmhlcm9TY3JpcHQuaGFuZENhcmQubGVuZ3RoO2luZGV4Kyspe1xyXG4gICAgICAgICAgICBpZihjYXJkID09PSB0aGlzLmhlcm9TY3JpcHQuaGFuZENhcmRbaW5kZXhdKXtcclxuICAgICAgICAgICAgICAgIHRoaXMuaGVyb1NjcmlwdC5oYW5kQ2FyZC5zcGxpY2UoaW5kZXgsIDEpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGNjLmxvZyh0aGlzLmhlcm9TY3JpcHQuaGFuZENhcmQubGVuZ3RoKTtcclxuICAgICAgICBjYXJkLnJlbW92ZUZyb21QYXJlbnQodHJ1ZSk7XHJcbiAgICB9LFxyXG4gICAgXHJcblxyXG4gICAgZGVsYXlUaW1lOiBmdW5jdGlvbih0aW1lKXtcclxuICAgICAgICB0aGlzLnNjaGVkdWxlKHRoaXMuc2hvd05ld0NhcmQsdGltZSk7XHJcbiAgICB9LFxyXG4gICAgXHJcbiAgICAvL2NhcmRTaGFwZTogZnVuY3Rpb24oY2FyZE9iamVjdCl7XHJcbiAgICAvLyAgICBjYXJkT2JqZWN0Lm9uKGNjLk5vZGUuRXZlbnRUeXBlLk1PVVNFX0VOVEVSLGZ1bmN0aW9uICgpIHtcclxuICAgIC8vICAgICAgICAgICAgY2FyZE9iamVjdC5ydW5BY3Rpb24oY2Muc3BlZWQoY2Muc2NhbGVCeSgxLjIsMS4yKSwgNykpO1xyXG4gICAgLy8gICAgfSwgdGhpcyk7XHJcbiAgICAvLyAgICBjYXJkT2JqZWN0Lm9uKGNjLk5vZGUuRXZlbnRUeXBlLk1PVVNFX0xFQVZFLGZ1bmN0aW9uKCl7XHJcbiAgICAvLyAgICAgICAgY2FyZE9iamVjdC5zdG9wQWxsQWN0aW9ucygpO1xyXG4gICAgLy8gICAgICAgIGNhcmRPYmplY3QucnVuQWN0aW9uKGNjLnNwZWVkKGNjLnNjYWxlVG8oMSwxKSw3KSk7XHJcbiAgICAvLyAgICB9LHRoaXMpO1xyXG4gICAgLy99LFxyXG4gICAgXHJcbiAgICAvL2NhcmRVc2U6IGZ1bmN0aW9uKGNhcmRPYmplY3Qpe1xyXG4gICAgLy8gICAgICAgIGNhcmRPYmplY3Qub24oY2MuTm9kZS5FdmVudFR5cGUuTU9VU0VfRE9XTiwgZnVuY3Rpb24gKCkge1xyXG4gICAgLy8gICAgICAgICAgICAvL2NhcmRPYmplY3Qub3BhY2l0eSA9IDkwO1xyXG4gICAgLy8gICAgICAgICAgICBjYXJkT2JqZWN0Lm9uKGNjLk5vZGUuRXZlbnRUeXBlLk1PVVNFX01PVkUsY2FyZE1vdmUsdGhpcyk7XHJcbiAgICAvLyAgICAgICAgfSwgdGhpcyk7XHJcbiAgICAvLyAgICAgICAgY2FyZE9iamVjdC5vbihjYy5Ob2RlLkV2ZW50VHlwZS5NT1VTRV9VUCxmdW5jdGlvbigpe1xyXG4gICAgLy8gICAgICAgICAgICAvL2NhcmRPYmplY3Qub3BhY2l0eSA9IDEwMDA7XHJcbiAgICAvLyAgICAgICAgICAgIGNhcmRPYmplY3Qub2ZmKGNjLk5vZGUuRXZlbnRUeXBlLk1PVVNFX01PVkUsY2FyZE1vdmUsdGhpcyk7XHJcbiAgICAvL1xyXG4gICAgLy8gICAgICAgICAgICBpZihjYXJkT2JqZWN0LnkgPj0gMTAwKXtcclxuICAgIC8vICAgICAgICAgICAgICAgIHZhciBzY3JpcHQgPSBjYXJkT2JqZWN0LmdldENvbXBvbmVudCgnQ2FyZCcpO1xyXG4gICAgLy8gICAgICAgICAgICAgICAgaWYodGhpcy5oZXJvQ29tcG9uZW50Lm1hbmEgPj0gc2NyaXB0Lm1hbmFDb25zdW1lXHJcbiAgICAvLyAgICAgICAgICAgICAgICAgICAmJiBzY3JpcHQuZ2V0VXNlU3RhdGUoKSA9PT0gdHJ1ZSl7XHJcbiAgICAvL1xyXG4gICAgLy8gICAgICAgICAgICAgICAgICAgIHRoaXMuaGVyb0NvbXBvbmVudC5tYW5hIC09IHNjcmlwdC5tYW5hQ29uc3VtZTtcclxuICAgIC8vICAgICAgICAgICAgICAgICAgICBzY3JpcHQudXNlQ2FyZCgpO1xyXG4gICAgLy8gICAgICAgICAgICAgICAgICAgIHRoaXMuY2FyZEdyb3VwLnNwbGljZSh0aGlzLmNhcmRHcm91cC5pbmRleE9mKGNhcmRPYmplY3QpLDEpO1xyXG4gICAgLy8gICAgICAgICAgICAgICAgICAgIHRoaXMuZm5SZW5ld0NhcmQoKTtcclxuICAgIC8vICAgICAgICAgICAgICAgICAgICB0aGlzLnBvc2l0aW9uWC0tO1xyXG4gICAgLy8gICAgICAgICAgICAgICAgICAgIGNhcmRPYmplY3QucmVtb3ZlRnJvbVBhcmVudCgpO1xyXG4gICAgLy8gICAgICAgICAgICAgICAgfWVsc2V7XHJcbiAgICAvLyAgICAgICAgICAgICAgICAgICAgY2FyZE9iamVjdC54ID0gMTIwKnRoaXMuY2FyZEdyb3VwLmluZGV4T2YoY2FyZE9iamVjdCk7XHJcbiAgICAvLyAgICAgICAgICAgICAgICAgICAgY2FyZE9iamVjdC55ID0gMDtcclxuICAgIC8vICAgICAgICAgICAgICAgIH1cclxuICAgIC8vXHJcbiAgICAvLyAgICAgICAgICAgIH1lbHNle1xyXG4gICAgLy8gICAgICAgICAgICAgICAgICAgIGNhcmRPYmplY3QueCA9IDEyMCp0aGlzLmNhcmRHcm91cC5pbmRleE9mKGNhcmRPYmplY3QpO1xyXG4gICAgLy8gICAgICAgICAgICAgICAgICAgIGNhcmRPYmplY3QueSA9IDA7XHJcbiAgICAvLyAgICAgICAgICAgICAgICB9XHJcbiAgICAvLyAgICAgICAgfSx0aGlzKTtcclxuICAgIC8vICAgICAgICBmdW5jdGlvbiBjYXJkTW92ZShldmVudCkge1xyXG4gICAgLy8gICAgICAgICAgICAgICAgY2FyZE9iamVjdC54ICs9IGV2ZW50LmdldERlbHRhWCgpO1xyXG4gICAgLy8gICAgICAgICAgICAgICAgY2FyZE9iamVjdC55ICs9IGV2ZW50LmdldERlbHRhWSgpO1xyXG4gICAgLy8gICAgICAgICAgICAgICAgaWYoY2FyZE9iamVjdC55ID49IDEwMCl7XHJcbiAgICAvLyAgICAgICAgICAgICAgICAvL2NhcmRPYmplY3Qub3BhY2l0eSA9IDEwMDA7XHJcbiAgICAvLyAgICAgICAgICAgIH1cclxuICAgIC8vICAgICAgICB9XHJcbiAgICAvL30sXHJcblxyXG4vLy8v5Yi35paw5Y2h54mM55qE5L2N572uXHJcbi8vICAgIGZuUmVuZXdDYXJkOmZ1bmN0aW9uKCl7XHJcbi8vICAgICAgICB2YXIgaSA9IDA7XHJcbi8vICAgICAgICBmb3IoaSA9IDA7aSA8IHRoaXMuY2FyZEdyb3VwLmxlbmd0aCA7IGkrKyl7XHJcbi8vICAgICAgICAgICAgdGhpcy5jYXJkR3JvdXBbaV0ueCA9IDEyMCppO1xyXG4vLyAgICAgICAgfVxyXG4vLyAgICB9LFxyXG5cclxuICAgIGNoYW5nZUNhcmRUb1VzaW5nOiBmdW5jdGlvbiAoZXZlbnQpIHtcclxuXHJcbiAgICB9LFxyXG5cclxuICAgIC8vIGNhbGxlZCBldmVyeSBmcmFtZSwgdW5jb21tZW50IHRoaXMgZnVuY3Rpb24gdG8gYWN0aXZhdGUgdXBkYXRlIGNhbGxiYWNrXHJcbiAgICAvLyB1cGRhdGU6IGZ1bmN0aW9uIChkdCkge1xyXG5cclxuICAgIC8vIH0sXHJcbn0pO1xyXG4iLCJjYy5DbGFzcyh7XHJcbiAgICBleHRlbmRzOiBjYy5Db21wb25lbnQsXHJcblxyXG4gICAgcHJvcGVydGllczoge1xyXG4gICAgICAgIGRhbWFnZTogMCxcclxuICAgICAgICBmbHlTcGVlZDogMCxcclxuICAgICAgICBmbHlEaXN0YW5jZTogMCxcclxuICAgICAgICAvLyBmb286IHtcclxuICAgICAgICAvLyAgICBkZWZhdWx0OiBudWxsLCAgICAgIC8vIFRoZSBkZWZhdWx0IHZhbHVlIHdpbGwgYmUgdXNlZCBvbmx5IHdoZW4gdGhlIGNvbXBvbmVudCBhdHRhY2hpbmdcclxuICAgICAgICAvLyAgICAgICAgICAgICAgICAgICAgICAgICAgIHRvIGEgbm9kZSBmb3IgdGhlIGZpcnN0IHRpbWVcclxuICAgICAgICAvLyAgICB1cmw6IGNjLlRleHR1cmUyRCwgIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIHR5cGVvZiBkZWZhdWx0XHJcbiAgICAgICAgLy8gICAgc2VyaWFsaXphYmxlOiB0cnVlLCAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyB0cnVlXHJcbiAgICAgICAgLy8gICAgdmlzaWJsZTogdHJ1ZSwgICAgICAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyB0cnVlXHJcbiAgICAgICAgLy8gICAgZGlzcGxheU5hbWU6ICdGb28nLCAvLyBvcHRpb25hbFxyXG4gICAgICAgIC8vICAgIHJlYWRvbmx5OiBmYWxzZSwgICAgLy8gb3B0aW9uYWwsIGRlZmF1bHQgaXMgZmFsc2VcclxuICAgICAgICAvLyB9LFxyXG4gICAgICAgIC8vIC4uLlxyXG4gICAgfSxcclxuXHJcbiAgICAvLyB1c2UgdGhpcyBmb3IgaW5pdGlhbGl6YXRpb25cclxuICAgIG9uTG9hZDogZnVuY3Rpb24gKCkge1xyXG5cclxuICAgIH0sXHJcblxyXG4gICAgLy8gY2FsbGVkIGV2ZXJ5IGZyYW1lLCB1bmNvbW1lbnQgdGhpcyBmdW5jdGlvbiB0byBhY3RpdmF0ZSB1cGRhdGUgY2FsbGJhY2tcclxuICAgIC8vIHVwZGF0ZTogZnVuY3Rpb24gKGR0KSB7XHJcblxyXG4gICAgLy8gfSxcclxufSk7XHJcbiIsImNjLkNsYXNzKHtcclxuICAgIGV4dGVuZHM6IGNjLkNvbXBvbmVudCxcclxuXHJcbiAgICBwcm9wZXJ0aWVzOiB7XHJcbiAgICAgICAgbW9vbkxpZ2h0V29ybTp7XHJcbiAgICAgICAgICAgIGRlZmF1bHQ6IG51bGwsXHJcbiAgICAgICAgICAgIHR5cGU6IGNjLlByZWZhYixcclxuICAgICAgICB9LFxyXG4gICAgICAgIHVuRGVhZEJpcmQ6e1xyXG4gICAgICAgICAgICBkZWZhdWx0OiBudWxsLFxyXG4gICAgICAgICAgICB0eXBlOiBjYy5QcmVmYWIsXHJcbiAgICAgICAgfSxcclxuICAgIH0sXHJcblxyXG4gICAgLy8gdXNlIHRoaXMgZm9yIGluaXRpYWxpemF0aW9uXHJcbiAgICBvbkxvYWQ6IGZ1bmN0aW9uICgpIHtcclxuICAgICAgICB0aGlzLmNyZWF0Q2FyZCh0aGlzLm1vb25MaWdodFdvcm0sMCk7XHJcbiAgICAgICAgdGhpcy5jcmVhdENhcmQodGhpcy51bkRlYWRCaXJkLDEpO1xyXG4gICAgfSxcclxuICAgIGNyZWF0Q2FyZDogZnVuY3Rpb24oY2FyZFR5cGUsaSl7XHJcbiAgICAgICAgdmFyIG5ld0NhcmQgPSBjYy5pbnN0YW50aWF0ZShjYXJkVHlwZSk7XHJcbiAgICAgICAgbmV3Q2FyZC54ID0gLTEyMCsoMTIwKmkpO1xyXG4gICAgICAgIG5ld0NhcmQueSA9IDEzMDtcclxuICAgICAgICB0aGlzLm5vZGUuYWRkQ2hpbGQobmV3Q2FyZCk7XHJcbiAgICB9XHJcblxyXG4gICAgLy8gY2FsbGVkIGV2ZXJ5IGZyYW1lLCB1bmNvbW1lbnQgdGhpcyBmdW5jdGlvbiB0byBhY3RpdmF0ZSB1cGRhdGUgY2FsbGJhY2tcclxuICAgIC8vIHVwZGF0ZTogZnVuY3Rpb24gKGR0KSB7XHJcblxyXG4gICAgLy8gfSxcclxufSk7XHJcbiIsImNjLkNsYXNzKHtcclxuICAgIGV4dGVuZHM6IGNjLkNvbXBvbmVudCxcclxuXHJcbiAgICBwcm9wZXJ0aWVzOiB7XHJcbiAgICAgICAgLy8gZm9vOiB7XHJcbiAgICAgICAgLy8gICAgZGVmYXVsdDogbnVsbCwgICAgICAvLyBUaGUgZGVmYXVsdCB2YWx1ZSB3aWxsIGJlIHVzZWQgb25seSB3aGVuIHRoZSBjb21wb25lbnQgYXR0YWNoaW5nXHJcbiAgICAgICAgLy8gICAgICAgICAgICAgICAgICAgICAgICAgICB0byBhIG5vZGUgZm9yIHRoZSBmaXJzdCB0aW1lXHJcbiAgICAgICAgLy8gICAgdXJsOiBjYy5UZXh0dXJlMkQsICAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyB0eXBlb2YgZGVmYXVsdFxyXG4gICAgICAgIC8vICAgIHNlcmlhbGl6YWJsZTogdHJ1ZSwgLy8gb3B0aW9uYWwsIGRlZmF1bHQgaXMgdHJ1ZVxyXG4gICAgICAgIC8vICAgIHZpc2libGU6IHRydWUsICAgICAgLy8gb3B0aW9uYWwsIGRlZmF1bHQgaXMgdHJ1ZVxyXG4gICAgICAgIC8vICAgIGRpc3BsYXlOYW1lOiAnRm9vJywgLy8gb3B0aW9uYWxcclxuICAgICAgICAvLyAgICByZWFkb25seTogZmFsc2UsICAgIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIGZhbHNlXHJcbiAgICAgICAgLy8gfSxcclxuICAgICAgICAvLyAuLi5cclxuICAgIH0sXHJcblxyXG4gICAgLy8gdXNlIHRoaXMgZm9yIGluaXRpYWxpemF0aW9uXHJcbiAgICBvbkxvYWQ6IGZ1bmN0aW9uICgpIHtcclxuICAgICAgICB0aGlzLnByb2Nlc3NCYXIgPSB0aGlzLm5vZGUuZ2V0Q29tcG9uZW50KGNjLlByb2dyZXNzQmFyKTtcclxuICAgICAgICB0aGlzLnRpbWVyID0gMDtcclxuICAgICAgICB0aGlzLm1heFRpbWVyID0gODAwO1xyXG4gICAgICAgIGNjLmxvZyh0aGlzLnByb2Nlc3NCYXIucHJvZ3Jlc3MpO1xyXG4gICAgICAgIHRoaXMucHJvY2Vzc0Jhci5wcm9ncmVzcyA9IHRoaXMudGltZXIvdGhpcy5tYXhUaW1lcjtcclxuICAgICAgICB0aGlzLnNjaGVkdWxlKGZ1bmN0aW9uKCkge1xyXG4gICAgICAgICAgICB0aGlzLnRpbWVyKys7XHJcblxyXG4gICAgICAgICAgICBpZih0aGlzLnRpbWVyID4gdGhpcy5tYXhUaW1lcil7XHJcbiAgICAgICAgICAgICAgICB0aGlzLnRpbWVyID0gMDtcclxuICAgICAgICAgICAgICAgIHZhciBhbGxDaGlsZCA9IHRoaXMubm9kZS5nZXRDaGlsZHJlbigpO1xyXG4gICAgICAgICAgICAgICAgICAgIGZvcih2YXIgaSA9IDA7aSA8IGFsbENoaWxkLmxlbmd0aDtpKyspe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIgY2hhbnRTY3JpcHQgPSBhbGxDaGlsZFtpXS5nZXRDb21wb25lbnQoXCJDaGFudFwiKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgaWYoY2hhbnRTY3JpcHQgIT0gbnVsbCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNoYW50U2NyaXB0LmZsYWcgPSBmYWxzZTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgdmFyIGFsbENoaWxkMSA9IHRoaXMubm9kZS5nZXRDaGlsZHJlbigpO1xyXG4gICAgICAgICAgICBmb3IodmFyIGogPSAwO2ogPCBhbGxDaGlsZDEubGVuZ3RoO2orKyl7XHJcbiAgICAgICAgICAgICAgICB2YXIgY2hhbnRTY3JpcHQxID0gYWxsQ2hpbGQxW2pdLmdldENvbXBvbmVudChcIkNoYW50XCIpO1xyXG4gICAgICAgICAgICAgICAgaWYoY2hhbnRTY3JpcHQxICE9IG51bGwpIHtcclxuICAgICAgICAgICAgICAgICAgICBpZihjaGFudFNjcmlwdDEucGVyY2VudCA8PSB0aGlzLnRpbWVyL3RoaXMubWF4VGltZXIgJiYgY2hhbnRTY3JpcHQxLmZsYWcgPT09IGZhbHNlKXtcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2hhbnRTY3JpcHQxLmZsYWcgPSB0cnVlO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBjaGFudFNjcmlwdDEuZm5DaGFuZ2VSb3VuZCgtMSk7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIC8vY2MubG9nKGopO1xyXG4gICAgICAgICAgICB0aGlzLnByb2Nlc3NCYXIucHJvZ3Jlc3MgPSB0aGlzLnRpbWVyL3RoaXMubWF4VGltZXI7XHJcblxyXG4gICAgICAgICAgICAvL2NjLmV2ZW50TWFuYWdlci5kaXNwYXRjaEV2ZW50KGV2ZW50KTtcclxuICAgICAgICB9LDAuMDEpO1xyXG4gICAgfSxcclxuXHJcbiAgICAvLyBjYWxsZWQgZXZlcnkgZnJhbWUsIHVuY29tbWVudCB0aGlzIGZ1bmN0aW9uIHRvIGFjdGl2YXRlIHVwZGF0ZSBjYWxsYmFja1xyXG4gICAgLy8gdXBkYXRlOiBmdW5jdGlvbiAoZHQpIHtcclxuICAgIC8vXHJcbiAgICAvLyB9LFxyXG59KTtcclxuIiwiLy8gR2xvYmFsLmpzLCBub3cgdGhlIGZpbGVuYW1lIG1hdHRlcnNcblxubW9kdWxlLmV4cG9ydHMgPSB7XG5cbiAgICAvL+eOqeWutuaMgeacieeahOmHkeW4gVxuICAgIG1vbmV5OjEwMDAsXG4gICAgLy/ngbXprYLnoo7niYdcbiAgICBzb3VsOjEyLFxuICAgIC8v5Y2h5YyF55qE5pWw6YePXG4gICAgYmFnTnVtOjEwLFxuICAgIC8v546w5Zyo5q2j5Zyo5rWP6KeI55qE5Y2h57uEXG4gICAgZGVja1ZpZXc6MCxcblxuICAgIC8v5Y2h57uE55qE57G75Z6LXG4gICAgdHlwZToge1xuICAgICAgICB0eXBlOiBjYy5FbnVtKHtcbiAgICAgICAgICAgIC8v56eR5a2mXG4gICAgICAgICAgICBTY2llbmNlOiAwLFxuICAgICAgICAgICAgLy/lubvmg7NcbiAgICAgICAgICAgIEZhbnRhc3k6IDEsXG4gICAgICAgICAgICAvL+a3t+ayjFxuICAgICAgICAgICAgQ2hhb3M6IDJcbiAgICAgICAgfSksXG4gICAgICAgIGRlZmF1bHQ6IDBcbiAgICB9LFxuXG4gICAgLy/miYDmnInnmoTljaHnu4TmlbDmja7lnKjmraRcbiAgICB0b3RhbERlY2tEYXRhOltdLFxuXG4gICAgLy/lh7rmiJjpgInmi6nnmoTljaHnu4TnvJblj7dcbiAgICBkZWNrVXNhZ2U6IDAsXG59O1xuLy97XG4vL2RlY2tEYXRhOntcbi8vICAgIG5hbWU6XCLmiJHnmoTljaHnu4RcIixcbi8vICAgIG51bTowLFxuLy8gICAgbWFnaWNEZWNrOntcbi8vICAgICAgICBkZWZhdWx0OiBbXSxcbi8vICAgICAgICB0eXBlOiBjYy5JbnRlZ2VyXG4vLyAgICB9LFxuLy8gICAgY3JlYXR1cmVEZWNrOntcbi8vICAgICAgICBkZWZhdWx0OltdLFxuLy8gICAgICAgIHR5cGU6IGNjLkludGVnZXJcbi8vICAgIH0sXG4vLyAgICAvL+WNoee7hOeahOexu+Wei1xuLy8gICAgdHlwZToge1xuLy8gICAgICAgIHR5cGU6IGNjLkVudW0oe1xuLy8gICAgICAgICAgICAvL+W5u+aDs1xuLy8gICAgICAgICAgICAvL+enkeWtplxuLy8gICAgICAgICAgICBTY2llbmNlOiAwLFxuLy8gICAgICAgICAgICBGYW50YXN5OiAxLFxuLy8gICAgICAgICAgICAvL+a3t+ayjFxuLy8gICAgICAgICAgICBDaGFvczogMixcbi8vICAgICAgICB9KSxcbi8vICAgICAgICBkZWZhdWx0OiAwLFxuLy8gICAgfSxcbi8vICAgIHVzYWJsZTp0cnVlLFxuLy99LCIsInZhciBHbG9iYWwgPSByZXF1aXJlKCdHbG9iYWwnKTtcclxuXHJcblxyXG5jYy5DbGFzcyh7XHJcbiAgICBleHRlbmRzOiBjYy5Db21wb25lbnQsXHJcblxyXG4gICAgcHJvcGVydGllczoge1xyXG4gICAgICAgIHBhbmVsTm9kZTpjYy5Ob2RlLFxyXG4gICAgICAgIC8vIGZvbzoge1xyXG4gICAgICAgIC8vICAgIGRlZmF1bHQ6IG51bGwsICAgICAgLy8gVGhlIGRlZmF1bHQgdmFsdWUgd2lsbCBiZSB1c2VkIG9ubHkgd2hlbiB0aGUgY29tcG9uZW50IGF0dGFjaGluZ1xyXG4gICAgICAgIC8vICAgICAgICAgICAgICAgICAgICAgICAgICAgdG8gYSBub2RlIGZvciB0aGUgZmlyc3QgdGltZVxyXG4gICAgICAgIC8vICAgIHVybDogY2MuVGV4dHVyZTJELCAgLy8gb3B0aW9uYWwsIGRlZmF1bHQgaXMgdHlwZW9mIGRlZmF1bHRcclxuICAgICAgICAvLyAgICBzZXJpYWxpemFibGU6IHRydWUsIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIHRydWVcclxuICAgICAgICAvLyAgICB2aXNpYmxlOiB0cnVlLCAgICAgIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIHRydWVcclxuICAgICAgICAvLyAgICBkaXNwbGF5TmFtZTogJ0ZvbycsIC8vIG9wdGlvbmFsXHJcbiAgICAgICAgLy8gICAgcmVhZG9ubHk6IGZhbHNlLCAgICAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyBmYWxzZVxyXG4gICAgICAgIC8vIH0sXHJcbiAgICAgICAgLy8gLi4uXHJcbiAgICAgICAgZ3Jhdml0ZTogMCxcclxuICAgICAgICBtb3ZlU3BlZWQ6IDAsXHJcbiAgICAgICAganVtcFNwZWVkOiAwLFxyXG4gICAgICAgIG1haW5TY2VuY2U6Y2MuTm9kZSxcclxuXHJcbiAgICAgICAgLy9kZWNrTnVtOmNjLkxhYmVsLFxyXG4gICAgfSxcclxuXHJcbiAgICAvLyB1c2UgdGhpcyBmb3IgaW5pdGlhbGl6YXRpb25cclxuICAgIG9uTG9hZDogZnVuY3Rpb24gKCkge1xyXG4gICAgICAgIHRoaXMuc3BlZWQgPSBjYy52MigwLDApO1xyXG4gICAgICAgIHRoaXMuaXNHb0xlZnQgPSBmYWxzZTsvL+WIpOaWreaYr+WQpuWQkeW3pui1sFxyXG4gICAgICAgIHRoaXMuaXNHb1JpZ2h0ID0gZmFsc2U7Ly/liKTmlq3mmK/lkKblkJHlj7PotbBcclxuICAgICAgICB0aGlzLmlzU3RhbmQgPSBmYWxzZTsvL+ermeeri+eKtuaAgVxyXG4gICAgICAgIHRoaXMuaXNTdGFuZFBsYXRmb3JtID0gZmFsc2U7Ly/mmK/lkKbnq5nlnKjlj7DkuIpcclxuICAgICAgICB0aGlzLmlzU3RhbmRXYWxsID0gZmFsc2U7Ly/mmK/lkKbnq5nlnKjlopnkvZPkuIpcclxuICAgICAgICB0aGlzLmlzVG91Y2hXYWxsTCA9IGZhbHNlO1xyXG4gICAgICAgIHRoaXMuaXNUb3VjaFdhbGxSID0gZmFsc2U7XHJcbiAgICAgICAgdGhpcy5pc1RvdWNoV2FsbEQgPSBmYWxzZTtcclxuICAgICAgICB0aGlzLmluRG9vciA9IGZhbHNlO1xyXG5cclxuICAgICAgICB0aGlzLmNsaW1iU3BlZWQgID0gY2MudjIoMCwwKTtcclxuICAgICAgICB0aGlzLmlzQ2xpbWJpbmdVcCA9IGZhbHNlOy8v5Yik5pat5piv5ZCm5Li65ZCR5LiK5pSA54is54q25oCBXHJcbiAgICAgICAgdGhpcy5pc0NsaW1iaW5nRG93biA9IGZhbHNlOy8v5Yik5pat5piv5ZCm5Li65ZCR5LiL5pSA54is54q25oCBXHJcbiAgICAgICAgdGhpcy5pc0NsaW1iaW5nID0gZmFsc2U7Ly/mmK/lkKbmraPlnKjmlIDniKxcclxuICAgICAgICB0aGlzLnRvdWNoZWRMYWRkZXIgPSBudWxsO1xyXG5cclxuICAgICAgICB0aGlzLm1haW5TY3JpcHQgPSB0aGlzLm1haW5TY2VuY2UuZ2V0Q29tcG9uZW50KCdNYWluU2NlbmVNYW5hZ2VyJyk7XHJcbiAgICAgICAgLy/lvIDlkK/norDmkp5cclxuICAgICAgICBjYy5kaXJlY3Rvci5nZXRDb2xsaXNpb25NYW5hZ2VyKCkuZW5hYmxlZCA9IHRydWU7XHJcbiAgICAgICAgLy9jYy5kaXJlY3Rvci5nZXRDb2xsaXNpb25NYW5hZ2VyKCkuZW5hYmxlZERlYnVnRHJhdyA9IHRydWU7XHJcblxyXG4gICAgICAgIGNjLmV2ZW50TWFuYWdlci5hZGRMaXN0ZW5lcih7XHJcbiAgICAgICAgICAgIGV2ZW50OiBjYy5FdmVudExpc3RlbmVyLktFWUJPQVJELFxyXG4gICAgICAgICAgICBvbktleVByZXNzZWQ6IHRoaXMub25LZXlQcmVzc2VkLmJpbmQodGhpcyksXHJcbiAgICAgICAgICAgIG9uS2V5UmVsZWFzZWQ6IHRoaXMub25LZXlSZWxlYXNlZC5iaW5kKHRoaXMpLFxyXG4gICAgICAgIH0sIHRoaXMubm9kZSk7XHJcbiAgICAgICAgXHJcbiAgICAgICAgdGhpcy5pbml0TW91c2VFdmVudCgpO1xyXG4gICAgICAgIFxyXG4gICAgICAgIFxyXG4gICAgfSxcclxuICAgIFxyXG4gICAgaW5pdE1vdXNlRXZlbnQ6ZnVuY3Rpb24oKXtcclxuICAgICAgICB0aGlzLm5vZGUub24oY2MuTm9kZS5FdmVudFR5cGUuTU9VU0VfRE9XTixvcGVuUGFuZWwsIHRoaXMpO1xyXG5cclxuICAgICAgICBmdW5jdGlvbiBvcGVuUGFuZWwoKXtcclxuICAgICAgICAgICAgdGhpcy5wYW5lbE5vZGUuYWN0aXZlID0gdHJ1ZTtcclxuICAgICAgICB9ICAgIFxyXG4gICAgfSxcclxuICAgIG9uS2V5UHJlc3NlZDogZnVuY3Rpb24gKGtleUNvZGUsIGV2ZW50KSB7XHJcbiAgICAgICAgc3dpdGNoKGtleUNvZGUpIHtcclxuICAgICAgICAgICAgY2FzZSBjYy5LRVkuYTpcclxuICAgICAgICAgICAgY2FzZSBjYy5LRVkubGVmdDpcclxuICAgICAgICAgICAgICAgIHRoaXMuaXNHb0xlZnQgPSB0cnVlO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5pc1RvdWNoV2FsbEwgPSBmYWxzZTtcclxuICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICBjYXNlIGNjLktFWS5kOlxyXG4gICAgICAgICAgICBjYXNlIGNjLktFWS5yaWdodDpcclxuICAgICAgICAgICAgICAgIHRoaXMuaXNHb1JpZ2h0ID0gdHJ1ZTtcclxuICAgICAgICAgICAgICAgIHRoaXMuaXNUb3VjaFdhbGxSID0gZmFsc2U7XHJcbiAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgY2FzZSBjYy5LRVkudzpcclxuICAgICAgICAgICAgY2FzZSBjYy5LRVkudXA6XHJcbiAgICAgICAgICAgICAgICBpZiAodGhpcy50b3VjaGVkTGFkZGVyID09PSBudWxsKSB7Ly98fCB0aGlzLmlzU3RhbmRQbGF0Zm9ybS8vdGhpcy5pc1N0YW5kICAgfHwodGhpcy5pc1N0YW5kV2FsbCkgJiZcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLnNwZWVkLnkgPSB0aGlzLmp1bXBTcGVlZDtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLmlzU3RhbmQgPSBmYWxzZTtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLmlzU3RhbmRQbGF0Zm9ybSA9IGZhbHNlO1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuaXNTdGFuZFdhbGwgPSBmYWxzZTtcclxuICAgICAgICAgICAgICAgIH0gZWxzZSBpZiAodGhpcy50b3VjaGVkTGFkZGVyICE9PSBudWxsKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5pc0NsaW1iaW5nID0gdHJ1ZTtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLmlzQ2xpbWJpbmdVcCA9IHRydWU7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5ub2RlLnggPSB0aGlzLnRvdWNoZWRMYWRkZXIueDtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLnNwZWVkLnkgPSAwO1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuaXNTdGFuZFBsYXRmb3JtID0gZmFsc2U7XHJcbiAgICAgICAgICAgICAgICAgICAgLy90aGlzLmlzU3RhbmRXYWxsID0gZmFsc2U7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgY2FzZSBjYy5LRVkuczpcclxuICAgICAgICAgICAgY2FzZSBjYy5LRVkuZG93bjpcclxuICAgICAgICAgICAgICAgIGlmICh0aGlzLnRvdWNoZWRMYWRkZXIgIT09IG51bGwpIHtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLmlzQ2xpbWJpbmcgPSB0cnVlO1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuaXNDbGltYmluZ0Rvd24gPSB0cnVlO1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMubm9kZS54ID0gdGhpcy50b3VjaGVkTGFkZGVyLng7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5zcGVlZC55ID0gMDtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLmlzU3RhbmRQbGF0Zm9ybSA9IGZhbHNlO1xyXG4gICAgICAgICAgICAgICAgICAgIC8vdGhpcy5pc1N0YW5kV2FsbCA9IGZhbHNlO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgfVxyXG4gICAgfSxcclxuXHJcbiAgICBvbktleVJlbGVhc2VkOiBmdW5jdGlvbiAoa2V5Q29kZSwgZXZlbnQpIHtcclxuICAgICAgICBzd2l0Y2goa2V5Q29kZSkge1xyXG4gICAgICAgICAgICBjYXNlIGNjLktFWS5hOlxyXG4gICAgICAgICAgICBjYXNlIGNjLktFWS5sZWZ0OlxyXG4gICAgICAgICAgICAgICAgdGhpcy5pc0dvTGVmdCA9IGZhbHNlO1xyXG4gICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgIGNhc2UgY2MuS0VZLmQ6XHJcbiAgICAgICAgICAgIGNhc2UgY2MuS0VZLnJpZ2h0OlxyXG4gICAgICAgICAgICAgICAgdGhpcy5pc0dvUmlnaHQgPSBmYWxzZTtcclxuICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICBjYXNlIGNjLktFWS53OlxyXG4gICAgICAgICAgICBjYXNlIGNjLktFWS51cDpcclxuICAgICAgICAgICAgICAgIHRoaXMuaXNDbGltYmluZ1VwID0gZmFsc2U7XHJcbiAgICAgICAgICAgICAgICBpZiAodGhpcy50b3VjaGVkTGFkZGVyICE9PSBudWxsKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5pc1N0YW5kUGxhdGZvcm0gPSBmYWxzZTtcclxuICAgICAgICAgICAgICAgICAgICAvL3RoaXMuaXNTdGFuZFdhbGwgPSBmYWxzZTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICBjYXNlIGNjLktFWS5zOlxyXG4gICAgICAgICAgICBjYXNlIGNjLktFWS5kb3duOlxyXG4gICAgICAgICAgICAgICAgdGhpcy5pc0NsaW1iaW5nRG93biA9IGZhbHNlO1xyXG4gICAgICAgICAgICAgICAgaWYgKHRoaXMudG91Y2hlZExhZGRlciAhPT0gbnVsbCkge1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuaXNTdGFuZFBsYXRmb3JtID0gZmFsc2U7XHJcbiAgICAgICAgICAgICAgICAgICAgLy90aGlzLmlzU3RhbmRXYWxsID0gZmFsc2U7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgY2FzZSBjYy5LRVkuZTpcclxuICAgICAgICAgICAgY2FzZSBjYy5LRVkuc3BhY2U6XHJcbiAgICAgICAgICAgICAgICBpZih0aGlzLmluRG9vciA9PT0gdHJ1ZSkge1xyXG4gICAgICAgICAgICAgICAgICAgIEdsb2JhbC50b3RhbERlY2tEYXRhW0dsb2JhbC5kZWNrVXNhZ2VdLm1hZ2ljRGVjayA9IHRoaXMubWFpblNjcmlwdC5teU1EZWNrO1xyXG4gICAgICAgICAgICAgICAgICAgIEdsb2JhbC50b3RhbERlY2tEYXRhW0dsb2JhbC5kZWNrVXNhZ2VdLmNyZWF0dXJlRGVjayA9IHRoaXMubWFpblNjcmlwdC5teUNEZWNrO1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuYmF0dGxlU2NlbmUoKTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgIH1cclxuICAgIH0sXHJcbiAgICBiYXR0bGVTY2VuZTogZnVuY3Rpb24oKXtcclxuICAgICAgICBjYy5kaXJlY3Rvci5wcmVsb2FkU2NlbmUoJ2dhbWUnLCBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgICAgIGNjLmxvZygnTmV4dCBzY2VuZSBwcmVsb2FkZWQnKTtcclxuICAgICAgICAgICAgY2MuZGlyZWN0b3IubG9hZFNjZW5lKCdnYW1lJyk7XHJcbiAgICAgICAgfSk7XHJcbiAgICB9LFxyXG5cclxuICAgIG9uQ29sbGlzaW9uRW50ZXI6IGZ1bmN0aW9uIChvdGhlciwgc2VsZikge1xyXG4gICAgICAgIC8v5Zyw6Z2i5o6l6Kem5Yik5patXHJcbiAgICAgICAgaWYgKG90aGVyLm5vZGUuZ3JvdXAgPT09IFwiR3JvdW5kXCIpIHtcclxuICAgICAgICAgICAgY29uc29sZS5sb2coXCJ0b3VjaCB0aGUgZ3JvdW5kXCIpO1xyXG4gICAgICAgICAgICB0aGlzLmlzU3RhbmQgPSB0cnVlO1xyXG4gICAgICAgICAgICB0aGlzLnNwZWVkLnkgPSAwO1xyXG4gICAgICAgICAgICBzZWxmLm5vZGUueSA9IG90aGVyLm5vZGUueSArIG90aGVyLm5vZGUuaGVpZ2h0IC8gMiArIHNlbGYubm9kZS5oZWlnaHQgLyAyO1xyXG4gICAgICAgIH1cclxuICAgICAgICBpZiAob3RoZXIubm9kZS5ncm91cCA9PT0gXCJEb29yXCIpIHtcclxuICAgICAgICAgICAgY29uc29sZS5sb2coXCJ0b3VjaCB0aGUgRG9vclwiKTtcclxuICAgICAgICAgICAgdGhpcy5pbkRvb3IgPSB0cnVlO1xyXG4gICAgICAgIH1cclxuICAgICAgICAvL+eIrOair+aOpeinpuWIpOaWrVxyXG4gICAgICAgIGlmIChvdGhlci5ub2RlLmdyb3VwID09PSBcIkxhZGRlclwiKSB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwidG91Y2ggdGhlIGxhZGRlclwiKTtcclxuICAgICAgICAgICAgdGhpcy50b3VjaGVkTGFkZGVyID0gb3RoZXIubm9kZTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIC8v5bmz5Y+w5o6l6Kem5Yik5patXHJcbiAgICAgICAgaWYgKG90aGVyLm5vZGUuZ3JvdXAgPT09IFwiUGxhdGZvcm1cIikge1xyXG4gICAgICAgICAgICBpZiAoKHNlbGYubm9kZS55ID4gb3RoZXIubm9kZS55KSAmJiAoTWF0aC5hYnMoc2VsZi5ub2RlLnggLSBvdGhlci5ub2RlLngpIDwgb3RoZXIubm9kZS53aWR0aCAvIDIpICkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5pc1N0YW5kUGxhdGZvcm0gPSB0cnVlO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5zcGVlZC55ID0gMDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcInRvdWNoIHRoZSBQbGF0Zm9ybVwiKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgXHJcbiAgICAgICAgLy/kuI7lrozlhajlopnkvZPnmoTmjqXop6bliKTmlq1cclxuICAgICAgICBpZiAob3RoZXIubm9kZS5ncm91cCA9PT0gXCJXYWxsVVwiKSB7XHJcbiAgICAgICAgICAgIGlmICgoc2VsZi5ub2RlLnkgPiBvdGhlci5ub2RlLnkpICYmIChNYXRoLmFicyhzZWxmLm5vZGUueCAtIG90aGVyLm5vZGUueCkgPCBvdGhlci5ub2RlLndpZHRoIC8gMikpIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuaXNTdGFuZFdhbGwgPSB0cnVlO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5zcGVlZC55ID0gMDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcInRvdWNoIHRoZSBXYWxsVVwiKTtcclxuICAgICAgICB9IFxyXG4gICAgICAgIGlmIChvdGhlci5ub2RlLmdyb3VwID09PSBcIldhbGxEXCIpIHtcclxuICAgICAgICAgICAgaWYgKChzZWxmLm5vZGUueSA8IG90aGVyLm5vZGUueSkgJiYgKChNYXRoLmFicyhzZWxmLm5vZGUueCAtIG90aGVyLm5vZGUueCkgLSBzZWxmLm5vZGUud2lkdGgvMikgIDwgb3RoZXIubm9kZS53aWR0aCAvIDIpICkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5pc1RvdWNoV2FsbEQgPSB0cnVlO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5zcGVlZC55ID0gMDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcInRvdWNoIHRoZSBXYWxsRFwiKTtcclxuICAgICAgICB9ICAgICAgICAgXHJcbiAgICAgICAgaWYgKG90aGVyLm5vZGUuZ3JvdXAgPT09IFwiV2FsbExcIikge1xyXG4gICAgICAgICAgICBpZiAoKHNlbGYubm9kZS54IDwgb3RoZXIubm9kZS54KSAmJiAoKE1hdGguYWJzKHNlbGYubm9kZS55IC0gb3RoZXIubm9kZS55KSA8IG90aGVyLm5vZGUuaGVpZ2h0IC8gMiArIHNlbGYubm9kZS5oZWlnaHQgLyAyKSkgKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmlzVG91Y2hXYWxsTCA9IHRydWU7XHJcbiAgICAgICAgICAgICAgICB0aGlzLnNwZWVkLnggPSAwO1xyXG4gICAgICAgICAgICB9ICAgICBcclxuICAgICAgICAgICAgY29uc29sZS5sb2coXCJ0b3VjaCB0aGUgV2FsbExcIik7XHJcbiAgICAgICAgfSAgICAgXHJcbiAgICAgICAgaWYgKG90aGVyLm5vZGUuZ3JvdXAgPT09IFwiV2FsbFJcIikge1xyXG4gICAgICAgICAgICBpZiAoKHNlbGYubm9kZS54ID4gb3RoZXIubm9kZS54KSAmJiAoKE1hdGguYWJzKHNlbGYubm9kZS55IC0gb3RoZXIubm9kZS55KSA8IG90aGVyLm5vZGUuaGVpZ2h0IC8gMiArIHNlbGYubm9kZS5oZWlnaHQgLyAyKSkgKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmlzVG91Y2hXYWxsUiA9IHRydWU7XHJcbiAgICAgICAgICAgICAgICB0aGlzLnNwZWVkLnggPSAwO1xyXG4gICAgICAgICAgICB9ICBcclxuICAgICAgICAgICAgY29uc29sZS5sb2coXCJ0b3VjaCB0aGUgV2FsbFJcIik7XHJcbiAgICAgICAgfSAgICAgICAgICAgICAgICAgXHJcbiAgICB9LFxyXG5cclxuICAgIG9uQ29sbGlzaW9uRXhpdDogZnVuY3Rpb24gKG90aGVyLCBzZWxmKSB7XHJcbiAgICAgICAgaWYgKG90aGVyLm5vZGUuZ3JvdXAgPT09IFwiR3JvdW5kXCIpIHtcclxuICAgICAgICAgICAgdGhpcy5pc1N0YW5kID0gZmFsc2U7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBpZiAob3RoZXIubm9kZS5ncm91cCA9PT0gXCJMYWRkZXJcIikge1xyXG4gICAgICAgICAgICB0aGlzLnRvdWNoZWRMYWRkZXIgPSBudWxsO1xyXG4gICAgICAgICAgICB0aGlzLmlzQ2xpbWJpbmcgPSBmYWxzZTtcclxuICAgICAgICB9XHJcbiAgICAgICAgaWYgKG90aGVyLm5vZGUuZ3JvdXAgPT09IFwiRG9vclwiKSB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwidW50b3VjaCB0aGUgRG9vclwiKTtcclxuICAgICAgICAgICAgdGhpcy5pbkRvb3IgPSBmYWxzZTtcclxuICAgICAgICB9XHJcbiAgICAgICAgaWYgKG90aGVyLm5vZGUuZ3JvdXAgPT09IFwiUGxhdGZvcm1cIikge1xyXG4gICAgICAgICAgICB0aGlzLmlzU3RhbmRQbGF0Zm9ybSA9IGZhbHNlO1xyXG4gICAgICAgIH1cclxuICAgICAgICBcclxuICAgICAgICBpZiAob3RoZXIubm9kZS5ncm91cCA9PT0gXCJXYWxsVVwiKSB7XHJcbiAgICAgICAgICAgIHRoaXMuaXNTdGFuZFdhbGwgPSBmYWxzZTtcclxuICAgICAgICAgICAgY29uc29sZS5sb2coXCJ1bnRvdWNoIHRoZSBXYWxsVVwiKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgaWYgKG90aGVyLm5vZGUuZ3JvdXAgPT09IFwiV2FsbERcIikge1xyXG4gICAgICAgICAgICB0aGlzLmlzVG91Y2hXYWxsRCA9IGZhbHNlO1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcInVudG91Y2ggdGhlIFdhbGxEXCIpO1xyXG4gICAgICAgIH0gIFxyXG4gICAgICAgIGlmIChvdGhlci5ub2RlLmdyb3VwID09PSBcIldhbGxMXCIvKiAmJiB0aGlzLmlzR29MZWZ0ID09PSB0cnVlKi8pIHtcclxuICAgICAgICAgICAgdGhpcy5pc1RvdWNoV2FsbEwgPSBmYWxzZTtcclxuICAgICAgICAgICAgY29uc29sZS5sb2coXCJ1bnRvdWNoIHRoZSBXYWxsTFwiKTtcclxuICAgICAgICB9ICBcclxuICAgICAgICBpZiAob3RoZXIubm9kZS5ncm91cCA9PT0gXCJXYWxsUlwiLyogJiYgdGhpcy5pc0dvUmlnaHQgPT09IHRydWUqLykge1xyXG4gICAgICAgICAgICB0aGlzLmlzVG91Y2hXYWxsUiA9IGZhbHNlO1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcInVudG91Y2ggdGhlIFdhbGxSXCIpO1xyXG4gICAgICAgIH0gICAgICAgICAgXHJcbiAgICB9LFxyXG5cclxuICAgIC8vIGNhbGxlZCBldmVyeSBmcmFtZSwgdW5jb21tZW50IHRoaXMgZnVuY3Rpb24gdG8gYWN0aXZhdGUgdXBkYXRlIGNhbGxiYWNrXHJcbiAgICB1cGRhdGU6IGZ1bmN0aW9uIChkdCkge1xyXG4gICAgICAgIC8v5aSE55CGWOi9tOeahOmAn+W6plxyXG4gICAgICAgIGlmICh0aGlzLmlzR29MZWZ0ID09PSB0aGlzLmlzR29SaWdodCkgey8v5bem5Y+z6ZSu5ZCM5pe25oyJ5oiW5LiN5oyJ77yM5YiZ5LiN5YqoXHJcbiAgICAgICAgICAgIHRoaXMuc3BlZWQueCA9IDA7XHJcbiAgICAgICAgfSBlbHNlIGlmICh0aGlzLmlzR29MZWZ0ID09PSB0cnVlICYmIHRoaXMuaXNUb3VjaFdhbGxSID09PSBmYWxzZSkge1xyXG4gICAgICAgICAgICB0aGlzLnNwZWVkLnggPSAtdGhpcy5tb3ZlU3BlZWQ7Ly/lkJHlt6ZcclxuICAgICAgICB9IGVsc2UgaWYgKHRoaXMuaXNHb1JpZ2h0ID09PSB0cnVlICYmIHRoaXMuaXNUb3VjaFdhbGxMID09PSBmYWxzZSkge1xyXG4gICAgICAgICAgICB0aGlzLnNwZWVkLnggPSB0aGlzLm1vdmVTcGVlZDsvL+WQkeWPs1xyXG4gICAgICAgIH1cclxuICAgICAgICAvL+WkhOeQhlnovbTnmoTmlIDniKzpgJ/luqZcclxuICAgICAgICBpZiAodGhpcy5pc0NsaW1iaW5nVXAgPT09IHRoaXMuaXNDbGltYmluZ0Rvd24pIHsvL+W3puWPs+mUruWQjOaXtuaMieaIluS4jeaMie+8jOWImeS4jeWKqFxyXG4gICAgICAgICAgICB0aGlzLmNsaW1iU3BlZWQueSA9IDA7XHJcbiAgICAgICAgfSBlbHNlIGlmICh0aGlzLmlzQ2xpbWJpbmdVcCA9PT0gdHJ1ZSAmJiAhdGhpcy5pc1RvdWNoV2FsbEQpIHtcclxuICAgICAgICAgICAgdGhpcy5jbGltYlNwZWVkLnkgPSB0aGlzLm1vdmVTcGVlZDsvL+WQkeS4ilxyXG4gICAgICAgIH0gZWxzZSBpZiAodGhpcy5pc0NsaW1iaW5nRG93biA9PT0gdHJ1ZSAmJiAhdGhpcy5pc1N0YW5kICYmICF0aGlzLmlzU3RhbmRXYWxsICkge1xyXG4gICAgICAgICAgICB0aGlzLmNsaW1iU3BlZWQueSA9IC10aGlzLm1vdmVTcGVlZDsvL+WQkeS4i1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIHRoaXMuY2xpbWJTcGVlZC55ID0gMDtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIC8v5aSE55CG6YeN5Yqb5Yqg6YCf5bqmXHJcbiAgICAgICAgaWYgKCF0aGlzLmlzU3RhbmQgJiYgIXRoaXMuaXNDbGltYmluZyAmJiAhdGhpcy5pc1N0YW5kUGxhdGZvcm0gJiYgIXRoaXMuaXNTdGFuZFdhbGwpIHtcclxuICAgICAgICAgICAgdGhpcy5zcGVlZC55IC09IHRoaXMuZ3Jhdml0ZSAqIGR0Oy8v5Yqg6YCf5bqm5a+55pe26Ze056ev5YiGXHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICAvL+mAn+W6puWvueaXtumXtOeahOenr+WIhuWPmOS4uuS9jeenu1xyXG4gICAgICAgIHRoaXMubm9kZS54ICs9ICh0aGlzLnNwZWVkLnggKyB0aGlzLmNsaW1iU3BlZWQueCkgKiBkdDtcclxuICAgICAgICB0aGlzLm5vZGUueSArPSAodGhpcy5zcGVlZC55ICsgdGhpcy5jbGltYlNwZWVkLnkpICogZHQ7XHJcbiAgICB9LFxyXG59KTtcclxuIiwiY2MuQ2xhc3Moe1xyXG4gICAgZXh0ZW5kczogY2MuQ29tcG9uZW50LFxyXG5cclxuICAgIHByb3BlcnRpZXM6IHtcclxuICAgICAgICAvLyBmb286IHtcclxuICAgICAgICAvLyAgICBkZWZhdWx0OiBudWxsLCAgICAgIC8vIFRoZSBkZWZhdWx0IHZhbHVlIHdpbGwgYmUgdXNlZCBvbmx5IHdoZW4gdGhlIGNvbXBvbmVudCBhdHRhY2hpbmdcclxuICAgICAgICAvLyAgICAgICAgICAgICAgICAgICAgICAgICAgIHRvIGEgbm9kZSBmb3IgdGhlIGZpcnN0IHRpbWVcclxuICAgICAgICAvLyAgICB1cmw6IGNjLlRleHR1cmUyRCwgIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIHR5cGVvZiBkZWZhdWx0XHJcbiAgICAgICAgLy8gICAgc2VyaWFsaXphYmxlOiB0cnVlLCAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyB0cnVlXHJcbiAgICAgICAgLy8gICAgdmlzaWJsZTogdHJ1ZSwgICAgICAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyB0cnVlXHJcbiAgICAgICAgLy8gICAgZGlzcGxheU5hbWU6ICdGb28nLCAvLyBvcHRpb25hbFxyXG4gICAgICAgIC8vICAgIHJlYWRvbmx5OiBmYWxzZSwgICAgLy8gb3B0aW9uYWwsIGRlZmF1bHQgaXMgZmFsc2VcclxuICAgICAgICAvLyB9LFxyXG4gICAgICAgIC8vIC4uLlxyXG4gICAgfSxcclxuXHJcbiAgICAvLyB1c2UgdGhpcyBmb3IgaW5pdGlhbGl6YXRpb25cclxuICAgIG9uTG9hZDogZnVuY3Rpb24gKCkge1xyXG5cclxuICAgIH0sXHJcblxyXG4gICAgLy8gY2FsbGVkIGV2ZXJ5IGZyYW1lLCB1bmNvbW1lbnQgdGhpcyBmdW5jdGlvbiB0byBhY3RpdmF0ZSB1cGRhdGUgY2FsbGJhY2tcclxuICAgIC8vIHVwZGF0ZTogZnVuY3Rpb24gKGR0KSB7XHJcblxyXG4gICAgLy8gfSxcclxufSk7XHJcbiIsImNjLkNsYXNzKHtcclxuICAgIGV4dGVuZHM6IGNjLkNvbXBvbmVudCxcclxuXHJcbiAgICBwcm9wZXJ0aWVzOiB7XHJcbiAgICAgICAgcHVyY2hhc2VCdXR0b246Y2MuTm9kZSxcclxuXHJcbiAgICAgICAgZm9sZGVkOmZhbHNlLFxyXG5cclxuICAgICAgICBpZDowLFxyXG4gICAgICAgIC8v77+977+977+977+9XHJcbiAgICAgICAgaU5hbWU6XCJcIixcclxuICAgICAgICAvL++/ve+/ve+/vca1xLHvv73HqVxyXG4gICAgICAgIGlOYW1lTGFiZWw6Y2MuTGFiZWwsXHJcblxyXG4gICAgICAgIC8v77+977+977+977+9XHJcbiAgICAgICAgZGV0YWlsTGFiZWw6Y2MuTGFiZWwsXHJcbiAgICAgICAgLy/vv73vv73vv73vv73vv73Eve+/ve+/ve+/vVxyXG4gICAgICAgIG1vbmV5OjAsXHJcblxyXG4gICAgICAgIG1vbmV5TGFiZWw6Y2MuTGFiZWwsXHJcblxyXG4gICAgICAgIGNsaWNrYWJsZTp0cnVlLFxyXG4gICAgICAgIHR5cGU6e1xyXG4gICAgICAgICAgICB0eXBlOmNjLkVudW0oe1xyXG4gICAgICAgICAgICAgICAgYmFnOjAsXHJcbiAgICAgICAgICAgICAgICBzdG9yeToxXHJcbiAgICAgICAgICAgIH0pLFxyXG4gICAgICAgICAgICBkZWZhdWx0OjBcclxuICAgICAgICB9XHJcbiAgICAgICAgLy8gZm9vOiB7XHJcbiAgICAgICAgLy8gICAgZGVmYXVsdDogbnVsbCwgICAgICAvLyBUaGUgZGVmYXVsdCB2YWx1ZSB3aWxsIGJlIHVzZWQgb25seSB3aGVuIHRoZSBjb21wb25lbnQgYXR0YWNoaW5nXHJcbiAgICAgICAgLy8gICAgICAgICAgICAgICAgICAgICAgICAgICB0byBhIG5vZGUgZm9yIHRoZSBmaXJzdCB0aW1lXHJcbiAgICAgICAgLy8gICAgdXJsOiBjYy5UZXh0dXJlMkQsICAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyB0eXBlb2YgZGVmYXVsdFxyXG4gICAgICAgIC8vICAgIHNlcmlhbGl6YWJsZTogdHJ1ZSwgLy8gb3B0aW9uYWwsIGRlZmF1bHQgaXMgdHJ1ZVxyXG4gICAgICAgIC8vICAgIHZpc2libGU6IHRydWUsICAgICAgLy8gb3B0aW9uYWwsIGRlZmF1bHQgaXMgdHJ1ZVxyXG4gICAgICAgIC8vICAgIGRpc3BsYXlOYW1lOiAnRm9vJywgLy8gb3B0aW9uYWxcclxuICAgICAgICAvLyAgICByZWFkb25seTogZmFsc2UsICAgIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIGZhbHNlXHJcbiAgICAgICAgLy8gfSxcclxuICAgICAgICAvLyAuLi5cclxuICAgIH0sXHJcblxyXG4gICAgLy8gdXNlIHRoaXMgZm9yIGluaXRpYWxpemF0aW9uXHJcbiAgICBvbkxvYWQ6IGZ1bmN0aW9uICgpIHtcclxuXHJcbiAgICAgICAgdGhpcy5pTmFtZUxhYmVsLnN0cmluZyA9IHRoaXMuaU5hbWU7XHJcbiAgICAgICAgdGhpcy5ub2RlLm9uKGNjLk5vZGUuRXZlbnRUeXBlLk1PVVNFX0VOVEVSLHRoaXMuZW50ZXJCYWcsIHRoaXMpO1xyXG4gICAgICAgIHRoaXMubm9kZS5vbihjYy5Ob2RlLkV2ZW50VHlwZS5NT1VTRV9MRUFWRSx0aGlzLmxlYXZlQmFnLCB0aGlzKTtcclxuICAgICAgICB0aGlzLm5vZGUub24oY2MuTm9kZS5FdmVudFR5cGUuTU9VU0VfVVAsdGhpcy5jbGlja0JhZywgdGhpcyk7XHJcbiAgICB9LFxyXG4gICAgaW5pdDpmdW5jdGlvbigpe1xyXG4gICAgICAgIHRoaXMuZm9sZGVkID0gZmFsc2U7XHJcbiAgICAgICAgdGhpcy5ub2RlLnkgPSAwO1xyXG4gICAgfSxcclxuICAgIGVudGVyQmFnOmZ1bmN0aW9uKCl7XHJcbiAgICAgICAgaWYodGhpcy5mb2xkZWQgPT09IGZhbHNlKXtcclxuICAgICAgICAgICAgdmFyIGFjdGlvbiA9IGNjLnNjYWxlVG8oMC43LDEuNCk7XHJcbiAgICAgICAgICAgIC8vdGhpcy5ub2RlLnJ1bkFjdGlvbihhY3Rpb24uZWFzaW5nKGNjLmVhc2VDaXJjbGVBY3Rpb25Jbk91dCgpKSk7XHJcbiAgICAgICAgICAgIHRoaXMubm9kZS5ydW5BY3Rpb24oYWN0aW9uLmVhc2luZyhjYy5lYXNlQmFja0luT3V0KCkpKTtcclxuICAgICAgICB9XHJcbiAgICB9LFxyXG4gICAgbGVhdmVCYWc6ZnVuY3Rpb24oKXtcclxuICAgICAgICBpZih0aGlzLmZvbGRlZCA9PT0gZmFsc2Upe1xyXG4gICAgICAgICAgICB2YXIgYWN0aW9uID0gY2Muc2NhbGVUbygwLjcsMSk7XHJcbiAgICAgICAgICAgIC8vdGhpcy5ub2RlLnJ1bkFjdGlvbihhY3Rpb24uZWFzaW5nKGNjLmVhc2VDaXJjbGVBY3Rpb25Jbk91dCgpKSk7XHJcbiAgICAgICAgICAgIHRoaXMubm9kZS5ydW5BY3Rpb24oYWN0aW9uLmVhc2luZyhjYy5lYXNlQmFja0luT3V0KCkpKTtcclxuICAgICAgICB9XHJcbiAgICB9LFxyXG4gICAgY2xpY2tCYWc6ZnVuY3Rpb24oKXtcclxuICAgICAgICBpZih0aGlzLmNsaWNrYWJsZSA9PT0gdHJ1ZSkge1xyXG4gICAgICAgICAgICB2YXIgY2hpbGRyZW4gPSB0aGlzLm5vZGUucGFyZW50LmNoaWxkcmVuO1xyXG4gICAgICAgICAgICB2YXIgZmluaXNoZWQgPSBjYy5jYWxsRnVuYyhmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmZvbGRlZCA9IGZhbHNlO1xyXG4gICAgICAgICAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCBjaGlsZHJlbi5sZW5ndGg7IGkrKykge1xyXG4gICAgICAgICAgICAgICAgICAgIGNoaWxkcmVuW2ldLmdldENvbXBvbmVudChcIkl0ZW1cIikuY2xpY2thYmxlID0gdHJ1ZTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSwgdGhpcyk7XHJcbiAgICAgICAgICAgIHZhciBhY3Rpb24xID0gY2Muc2VxdWVuY2UoY2MubW92ZVRvKDAuNywgMCwgMCkuZWFzaW5nKGNjLmVhc2VDaXJjbGVBY3Rpb25Jbk91dCgpKSwgY2Muc2NhbGVUbygwLjUsIDEpLmVhc2luZyhcclxuICAgICAgICAgICAgICAgIGNjLmVhc2VDaXJjbGVBY3Rpb25Jbk91dCgpXHJcbiAgICAgICAgICAgICksIGZpbmlzaGVkKTtcclxuXHJcbiAgICAgICAgICAgIHRoaXMubm9kZS5ydW5BY3Rpb24oYWN0aW9uMSk7XHJcbiAgICAgICAgICAgIC8vdGhpcy5wdXJjaGFzZUJ1dHRvbi5ydW5BY3Rpb24oY2MubW92ZVRvKDAuNyx0aGlzLm5vZGUueCkuZWFzaW5nKGNjLmVhc2VCYWNrSW5PdXQoKSkpO1xyXG4gICAgICAgICAgICBmb3IgKHZhciBpID0gMDsgaSA8IGNoaWxkcmVuLmxlbmd0aDsgaSsrKSB7XHJcbiAgICAgICAgICAgICAgICBpZiAoY2hpbGRyZW5baV0gIT09IHRoaXMubm9kZSkge1xyXG4gICAgICAgICAgICAgICAgICAgIHZhciBhY3Rpb24gPSBjYy5zcGF3bihjYy5zY2FsZVRvKDAuNywgMC4zKSwgY2MubW92ZVRvKDAuNywgMCwgLTEwMCkpO1xyXG4gICAgICAgICAgICAgICAgICAgIGNoaWxkcmVuW2ldLnJ1bkFjdGlvbihhY3Rpb24uZWFzaW5nKGNjLmVhc2VDaXJjbGVBY3Rpb25Jbk91dCgpKSk7XHJcbiAgICAgICAgICAgICAgICAgICAgY2hpbGRyZW5baV0uZ2V0Q29tcG9uZW50KFwiSXRlbVwiKS5mb2xkZWQgPSB0cnVlO1xyXG4gICAgICAgICAgICAgICAgICAgIGNoaWxkcmVuW2ldLmdldENvbXBvbmVudChcIkl0ZW1cIikuY2xpY2thYmxlID0gZmFsc2U7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIHZhciBldmVudHNlbmQgPSBuZXcgY2MuRXZlbnQuRXZlbnRDdXN0b20oJ3B1cmNoYXNlSWQnLCB0cnVlKTtcclxuICAgICAgICAgICAgZXZlbnRzZW5kLnNldFVzZXJEYXRhKHtpZDogdGhpcy5pZCwgc2NyaXB0OiB0aGlzfSk7XHJcbiAgICAgICAgICAgIHRoaXMubm9kZS5kaXNwYXRjaEV2ZW50KGV2ZW50c2VuZCk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG4gICAgLy8gY2FsbGVkIGV2ZXJ5IGZyYW1lLCB1bmNvbW1lbnQgdGhpcyBmdW5jdGlvbiB0byBhY3RpdmF0ZSB1cGRhdGUgY2FsbGJhY2tcclxuICAgIC8vIHVwZGF0ZTogZnVuY3Rpb24gKGR0KSB7XHJcblxyXG4gICAgLy8gfSxcclxufSk7XHJcbiIsImNjLkNsYXNzKHtcclxuICAgIGV4dGVuZHM6IGNjLkNvbXBvbmVudCxcclxuXHJcbiAgICBwcm9wZXJ0aWVzOiB7XHJcbiAgICAgICAgY2FyZEdyb3VwQnV0dG9uOntcclxuICAgICAgICAgICAgZGVmYXVsdDogbnVsbCxcclxuICAgICAgICAgICAgdHlwZTogY2MuQnV0dG9uLFxyXG4gICAgICAgIH0sXHJcbiAgICAgICAgb3BlbkNhcmRCdXR0b246e1xyXG4gICAgICAgICAgICBkZWZhdWx0Om51bGwsXHJcbiAgICAgICAgICAgIHR5cGU6Y2MuQnV0dG9uLFxyXG4gICAgICAgIH0sXHJcbiAgICAgICAgaGVyb0luZkJ1dHRvbjp7XHJcbiAgICAgICAgICAgIGRlZmF1bHQ6bnVsbCxcclxuICAgICAgICAgICAgdHlwZTpjYy5CdXR0b24sXHJcbiAgICAgICAgfSxcclxuICAgICAgICBjaG9pY2VIZXJvQm9hcmQ6e1xyXG4gICAgICAgICAgICBkZWZhdWx0OiBudWxsLFxyXG4gICAgICAgICAgICB0eXBlOiBjYy5Ob2RlLFxyXG4gICAgICAgIH0sXHJcbiAgICAgICAgY2hvaWNlT3BlbkJvYXJkOntcclxuICAgICAgICAgICAgZGVmYXVsdDogbnVsbCxcclxuICAgICAgICAgICAgdHlwZTogY2MuTm9kZSxcclxuICAgICAgICB9LFxyXG4gICAgICAgIGNob2ljZUNhcmRCb2FyZDp7XHJcbiAgICAgICAgICAgIGRlZmF1bHQ6IG51bGwsXHJcbiAgICAgICAgICAgIHR5cGU6IGNjLk5vZGUsXHJcbiAgICAgICAgfSxcclxuICAgICAgICBjYXJkTGlzdE5vZGU6Y2MuTm9kZSxcclxuICAgIH0sXHJcbiAgICBcclxuICAgIG9uTG9hZDpmdW5jdGlvbigpe1xyXG4gICAgICAgIHRoaXMuY2hvaWNlSGVyb0JvYXJkLmFjdGl2ZSA9IGZhbHNlO1xyXG4gICAgICAgIHRoaXMuY2hvaWNlT3BlbkJvYXJkLmFjdGl2ZSA9IGZhbHNlO1xyXG4gICAgICAgIHRoaXMuY2hvaWNlQ2FyZEJvYXJkLmFjdGl2ZSA9IHRydWU7XHJcbiAgICAgICAgdGhpcy5jYXJkTGlzdFNjcmlwdCA9IHRoaXMuY2FyZExpc3ROb2RlLmdldENvbXBvbmVudChcIkNhcmRMaXN0XCIpO1xyXG4gICAgfSxcclxuICAgIC8v06Lvv73vv71cclxuICAgIGhlcm9JbmZMYXlvdXQ6IGZ1bmN0aW9uICgpIHtcclxuICAgICAgICB0aGlzLmxheW91dFN3aXRjaCh0aGlzLmNob2ljZUhlcm9Cb2FyZCx0aGlzLmhlcm9JbmZCdXR0b24pO1xyXG4gICAgICAgIHRoaXMuY2hvaWNlSGVyb0JvYXJkLmFjdGl2ZSA9IHRydWU7XHJcbiAgICAgICAgdGhpcy5jaG9pY2VPcGVuQm9hcmQuYWN0aXZlID0gZmFsc2U7XHJcbiAgICAgICAgdGhpcy5jaG9pY2VDYXJkQm9hcmQuYWN0aXZlID0gZmFsc2U7XHJcbiAgICAgICAgLy9jYy5kaXJlY3Rvci5sb2FkU2NlbmUoXCJIZXJvSW5mU2NlbmUuZmlyZVwiKTtcclxuICAgIH0sXHJcbiAgICAvL++/ve+/ve+/ve+/vVxyXG4gICAgb3BlbkNhcmRMYXlvdXQ6IGZ1bmN0aW9uKCl7XHJcbiAgICAgICAgdGhpcy5sYXlvdXRTd2l0Y2godGhpcy5jaG9pY2VPcGVuQm9hcmQsdGhpcy5vcGVuQ2FyZEJ1dHRvbik7XHJcbiAgICAgICAgdGhpcy5jaG9pY2VIZXJvQm9hcmQuYWN0aXZlID0gZmFsc2U7XHJcbiAgICAgICAgdGhpcy5jaG9pY2VPcGVuQm9hcmQuYWN0aXZlID0gdHJ1ZTtcclxuICAgICAgICB0aGlzLmNob2ljZUNhcmRCb2FyZC5hY3RpdmUgPSBmYWxzZTtcclxuICAgICAgICAvL2NjLmRpcmVjdG9yLmxvYWRTY2VuZShcIk9wZW5DYXJkU2NlbmUuZmlyZVwiKTtcclxuICAgIH0sXHJcbiAgICAvL++/ve+/ve+/ve+/vVxyXG4gICAgY2FyZEdyb3VwTGF5b3V0OiBmdW5jdGlvbigpe1xyXG4gICAgICAgIHRoaXMubGF5b3V0U3dpdGNoKHRoaXMuY2hvaWNlQ2FyZEJvYXJkLHRoaXMuY2FyZEdyb3VwQnV0dG9uKTtcclxuICAgICAgICB0aGlzLmNhcmRMaXN0U2NyaXB0LnJlbmV3U2hvd0NhcmRHcm91cCgpO1xyXG4gICAgICAgIHRoaXMuY2hvaWNlSGVyb0JvYXJkLmFjdGl2ZSA9IGZhbHNlO1xyXG4gICAgICAgIHRoaXMuY2hvaWNlT3BlbkJvYXJkLmFjdGl2ZSA9IGZhbHNlO1xyXG4gICAgICAgIHRoaXMuY2hvaWNlQ2FyZEJvYXJkLmFjdGl2ZSA9IHRydWU7XHJcbiAgICAgICAgLy9jYy5kaXJlY3Rvci5sb2FkU2NlbmUoXCJDYXJkR3JvdXBTY2VuZS5maXJlXCIpO1xyXG4gICAgfSxcclxuICAgIC8qbGF5b3V0U3dpdGNoOiBmdW5jdGlvbihjaG9pY2VCb2FyZCxjaG9pY2VCdXR0b24pe1xyXG4gICAgICAgIGNob2ljZUJvYXJkLnpJbmRleCA9IDI7XHJcbiAgICAgICAgY2hvaWNlQm9hcmQuekluZGV4ID0gMTtcclxuICAgICAgICBjaG9pY2VCdXR0b24ucHJlc3NlZENvbG9yID0gbmV3IGNjLkNvbG9yLnRvQ1NTKFwiI0U5QkY4MVwiKTtcclxuICAgIH0qL1xyXG4gICAgbGF5b3V0U3dpdGNoOiBmdW5jdGlvbihjaG9pY2VCb2FyZCxjaG9pY2VCdXR0b24pe1xyXG4gICAgICAgIGNob2ljZUJvYXJkLnpJbmRleCA9IDI7XHJcbiAgICAgICAgY2hvaWNlQnV0dG9uLnpJbmRleCA9IDE7XHJcbiAgICB9XHJcblxyXG5cclxuICAgIC8vIGNhbGxlZCBldmVyeSBmcmFtZSwgdW5jb21tZW50IHRoaXMgZnVuY3Rpb24gdG8gYWN0aXZhdGUgdXBkYXRlIGNhbGxiYWNrXHJcbiAgICAvLyB1cGRhdGU6IGZ1bmN0aW9uIChkdCkge1xyXG5cclxuICAgIC8vIH0sXHJcbn0pO1xyXG4iLCJ2YXIgZ2xvYmFsQ29uc3RhbnQgPSByZXF1aXJlKFwiQ29uc3RhbnRcIik7XHJcbmNjLkNsYXNzKHtcclxuICAgIGV4dGVuZHM6IGNjLkNvbXBvbmVudCxcclxuXHJcbiAgICBwcm9wZXJ0aWVzOiB7XHJcblxyXG4gICAgfSxcclxuXHJcbiAgICAvLyB1c2UgdGhpcyBmb3IgaW5pdGlhbGl6YXRpb25cclxuICAgIG9uTG9hZDogZnVuY3Rpb24gKCkge1xyXG4gICAgICAgIHRoaXMuY2FyZFNjcmlwdCA9IHRoaXMubm9kZS5nZXRDb21wb25lbnQoJ0NhcmQnKTtcclxuICAgICAgICB0aGlzLm1hZ2ljQ2FyZFNjcmlwdCA9IHRoaXMubm9kZS5nZXRDb21wb25lbnQoJ01hZ2ljQ2FyZCcpO1xyXG4gICAgICAgIHZhciB0eXBlID0gY2MuRW51bSh7XHJcbiAgICAgICAgICAgIE5vVGFyZ2V0OiAwLFxyXG4gICAgICAgICAgICBBcmVhVGFyZ2V0OiAxLFxyXG4gICAgICAgICAgICBEaXJlY3Rpb25UYXJnZXQ6IDIsXHJcbiAgICAgICAgfSk7XHJcbi8vICAgICAgICB2YXIgc2VsZiA9IHRoaXM7XHJcbiAgICAgICAgaWYodGhpcy5tYWdpY0NhcmRTY3JpcHQubWFnaWNUeXBlID09PSB0eXBlLkFyZWFUYXJnZXQpe1xyXG4gICAgICAgICAgICB0aGlzLnVzZUNhcmQgPSBmdW5jdGlvbihwb3NpdGlvbixhcmVhKXtcclxuICAgICAgICAgICAgICAgIHZhciBldmVudHNlbmQgPSBuZXcgY2MuRXZlbnQuRXZlbnRDdXN0b20oJ21hZ2ljQ3JlYXRlJyx0cnVlKTtcclxuICAgICAgICAgICAgICAgIGV2ZW50c2VuZC5zZXRVc2VyRGF0YSh7XHJcbiAgICAgICAgICAgICAgICAgICAgbmFtZTp0aGlzLmNhcmRTY3JpcHQuY05hbWUsXHJcbiAgICAgICAgICAgICAgICAgICAgcm91bmQ6MyxcclxuICAgICAgICAgICAgICAgICAgICB5Om51bGwsXHJcbiAgICAgICAgICAgICAgICAgICAgcG9zaXRpb246cG9zaXRpb24sXHJcbiAgICAgICAgICAgICAgICAgICAgYXJlYTphcmVhLFxyXG4gICAgICAgICAgICAgICAgICAgIHRlYW06dGhpcy5jYXJkU2NyaXB0LnRlYW0sXHJcbiAgICAgICAgICAgICAgICAgICAgaWQ6dGhpcy5jYXJkU2NyaXB0LmNhcmRJRFxyXG4gICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICB0aGlzLm5vZGUuZGlzcGF0Y2hFdmVudChldmVudHNlbmQpO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5jYXJkU2NyaXB0LmRyYXdDYXJkU2NyaXB0LmRlbGV0ZUNhcmQodGhpcy5ub2RlKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1lbHNlIGlmKHRoaXMubWFnaWNDYXJkU2NyaXB0Lm1hZ2ljVHlwZSA9PT0gdHlwZS5EaXJlY3Rpb25UYXJnZXQpe1xyXG4gICAgICAgICAgICB0aGlzLnVzZUNhcmQgPSBmdW5jdGlvbihpZCxhbmdlbCxzcGVlZCxhcmVhLHgseSl7XHJcblxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfWVsc2V7XHJcbiAgICAgICAgICAgIHRoaXMudXNlQ2FyZCA9IGZ1bmN0aW9uKCl7XHJcblxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgfSxcclxuIFxyXG4gICAgZ2V0VXNlU3RhdGU6IGZ1bmN0aW9uKCl7XHJcbiAgICAgICAgcmV0dXJuIHRydWU7XHJcbiAgICB9LCAgICBcclxuICAgIFxyXG4gICAgLy91c2VDYXJkOiBmdW5jdGlvbihwb3NpdGlvbixhcmVhKXtcclxuICAgIC8vXHJcbiAgICAvLyAgICB2YXIgZXZlbnRzZW5kID0gbmV3IGNjLkV2ZW50LkV2ZW50Q3VzdG9tKCdtYWdpY0NyZWF0ZScsdHJ1ZSk7XHJcbiAgICAvLyAgICBldmVudHNlbmQuc2V0VXNlckRhdGEoe1xyXG4gICAgLy8gICAgICAgIG5hbWU6dGhpcy5jYXJkU2NyaXB0LmNOYW1lLFxyXG4gICAgLy8gICAgICAgIHJvdW5kOjMsXHJcbiAgICAvLyAgICAgICAgeTpudWxsLFxyXG4gICAgLy8gICAgICAgIHBvc2l0aW9uOnBvc2l0aW9uLFxyXG4gICAgLy8gICAgICAgIGFyZWE6YXJlYSxcclxuICAgIC8vICAgICAgICB0ZWFtOnRoaXMuY2FyZFNjcmlwdC50ZWFtLFxyXG4gICAgLy8gICAgICAgIGlkOnRoaXMuY2FyZFNjcmlwdC5jYXJkSURcclxuICAgIC8vICAgIH0pO1xyXG4gICAgLy8gICAgdGhpcy5ub2RlLmRpc3BhdGNoRXZlbnQoZXZlbnRzZW5kKTtcclxuICAgIC8vICAgIHRoaXMuY2FyZFNjcmlwdC5kcmF3Q2FyZFNjcmlwdC5kZWxldGVDYXJkKHRoaXMubm9kZSk7XHJcbiAgICAvL30sXHJcbiAgICB1c2VDYXJkOiBmdW5jdGlvbigpe1xyXG5cclxuICAgIH0sXHJcblxyXG4gICAgLy8gY2FsbGVkIGV2ZXJ5IGZyYW1lLCB1bmNvbW1lbnQgdGhpcyBmdW5jdGlvbiB0byBhY3RpdmF0ZSB1cGRhdGUgY2FsbGJhY2tcclxuICAgIC8vIHVwZGF0ZTogZnVuY3Rpb24gKGR0KSB7XHJcblxyXG4gICAgLy8gfSxcclxufSk7IiwidmFyIGdsb2JhbENvbnN0YW50ID0gcmVxdWlyZShcIkNvbnN0YW50XCIpO1xyXG5jYy5DbGFzcyh7XHJcbiAgICBleHRlbmRzOiBjYy5Db21wb25lbnQsXHJcblxyXG4gICAgcHJvcGVydGllczoge1xyXG4gICAgICAgIG1hZ2ljVHlwZToge1xyXG4gICAgICAgICAgICB0eXBlOiBjYy5FbnVtKHtcclxuICAgICAgICAgICAgICAgIE5vVGFyZ2V0OiAwLFxyXG4gICAgICAgICAgICAgICAgQXJlYVRhcmdldDogMSxcclxuICAgICAgICAgICAgICAgIERpcmVjdGlvblRhcmdldDogMixcclxuICAgICAgICAgICAgfSksXHJcbiAgICAgICAgICAgIGRlZmF1bHQ6IDBcclxuICAgICAgICB9LFxyXG5cclxuICAgIH0sXHJcblxyXG4gICAgLy8gdXNlIHRoaXMgZm9yIGluaXRpYWxpemF0aW9uXHJcbiAgICBvbkxvYWQ6IGZ1bmN0aW9uICgpIHtcclxuICAgICAgICB0aGlzLmNhcmRTY3JpcHQgPSB0aGlzLm5vZGUuZ2V0Q29tcG9uZW50KCdDYXJkJyk7XHJcbiAgICAgICAgdGhpcy5tYWdpY0NhcmRTY3JpcHQgPSB0aGlzLm5vZGUuZ2V0Q29tcG9uZW50KCdNYWdpY0NhcmQnKTtcclxuICAgICAgICB2YXIgdHlwZSA9IGNjLkVudW0oe1xyXG4gICAgICAgICAgICBOb1RhcmdldDogMCxcclxuICAgICAgICAgICAgQXJlYVRhcmdldDogMSxcclxuICAgICAgICAgICAgRGlyZWN0aW9uVGFyZ2V0OiAyLFxyXG4gICAgICAgIH0pO1xyXG4vLyAgICAgICAgdmFyIHNlbGYgPSB0aGlzO1xyXG4gICAgICAgIGlmKHRoaXMubWFnaWNDYXJkU2NyaXB0Lm1hZ2ljVHlwZSA9PT0gdHlwZS5BcmVhVGFyZ2V0KXtcclxuICAgICAgICAgICAgdGhpcy51c2VDYXJkID0gZnVuY3Rpb24ocG9zaXRpb24sYXJlYSl7XHJcblxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfWVsc2UgaWYodGhpcy5tYWdpY0NhcmRTY3JpcHQubWFnaWNUeXBlID09PSB0eXBlLkRpcmVjdGlvblRhcmdldCl7XHJcbiAgICAgICAgICAgIHRoaXMudXNlQ2FyZCA9IGZ1bmN0aW9uKGlkLGFuZ2VsLHNwZWVkLGFyZWEseCx5KXtcclxuICAgICAgICAgICAgICAgIHZhciBldmVudHNlbmQgPSBuZXcgY2MuRXZlbnQuRXZlbnRDdXN0b20oJ21hZ2ljQ3JlYXRlJyx0cnVlKTtcclxuICAgICAgICAgICAgICAgIGV2ZW50c2VuZC5zZXRVc2VyRGF0YSh7XHJcbiAgICAgICAgICAgICAgICAgICAgbmFtZTp0aGlzLmNhcmRTY3JpcHQuY05hbWUsXHJcbiAgICAgICAgICAgICAgICAgICAgcm91bmQ6MSxcclxuICAgICAgICAgICAgICAgICAgICBwb3NpdGlvbjp4LFxyXG4gICAgICAgICAgICAgICAgICAgIHk6eSxcclxuICAgICAgICAgICAgICAgICAgICBhbmdlbDphbmdlbCxcclxuICAgICAgICAgICAgICAgICAgICBzcGVlZDpzcGVlZCxcclxuICAgICAgICAgICAgICAgICAgICBhcmVhOmFyZWEsXHJcbiAgICAgICAgICAgICAgICAgICAgdGVhbTp0aGlzLmNhcmRTY3JpcHQudGVhbSxcclxuICAgICAgICAgICAgICAgICAgICBpZDp0aGlzLmNhcmRTY3JpcHQuY2FyZElEXHJcbiAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgIHRoaXMubm9kZS5kaXNwYXRjaEV2ZW50KGV2ZW50c2VuZCk7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmNhcmRTY3JpcHQuaGVyb1NjaXJwdC5kcmF3Q2FyZCgxKTtcclxuICAgICAgICAgICAgICAgIHRoaXMuY2FyZFNjcmlwdC5kcmF3Q2FyZFNjcmlwdC5kZWxldGVDYXJkKHRoaXMubm9kZSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9ZWxzZXtcclxuICAgICAgICAgICAgdGhpcy51c2VDYXJkID0gZnVuY3Rpb24oKXtcclxuXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9LFxyXG5cclxuICAgIGdldFVzZVN0YXRlOiBmdW5jdGlvbigpe1xyXG4gICAgICAgIHJldHVybiB0cnVlO1xyXG4gICAgfSxcclxuICAgIHVzZUNhcmQ6IGZ1bmN0aW9uKCl7XHJcblxyXG4gICAgfVxyXG4gICAgLy91c2VDYXJkOiBmdW5jdGlvbihpZCxhbmdlbCxzcGVlZCx4LHkpe1xyXG4gICAgLy9cclxuICAgIC8vICAgIHZhciBldmVudHNlbmQgPSBuZXcgY2MuRXZlbnQuRXZlbnRDdXN0b20oJ21hZ2ljQ3JlYXRlJyx0cnVlKTtcclxuICAgIC8vICAgIGV2ZW50c2VuZC5zZXRVc2VyRGF0YSh7XHJcbiAgICAvLyAgICAgICAgbmFtZTp0aGlzLmNhcmRTY3JpcHQuY05hbWUsXHJcbiAgICAvLyAgICAgICAgcm91bmQ6MSxcclxuICAgIC8vICAgICAgICBwb3NpdGlvbjp4LFxyXG4gICAgLy8gICAgICAgIHk6eSxcclxuICAgIC8vICAgICAgICBhbmdlbDphbmdlbCxcclxuICAgIC8vICAgICAgICBzcGVlZDpzcGVlZCxcclxuICAgIC8vICAgICAgICB0ZWFtOnRoaXMuY2FyZFNjcmlwdC50ZWFtLFxyXG4gICAgLy8gICAgICAgIGlkOnRoaXMuY2FyZFNjcmlwdC5jYXJkSURcclxuICAgIC8vICAgIH0pO1xyXG4gICAgLy8gICAgdGhpcy5ub2RlLmRpc3BhdGNoRXZlbnQoZXZlbnRzZW5kKTtcclxuICAgIC8vICAgIHRoaXMuY2FyZFNjcmlwdC5oZXJvU2NpcnB0LmRyYXdDYXJkKDIpO1xyXG4gICAgLy8gICAgLy9mb3IodmFyIGkgPSAwO2kgPCAoMzYwLzMpO2krKykge1xyXG4gICAgLy8gICAgLy8gICAgdmFyIGV2ZW50c2VuZCA9IG5ldyBjYy5FdmVudC5FdmVudEN1c3RvbSgnY2hhbnRDcmVhdGUnLCB0cnVlKTtcclxuICAgIC8vICAgIC8vICAgIGV2ZW50c2VuZC5zZXRVc2VyRGF0YSh7XHJcbiAgICAvLyAgICAvLyAgICAgICAgbmFtZTp0aGlzLmNhcmRTY3JpcHQuY05hbWUsXHJcbiAgICAvLyAgICAvLyAgICAgICAgcm91bmQ6MTUsXHJcbiAgICAvLyAgICAvLyAgICAgICAgcG9zaXRpb246IHgsXHJcbiAgICAvLyAgICAvLyAgICAgICAgeTogeSxcclxuICAgIC8vICAgIC8vICAgICAgICBhbmdlbDogYW5nZWwgKyAzKmksXHJcbiAgICAvLyAgICAvLyAgICAgICAgaWQ6IHRoaXMuY2FyZFNjcmlwdC5jYXJkSUQsXHJcbiAgICAvLyAgICAvLyAgICAgICAgc3BlZWQ6IHNwZWVkLFxyXG4gICAgLy8gICAgLy8gICAgICAgIHRlYW06IHRoaXMuY2FyZFNjcmlwdC50ZWFtXHJcbiAgICAvLyAgICAvLyAgICB9KTtcclxuICAgIC8vICAgIC8vICAgIHRoaXMubm9kZS5kaXNwYXRjaEV2ZW50KGV2ZW50c2VuZCk7XHJcbiAgICAvLyAgICAvL31cclxuICAgIC8vXHJcbiAgICAvLyAgICB0aGlzLmNhcmRTY3JpcHQuZHJhd0NhcmRTY3JpcHQuZGVsZXRlQ2FyZCh0aGlzLm5vZGUpO1xyXG4gICAgLy99XHJcbiAgICAvLyBjYWxsZWQgZXZlcnkgZnJhbWUsIHVuY29tbWVudCB0aGlzIGZ1bmN0aW9uIHRvIGFjdGl2YXRlIHVwZGF0ZSBjYWxsYmFja1xyXG4gICAgLy8gdXBkYXRlOiBmdW5jdGlvbiAoZHQpIHtcclxuXHJcbiAgICAvLyB9LFxyXG59KTtcclxuIiwidmFyIGdsb2JhbENvbnN0YW50ID0gcmVxdWlyZShcIkNvbnN0YW50XCIpO1xyXG5jYy5DbGFzcyh7XHJcbiAgICBleHRlbmRzOiBjYy5Db21wb25lbnQsXHJcblxyXG4gICAgcHJvcGVydGllczoge1xyXG4gICAgICAgIC8v6a2U5rOV5Yib5bu65oiQ5Yqf55qE6Z+z5LmQXHJcbiAgICAgICAgbG9hZEVmZmVjdDpjYy5BdWRpb0NsaXAsXHJcbiAgICAgICAgLy/lkb3kuK3ml7bnmoTpn7PkuZBcclxuICAgICAgICBoaXRFZmZlY3Q6Y2MuQXVkaW9DbGlwLFxyXG5cclxuICAgIH0sXHJcblxyXG4gICAgLy8gdXNlIHRoaXMgZm9yIGluaXRpYWxpemF0aW9uXHJcbiAgICBvbkxvYWQ6IGZ1bmN0aW9uICgpIHtcclxuXHJcbiAgICAgICAgdmFyIGFuaW1hdGlvbiA9IHRoaXMubm9kZS5nZXRDb21wb25lbnQoY2MuQW5pbWF0aW9uKTtcclxuICAgICAgICB0aGlzLnRlYW0gPSAwO1xyXG5cclxuICAgICAgICAvL+S8oOmAkuWIm+W7uuazleacr+aIkOWKn+aXtumfs+aViOeahOS6i+S7tlxyXG4gICAgICAgIGlmKHRoaXMubG9hZEVmZmVjdCAhPT0gbnVsbClcclxuICAgICAgICB0aGlzLnNlbmRFdmVudCh0aGlzLmxvYWRFZmZlY3QpO1xyXG5cclxuICAgICAgICBhbmltYXRpb24ub24oJ2ZpbmlzaGVkJywgIHRoaXMub25GaW5pc2hlZCwgICAgdGhpcyk7XHJcblxyXG4gICAgICAgIGNjLmRpcmVjdG9yLmdldENvbGxpc2lvbk1hbmFnZXIoKS5lbmFibGVkID0gdHJ1ZTtcclxuICAgICAgICAvL2NjLmRpcmVjdG9yLmdldENvbGxpc2lvbk1hbmFnZXIoKS5lbmFibGVkRGVidWdEcmF3ID0gdHJ1ZTtcclxuXHJcbiAgICB9LFxyXG5cclxuICAgIG9uQ29sbGlzaW9uRW50ZXI6IGZ1bmN0aW9uIChvdGhlciwgc2VsZikge1xyXG4gICAgICAgIC8v77+977+977+977+977+907Tvv73vv73Qtu+/vVxyXG4gICAgICAgIGlmIChvdGhlci5ub2RlLmdyb3VwID09PSBcIkdyb3VuZFwiKSB7XHJcblxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgLy/vv73vv73vv73vv73vv73TtO+/ve+/vdC277+9XHJcbiAgICAgICAgaWYgKG90aGVyLm5vZGUuZ3JvdXAgPT09IFwiQ3JlYXR1cmVcIikge1xyXG4gICAgICAgICAgICB2YXIgc2NyaXB0MSA9IG90aGVyLm5vZGUuZ2V0Q29tcG9uZW50KCdDcmVhdHVyZScpO1xyXG4gICAgICAgICAgICB2YXIgc3RhdGVTY3JpcHQgPSBzY3JpcHQxLnN0YXRlTm9kZS5nZXRDb21wb25lbnQoJ0NyZWF0dXJlU3RhdGUnKTtcclxuICAgICAgICAgICAgY2MubG9nKFwi546w5Zyo55qE6Zif5LyN5pivXCIgKyBzY3JpcHQxLnRlYW0pO1xyXG4gICAgICAgICAgICBpZihzY3JpcHQxLnRlYW0gIT09IHRoaXMudGVhbSl7XHJcblxyXG4gICAgICAgICAgICAgICAgLy/kvKDpgJLmkq3mlL7pn7PmlYjnmoTkuovku7ZcclxuICAgICAgICAgICAgICAgIGlmKHRoaXMuaGl0RWZmZWN0ICE9PSBudWxsKVxyXG4gICAgICAgICAgICAgICAgdGhpcy5zZW5kRXZlbnQodGhpcy5oaXRFZmZlY3QpO1xyXG5cclxuICAgICAgICAgICAgICAgIC8vc3RhdGVTY3JpcHQuYWRkU3RhdGUoZ2xvYmFsQ29uc3RhbnQuc3RhdGVFbnVtLmhlYWwsMyw0MCk7XHJcblxyXG4gICAgICAgICAgICAgICAgLy/kvKDpgJLmkq3mlL7pn7PmlYjnmoTkuovku7ZcclxuICAgICAgICAgICAgICAgIHNjcmlwdDEuY2hhbmdlSGVhbHRoKC0xMCk7XHJcbiAgICAgICAgICAgICAgICAvL3NjcmlwdC5jbGVhblRhcmdldCgpO1xyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgIH1cclxuICAgICAgICBpZiAob3RoZXIubm9kZS5ncm91cCA9PT0gXCJIZXJvXCIpIHtcclxuICAgICAgICAgICAgdmFyIHNjcmlwdDIgPSBvdGhlci5ub2RlLmdldENvbXBvbmVudCgnUGxheWVyJyk7XHJcbiAgICAgICAgICAgIGlmKHNjcmlwdDIudGVhbSAhPT0gdGhpcy50ZWFtKXtcclxuICAgICAgICAgICAgICAgIC8v5Lyg6YCS5pKt5pS+6Z+z5pWI55qE5LqL5Lu2XHJcbiAgICAgICAgICAgICAgICBpZih0aGlzLmhpdEVmZmVjdCAhPT0gbnVsbClcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLnNlbmRFdmVudCh0aGlzLmhpdEVmZmVjdCk7XHJcbiAgICAgICAgICAgICAgICAvL3NjcmlwdC5jaGFuZ2VIZWFsdGgoLTEwKTtcclxuXHJcbiAgICAgICAgICAgICAgICB2YXIgZGVhZEZsYWcgPSBzY3JpcHQyLmNoYW5nZUhlYWx0aCgtMTApO1xyXG4gICAgICAgICAgICAgICAgaWYoZGVhZEZsYWcgIT0gbnVsbCAmJiBkZWFkRmxhZyA9PSAxKXtcclxuICAgICAgICAgICAgICAgICAgICBzY3JpcHQyLnJlbGVhc2VUYXJnZXQoKTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICBpZiAob3RoZXIubm9kZS5ncm91cCA9PT0gXCJCYXNlXCIpIHtcclxuICAgICAgICAgICAgdmFyIHNjcmlwdDMgPSBvdGhlci5ub2RlLmdldENvbXBvbmVudCgnQmFzZScpO1xyXG4gICAgICAgICAgICBpZihzY3JpcHQzLnRlYW0gIT09IHRoaXMudGVhbSl7XHJcbiAgICAgICAgICAgICAgICAvL+S8oOmAkuaSreaUvumfs+aViOeahOS6i+S7tlxyXG4gICAgICAgICAgICAgICAgaWYodGhpcy5oaXRFZmZlY3QgIT09IG51bGwpXHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5zZW5kRXZlbnQodGhpcy5oaXRFZmZlY3QpO1xyXG4gICAgICAgICAgICAgICAgc2NyaXB0My5jaGFuZ2VIZWFsdGgoLTEwKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH0sXHJcblxyXG4gICAgb25Db2xsaXNpb25FeGl0OiBmdW5jdGlvbiAob3RoZXIsIHNlbGYpIHtcclxuICAgICAgICBpZiAob3RoZXIubm9kZS5ncm91cCA9PT0gXCJHcm91bmRcIikge1xyXG5cclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGlmIChvdGhlci5ub2RlLmdyb3VwID09PSBcIkNyZWF0dXJlXCIpIHtcclxuXHJcbiAgICAgICAgfVxyXG4gICAgfSxcclxuICAgIG9uRmluaXNoZWQ6IGZ1bmN0aW9uKCl7XHJcbiAgICAgICAgdGhpcy5ub2RlLnJlbW92ZUZyb21QYXJlbnQoKTtcclxuICAgIH0sXHJcbiAgICBpbml0TWFnaWM6ZnVuY3Rpb24oZGV0YWlsKXtcclxuICAgICAgICB2YXIgYm94ID0gdGhpcy5ub2RlLmdldENvbXBvbmVudChjYy5Cb3hDb2xsaWRlcik7XHJcbiAgICAgICAgYm94LnNpemUud2lkdGggPSBkZXRhaWwuYXJlYTtcclxuICAgICAgICB0aGlzLnRlYW0gPSBkZXRhaWwudGVhbTtcclxuICAgICAgICB0aGlzLm5vZGUud2lkdGggPSBkZXRhaWwuYXJlYTtcclxuICAgIH0sXHJcbiAgICAvKipcclxuICAgICAqIEDkuLvopoHlip/og70g5ZCR5LiK57qn6IqC54K55Lyg6YCS5raI5oGv77yM5L2/5LmL5pKt5pS+6Z+z5pWIXHJcbiAgICAgKiBAYXV0aG9yIEMxNFxyXG4gICAgICogQERhdGUgMjAxNy8xMi8xMlxyXG4gICAgICogQHBhcmFtZXRlcnMgYXVkaW9DaGlwIHZvbHVtZVxyXG4gICAgICogQHJldHVybnMgbnVsbFxyXG4gICAgICovXHJcbiAgICBzZW5kRXZlbnQ6ZnVuY3Rpb24oYXVkaW9DaGlwLGZ1bGxWb2x1bWUsdm9sdW1lKSB7XHJcbiAgICAgICAgdmFyIGV2ZW50c2VuZCA9IG5ldyBjYy5FdmVudC5FdmVudEN1c3RvbShcInBsYXlFZmZlY3RcIiwgdHJ1ZSk7XHJcbiAgICAgICAgaWYodm9sdW1lID09PSB1bmRlZmluZWQgfHwgdm9sdW1lID09PSBudWxsKXtcclxuICAgICAgICAgICAgdm9sdW1lID0gMTtcclxuICAgICAgICB9XHJcbiAgICAgICAgaWYoZnVsbFZvbHVtZSA9PT0gdW5kZWZpbmVkIHx8IGZ1bGxWb2x1bWUgPT09IG51bGwgfHwgZnVsbFZvbHVtZSA9PT0gZmFsc2Upe1xyXG4gICAgICAgICAgICBmdWxsVm9sdW1lID0gZmFsc2U7XHJcbiAgICAgICAgfWVsc2V7XHJcbiAgICAgICAgICAgIGZ1bGxWb2x1bWUgPSB0cnVlO1xyXG4gICAgICAgIH1cclxuICAgICAgICBldmVudHNlbmQuc2V0VXNlckRhdGEoe1xyXG4gICAgICAgICAgICBlZmZlY3Q6YXVkaW9DaGlwLFxyXG4gICAgICAgICAgICB2b2x1bWU6dm9sdW1lLFxyXG4gICAgICAgICAgICBmdWxsVm9sdW1lOmZ1bGxWb2x1bWUsXHJcbiAgICAgICAgICAgIHRhcmdldDp0aGlzLm5vZGUsXHJcbiAgICAgICAgfSk7XHJcbiAgICAgICAgdGhpcy5ub2RlLmRpc3BhdGNoRXZlbnQoZXZlbnRzZW5kKTtcclxuICAgIH0sXHJcbiAgICAvLyBjYWxsZWQgZXZlcnkgZnJhbWUsIHVuY29tbWVudCB0aGlzIGZ1bmN0aW9uIHRvIGFjdGl2YXRlIHVwZGF0ZSBjYWxsYmFja1xyXG4gICAgLy91cGRhdGU6IGZ1bmN0aW9uIChkdCkge1xyXG4gICAgLy99LFxyXG59KTtcclxuXHJcbiIsImNjLkNsYXNzKHtcclxuICAgIGV4dGVuZHM6IGNjLkNvbXBvbmVudCxcclxuXHJcbiAgICBwcm9wZXJ0aWVzOiB7XHJcbiAgICAgICAgLy/prZTms5XliJvlu7rmiJDlip/nmoTpn7PkuZBcclxuICAgICAgICBsb2FkRWZmZWN0OmNjLkF1ZGlvQ2xpcCxcclxuICAgICAgICAvL+WRveS4reaXtueahOmfs+S5kFxyXG4gICAgICAgIGhpdEVmZmVjdDpjYy5BdWRpb0NsaXAsXHJcbiAgICAgICAgLy8gZm9vOiB7XHJcbiAgICAgICAgLy8gICAgZGVmYXVsdDogbnVsbCwgICAgICAvLyBUaGUgZGVmYXVsdCB2YWx1ZSB3aWxsIGJlIHVzZWQgb25seSB3aGVuIHRoZSBjb21wb25lbnQgYXR0YWNoaW5nXHJcbiAgICAgICAgLy8gICAgICAgICAgICAgICAgICAgICAgICAgICB0byBhIG5vZGUgZm9yIHRoZSBmaXJzdCB0aW1lXHJcbiAgICAgICAgLy8gICAgdXJsOiBjYy5UZXh0dXJlMkQsICAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyB0eXBlb2YgZGVmYXVsdFxyXG4gICAgICAgIC8vICAgIHNlcmlhbGl6YWJsZTogdHJ1ZSwgLy8gb3B0aW9uYWwsIGRlZmF1bHQgaXMgdHJ1ZVxyXG4gICAgICAgIC8vICAgIHZpc2libGU6IHRydWUsICAgICAgLy8gb3B0aW9uYWwsIGRlZmF1bHQgaXMgdHJ1ZVxyXG4gICAgICAgIC8vICAgIGRpc3BsYXlOYW1lOiAnRm9vJywgLy8gb3B0aW9uYWxcclxuICAgICAgICAvLyAgICByZWFkb25seTogZmFsc2UsICAgIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIGZhbHNlXHJcbiAgICAgICAgLy8gfSxcclxuICAgICAgICAvLyAuLi5cclxuICAgIH0sXHJcblxyXG4gICAgLy8gdXNlIHRoaXMgZm9yIGluaXRpYWxpemF0aW9uXHJcbiAgICBvbkxvYWQ6IGZ1bmN0aW9uICgpIHtcclxuICAgICAgICB0aGlzLnNwZWVkID0gY2MudjIoMCwwKTtcclxuICAgICAgICB0aGlzLnRlYW0gPSAwO1xyXG4gICAgICAgIHRoaXMuYXJlYSA9IDA7XHJcbiAgICAgICAgdGhpcy5jb2xsaXNpb25UaW1lID0gMDtcclxuXHJcbiAgICAgICAgLy/kvKDpgJLliJvlu7rms5XmnK/miJDlip/ml7bpn7PmlYjnmoTkuovku7ZcclxuICAgICAgICBpZih0aGlzLmxvYWRFZmZlY3QgIT09IG51bGwpXHJcbiAgICAgICAgdGhpcy5zZW5kRXZlbnQodGhpcy5sb2FkRWZmZWN0KTtcclxuXHJcbiAgICAgICAgdmFyIGFuaW1hdGlvbiA9IHRoaXMubm9kZS5nZXRDb21wb25lbnQoY2MuQW5pbWF0aW9uKTtcclxuICAgICAgICB2YXIgYW5pbVN0YXRlID0gYW5pbWF0aW9uLnBsYXkoKTtcclxuICAgICAgICBhbmltU3RhdGUucmVwZWF0Q291bnQgPSBJbmZpbml0eTtcclxuXHJcbiAgICAgICAgLy9hbmltYXRpb24ub24oJ2ZpbmlzaGVkJywgIHRoaXMub25GaW5pc2hlZCwgICAgdGhpcyk7XHJcblxyXG4gICAgICAgIC8v77+977+977+977+977+977+917JcclxuICAgICAgICBjYy5kaXJlY3Rvci5nZXRDb2xsaXNpb25NYW5hZ2VyKCkuZW5hYmxlZCA9IHRydWU7XHJcbiAgICAgICAgLy9jYy5kaXJlY3Rvci5nZXRDb2xsaXNpb25NYW5hZ2VyKCkuZW5hYmxlZERlYnVnRHJhdyA9IHRydWU7XHJcblxyXG4gICAgfSxcclxuXHJcbiAgICBvbkNvbGxpc2lvbkVudGVyOiBmdW5jdGlvbiAob3RoZXIsIHNlbGYpIHtcclxuICAgICAgICAvL++/ve+/ve+/ve+/ve+/vdO077+977+90Lbvv71cclxuICAgICAgICBpZiAob3RoZXIubm9kZS5ncm91cCA9PT0gXCJHcm91bmRcIikge1xyXG4gICAgICAgICAgICB0aGlzLmNvbGxpc2lvblRpbWUgKys7XHJcbiAgICAgICAgICAgIGlmKHRoaXMuY29sbGlzaW9uVGltZSA+PSAxNClcclxuICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgdmFyIGV2ZW50c2VuZCA9IG5ldyBjYy5FdmVudC5FdmVudEN1c3RvbSgnbWFnaWNDcmVhdGUnLHRydWUpO1xyXG4gICAgICAgICAgICAgICAgZXZlbnRzZW5kLnNldFVzZXJEYXRhKHtcclxuICAgICAgICAgICAgICAgICAgICBwb3NpdGlvbjp0aGlzLm5vZGUueCxcclxuICAgICAgICAgICAgICAgICAgICB5Om51bGwsXHJcbiAgICAgICAgICAgICAgICAgICAgYXJlYTp0aGlzLmFyZWEsXHJcbiAgICAgICAgICAgICAgICAgICAgdGVhbTp0aGlzLnRlYW0sXHJcbiAgICAgICAgICAgICAgICAgICAgaWQ6MCxcclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5ub2RlLmRpc3BhdGNoRXZlbnQoZXZlbnRzZW5kKTtcclxuICAgICAgICAgICAgICAgIHRoaXMubm9kZS5yZW1vdmVGcm9tUGFyZW50KCk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgdGhpcy5zcGVlZC55ID0gLSB0aGlzLnNwZWVkLnk7XHJcbiAgICAgICAgICAgIC8vdGhpcy5ub2RlLnJlbW92ZUZyb21QYXJlbnQoKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgaWYgKG90aGVyLm5vZGUuZ3JvdXAgPT09IFwiU2t5XCIpIHtcclxuICAgICAgICAgICAgdGhpcy5jb2xsaXNpb25UaW1lICsrO1xyXG4gICAgICAgICAgICB0aGlzLnNwZWVkLnkgPSAtIHRoaXMuc3BlZWQueTtcclxuICAgICAgICB9XHJcbiAgICAgICAgaWYgKG90aGVyLm5vZGUuZ3JvdXAgPT09IFwiTEJvdW5kXCIpIHtcclxuICAgICAgICAgICAgdGhpcy5zcGVlZC54ID0gLSB0aGlzLnNwZWVkLng7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlmIChvdGhlci5ub2RlLmdyb3VwID09PSBcIlJCb3VuZFwiKSB7XHJcbiAgICAgICAgICAgIHRoaXMuc3BlZWQueCA9IC0gdGhpcy5zcGVlZC54O1xyXG4gICAgICAgIH1cclxuICAgICAgICAvL++/ve+/ve+/ve+/ve+/vdO077+977+90Lbvv71cclxuICAgICAgICBpZiAob3RoZXIubm9kZS5ncm91cCA9PT0gXCJDcmVhdHVyZVwiKSB7XHJcbiAgICAgICAgICAgIHZhciBzY3JpcHQgPSBvdGhlci5ub2RlLmdldENvbXBvbmVudCgnQ3JlYXR1cmUnKTtcclxuICAgICAgICAgICAgaWYoc2NyaXB0LnRlYW0gIT09IHRoaXMudGVhbSl7XHJcbiAgICAgICAgICAgICAgICAvL+S8oOmAkuaSreaUvumfs+aViOeahOS6i+S7tlxyXG4gICAgICAgICAgICAgICAgaWYodGhpcy5oaXRFZmZlY3QgIT09IG51bGwpXHJcbiAgICAgICAgICAgICAgICB0aGlzLnNlbmRFdmVudCh0aGlzLmhpdEVmZmVjdCk7XHJcbiAgICAgICAgICAgICAgICAvL3NjcmlwdC5jaGFuZ2VIZWFsdGgoLTEwKTtcclxuXHJcbiAgICAgICAgICAgICAgICB2YXIgZXZlbnRzZW5kID0gbmV3IGNjLkV2ZW50LkV2ZW50Q3VzdG9tKCdtYWdpY0NyZWF0ZScsdHJ1ZSk7XHJcbiAgICAgICAgICAgICAgICBldmVudHNlbmQuc2V0VXNlckRhdGEoe1xyXG4gICAgICAgICAgICAgICAgICAgIHBvc2l0aW9uOnRoaXMubm9kZS54LFxyXG4gICAgICAgICAgICAgICAgICAgIHk6bnVsbCxcclxuICAgICAgICAgICAgICAgICAgICBhcmVhOnRoaXMuYXJlYSxcclxuICAgICAgICAgICAgICAgICAgICB0ZWFtOnRoaXMudGVhbSxcclxuICAgICAgICAgICAgICAgICAgICBpZDowLFxyXG4gICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICB0aGlzLm5vZGUuZGlzcGF0Y2hFdmVudChldmVudHNlbmQpO1xyXG5cclxuICAgICAgICAgICAgICAgIHRoaXMubm9kZS5yZW1vdmVGcm9tUGFyZW50KCk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgICAgaWYgKG90aGVyLm5vZGUuZ3JvdXAgPT09IFwiQmFzZVwiKSB7XHJcbiAgICAgICAgICAgIHZhciBzY3JpcHQyID0gb3RoZXIubm9kZS5nZXRDb21wb25lbnQoJ0Jhc2UnKTtcclxuICAgICAgICAgICAgaWYoc2NyaXB0Mi50ZWFtICE9PSB0aGlzLnRlYW0pe1xyXG4gICAgICAgICAgICAgICAgLy/kvKDpgJLmkq3mlL7pn7PmlYjnmoTkuovku7ZcclxuICAgICAgICAgICAgICAgIGlmKHRoaXMuaGl0RWZmZWN0ICE9PSBudWxsKVxyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuc2VuZEV2ZW50KHRoaXMuaGl0RWZmZWN0KTtcclxuICAgICAgICAgICAgICAgIC8vc2NyaXB0LmNoYW5nZUhlYWx0aCgtMTApO1xyXG5cclxuICAgICAgICAgICAgICAgIHZhciBldmVudHNlbmQyID0gbmV3IGNjLkV2ZW50LkV2ZW50Q3VzdG9tKCdtYWdpY0NyZWF0ZScsdHJ1ZSk7XHJcbiAgICAgICAgICAgICAgICBldmVudHNlbmQyLnNldFVzZXJEYXRhKHtcclxuICAgICAgICAgICAgICAgICAgICBwb3NpdGlvbjp0aGlzLm5vZGUueCxcclxuICAgICAgICAgICAgICAgICAgICB5Om51bGwsXHJcbiAgICAgICAgICAgICAgICAgICAgYXJlYTp0aGlzLmFyZWEsXHJcbiAgICAgICAgICAgICAgICAgICAgdGVhbTp0aGlzLnRlYW0sXHJcbiAgICAgICAgICAgICAgICAgICAgaWQ6MCxcclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5ub2RlLmRpc3BhdGNoRXZlbnQoZXZlbnRzZW5kMik7XHJcblxyXG4gICAgICAgICAgICAgICAgdGhpcy5ub2RlLnJlbW92ZUZyb21QYXJlbnQoKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICBpZiAob3RoZXIubm9kZS5ncm91cCA9PT0gXCJIZXJvXCIpIHtcclxuICAgICAgICAgICAgdmFyIHNjcmlwdDMgPSBvdGhlci5ub2RlLmdldENvbXBvbmVudCgnUGxheWVyJyk7XHJcbiAgICAgICAgICAgIGlmKHNjcmlwdDMudGVhbSAhPT0gdGhpcy50ZWFtKXtcclxuICAgICAgICAgICAgICAgIC8v5Lyg6YCS5pKt5pS+6Z+z5pWI55qE5LqL5Lu2XHJcbiAgICAgICAgICAgICAgICBpZih0aGlzLmhpdEVmZmVjdCAhPT0gbnVsbClcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLnNlbmRFdmVudCh0aGlzLmhpdEVmZmVjdCk7XHJcbiAgICAgICAgICAgICAgICAvL3NjcmlwdC5jaGFuZ2VIZWFsdGgoLTEwKTtcclxuXHJcbiAgICAgICAgICAgICAgICB2YXIgZXZlbnRzZW5kMyA9IG5ldyBjYy5FdmVudC5FdmVudEN1c3RvbSgnbWFnaWNDcmVhdGUnLHRydWUpO1xyXG4gICAgICAgICAgICAgICAgZXZlbnRzZW5kMy5zZXRVc2VyRGF0YSh7XHJcbiAgICAgICAgICAgICAgICAgICAgcG9zaXRpb246dGhpcy5ub2RlLngsXHJcbiAgICAgICAgICAgICAgICAgICAgeTpudWxsLFxyXG4gICAgICAgICAgICAgICAgICAgIGFyZWE6dGhpcy5hcmVhLFxyXG4gICAgICAgICAgICAgICAgICAgIHRlYW06dGhpcy50ZWFtLFxyXG4gICAgICAgICAgICAgICAgICAgIGlkOjAsXHJcbiAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgIHRoaXMubm9kZS5kaXNwYXRjaEV2ZW50KGV2ZW50c2VuZDMpO1xyXG5cclxuICAgICAgICAgICAgICAgIHRoaXMubm9kZS5yZW1vdmVGcm9tUGFyZW50KCk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9LFxyXG5cclxuICAgIG9uQ29sbGlzaW9uRXhpdDogZnVuY3Rpb24gKG90aGVyLCBzZWxmKSB7XHJcbiAgICAgICAgaWYgKG90aGVyLm5vZGUuZ3JvdXAgPT09IFwiR3JvdW5kXCIpIHtcclxuXHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBpZiAob3RoZXIubm9kZS5ncm91cCA9PT0gXCJDcmVhdHVyZVwiKSB7XHJcblxyXG4gICAgICAgIH1cclxuICAgIH0sXHJcblxyXG4gICAgY2hhbmdlVGVhbTogZnVuY3Rpb24odGVhbSl7XHJcbiAgICAgICAgLy90aGlzLm5vZGUucmVtb3ZlRnJvbVBhcmVudCgpO1xyXG4gICAgfSxcclxuICAgIGluaXRNYWdpYzpmdW5jdGlvbihkZXRhaWwpe1xyXG4gICAgICAgIHRoaXMudGVhbSA9IGRldGFpbC50ZWFtO1xyXG4gICAgICAgIHRoaXMuYXJlYSA9IGRldGFpbC5hcmVhO1xyXG4gICAgICAgIHRoaXMuc3BlZWQueCA9IE1hdGguc2luKChkZXRhaWwuYW5nZWwgKyA5MCkqTWF0aC5QSS8xODApKmRldGFpbC5zcGVlZDtcclxuICAgICAgICB0aGlzLnNwZWVkLnkgPSBNYXRoLmNvcygoZGV0YWlsLmFuZ2VsICsgOTApKk1hdGguUEkvMTgwKSpkZXRhaWwuc3BlZWQ7XHJcbiAgICB9LFxyXG4gICAgIC8vY2FsbGVkIGV2ZXJ5IGZyYW1lLCB1bmNvbW1lbnQgdGhpcyBmdW5jdGlvbiB0byBhY3RpdmF0ZSB1cGRhdGUgY2FsbGJhY2tcclxuICAgIHVwZGF0ZTogZnVuY3Rpb24gKGR0KSB7XHJcbiAgICAgICAgLy9kZWxheVRpbWUoMSk7XHJcbiAgICAgICAgdGhpcy5ub2RlLnggKz0gdGhpcy5zcGVlZC54ICogZHQ7XHJcbiAgICAgICAgdGhpcy5ub2RlLnkgKz0gdGhpcy5zcGVlZC55ICogZHQ7XHJcbiAgICB9LFxyXG4gICAgLyoqXHJcbiAgICAgKiBA5Li76KaB5Yqf6IO9IOWQkeS4iue6p+iKgueCueS8oOmAkua2iOaBr++8jOS9v+S5i+aSreaUvumfs+aViFxyXG4gICAgICogQGF1dGhvciBDMTRcclxuICAgICAqIEBEYXRlIDIwMTcvMTIvMTJcclxuICAgICAqIEBwYXJhbWV0ZXJzIGF1ZGlvQ2hpcCB2b2x1bWVcclxuICAgICAqIEByZXR1cm5zIG51bGxcclxuICAgICAqL1xyXG4gICAgc2VuZEV2ZW50OmZ1bmN0aW9uKGF1ZGlvQ2hpcCxmdWxsVm9sdW1lLHZvbHVtZSkge1xyXG4gICAgICAgIHZhciBldmVudHNlbmQgPSBuZXcgY2MuRXZlbnQuRXZlbnRDdXN0b20oXCJwbGF5RWZmZWN0XCIsIHRydWUpO1xyXG4gICAgICAgIGlmKHZvbHVtZSA9PT0gdW5kZWZpbmVkIHx8IHZvbHVtZSA9PT0gbnVsbCl7XHJcbiAgICAgICAgICAgIHZvbHVtZSA9IDE7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlmKGZ1bGxWb2x1bWUgPT09IHVuZGVmaW5lZCB8fCBmdWxsVm9sdW1lID09PSBudWxsIHx8IGZ1bGxWb2x1bWUgPT09IGZhbHNlKXtcclxuICAgICAgICAgICAgZnVsbFZvbHVtZSA9IGZhbHNlO1xyXG4gICAgICAgIH1lbHNle1xyXG4gICAgICAgICAgICBmdWxsVm9sdW1lID0gdHJ1ZTtcclxuICAgICAgICB9XHJcbiAgICAgICAgZXZlbnRzZW5kLnNldFVzZXJEYXRhKHtcclxuICAgICAgICAgICAgZWZmZWN0OmF1ZGlvQ2hpcCxcclxuICAgICAgICAgICAgdm9sdW1lOnZvbHVtZSxcclxuICAgICAgICAgICAgZnVsbFZvbHVtZTpmdWxsVm9sdW1lLFxyXG4gICAgICAgICAgICB0YXJnZXQ6dGhpcy5ub2RlLFxyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIHRoaXMubm9kZS5kaXNwYXRjaEV2ZW50KGV2ZW50c2VuZCk7XHJcbiAgICB9LFxyXG59KTtcclxuXHJcbiIsInZhciBnbG9iYWxDb25zdGFudCA9IHJlcXVpcmUoXCJDb25zdGFudFwiKTtcclxuXHJcbmNjLkNsYXNzKHtcclxuICAgIGV4dGVuZHM6IGNjLkNvbXBvbmVudCxcclxuXHJcbiAgICBwcm9wZXJ0aWVzOiB7XHJcblxyXG4gICAgICAgIGNhcmRJRDogMCxcclxuXHJcbiAgICAgICAgY2FyZFR5cGU6IDAsXHJcbiAgICAgICAgLy8g6L+Z5Liq5piv5p6a5Li+77yM55u45b2T55qE5aW955So5ZWK77yM5Lul5ZCO6YO955So6L+Z5Liq5aW95LqGXHJcbiAgICAgICAgbWFnaWNUeXBlOiB7XHJcbiAgICAgICAgICAgIHR5cGU6IGNjLkVudW0oe1xyXG4gICAgICAgICAgICAgICAgTm9UYXJnZXQ6IDAsXHJcbiAgICAgICAgICAgICAgICBBcmVhVGFyZ2V0OiAxLFxyXG4gICAgICAgICAgICAgICAgRGlyZWN0aW9uVGFyZ2V0OiAyLFxyXG4gICAgICAgICAgICB9KSxcclxuICAgICAgICAgICAgZGVmYXVsdDogMFxyXG4gICAgICAgIH0sXHJcbiAgICAgICAgLy/kuLror6XlsYLmt7vliqDojIPlm7Tms5XmnK/vvIzmipXmjrfms5XmnK/nmoTlj4LmlbBcclxuICAgICAgICBhcmVhOjAsXHJcbiAgICAgICAgLy/mipXmjrfpgJ/luqZcclxuICAgICAgICBzcGVlZDowLFxyXG5cclxuICAgICAgICBoZXJvOmNjLk5vZGUsXHJcbiAgICAgICAgYmFja1JvbGw6Y2MuTm9kZSxcclxuXHJcbiAgICAgICAgcmFuZ2VOb2RlOiBjYy5QcmVmYWIsXHJcbiAgICAgICAgcmFuZ2VBbmltYXRpb25Ob2RlOiBjYy5QcmVmYWIsXHJcbiAgICAgICAgYXJyb3dOb2RlOiBjYy5QcmVmYWIsXHJcblxyXG5cclxuICAgICAgICBwcmVwYXJlQ2FyZEVmZmVjdDpjYy5BdWRpb0NsaXAsXHJcbiAgICAgICAgdXNlQ2FyZEVmZmVjdDpjYy5BdWRpb0NsaXAsXHJcblxyXG4gICAgfSxcclxuXHJcbiAgICAvLyB1c2UgdGhpcyBmb3IgaW5pdGlhbGl6YXRpb25cclxuICAgIG9uTG9hZDogZnVuY3Rpb24gKCkge1xyXG4gICAgICAgIHZhciBzZWxmID0gdGhpcztcclxuICAgICAgICBzZWxmLm1hZ2ljVHlwZUVudW0gPSBjYy5FbnVtKHtcclxuICAgICAgICAgICAgTm9UYXJnZXQ6IDAsXHJcbiAgICAgICAgICAgIEFyZWFUYXJnZXQ6IDEsXHJcbiAgICAgICAgICAgIERpcmVjdGlvblRhcmdldDogMixcclxuICAgICAgICB9KTtcclxuICAgICAgICAvL3RoaXMuYXJyb3cgPSBjYy5pbnN0YW50aWF0ZSh0aGlzLmFycm93Tm9kZSk7XHJcbiAgICAgICAgdGhpcy5zdGFydExpc3RlbigpO1xyXG4gICAgICAgIC8v5piv5ZCm56e75Yqo5Yiw5LiK6Z2i5YeG5aSH5L2/55So5LqG77yM5Yid5aeL5YC877yM5ZCmXHJcbiAgICAgICAgdGhpcy5wcmVVc2UgPSBmYWxzZTtcclxuICAgICAgICB0aGlzLmJhY2tSb2xsU2NyaXB0ID0gdGhpcy5iYWNrUm9sbC5nZXRDb21wb25lbnQoXCJCYWNrUm9sbFwiKTtcclxuICAgICAgICBzZWxmLmNhcmRTY3JpcHQgPSBzZWxmLm5vZGUuZ2V0Q29tcG9uZW50KCdDYXJkJyk7XHJcbiAgICAgICAgdGhpcy5oZXJvU2NpcnB0ID0gdGhpcy5jYXJkU2NyaXB0Lmhlcm8uZ2V0Q29tcG9uZW50KCdQbGF5ZXInKTtcclxuXHJcbiAgICAgICAgLy/ov5nkuKrnmoTmnIDmt7HlsYLku6PnoIFKU+eahOiOt+WPllxyXG4gICAgICAgICB0aGlzLm1TY3JpcHQgPSBudWxsO1xyXG4gICAgICAgICBpZihzZWxmLmNhcmRUeXBlID09PSAwKXtcclxuICAgICAgICAgICAgIHRoaXMubVNjcmlwdCA9IHNlbGYubm9kZS5nZXRDb21wb25lbnQoJ00nICsgc2VsZi5jYXJkSUQpO1xyXG4gICAgICAgICB9ZWxzZXtcclxuICAgICAgICAgICAgIHRoaXMubVNjcmlwdCA9IHNlbGYubm9kZS5nZXRDb21wb25lbnQoJ0MnICsgc2VsZi5jYXJkSUQpO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgdGhpcy5jdXJyZW50RWZmZWN0ID0gZmFsc2U7XHJcbiAgICAgICAgLy/kuLror6XlsYLmt7vliqDojIPlm7Tms5XmnK/vvIzmipXmjrfms5XmnK/nmoTlj4LmlbBcclxuICAgICAgICB0aGlzLm1BbmdsZSA9IDA7XHJcbiAgICAgICAgLy92YXIgc3RhdGUgPSB0aGlzLnNjcmlwdC5nZXRVc2VTdGF0ZSgpO1xyXG4gICAgICAgICAvL3JldHVybiBzdGF0ZTtcclxuXHJcbiAgICAgICAgLy8g6L+Z5Liq5re75Yqg55uR5ZCs5Li65rWL6K+V55SoXHJcbiAgICAgICAgLy8gc2VsZi5zdGFydExpc3RlbigpO1xyXG4gICAgfSxcclxuXHJcbiAgICAvKipcclxuICAgICAqXHJcbiAgICAgKiBAcGFyYW0gZXZlbnRcclxuICAgICAqIEBjb25zdHJ1Y3RvclxyXG4gICAgICovXHJcbiAgICBOb1RhcmdldE1hZ2ljU3RhcnRMaXN0ZW46IGZ1bmN0aW9uIChldmVudCkge1xyXG4gICAgICAgIC8vIHRoaXMubm9kZS54ID0gZXZlbnQuZ2V0TG9jYXRpb25YKCk7XHJcbiAgICAgICAgLy8gdGhpcy5ub2RlLnkgPSBldmVudC5nZXRMb2NhdGlvblkoKTtcclxuICAgICAgICBpZiAoZXZlbnQuZ2V0QnV0dG9uKCkgPT09IGNjLkV2ZW50LkV2ZW50TW91c2UuQlVUVE9OX0xFRlQpXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgICAvLyBjb25zb2xlLmxvZyhcIk5vVGFyZ2V0TWFnaWNTdGFydExpc3RlblwiICsgZXZlbnQuZ2V0TG9jYXRpb25YKCkudG9GaXhlZCgwKSk7XHJcbiAgICAgICAgfVxyXG4gICAgfSxcclxuICAgIC8qKlxyXG4gICAgICpcclxuICAgICAqIEBwYXJhbSBldmVudFxyXG4gICAgICogQGNvbnN0cnVjdG9yXHJcbiAgICAgKi9cclxuICAgIEFyZWFUYXJnZXRNYWdpY1N0YXJ0TGlzdGVuOiBmdW5jdGlvbiAoZXZlbnQpIHtcclxuICAgICAgICAvL+WQkeS4u+aOp+WItuiEmuacrOS8oOmAkuS/oeaBr++8jOaSreaUvuW8gOWni+eahOmfs+aViFxyXG4gICAgfSxcclxuICAgIC8qKlxyXG4gICAgICpcclxuICAgICAqIEBwYXJhbSBldmVudFxyXG4gICAgICogQGNvbnN0cnVjdG9yXHJcbiAgICAgKi9cclxuICAgIERpcmVjdGlvblRhcmdldE1hZ2ljU3RhcnRMaXN0ZW46IGZ1bmN0aW9uIChldmVudCkge1xyXG4gICAgICAgIC8vIHRoaXMubm9kZS54ID0gZXZlbnQuZ2V0TG9jYXRpb25YKCk7XHJcbiAgICAgICAgLy8gdGhpcy5ub2RlLnkgPSBldmVudC5nZXRMb2NhdGlvblkoKTtcclxuICAgICAgICAvLyBjb25zb2xlLmxvZyhcIkRpcmVjdGlvblRhcmdldE1hZ2ljU3RhcnRMaXN0ZW5cIik7XHJcbiAgICB9LFxyXG4gICAgLyoqXHJcbiAgICAgKlxyXG4gICAgICogQHBhcmFtIGV2ZW50XHJcbiAgICAgKiBAY29uc3RydWN0b3JcclxuICAgICAqL1xyXG4gICAgTm9UYXJnZXRNYWdpY01vdmVMaXN0ZW46IGZ1bmN0aW9uIChldmVudCkge1xyXG4gICAgICAgIC8vIGNvbnNvbGUubG9nKFwiTm9UYXJnZXRNYWdpY1N0YXJ0TGlzdGVuIFwiICsgZXZlbnQuZ2V0TG9jYXRpb25YKCkudG9GaXhlZCgwKSArIFwiLFwiICsgZXZlbnQuZ2V0TG9jYXRpb25ZKCkudG9GaXhlZCgwKSk7XHJcbiAgICAgICAgaWYodGhpcy5ub2RlLnkgPiBnbG9iYWxDb25zdGFudC5jYXJkVXNlTGluZSAmJiB0aGlzLnByZVVzZSA9PT0gZmFsc2Upe1xyXG4gICAgICAgICAgICB0aGlzLm5vZGUub3BhY2l0eSA9IDIwMDtcclxuICAgICAgICAgICAgdGhpcy5wcmVVc2UgPSB0cnVlO1xyXG4gICAgICAgICAgICAvL+aSreaUvuazleacr+WHhuWkh+eUqOeahOmfs+aViFxyXG4gICAgICAgICAgICB0aGlzLmN1cnJlbnRFZmZlY3QgPSBjYy5hdWRpb0VuZ2luZS5wbGF5RWZmZWN0KHRoaXMucHJlcGFyZUNhcmRFZmZlY3QsIHRydWUsIDEpO1xyXG4gICAgICAgIH1cclxuICAgICAgICBpZih0aGlzLm5vZGUueSA8PSBnbG9iYWxDb25zdGFudC5jYXJkVXNlTGluZSAmJiB0aGlzLnByZVVzZSA9PT0gdHJ1ZSl7XHJcbiAgICAgICAgICAgIHRoaXMubm9kZS5vcGFjaXR5ID0gMTAwMDtcclxuICAgICAgICAgICAgdGhpcy5wcmVVc2UgPSBmYWxzZTtcclxuICAgICAgICAgICAgLy/lgZzmraLlh4blpIfnlKjnmoTpn7PkuZBcclxuICAgICAgICAgICAgY2MuYXVkaW9FbmdpbmUuc3RvcEVmZmVjdCh0aGlzLmN1cnJlbnRFZmZlY3QpO1xyXG4gICAgICAgIH1cclxuICAgIH0sXHJcbiAgICAvKipcclxuICAgICAqXHJcbiAgICAgKiBAcGFyYW0gZXZlbnRcclxuICAgICAqIEBjb25zdHJ1Y3RvclxyXG4gICAgICovXHJcbiAgICBBcmVhVGFyZ2V0TWFnaWNNb3ZlTGlzdGVuOiBmdW5jdGlvbiAoZXZlbnQpIHtcclxuICAgICAgICAgLy9jb25zb2xlLmxvZyhcIkFyZWFUYXJnZXRNYWdpY01vdmVMaXN0ZW5cIik7XHJcbiAgICAgICAgaWYodGhpcy5ub2RlLnkgPiBnbG9iYWxDb25zdGFudC5jYXJkVXNlTGluZSl7XHJcbiAgICAgICAgICAgIGlmKHRoaXMucHJlVXNlID09PSBmYWxzZSl7XHJcbiAgICAgICAgICAgICAgICB0aGlzLm5vZGUub3BhY2l0eSA9IDA7XHJcbiAgICAgICAgICAgICAgICB0aGlzLnByZVVzZSA9IHRydWU7XHJcbiAgICAgICAgICAgICAgICB0aGlzLnJhbmdlTE5vZGUuYWN0aXZlID0gdHJ1ZTtcclxuICAgICAgICAgICAgICAgIHRoaXMucmFuZ2VSTm9kZS5hY3RpdmUgPSB0cnVlO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5yYW5nZUFuaW1lTm9kZS5hY3RpdmUgPSB0cnVlO1xyXG4gICAgICAgICAgICAgICAgLy/mkq3mlL7ms5XmnK/lh4blpIfnlKjnmoTpn7PmlYhcclxuICAgICAgICAgICAgICAgIHRoaXMuY3VycmVudEVmZmVjdCA9IGNjLmF1ZGlvRW5naW5lLnBsYXlFZmZlY3QodGhpcy5wcmVwYXJlQ2FyZEVmZmVjdCwgdHJ1ZSwgMSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgdGhpcy5yYW5nZUFuaW1lTm9kZS54ID0gdGhpcy5ub2RlLng7XHJcbiAgICAgICAgICAgIHRoaXMucmFuZ2VMTm9kZS54ID0gdGhpcy5ub2RlLnggLSB0aGlzLmFyZWEgKiBnbG9iYWxDb25zdGFudC51bml0TGVuZ3RoIC8gMjtcclxuICAgICAgICAgICAgdGhpcy5yYW5nZVJOb2RlLnggPSB0aGlzLm5vZGUueCArIHRoaXMuYXJlYSAqIGdsb2JhbENvbnN0YW50LnVuaXRMZW5ndGggLyAyO1xyXG4gICAgICAgIH1cclxuXHJcblxyXG4gICAgICAgIGlmKHRoaXMubm9kZS55IDw9IGdsb2JhbENvbnN0YW50LmNhcmRVc2VMaW5lICYmIHRoaXMucHJlVXNlID09PSB0cnVlKXtcclxuICAgICAgICAgICAgdGhpcy5ub2RlLm9wYWNpdHkgPSAxMDAwO1xyXG4gICAgICAgICAgICB0aGlzLnByZVVzZSA9IGZhbHNlO1xyXG4gICAgICAgICAgICB0aGlzLnJhbmdlTE5vZGUuYWN0aXZlID0gZmFsc2U7XHJcbiAgICAgICAgICAgIHRoaXMucmFuZ2VSTm9kZS5hY3RpdmUgPSBmYWxzZTtcclxuICAgICAgICAgICAgdGhpcy5yYW5nZUFuaW1lTm9kZS5hY3RpdmUgPSBmYWxzZTtcclxuICAgICAgICAgICAgLy/lgZzmraLlh4blpIfnlKjnmoTpn7PkuZBcclxuICAgICAgICAgICAgY2MuYXVkaW9FbmdpbmUuc3RvcEVmZmVjdCh0aGlzLmN1cnJlbnRFZmZlY3QpO1xyXG4gICAgICAgIH1cclxuICAgIH0sXHJcbiAgICAvKipcclxuICAgICAqXHJcbiAgICAgKiBAcGFyYW0gZXZlbnRcclxuICAgICAqIEBjb25zdHJ1Y3RvclxyXG4gICAgICovXHJcbiAgICBEaXJlY3Rpb25UYXJnZXRNYWdpY01vdmVMaXN0ZW46IGZ1bmN0aW9uIChldmVudCkge1xyXG5cclxuICAgICAgICAvLyBjb25zb2xlLmxvZyhcIkRpcmVjdGlvblRhcmdldE1hZ2ljTW92ZUxpc3RlblwiKTtcclxuICAgICAgICBpZih0aGlzLm5vZGUueSA+IGdsb2JhbENvbnN0YW50LmNhcmRVc2VMaW5lKXtcclxuICAgICAgICAgICAgaWYodGhpcy5wcmVVc2UgPT09IGZhbHNlKXtcclxuICAgICAgICAgICAgICAgIHRoaXMubm9kZS5vcGFjaXR5ID0gMDtcclxuICAgICAgICAgICAgICAgIHRoaXMucHJlVXNlID0gdHJ1ZTtcclxuICAgICAgICAgICAgICAgIHRoaXMuYXJyb3cuYWN0aXZlID0gdHJ1ZTtcclxuICAgICAgICAgICAgICAgIC8v5pKt5pS+5rOV5pyv5YeG5aSH55So55qE6Z+z5pWIXHJcbiAgICAgICAgICAgICAgICB0aGlzLmN1cnJlbnRFZmZlY3QgPSBjYy5hdWRpb0VuZ2luZS5wbGF5RWZmZWN0KHRoaXMucHJlcGFyZUNhcmRFZmZlY3QsIHRydWUsIDEpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIHZhciB0YXJnZXRQb3MgPSB0aGlzLmFycm93LmNvbnZlcnRUb1dvcmxkU3BhY2VBUihjYy5WZWMyLlpFUk8pO1xyXG4gICAgICAgICAgICBpZiAoZ2xvYmFsQ29uc3RhbnQuY2FtZXJhT2Zmc2V0ID09PSAwKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmFycm93LnJvdGF0aW9uID0gMzYwIC0gTWF0aC5hdGFuMihldmVudC5nZXRMb2NhdGlvblkoKSAtIHRhcmdldFBvcy55LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBldmVudC5nZXRMb2NhdGlvblgoKSAtIHRoaXMuaGVyby54KSAqIDE4MCAvIE1hdGguUEk7XHJcbiAgICAgICAgICAgIH1lbHNlIGlmKHRoaXMuaGVyby54ID4gY2MuZGlyZWN0b3IuZ2V0V2luU2l6ZSgpLndpZHRoICogKGdsb2JhbENvbnN0YW50LnNjZW5lV2lkdGggLSBnbG9iYWxDb25zdGFudC5zY2VuZUVkZ2UpKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmFycm93LnJvdGF0aW9uID0gMzYwIC0gTWF0aC5hdGFuMihldmVudC5nZXRMb2NhdGlvblkoKSAtIGNjLmRpcmVjdG9yLmdldFdpblNpemUoKS5oZWlnaHQgLyAyIC0gKHRoaXMuYXJyb3cueSArIHRoaXMuYXJyb3cucGFyZW50LnkpLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBldmVudC5nZXRMb2NhdGlvblgoKSAtIHRoaXMuaGVyby54ICsgY2MuZGlyZWN0b3IuZ2V0V2luU2l6ZSgpLndpZHRoICogKGdsb2JhbENvbnN0YW50LnNjZW5lV2lkdGggLSBnbG9iYWxDb25zdGFudC5zY2VuZUVkZ2UgKiAyKSkgKiAxODAgLyBNYXRoLlBJO1xyXG4gICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5hcnJvdy5yb3RhdGlvbiA9IDM2MCAtIE1hdGguYXRhbjIoZXZlbnQuZ2V0TG9jYXRpb25ZKCkgLSBjYy5kaXJlY3Rvci5nZXRXaW5TaXplKCkuaGVpZ2h0IC8gMiAtICh0aGlzLmFycm93LnkgKyB0aGlzLmFycm93LnBhcmVudC55KSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgZXZlbnQuZ2V0TG9jYXRpb25YKCkgLSBjYy5kaXJlY3Rvci5nZXRXaW5TaXplKCkud2lkdGggKiBnbG9iYWxDb25zdGFudC5zY2VuZUVkZ2UpICogMTgwIC8gTWF0aC5QSTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuXHJcblxyXG4gICAgICAgIGlmKHRoaXMubm9kZS55IDw9IGdsb2JhbENvbnN0YW50LmNhcmRVc2VMaW5lICYmIHRoaXMucHJlVXNlID09PSB0cnVlKXtcclxuICAgICAgICAgICAgdGhpcy5ub2RlLm9wYWNpdHkgPSAxMDAwO1xyXG4gICAgICAgICAgICB0aGlzLnByZVVzZSA9IGZhbHNlO1xyXG4gICAgICAgICAgICB0aGlzLmFycm93LmFjdGl2ZSA9IGZhbHNlO1xyXG4gICAgICAgICAgICAvL+WBnOatouWHhuWkh+eUqOeahOmfs+S5kFxyXG4gICAgICAgICAgICBjYy5hdWRpb0VuZ2luZS5zdG9wRWZmZWN0KHRoaXMuY3VycmVudEVmZmVjdCk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgIH0sXHJcbiAgICAvKipcclxuICAgICAqXHJcbiAgICAgKiBAcGFyYW0gZXZlbnRcclxuICAgICAqIEBjb25zdHJ1Y3RvclxyXG4gICAgICovXHJcbiAgICBOb1RhcmdldE1hZ2ljRW5kTGlzdGVuOiBmdW5jdGlvbiAoZXZlbnQpIHtcclxuICAgICAgICAvL+WBnOatouWHhuWkh+eUqOeahOmfs+S5kFxyXG4gICAgICAgIHRoaXMuc3RvcEVmZmVjdCgpO1xyXG4gICAgICAgIHRoaXMuc2VuZEV2ZW50KHRoaXMudXNlQ2FyZEVmZmVjdCx0cnVlKTtcclxuICAgIH0sXHJcbiAgICAvKipcclxuICAgICAqXHJcbiAgICAgKiBAcGFyYW0gZXZlbnRcclxuICAgICAqIEBjb25zdHJ1Y3RvclxyXG4gICAgICovXHJcbiAgICBBcmVhVGFyZ2V0TWFnaWNFbmRMaXN0ZW46IGZ1bmN0aW9uIChldmVudCkge1xyXG5cclxuICAgICAgICAvL+WBnOatouWHhuWkh+eUqOeahOmfs+S5kFxyXG4gICAgICAgIHRoaXMuc3RvcEVmZmVjdCgpO1xyXG5cclxuICAgICAgICBpZih0aGlzLnByZVVzZSA9PT0gdHJ1ZSkge1xyXG4gICAgICAgICAgICB0aGlzLnJhbmdlTE5vZGUuYWN0aXZlID0gZmFsc2U7XHJcbiAgICAgICAgICAgIHRoaXMucmFuZ2VSTm9kZS5hY3RpdmUgPSBmYWxzZTtcclxuICAgICAgICAgICAgdGhpcy5yYW5nZUFuaW1lTm9kZS5hY3RpdmUgPSBmYWxzZTtcclxuXHJcbiAgICAgICAgICAgIHRoaXMuaGVyb1NjaXJwdC5tYW5hIC09IHRoaXMuY2FyZFNjcmlwdC5tYW5hQ29uc3VtZTtcclxuXHJcbiAgICAgICAgICAgIHRoaXMuc2VuZEV2ZW50KHRoaXMudXNlQ2FyZEVmZmVjdCx0cnVlKTtcclxuICAgICAgICAgICAgdGhpcy5tU2NyaXB0LnVzZUNhcmQoZXZlbnQuZ2V0TG9jYXRpb25YKCkgKyBnbG9iYWxDb25zdGFudC5jYW1lcmFPZmZzZXQsIHRoaXMuYXJlYSAqIGdsb2JhbENvbnN0YW50LnVuaXRMZW5ndGgpO1xyXG4gICAgICAgIH1cclxuICAgIH0sXHJcbiAgICAvKipcclxuICAgICAqXHJcbiAgICAgKiBAcGFyYW0gZXZlbnRcclxuICAgICAqIEBjb25zdHJ1Y3RvclxyXG4gICAgICovXHJcbiAgICBEaXJlY3Rpb25UYXJnZXRNYWdpY0VuZExpc3RlbjogZnVuY3Rpb24gKGV2ZW50KSB7XHJcbiAgICAgICAgLy8gY29uc29sZS5sb2coXCJEaXJlY3Rpb25UYXJnZXRNYWdpY0VuZExpc3RlblwiKTtcclxuICAgICAgICAvL+WBnOatouWHhuWkh+eUqOeahOmfs+S5kFxyXG4gICAgICAgIHRoaXMuc3RvcEVmZmVjdCgpO1xyXG4gICAgICAgIGlmKHRoaXMucHJlVXNlID09PSB0cnVlKSB7XHJcbiAgICAgICAgICAgIHRoaXMuYXJyb3cuYWN0aXZlID0gZmFsc2U7XHJcbiAgICAgICAgICAgIHRoaXMuaGVyb1NjaXJwdC5tYW5hIC09IHRoaXMuY2FyZFNjcmlwdC5tYW5hQ29uc3VtZTtcclxuICAgICAgICAgICAgdGhpcy5zZW5kRXZlbnQodGhpcy51c2VDYXJkRWZmZWN0LHRydWUpO1xyXG4gICAgICAgICAgICBpZiAoZ2xvYmFsQ29uc3RhbnQuY2FtZXJhT2Zmc2V0ID09PSAwKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLm1BbmdsZSA9IDM2MCAtIE1hdGguYXRhbjIoZXZlbnQuZ2V0TG9jYXRpb25ZKCkgLSBjYy5kaXJlY3Rvci5nZXRXaW5TaXplKCkuaGVpZ2h0IC8gMiAtICh0aGlzLmFycm93LnkgKyB0aGlzLmFycm93LnBhcmVudC55KSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgZXZlbnQuZ2V0TG9jYXRpb25YKCkgLSB0aGlzLmhlcm8ueCkgKiAxODAgLyBNYXRoLlBJO1xyXG4gICAgICAgICAgICB9ZWxzZSBpZih0aGlzLmhlcm8ueCA+IGNjLmRpcmVjdG9yLmdldFdpblNpemUoKS53aWR0aCAqIChnbG9iYWxDb25zdGFudC5zY2VuZVdpZHRoIC0gZ2xvYmFsQ29uc3RhbnQuc2NlbmVFZGdlKSkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5tQW5nbGUgPSAzNjAgLSBNYXRoLmF0YW4yKGV2ZW50LmdldExvY2F0aW9uWSgpIC0gY2MuZGlyZWN0b3IuZ2V0V2luU2l6ZSgpLmhlaWdodCAvIDIgLSAodGhpcy5hcnJvdy55ICsgdGhpcy5hcnJvdy5wYXJlbnQueSksXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGV2ZW50LmdldExvY2F0aW9uWCgpIC0gdGhpcy5oZXJvLnggKyBjYy5kaXJlY3Rvci5nZXRXaW5TaXplKCkud2lkdGggKiAoZ2xvYmFsQ29uc3RhbnQuc2NlbmVXaWR0aCAtIGdsb2JhbENvbnN0YW50LnNjZW5lRWRnZSAqIDIpKSAqIDE4MCAvIE1hdGguUEk7XHJcbiAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLm1BbmdsZSA9IDM2MCAtIE1hdGguYXRhbjIoZXZlbnQuZ2V0TG9jYXRpb25ZKCkgLSBjYy5kaXJlY3Rvci5nZXRXaW5TaXplKCkuaGVpZ2h0IC8gMiAtICh0aGlzLmFycm93LnkgKyB0aGlzLmFycm93LnBhcmVudC55KSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgZXZlbnQuZ2V0TG9jYXRpb25YKCkgLSBjYy5kaXJlY3Rvci5nZXRXaW5TaXplKCkud2lkdGggKiBnbG9iYWxDb25zdGFudC5zY2VuZUVkZ2UpICogMTgwIC8gTWF0aC5QSTtcclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgdGhpcy5tU2NyaXB0LnVzZUNhcmQodGhpcy5jYXJkSUQsIHRoaXMubUFuZ2xlLCB0aGlzLnNwZWVkLCB0aGlzLmFyZWEgKiBnbG9iYWxDb25zdGFudC51bml0TGVuZ3RoLCB0aGlzLmhlcm8ueCwgdGhpcy5hcnJvdy55ICsgdGhpcy5oZXJvLnkpO1xyXG4gICAgICAgIH1cclxuICAgIH0sXHJcblxyXG5cclxuICAgIC8qKlxyXG4gICAgICogQOS4u+imgeWKn+iDvSDlkJHkuIrnuqfoioLngrnkvKDpgJLmtojmga/vvIzkvb/kuYvmkq3mlL7pn7PmlYhcclxuICAgICAqIEBhdXRob3IgQzE0XHJcbiAgICAgKiBARGF0ZSAyMDE3LzEyLzEyXHJcbiAgICAgKiBAcGFyYW1ldGVycyAgYXVkaW9DaGlwIHZvbHVtZSBmdWxsVm9sdW1lXHJcbiAgICAgKiBAcmV0dXJucyBudWxsXHJcbiAgICAgKi9cclxuICAgIHNlbmRFdmVudDpmdW5jdGlvbihhdWRpb0NoaXAsZnVsbFZvbHVtZSx2b2x1bWUpIHtcclxuICAgICAgICB2YXIgZXZlbnRzZW5kID0gbmV3IGNjLkV2ZW50LkV2ZW50Q3VzdG9tKFwicGxheUVmZmVjdFwiLCB0cnVlKTtcclxuICAgICAgICBpZih2b2x1bWUgPT09IHVuZGVmaW5lZCB8fCB2b2x1bWUgPT09IG51bGwpe1xyXG4gICAgICAgICAgICB2b2x1bWUgPSAxO1xyXG4gICAgICAgIH1cclxuICAgICAgICBpZihmdWxsVm9sdW1lID09PSB1bmRlZmluZWQgfHwgZnVsbFZvbHVtZSA9PT0gbnVsbCB8fCBmdWxsVm9sdW1lID09PSBmYWxzZSl7XHJcbiAgICAgICAgICAgIGZ1bGxWb2x1bWUgPSBmYWxzZTtcclxuICAgICAgICB9ZWxzZXtcclxuICAgICAgICAgICAgZnVsbFZvbHVtZSA9IHRydWU7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGV2ZW50c2VuZC5zZXRVc2VyRGF0YSh7XHJcbiAgICAgICAgICAgIGVmZmVjdDphdWRpb0NoaXAsXHJcbiAgICAgICAgICAgIHZvbHVtZTp2b2x1bWUsXHJcbiAgICAgICAgICAgIGZ1bGxWb2x1bWU6ZnVsbFZvbHVtZSxcclxuICAgICAgICAgICAgdGFyZ2V0OnRoaXMubm9kZSxcclxuICAgICAgICB9KTtcclxuICAgICAgICB0aGlzLm5vZGUuZGlzcGF0Y2hFdmVudChldmVudHNlbmQpO1xyXG4gICAgfSxcclxuICAgIC8qKlxyXG4gICAgICogQOS4u+imgeWKn+iDvSDlgZzmraLlvZPliY3mkq3mlL7nmoTpn7PmlYhcclxuICAgICAqIEBhdXRob3IgQzE0XHJcbiAgICAgKiBARGF0ZSAyMDE3LzEyLzEyXHJcbiAgICAgKiBAcGFyYW1ldGVycyBudWxsXHJcbiAgICAgKiBAcmV0dXJucyBudWxsXHJcbiAgICAgKi9cclxuICAgIHN0b3BFZmZlY3Q6ZnVuY3Rpb24oKSB7XHJcbiAgICAgICAgY2MuYXVkaW9FbmdpbmUuc3RvcEVmZmVjdCh0aGlzLmN1cnJlbnRFZmZlY3QpO1xyXG4gICAgfSxcclxuICAgIC8vIOW8gOWQr+ebkeWQrOeahOS9jee9ru+8jOS4jei/h+WYm++8jOWQjumdoui/mOW+l+aUue+8jOi/memHjOWFiOaQreS4quaooeWtkO+8jOiHs+WwkeS/neivgeWKn+iDveato+W4uFxyXG4gICAgc3RhcnRMaXN0ZW46IGZ1bmN0aW9uICgpIHtcclxuICAgICAgICB2YXIgc2VsZiA9IHRoaXM7XHJcbiAgICAgICAgLy9jb25zb2xlLmxvZyhcImFkZCBsaXN0ZW5cIik7XHJcbiAgICAgICAgc3dpdGNoIChzZWxmLm1hZ2ljVHlwZSkge1xyXG4gICAgICAgICAgICBjYXNlIDA6XHJcbiAgICAgICAgICAgICAgICBzZWxmLm5vZGUub24oY2MuTm9kZS5FdmVudFR5cGUuTU9VU0VfRE9XTiwgc2VsZi5Ob1RhcmdldE1hZ2ljU3RhcnRMaXN0ZW4sIHNlbGYpO1xyXG4gICAgICAgICAgICAgICAgc2VsZi5ub2RlLm9uKGNjLk5vZGUuRXZlbnRUeXBlLk1PVVNFX01PVkUsIHNlbGYuTm9UYXJnZXRNYWdpY01vdmVMaXN0ZW4sIHNlbGYpO1xyXG4gICAgICAgICAgICAgICAgc2VsZi5ub2RlLm9uKGNjLk5vZGUuRXZlbnRUeXBlLk1PVVNFX1VQLCBzZWxmLk5vVGFyZ2V0TWFnaWNFbmRMaXN0ZW4sIHNlbGYpO1xyXG4gICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgIGNhc2UgMTpcclxuICAgICAgICAgICAgICAgIHNlbGYubm9kZS5vbihjYy5Ob2RlLkV2ZW50VHlwZS5NT1VTRV9ET1dOLCBzZWxmLkFyZWFUYXJnZXRNYWdpY1N0YXJ0TGlzdGVuLCBzZWxmKTtcclxuICAgICAgICAgICAgICAgIHNlbGYubm9kZS5vbihjYy5Ob2RlLkV2ZW50VHlwZS5NT1VTRV9NT1ZFLCBzZWxmLkFyZWFUYXJnZXRNYWdpY01vdmVMaXN0ZW4sIHNlbGYpO1xyXG4gICAgICAgICAgICAgICAgc2VsZi5ub2RlLm9uKGNjLk5vZGUuRXZlbnRUeXBlLk1PVVNFX1VQLCBzZWxmLkFyZWFUYXJnZXRNYWdpY0VuZExpc3Rlbiwgc2VsZik7XHJcblxyXG4gICAgICAgICAgICAgICAgdGhpcy5yYW5nZUxOb2RlID0gY2MuaW5zdGFudGlhdGUodGhpcy5yYW5nZU5vZGUpO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5yYW5nZVJOb2RlID0gY2MuaW5zdGFudGlhdGUodGhpcy5yYW5nZU5vZGUpO1xyXG5cclxuICAgICAgICAgICAgICAgIHRoaXMucmFuZ2VMTm9kZS5hY3RpdmUgPSBmYWxzZTtcclxuICAgICAgICAgICAgICAgIHRoaXMucmFuZ2VSTm9kZS5hY3RpdmUgPSBmYWxzZTtcclxuXHJcbiAgICAgICAgICAgICAgICB0aGlzLnJhbmdlTE5vZGUueSA9IC0gMTAwO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5yYW5nZVJOb2RlLnkgPSAtIDEwMDtcclxuXHJcbiAgICAgICAgICAgICAgICB0aGlzLnJhbmdlQW5pbWVOb2RlID0gY2MuaW5zdGFudGlhdGUodGhpcy5yYW5nZUFuaW1hdGlvbk5vZGUpO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5yYW5nZUFuaW1lTm9kZS5hY3RpdmUgPSBmYWxzZTtcclxuICAgICAgICAgICAgICAgIHRoaXMucmFuZ2VBbmltZU5vZGUueSA9IC0gMTAwO1xyXG5cclxuICAgICAgICAgICAgICAgIHRoaXMubm9kZS5wYXJlbnQucGFyZW50LmFkZENoaWxkKHRoaXMucmFuZ2VBbmltZU5vZGUpO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5ub2RlLnBhcmVudC5wYXJlbnQuYWRkQ2hpbGQodGhpcy5yYW5nZUxOb2RlKTtcclxuICAgICAgICAgICAgICAgIHRoaXMubm9kZS5wYXJlbnQucGFyZW50LmFkZENoaWxkKHRoaXMucmFuZ2VSTm9kZSk7XHJcblxyXG4gICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgIGNhc2UgMjpcclxuICAgICAgICAgICAgICAgIHNlbGYubm9kZS5vbihjYy5Ob2RlLkV2ZW50VHlwZS5NT1VTRV9ET1dOLCBzZWxmLkRpcmVjdGlvblRhcmdldE1hZ2ljU3RhcnRMaXN0ZW4sIHNlbGYpO1xyXG4gICAgICAgICAgICAgICAgc2VsZi5ub2RlLm9uKGNjLk5vZGUuRXZlbnRUeXBlLk1PVVNFX01PVkUsIHNlbGYuRGlyZWN0aW9uVGFyZ2V0TWFnaWNNb3ZlTGlzdGVuLCBzZWxmKTtcclxuICAgICAgICAgICAgICAgIHNlbGYubm9kZS5vbihjYy5Ob2RlLkV2ZW50VHlwZS5NT1VTRV9VUCwgc2VsZi5EaXJlY3Rpb25UYXJnZXRNYWdpY0VuZExpc3Rlbiwgc2VsZik7XHJcblxyXG4gICAgICAgICAgICAgICAgdGhpcy5hcnJvdyA9IGNjLmluc3RhbnRpYXRlKHRoaXMuYXJyb3dOb2RlKTtcclxuICAgICAgICAgICAgICAgIHRoaXMuYXJyb3cuYWN0aXZlID0gZmFsc2U7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmFycm93LnkgPSAyMDA7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmFycm93LnggPSAwO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5oZXJvLmFkZENoaWxkKHRoaXMuYXJyb3cpO1xyXG5cclxuICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgIH1cclxuICAgIH0sXHJcblxyXG4gICAgLy8gY2FsbGVkIGV2ZXJ5IGZyYW1lLCB1bmNvbW1lbnQgdGhpcyBmdW5jdGlvbiB0byBhY3RpdmF0ZSB1cGRhdGUgY2FsbGJhY2tcclxuICAgIC8vIHVwZGF0ZTogZnVuY3Rpb24gKGR0KSB7XHJcblxyXG4gICAgLy8gfSxcclxufSk7XHJcbiIsImNjLkNsYXNzKHtcclxuICAgIGV4dGVuZHM6IGNjLkNvbXBvbmVudCxcclxuXHJcbiAgICBwcm9wZXJ0aWVzOiB7XHJcbiAgICAgICAgcHJvZ3Jlc3NCYXI6IGNjLk5vZGUsXHJcbiAgICAgICAgbWFnaWNOdW06IGNjLkxhYmVsLFxyXG4gICAgICAgIGhlcm86IGNjLk5vZGUsXHJcbiAgICAgICAgLy8gZm9vOiB7XHJcbiAgICAgICAgLy8gICAgZGVmYXVsdDogbnVsbCwgICAgICAvLyBUaGUgZGVmYXVsdCB2YWx1ZSB3aWxsIGJlIHVzZWQgb25seSB3aGVuIHRoZSBjb21wb25lbnQgYXR0YWNoaW5nXHJcbiAgICAgICAgLy8gICAgICAgICAgICAgICAgICAgICAgICAgICB0byBhIG5vZGUgZm9yIHRoZSBmaXJzdCB0aW1lXHJcbiAgICAgICAgLy8gICAgdXJsOiBjYy5UZXh0dXJlMkQsICAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyB0eXBlb2YgZGVmYXVsdFxyXG4gICAgICAgIC8vICAgIHNlcmlhbGl6YWJsZTogdHJ1ZSwgLy8gb3B0aW9uYWwsIGRlZmF1bHQgaXMgdHJ1ZVxyXG4gICAgICAgIC8vICAgIHZpc2libGU6IHRydWUsICAgICAgLy8gb3B0aW9uYWwsIGRlZmF1bHQgaXMgdHJ1ZVxyXG4gICAgICAgIC8vICAgIGRpc3BsYXlOYW1lOiAnRm9vJywgLy8gb3B0aW9uYWxcclxuICAgICAgICAvLyAgICByZWFkb25seTogZmFsc2UsICAgIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIGZhbHNlXHJcbiAgICAgICAgLy8gfSxcclxuICAgICAgICAvLyAuLi5cclxuICAgIH0sXHJcblxyXG4gICAgLy8gdXNlIHRoaXMgZm9yIGluaXRpYWxpemF0aW9uXHJcbiAgICB1cGRhdGU6IGZ1bmN0aW9uICgpIHtcclxuICAgICAgICB2YXIgc2NyaXB0ID0gdGhpcy5oZXJvLmdldENvbXBvbmVudChcIlBsYXllclwiKTsgIFxyXG4gICAgICAgIHRoaXMubWFnaWNOdW0uc3RyaW5nID0gKE1hdGguZmxvb3Ioc2NyaXB0Lm1hbmEpKS50b0ZpeGVkKDApICsgJy8nICsgc2NyaXB0Lm1heE1hbmEudG9GaXhlZCgwKTtcclxuICAgICAgICAvLyB0aGlzLm1hZ2ljTnVtLm5vZGUueCA9IDkwKnNjcmlwdC5tYW5hIC0gNDQwO1xyXG4gICAgICAgIC8vIHRoaXMucHJvZ3Jlc3NCYXIuc2NhbGVYID0gOTAqc2NyaXB0Lm1hbmEvNzQ0O1xyXG4gICAgICAgIHRoaXMucHJvZ3Jlc3NCYXIuc2NhbGVYID0gc2NyaXB0Lm1hbmEgLyAxMDtcclxuICAgIH0sXHJcblxyXG4gICAgLy8gY2FsbGVkIGV2ZXJ5IGZyYW1lLCB1bmNvbW1lbnQgdGhpcyBmdW5jdGlvbiB0byBhY3RpdmF0ZSB1cGRhdGUgY2FsbGJhY2tcclxuICAgIC8vIHVwZGF0ZTogZnVuY3Rpb24gKGR0KSB7XHJcblxyXG4gICAgLy8gfSxcclxufSk7XHJcbiIsIi8vdmFyIFNtYWxsTWFwID0gcmVxdWlyZSgnU21hbGxNYXAnKTtcclxudmFyIGdsb2JhbENvbnN0YW50ID0gcmVxdWlyZShcIkNvbnN0YW50XCIpO1xyXG4vKipcclxuICogQOS4u+imgeWKn+iDvTogIOa4uOaIj+S4u+a1geeoi+aOp+WItuWZqFxyXG4gKiBAdHlwZSB7RnVuY3Rpb259XHJcbiAqL1xyXG52YXIgTWFpbkdhbWVNYW5hZ2VyID0gY2MuQ2xhc3Moe1xyXG4gICAgZXh0ZW5kczogY2MuQ29tcG9uZW50LFxyXG5cclxuICAgIHByb3BlcnRpZXM6IHtcclxuICAgICAgICAvL+WQhOenjeWwj+WFtemihOWItlxyXG4gICAgICAgIGNyZWF0dXJlUHJlZmFiOiBbY2MuUHJlZmFiXSxcclxuICAgICAgICAvL+WFqOmDqOazleacr+mihOWItlxyXG4gICAgICAgIG1hZ2ljUHJlZmFiOiBbY2MuUHJlZmFiXSxcclxuICAgICAgICAvL+WFqOmDqOWSj+WUsemihOWItlxyXG4gICAgICAgIGNoYW50UHJlZmFiOmNjLlByZWZhYixcclxuICAgICAgICAvL+eUn+eJqeiKgueCuVxyXG4gICAgICAgIGNyZWF0dXJlczogW2NjLk5vZGVdLFxyXG4gICAgICAgIC8v6Iux6ZuE6IqC54K5KDLkuKopXHJcbiAgICAgICAgaGVyb3M6IFtjYy5Ob2RlXSxcclxuICAgICAgICAvLy8v6YC76L6R5bGCXHJcbiAgICAgICAgLy9sb2dpY0xheWVyOiBjYy5Ob2RlLCAgICAvL+iDjOaZr+iKgueCuVxyXG4gICAgICAgIC8v5Z+65Zyw5bGCXHJcbiAgICAgICAgYmFzZUxheWVyOiBjYy5Ob2RlLFxyXG4gICAgICAgIC8v55Sf54mp5bGCXHJcbiAgICAgICAgY3JlYXR1cmVMYXllcjogY2MuTm9kZSxcclxuICAgICAgICAvL+mtlOazleWxglxyXG4gICAgICAgIG1hZ2ljTGF5ZXI6IGNjLk5vZGUsXHJcblxyXG4gICAgICAgIC8v5bCP5Zyw5Zu+6IqC54K5XHJcbiAgICAgICAgbWFwTGF5ZXI6IGNjLk5vZGUsXHJcbiAgICAgICAgLy/lj7PkuIvop5Llrprml7blmajnmoToioLngrlcclxuICAgICAgICB0aW1lckxheWVyOiBjYy5Ob2RlLFxyXG4gICAgICAgIC8v5pGE5YOP5py66IqC54K5XHJcbiAgICAgICAgY2FtZXJhTGF5ZXI6Y2MuTm9kZSxcclxuXHJcblxyXG4gICAgICAgIGF1ZGlvU291cmNlOiBjYy5BdWRpb1NvdXJjZSxcclxuXHJcbiAgICAgICAgLy/ln7rlnLDpooTliLZcclxuICAgICAgICBiYXNlOiBjYy5QcmVmYWIsXHJcbiAgICAgICAgLy/lt6bkvqfnjqnlrrZcclxuICAgICAgICBiYXNlRGF0YTE6MCxcclxuICAgICAgICAvL3lvb+S+p+eOqeWutlxyXG4gICAgICAgIGJhc2VEYXRhMjowLFxyXG4gICAgICAgIFxyXG4gICAgICAgIGJhc2VPZmZzZXQ6MCxcclxuICAgICAgICBcclxuICAgICAgICBkZWxheTowXHJcbiAgICB9LFxyXG5cclxuICAgIG9uTG9hZDogZnVuY3Rpb24gKCkge1xyXG5cclxuICAgICAgICAvL+iOt+WPluWfuuWcsOiKgueCue+8jOWwhumihOWItuWunuS+i+WMllxyXG4gICAgICAgIHZhciBiYXNlTm9kZSA9IGNjLmluc3RhbnRpYXRlKHRoaXMuYmFzZSk7XHJcbiAgICAgICAgLy/ojrflj5bln7rlnLDoioLngrnnmoRqc+iEmuacrFxyXG4gICAgICAgIHZhciBzY3JpcHQxID0gYmFzZU5vZGUuZ2V0Q29tcG9uZW50KCdCYXNlJyk7XHJcbiAgICAgICAgdmFyIGJhc2VOb2RlMiA9IGNjLmluc3RhbnRpYXRlKHRoaXMuYmFzZSk7XHJcbiAgICAgICAgdmFyIHNjcmlwdDIgPSBiYXNlTm9kZTIuZ2V0Q29tcG9uZW50KCdCYXNlJyk7XHJcblxyXG4gICAgICAgIC8v6I635Y+W572R57uc6ISa5pysXHJcbiAgICAgICAgdGhpcy5uZXR3b3JrID0gdGhpcy5ub2RlLmdldENvbXBvbmVudChcIm5ldHdvcmtcIik7XHJcblxyXG4gICAgICAgIC8v5Yid5aeL5YyW5Lik5Liq5Z+65Zyw5Z2Q5qCH77yM5Lul5Y+K5rOo5YWl5LiA5Lqb5YWz6ZSu5pWw5o2uXHJcbiAgICAgICAgc2NyaXB0MS5pbml0KHRoaXMuYmFzZURhdGExLC10aGlzLmJhc2VPZmZzZXQsLTEpO1xyXG4gICAgICAgIHNjcmlwdDEuaGVybyA9IHRoaXMuaGVyb3NbMF0uZ2V0Q29tcG9uZW50KFwiUGxheWVyXCIpO1xyXG4gICAgICAgIC8v5Z+65Zyw5bGC5re75Yqg5LiK6L+w6IqC54K5XHJcbiAgICAgICAgdGhpcy5iYXNlTGF5ZXIuYWRkQ2hpbGQoYmFzZU5vZGUpO1xyXG4gICAgICAgIHNjcmlwdDIuaW5pdCh0aGlzLmJhc2VEYXRhMix0aGlzLmJhc2VPZmZzZXQsMSk7XHJcbiAgICAgICAgc2NyaXB0Mi5oZXJvID0gdGhpcy5oZXJvc1sxXS5nZXRDb21wb25lbnQoXCJQbGF5ZXJcIik7XHJcbiAgICAgICAgdGhpcy5iYXNlTGF5ZXIuYWRkQ2hpbGQoYmFzZU5vZGUyKTtcclxuXHJcbiAgICAgICAgLy/norDmkp7ns7vnu5/miZPlvIBcclxuICAgICAgICBjYy5kaXJlY3Rvci5nZXRDb2xsaXNpb25NYW5hZ2VyKCkuZW5hYmxlZCA9IHRydWU7XHJcblxyXG4gICAgICAgIC8v6I635Y+W5bCP5Zyw5Zu+6ISa5pysXHJcbiAgICAgICAgdmFyIG1hcFNjcmlwdCA9IHRoaXMubWFwTGF5ZXIuZ2V0Q29tcG9uZW50KFwiU21hbGxNYXBcIik7XHJcbiAgICAgICAgLy/oi7Hpm4TmoIforrDkuK3mt7vliqDkuKTkuKroi7Hpm4ToioLngrnvvIjmlrnkvr/lnZDmoIfojrflj5bvvIlcclxuICAgICAgICBtYXBTY3JpcHQuZm5DcmVhdGVIZXJvU2lnbih0aGlzLmhlcm9zWzBdKTtcclxuICAgICAgICBtYXBTY3JpcHQuZm5DcmVhdGVIZXJvU2lnbih0aGlzLmhlcm9zWzFdKTtcclxuXHJcbiAgICAgICAgLy/ojrflj5bml7bpl7TorrDlvZXlmajohJrmnKzvvIzmraTohJrmnKzotJ/otKPoh6rliqjmjqjov5vml7bpl7TovbRcclxuICAgICAgICB0aGlzLnRpbWVyTGF5ZXJTY3JpcHQgPSB0aGlzLnRpbWVyTGF5ZXIuZ2V0Q29tcG9uZW50KFwiR2FtZVRpbWVyXCIpO1xyXG5cclxuICAgICAgICAvL+avj+malOS4gOauteaXtumXtOWPrOWUpOS4gOS4quWwj+aAqlxyXG4gICAgICAgIC8vdGhpcy5zY2hlZHVsZShmdW5jdGlvbigpIHtcclxuICAgICAgICAvLyAgICB2YXIgZXZlbnRzZW5kID0gbmV3IGNjLkV2ZW50LkV2ZW50Q3VzdG9tKCdjcmVhdHVyZUNyZWF0ZScsdHJ1ZSk7XHJcbiAgICAgICAgLy8gICAgZXZlbnRzZW5kLnNldFVzZXJEYXRhKHtYOihjYy5kaXJlY3Rvci5nZXRXaW5TaXplKCkud2lkdGggKiBnbG9iYWxDb25zdGFudC5zY2VuZVdpZHRoKSxZOm51bGwsYXR0YWNrOjIsaGVhbHRoOjEwLHRlYW06MSx2ZWxvY2l0eTozLGlkOjF9KTtcclxuICAgICAgICAvL1xyXG4gICAgICAgIC8vICAgIHRoaXMubm9kZS5kaXNwYXRjaEV2ZW50KGV2ZW50c2VuZCk7XHJcbiAgICAgICAgLy99LDIpO1xyXG5cclxuICAgICAgICAvL+WIm+W7um5wYyDlsI/lnLDlm77oioLngrkg5LqL5Lu2XHJcbiAgICAgICAgdGhpcy5ub2RlLm9uKCdjcmVhdHVyZUNyZWF0ZScsdGhpcy5jcmVhdHVyZUNyZWF0ZSx0aGlzKTtcclxuICAgICAgICAvL+WIm+W7uuWSj+WUseazleacr+S6i+S7tlxyXG4gICAgICAgIHRoaXMubm9kZS5vbignY2hhbnRDcmVhdGUnLHRoaXMuY2hhbnRDcmVhdGUsdGhpcyk7XHJcbiAgICAgICAgLy/oi7Hpm4TmrbvkuqHkuovku7ZcclxuICAgICAgICB0aGlzLm5vZGUub24oJ2hlcm9EZWF0aCcsdGhpcy5oZXJvRGVhdGgsdGhpcyk7XHJcbiAgICAgICAgLy/prZTms5XliJvlu7rkuovku7ZcclxuICAgICAgICB0aGlzLm5vZGUub24oJ21hZ2ljQ3JlYXRlJyx0aGlzLm1hZ2ljQ3JlYXRlLHRoaXMpO1xyXG4gICAgICAgIC8v5ri45oiP5piv5ZCm6I636IOc5LqL5Lu2XHJcbiAgICAgICAgdGhpcy5ub2RlLm9uKCdpc1dpbicsdGhpcy5pc1dpbix0aGlzKTtcclxuICAgICAgICAvL+mfs+aViOaSreaUvuS6i+S7tlxyXG4gICAgICAgIHRoaXMubm9kZS5vbigncGxheUVmZmVjdCcsdGhpcy5wbGF5RWZmZWN0LHRoaXMpO1xyXG4gICAgICAgICAgICBcclxuICAgIH0sXHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBA5Li76KaB5Yqf6IO9IOWIpOaWreiDnOWIqe+8jOiDnOWIqeWwsei/lOWbnuWIsOWIneWni+WcuuaZr+S4rVxyXG4gICAgICogQGF1dGhvciBDMTRcclxuICAgICAqIEBEYXRlIDIwMTcvMTEvMTlcclxuICAgICAqIEBwYXJhbWV0ZXJzXHJcbiAgICAgKiBAcmV0dXJuc1xyXG4gICAgICovXHJcbiAgICBpc1dpbjpmdW5jdGlvbihldmVudCl7XHJcbiAgICAgICAgLy90aGlzLmN1cnJlbnQgPSBjYy5hdWRpb0VuZ2luZS5wbGF5KHRoaXMuYXVkaW8sIGZhbHNlLCAxKTtcclxuICAgICAgICAvL3RoaXMuYXVkaW8uc2NoZWR1bGUoYmFjaygpKTtcclxuICAgICAgICAvL3ZhciBiYWNrID0gZnVuY3Rpb24oKXtcclxuICAgICAgICAgICAgY2MuZGlyZWN0b3IubG9hZFNjZW5lKFwiTWFpblNjZW5lXCIpO1xyXG4gICAgICAgIC8vfVxyXG4gICAgfSxcclxuXHJcbiAgICAvKipcclxuICAgICAqIEDkuLvopoHlip/og70g6LSf6LSj5aSE55CG5Lyg6L6T5LiK5p2l55qE6Z+z5pWI77yM55u05o6l5pKt5pS+XHJcbiAgICAgKiBAYXV0aG9yIEMxNFxyXG4gICAgICogQERhdGUgMjAxOC8xLzJcclxuICAgICAqIEBwYXJhbWV0ZXJzXHJcbiAgICAgKiBAcmV0dXJuc1xyXG4gICAgICovXHJcbiAgICBwbGF5RWZmZWN0OmZ1bmN0aW9uKGV2ZW50KXtcclxuICAgICAgICB2YXIgdm9sdW1lID0gMTtcclxuICAgICAgICBpZihldmVudC5kZXRhaWwuZnVsbFZvbHVtZSA9PT0gZmFsc2UpIHtcclxuICAgICAgICAgICAgaWYgKE1hdGguYWJzKHRoaXMuY2FtZXJhTGF5ZXIueCAtIGV2ZW50LmRldGFpbC50YXJnZXQueCkgPFxyXG4gICAgICAgICAgICAgICAgZ2xvYmFsQ29uc3RhbnQuc2NlbmVXaWR0aCAqIGNjLmRpcmVjdG9yLmdldFdpblNpemUoKS53aWR0aCAvIDIpIHtcclxuICAgICAgICAgICAgICAgIHZvbHVtZSA9IDEgLSBNYXRoLmFicyh0aGlzLmNhbWVyYUxheWVyLnggLSBldmVudC5kZXRhaWwudGFyZ2V0LngpIC9cclxuICAgICAgICAgICAgICAgICAgICAoZ2xvYmFsQ29uc3RhbnQuc2NlbmVXaWR0aCAqIGNjLmRpcmVjdG9yLmdldFdpblNpemUoKS53aWR0aCAvIDIpO1xyXG4gICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgdm9sdW1lID0gMDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICAvL+aSreaUvumfs+aViFxyXG4gICAgICAgIC8vY2MuYXVkaW9FbmdpbmUucGxheUVmZmVjdChldmVudC5kZXRhaWwuZWZmZWN0LGZhbHNlLGV2ZW50LmRldGFpbC52b2x1bWUgKiB2b2x1bWUpO1xyXG4gICAgfSxcclxuXHJcbiAgICAvKipcclxuICAgICAqIEDkuLvopoHlip/og70g6Iux6ZuE5q275Lqh5ZCO6L+Q6KGM5LiA5Liq5a6a5pe25Zmo77yM5Y2z77yM5aSN5rS76Iux6ZuEXHJcbiAgICAgKiBAYXV0aG9yIEMxNFxyXG4gICAgICogQERhdGUgMjAxNy8xMi8yMFxyXG4gICAgICogQHBhcmFtZXRlcnNcclxuICAgICAqIEByZXR1cm5zXHJcbiAgICAgKi9cclxuICAgIGhlcm9EZWF0aDpmdW5jdGlvbihldmVudCl7XHJcbiAgICAgICAgLy/orqlZ5Z2Q5qCH5LiL5Y67XHJcbiAgICAgICAgZXZlbnQuZGV0YWlsLmhlcm9TY3JpcHQubm9kZS55ID0gLTEwMDA7XHJcbiAgICAgICAgLy/lrprml7blmajvvIzmrbvkuqHmrKHmlbDotorlpJrlpI3mtLvpnIDopoHotorplb/nmoTml7bpl7RcclxuICAgICAgICB0aGlzLnNjaGVkdWxlT25jZShmdW5jdGlvbigpIHtcclxuICAgICAgICAgICAgLy/lpI3mtLvnmoR45Z2Q5qCH5qC55o2u6Zif5LyN6ICM6YCJ5oup5bem5Y+zXHJcbiAgICAgICAgICAgIGV2ZW50LmRldGFpbC5oZXJvU2NyaXB0Lm5vZGUueCA9IGNjLmRpcmVjdG9yLmdldFdpblNpemUoKS53aWR0aCAqIGdsb2JhbENvbnN0YW50LnNjZW5lV2lkdGggLyAyXHJcbiAgICAgICAgICAgICAgICArIGNjLmRpcmVjdG9yLmdldFdpblNpemUoKS53aWR0aCAqIGdsb2JhbENvbnN0YW50LnNjZW5lV2lkdGggLyAyICogZXZlbnQuZGV0YWlsLmhlcm9TY3JpcHQudGVhbTtcclxuICAgICAgICAgICAgLy/ov5DooYzoi7Hpm4TlhoXpg6jnmoTlpI3mtLvmjqXlj6NcclxuICAgICAgICAgICAgZXZlbnQuZGV0YWlsLmhlcm9TY3JpcHQucmVsaXZlKCk7XHJcblxyXG4gICAgICAgIH0sOCooZXZlbnQuZGV0YWlsLmhlcm9TY3JpcHQuZGVhdGhUaW1lcykpO1xyXG4gICAgICAgIGV2ZW50LmRldGFpbC5oZXJvU2NyaXB0Lm5vZGUub3BhY2l0eSA9IDA7XHJcbiAgICAgICAgZXZlbnQuc3RvcFByb3BhZ2F0aW9uKCk7XHJcbiAgICB9LFxyXG5cclxuICAgIC8qKlxyXG4gICAgICogQOS4u+imgeWKn+iDvTogIOWIm+W7uuazleacr1xyXG4gICAgICogICAgICAgICAgICAgIOW7uuiuruS7peWQjuaUueeUqOi1hOa6kOaxoOiOt+WPluiKgueCuSAgIOi1hOa6kOaxoOS9v+eUqOW3peWOguWIm+W7uuiKgueCue+8jOi/memHjOWPr+S7pei0n+i0o+WIneWni+WMluiKgueCueWxnuaAp1xyXG4gICAgICogQGF1dGhvciBDMTRcclxuICAgICAqIEBEYXRlIDIwMTcvMTEvMDEgMTM6MDRcclxuICAgICAqIEBwYXJhbSBldmVudFxyXG4gICAgICovXHJcbiAgICBtYWdpY0NyZWF0ZTogZnVuY3Rpb24oZXZlbnQpeyAgLy9ldmVudOS4uueItuexu+S6i+S7tiAg5a6e6ZmF6L+Z6YeM5pivRXZlbnQuRXZlbnRDdXN0b23lrZDnsbtcclxuICAgICAgICB0aGlzLm5ldHdvcmsucm9vbU1zZygncm9vbUNoYXQnLHtuYW1lOlwibWFnaWNDcmVhdGVcIixkZXRhaWw6ZXZlbnQuZGV0YWlsfSk7XHJcbiAgICAgICAgLy9rZW5hbiDlrp7pqozor4HmmI4gIOS6i+S7tuaYr+WQjOatpeeahCAg6K6h5pe25Zmo5piv5byC5q2l55qEXHJcbiAgICAgICAgLy8gdGhpcy5zY2hlZHVsZU9uY2UoZnVuY3Rpb24oKSB7XHJcblxyXG4gICAgICAgICAgICAvKioga2VuYW4g6L+Z6YeM6I635Y+WbnBj55qE6LWE5rqQ5pa55rOV5Y+v5Lul5pS55Li677yM5L2/55So6LWE5rqQ5rGg6I635Y+WbnBj6IqC54K5Ki9cclxuICAgICAgICAgICAgdmFyIG1hZyA9IGNjLmluc3RhbnRpYXRlKHRoaXMubWFnaWNQcmVmYWJbZXZlbnQuZGV0YWlsLmlkXSk7XHJcbiAgICAgICAgICAgIHZhciBtYWdTY3JpcHQgPSBtYWcuZ2V0Q29tcG9uZW50KCdNYWdpYycgKyBldmVudC5kZXRhaWwuaWQpO1xyXG5cclxuICAgICAvLyAgICAgICBtYWdTY3JpcHQuZm5DcmVhdGVNYWdpYyhldmVudC5kZXRhaWwpOy8v5Yid5aeL5YyWbnBj5bGe5oCnXHJcbiAgICAgICAgICAgIG1hZy54ID0gZXZlbnQuZGV0YWlsLnBvc2l0aW9uO1xyXG4gICAgICAgIGlmKGV2ZW50LmRldGFpbC55ID09PSBudWxsKXtcclxuICAgICAgICAgICAgbWFnLnkgPSBnbG9iYWxDb25zdGFudC5tYWdpY1k7XHJcbiAgICAgICAgfWVsc2V7XHJcbiAgICAgICAgICAgIG1hZy55ID0gZXZlbnQuZGV0YWlsLnk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHRoaXMubWFnaWNMYXllci5hZGRDaGlsZChtYWcpO1xyXG4gICAgICAgIG1hZ1NjcmlwdC5pbml0TWFnaWMoZXZlbnQuZGV0YWlsKTtcclxuICAgICAgICAvL+WBnOatouS6i+S7tuWGkuazoSjlgZzmraLnu6fnu63lkJHkuIrkvKDpgJLmraTkuovku7YpXHJcbiAgICAgICAgZXZlbnQuc3RvcFByb3BhZ2F0aW9uKCk7XHJcbiAgICB9LFxyXG4gICAgLyoqXHJcbiAgICAgKiBA5Li76KaB5Yqf6IO9ICAgIOe9kee7nOaooeWdl+iwg+eUqOatpOS7o+eggVxyXG4gICAgICogICAgICAgICAgICAgICDliJvlu7rlhbbku5bkurrnmoTms5XmnK9cclxuICAgICAqIEBhdXRob3IgQzE0XHJcbiAgICAgKiBARGF0ZSAyMDE4LzEvOVxyXG4gICAgICogQHBhcmFtZXRlcnNcclxuICAgICAqIEByZXR1cm5zXHJcbiAgICAgKi9cclxuICAgIG1hZ2ljQ3JlYXRlTmV0d29yazogZnVuY3Rpb24oZGF0YSl7XHJcbiAgICAgICAgLyoqIGtlbmFuIOi/memHjOiOt+WPlm5wY+eahOi1hOa6kOaWueazleWPr+S7peaUueS4uu+8jOS9v+eUqOi1hOa6kOaxoOiOt+WPlm5wY+iKgueCuSovXHJcbiAgICAgICAgdmFyIG1hZyA9IGNjLmluc3RhbnRpYXRlKHRoaXMubWFnaWNQcmVmYWJbZGF0YS5pZF0pO1xyXG4gICAgICAgIHZhciBtYWdTY3JpcHQgPSBtYWcuZ2V0Q29tcG9uZW50KCdNYWdpYycgKyBkYXRhLmlkKTtcclxuXHJcbiAgICAgICAgLy8gbWFnU2NyaXB0LmZuQ3JlYXRlTWFnaWMoZXZlbnQuZGV0YWlsKTsvL+WIneWni+WMlm5wY+WxnuaAp1xyXG4gICAgICAgIG1hZy54ID0gZGF0YS5wb3NpdGlvbjtcclxuICAgICAgICBpZihkYXRhLnkgPT09IG51bGwpe1xyXG4gICAgICAgICAgICBtYWcueSA9IGdsb2JhbENvbnN0YW50Lm1hZ2ljWTtcclxuICAgICAgICB9ZWxzZXtcclxuICAgICAgICAgICAgbWFnLnkgPSBkYXRhLnk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHRoaXMubWFnaWNMYXllci5hZGRDaGlsZChtYWcpO1xyXG4gICAgICAgIG1hZ1NjcmlwdC5pbml0TWFnaWMoZGF0YSk7XHJcbiAgICB9LFxyXG5cclxuICAgIC8qKlxyXG4gICAgICogQOS4u+imgeWKn+iDvTogIOWIm+W7uueUn+eJqeiKgueCuVxyXG4gICAgICogICAgICAgICAgICAgIOW7uuiuruS7peWQjuaUueeUqOi1hOa6kOaxoOiOt+WPluiKgueCuSAgIOi1hOa6kOaxoOS9v+eUqOW3peWOguWIm+W7uuiKgueCue+8jOi/memHjOWPr+S7pei0n+i0o+WIneWni+WMluiKgueCueWxnuaAp1xyXG4gICAgICogQGF1dGhvciBrZW5hblxyXG4gICAgICogQERhdGUgMjAxNy83LzIzIDA6MjVcclxuICAgICAqIEBwYXJhbSBldmVudFxyXG4gICAgICovXHJcbiAgICBjcmVhdHVyZUNyZWF0ZTogZnVuY3Rpb24oZGF0YSl7ICAvL2V2ZW505Li654i257G75LqL5Lu2ICDlrp7pmYXov5nph4zmmK9FdmVudC5FdmVudEN1c3RvbeWtkOexu1xyXG5cclxuICAgICAgICB0aGlzLm5ldHdvcmsucm9vbU1zZygncm9vbUNoYXQnLHtuYW1lOlwiY3JlYXR1cmVDcmVhdGVcIixkZXRhaWw6ZGF0YS5kZXRhaWx9KTtcclxuICAgICAgICAvL2tlbmFuIOWunumqjOivgeaYjiAg5LqL5Lu25piv5ZCM5q2l55qEICDorqHml7blmajmmK/lvILmraXnmoRcclxuICAgICAgICAvLyB0aGlzLnNjaGVkdWxlT25jZShmdW5jdGlvbigpIHtcclxuICAgICAgICAvKioga2VuYW4g6L+Z6YeM6I635Y+WbnBj55qE6LWE5rqQ5pa55rOV5Y+v5Lul5pS55Li677yM5L2/55So6LWE5rqQ5rGg6I635Y+WbnBj6IqC54K5Ki9cclxuICAgICAgICB2YXIgbnBjID0gY2MuaW5zdGFudGlhdGUodGhpcy5jcmVhdHVyZVByZWZhYltkYXRhLmRldGFpbC5pZF0pO1xyXG4gICAgICAgIHZhciBucGNTY3JpcHQgPSBucGMuZ2V0Q29tcG9uZW50KFwiQ3JlYXR1cmVcIik7XHJcblxyXG4gICAgICAgIHZhciBtYXBTY3JpcHQgPSB0aGlzLm1hcExheWVyLmdldENvbXBvbmVudChcIlNtYWxsTWFwXCIpO1xyXG5cclxuICAgICAgICB2YXIgZGV0YWlsID0gZGF0YS5kZXRhaWw7XHJcbiAgICAgICAgZGV0YWlsLlkgPSBkZXRhaWwuWSA9PT0gbnVsbCA/IGdsb2JhbENvbnN0YW50LnN1bW1vblkgOiBkZXRhaWwuWTtcclxuXHJcbiAgICAgICAgbnBjU2NyaXB0LmZuR2V0TWFuYWdlcih0aGlzKTtcclxuXHJcbiAgICAgICAgdGhpcy5jcmVhdHVyZXMucHVzaChucGMpO1xyXG5cclxuICAgICAgICBtYXBTY3JpcHQuZm5DcmVhdGVDcmVhdHVyZVNpZ24odGhpcy5jcmVhdHVyZXNbdGhpcy5jcmVhdHVyZXMubGVuZ3RoIC0gMV0pO1xyXG4gICAgICAgIG5wY1NjcmlwdC5mbkNyZWF0ZUNyZWF0dXJlKGRldGFpbCk7Ly/liJ3lp4vljJZucGPlsZ7mgKdcclxuICAgICAgICB0aGlzLmNyZWF0dXJlTGF5ZXIuYWRkQ2hpbGQodGhpcy5jcmVhdHVyZXNbdGhpcy5jcmVhdHVyZXMubGVuZ3RoIC0gMV0pO1xyXG5cclxuICAgICAgICAvL2tlbmFuIOWBnOatouS6i+S7tuWGkuazoSAgICjlgZzmraLnu6fnu63lkJHkuIrkvKDpgJLmraTkuovku7YpXHJcbiAgICAgICAgZGF0YS5zdG9wUHJvcGFnYXRpb24oKTtcclxuXHJcbiAgICAgICAgLy8gY29uc29sZS5sb2coXCJjcmVhdHVyZUNyZWF0Zee7k+adn1wiKTtcclxuXHJcbiAgICAgICAgLy8gfSk7XHJcbiAgICB9LFxyXG4gICAgLyoqXHJcbiAgICAgKiBA5Li76KaB5Yqf6IO9ICAgIOe9kee7nOaooeWdl+iwg+eUqOatpOS7o+eggVxyXG4gICAgICogICAgICAgICAgICAgICDliJvlu7rlhbbku5bkurrnmoTnlJ/nialcclxuICAgICAqIEBhdXRob3IgQzE0XHJcbiAgICAgKiBARGF0ZSAyMDE4LzEvOVxyXG4gICAgICogQHBhcmFtZXRlcnNcclxuICAgICAqIEByZXR1cm5zXHJcbiAgICAgKi9cclxuICAgIGNyZWF0dXJlQ3JlYXRlTmV0d29yazogZnVuY3Rpb24oZGF0YSl7XHJcbiAgICAgICAgLy9rZW5hbiDlrp7pqozor4HmmI4gIOS6i+S7tuaYr+WQjOatpeeahCAg6K6h5pe25Zmo5piv5byC5q2l55qEXHJcbiAgICAgICAgLy8gdGhpcy5zY2hlZHVsZU9uY2UoZnVuY3Rpb24oKSB7XHJcbiAgICAgICAgLyoqIGtlbmFuIOi/memHjOiOt+WPlm5wY+eahOi1hOa6kOaWueazleWPr+S7peaUueS4uu+8jOS9v+eUqOi1hOa6kOaxoOiOt+WPlm5wY+iKgueCuSovXHJcbiAgICAgICAgdmFyIG5wYyA9IGNjLmluc3RhbnRpYXRlKHRoaXMuY3JlYXR1cmVQcmVmYWJbZGF0YS5pZF0pO1xyXG4gICAgICAgIHZhciBucGNTY3JpcHQgPSBucGMuZ2V0Q29tcG9uZW50KFwiQ3JlYXR1cmVcIik7XHJcblxyXG4gICAgICAgIHZhciBtYXBTY3JpcHQgPSB0aGlzLm1hcExheWVyLmdldENvbXBvbmVudChcIlNtYWxsTWFwXCIpO1xyXG5cclxuICAgICAgICB2YXIgZGV0YWlsID0gZGF0YTtcclxuICAgICAgICBkZXRhaWwuWSA9IGRldGFpbC5ZID09PSBudWxsID8gZ2xvYmFsQ29uc3RhbnQuc3VtbW9uWSA6IGRldGFpbC5ZO1xyXG5cclxuICAgICAgICBucGNTY3JpcHQuZm5HZXRNYW5hZ2VyKHRoaXMpO1xyXG5cclxuICAgICAgICB0aGlzLmNyZWF0dXJlcy5wdXNoKG5wYyk7XHJcblxyXG4gICAgICAgIG1hcFNjcmlwdC5mbkNyZWF0ZUNyZWF0dXJlU2lnbih0aGlzLmNyZWF0dXJlc1t0aGlzLmNyZWF0dXJlcy5sZW5ndGggLSAxXSk7XHJcbiAgICAgICAgbnBjU2NyaXB0LmZuQ3JlYXRlQ3JlYXR1cmUoZGV0YWlsKTsvL+WIneWni+WMlm5wY+WxnuaAp1xyXG4gICAgICAgIHRoaXMuY3JlYXR1cmVMYXllci5hZGRDaGlsZCh0aGlzLmNyZWF0dXJlc1t0aGlzLmNyZWF0dXJlcy5sZW5ndGggLSAxXSk7XHJcbiAgICB9LFxyXG4gICAgLyoqXHJcbiAgICAgKiBA5Li76KaB5Yqf6IO9OiAg5Yib5bu65ZCf5ZSxXHJcbiAgICAgKiAgICAgICAgICAgICAg5bu66K6u5Lul5ZCO5pS555So6LWE5rqQ5rGg6I635Y+W6IqC54K5ICAg6LWE5rqQ5rGg5L2/55So5bel5Y6C5Yib5bu66IqC54K577yM6L+Z6YeM5Y+v5Lul6LSf6LSj5Yid5aeL5YyW6IqC54K55bGe5oCnXHJcbiAgICAgKiBAYXV0aG9yIEMxNFxyXG4gICAgICogQERhdGUgMjAxNy8xMS8xNyAyMDowM1xyXG4gICAgICogQHBhcmFtIGV2ZW50XHJcbiAgICAgKi9cclxuICAgIGNoYW50Q3JlYXRlOiBmdW5jdGlvbihldmVudCl7ICAvL2V2ZW505Li654i257G75LqL5Lu2ICDlrp7pmYXov5nph4zmmK9FdmVudC5FdmVudEN1c3RvbeWtkOexu1xyXG4gICAgICAgIHRoaXMubmV0d29yay5yb29tTXNnKCdyb29tQ2hhdCcse25hbWU6XCJjaGFudENyZWF0ZVwiLGRldGFpbDpldmVudC5kZXRhaWx9KTtcclxuXHJcbiAgICAgICAgLyoqIGtlbmFuIOi/memHjOiOt+WPlm5wY+eahOi1hOa6kOaWueazleWPr+S7peaUueS4uu+8jOS9v+eUqOi1hOa6kOaxoOiOt+WPlm5wY+iKgueCuSovXHJcbiAgICAgICAgdmFyIGNoYW50TWFnID0gY2MuaW5zdGFudGlhdGUodGhpcy5jaGFudFByZWZhYik7XHJcbiAgICAgICAgdmFyIGNoYW50TWFnU2NyaXB0ID0gY2hhbnRNYWcuZ2V0Q29tcG9uZW50KCdDaGFudCcpO1xyXG5cclxuXHJcbiAgICAgICAgY2hhbnRNYWdTY3JpcHQucGVyY2VudCA9IHRoaXMudGltZXJMYXllclNjcmlwdC50aW1lci90aGlzLnRpbWVyTGF5ZXJTY3JpcHQubWF4VGltZXI7XHJcbiAgICAgICAgY2hhbnRNYWdTY3JpcHQuZm5Jbml0Q2hhbnQoZXZlbnQuZGV0YWlsKTtcclxuICAgICAgICB0aGlzLnRpbWVyTGF5ZXIuYWRkQ2hpbGQoY2hhbnRNYWcpO1xyXG4gICAgICAgIC8vICAgICAgIG1hZ1NjcmlwdC5mbkNyZWF0ZU1hZ2ljKGV2ZW50LmRldGFpbCk7Ly/liJ3lp4vljJZucGPlsZ7mgKdcclxuXHJcblxyXG5cclxuICAgICAgICAvL2tlbmFuIOWBnOatouS6i+S7tuWGkuazoSAgICjlgZzmraLnu6fnu63lkJHkuIrkvKDpgJLmraTkuovku7YpXHJcbiAgICAgICAgZXZlbnQuc3RvcFByb3BhZ2F0aW9uKCk7XHJcblxyXG4gICAgICAgIC8vIGNvbnNvbGUubG9nKFwiY3JlYXR1cmVDcmVhdGXnu5PmnZ9cIik7XHJcblxyXG4gICAgICAgIC8vIH0pO1xyXG4gICAgfSxcclxuICAgIC8qKlxyXG4gICAgICogQOS4u+imgeWKn+iDvSAgICDnvZHnu5zmqKHlnZfosIPnlKjmraTku6PnoIFcclxuICAgICAqICAgICAgICAgICAgICAg5Yib5bu65YW25LuW5Lq655qE5ZKP5ZSx5rOV5pyvXHJcbiAgICAgKiBAYXV0aG9yIEMxNFxyXG4gICAgICogQERhdGUgMjAxOC8xLzlcclxuICAgICAqIEBwYXJhbWV0ZXJzXHJcbiAgICAgKiBAcmV0dXJuc1xyXG4gICAgICovXHJcbiAgICBjaGFudENyZWF0ZU5ldHdvcms6IGZ1bmN0aW9uKGRhdGEpeyAgLy9ldmVudOS4uueItuexu+S6i+S7tiAg5a6e6ZmF6L+Z6YeM5pivRXZlbnQuRXZlbnRDdXN0b23lrZDnsbtcclxuXHJcbiAgICAgICAgLy9rZW5hbiDlrp7pqozor4HmmI4gIOS6i+S7tuaYr+WQjOatpeeahCAg6K6h5pe25Zmo5piv5byC5q2l55qEXHJcbiAgICAgICAgLy8gdGhpcy5zY2hlZHVsZU9uY2UoZnVuY3Rpb24oKSB7XHJcblxyXG4gICAgICAgIC8qKiBrZW5hbiDov5nph4zojrflj5ZucGPnmoTotYTmupDmlrnms5Xlj6/ku6XmlLnkuLrvvIzkvb/nlKjotYTmupDmsaDojrflj5ZucGPoioLngrkqL1xyXG4gICAgICAgIHZhciBjaGFudE1hZyA9IGNjLmluc3RhbnRpYXRlKHRoaXMuY2hhbnRQcmVmYWIpO1xyXG4gICAgICAgIHZhciBjaGFudE1hZ1NjcmlwdCA9IGNoYW50TWFnLmdldENvbXBvbmVudCgnQ2hhbnQnKTtcclxuXHJcbiAgICAgICAgLy8gICAgICAgbWFnU2NyaXB0LmZuQ3JlYXRlTWFnaWMoZXZlbnQuZGV0YWlsKTsvL+WIneWni+WMlm5wY+WxnuaAp1xyXG4gICAgICAgIGNoYW50TWFnU2NyaXB0LnBlcmNlbnQgPSB0aGlzLnRpbWVyTGF5ZXJTY3JpcHQudGltZXIvdGhpcy50aW1lckxheWVyU2NyaXB0Lm1heFRpbWVyO1xyXG4gICAgICAgIGNoYW50TWFnU2NyaXB0LmZuSW5pdENoYW50KGRhdGEpO1xyXG4gICAgICAgIHRoaXMudGltZXJMYXllci5hZGRDaGlsZChjaGFudE1hZyk7XHJcbiAgICB9LFxyXG4gICAgLyoqXHJcbiAgICAgKiBA5Li76KaB5Yqf6IO9IOiwg+aVtOaVjOS6uueahOihgOmHj++8jOmAn+W6puaWueWQke+8jFjlnZDmoIdcclxuICAgICAqIEBhdXRob3IgQzE0XHJcbiAgICAgKiBARGF0ZSAyMDE4LzEvOVxyXG4gICAgICogQHBhcmFtZXRlcnNcclxuICAgICAqIEByZXR1cm5zXHJcbiAgICAgKi9cclxuICAgIGNoYW5nZUVuZW15TW92ZTpmdW5jdGlvbihkYXRhKXtcclxuICAgICAgICB2YXIgc2NyaXB0ID0gdGhpcy5oZXJvc1sxXS5nZXRDb21wb25lbnQoXCJQbGF5ZXJcIik7XHJcbiAgICAgICAgdGhpcy5oZXJvc1sxXS54ID0gZGF0YS54O1xyXG4gICAgICAgIHNjcmlwdC5hY2NMZWZ0ID0gZGF0YS5hY2NMZWZ0O1xyXG4gICAgICAgIHNjcmlwdC5hY2NSaWdodCA9IGRhdGEuYWNjUmlnaHQ7XHJcbiAgICAgICAgc2NyaXB0LmhlYWx0aCA9IGRhdGEuaGVhbHRoO1xyXG4gICAgfSxcclxuXHJcbiAgICAvKipcclxuICAgICAqIEDkuLvopoHlip/og706IOmHiuaUvuWwj+WFteiKgueCuVxyXG4gICAgICogICAgICAgICAg5bu66K6u5L2/55So6LWE5rqQ5rGg5Zue5pS26IqC54K5XHJcbiAgICAgKiBAcGFyYW0gbm9kZVxyXG4gICAgICovXHJcbiAgICByZW1vdmVDcmVhdHVyZTogZnVuY3Rpb24obm9kZSl7XHJcbiAgICAgICAgdmFyIGkgPSAwO1xyXG4gICAgICAgIHZhciBzY3JpcHQgPSBub2RlLmdldENvbXBvbmVudCgnQ3JlYXR1cmUnKTtcclxuICAgICAgICB2YXIgbWFwU2NyaXB0ID0gdGhpcy5tYXBMYXllci5nZXRDb21wb25lbnQoJ1NtYWxsTWFwJyk7XHJcbiAgICAgICAgbWFwU2NyaXB0LmZuRGVsZXRlU2lnbihub2RlKTtcclxuICAgICAgICBmb3IoaSA9IDA7aSA8IHRoaXMuY3JlYXR1cmVzLmxlbmd0aDsgaSsrKXtcclxuICAgICAgICAgICAgaWYoIHRoaXMuY3JlYXR1cmVzW2ldID09PSBub2RlKXtcclxuICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgLy90aGlzLmNyZWF0dXJlc1tpXS5yZW1vdmVGcm9tUGFyZW50KCk7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmNyZWF0dXJlcy5zcGxpY2UoaSwxKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgLy9rZW5hbiDlm6DkuLrmsqHmnInlm57mlLbmsaAgIOi/memHjOmcgOimgemHiuaUvui1hOa6kFxyXG4vLyAgICAgICAgbm9kZS5kZXN0cm95KCk7XHJcblxyXG4gICAgfVxyXG4gICAgXHJcbn0pO1xyXG5cclxuIiwiLy/mraTnu4Tku7bmjILovb3kuo5TY2VuZU1hbmFnZXLjgILnlKjkuo7lgqjlrZjlkITnp43mlbDmja7vvIzku6Xlj4rnu4Tku7bvvIzkvr/kuo7lj5bnlKjkuI7nrqHnkIZcclxudmFyIEdsb2JhbCA9IHJlcXVpcmUoJ0dsb2JhbCcpO1xyXG5jYy5DbGFzcyh7XHJcbiAgICBleHRlbmRzOiBjYy5Db21wb25lbnQsXHJcblxyXG4gICAgcHJvcGVydGllczoge1xyXG4gICAgICAgIFxyXG4gICAgICAgIC8v546p5a6255qE6YeR5biB5pWw6YePXHJcbiAgICAgICAgY29pbjogMCxcclxuICAgICAgICBcclxuICAgICAgICAvL+eOqeWutueahOeBtemtgijnsbvkvLznsonlsJgp5pWw6YePXHJcbiAgICAgICAgc291bDogMCxcclxuXHJcbiAgICAgICAgLy/njqnlrrblj6/ku6XmiZPlvIDnmoTljaHniYzljIXmlbDph49cclxuICAgICAgICBiYWdzOiAwLFxyXG4gICAgICAgIFxyXG4gICAgICAgIFxyXG4gICAgICAgIC8v55Sf54mp5Y2h54mH6aKE6KeI55So55qE6aKE5Yi2XHJcbiAgICAgICAgbWluaUNyZWF0dXJlUHJlZmFiOiBbY2MuUHJlZmFiXSxcclxuICAgICAgICBcclxuICAgICAgICAvL+mtlOazleWNoeeJh+mihOiniOeUqOeahOmihOWItlxyXG4gICAgICAgIG1pbmlNYWdpY1ByZWZhYjogW2NjLlByZWZhYl0sXHJcbiAgICAgICAgXHJcbiAgICAgICAgLy/njqnlrrbnjrDlnKjmi6XmnInnmoTljaFcclxuICAgICAgICBteUNDYXJkczogW2NjLkludGVnZXJdLFxyXG4gICAgICAgIFxyXG4gICAgICAgIG15TUNhcmRzOltjYy5JbnRlZ2VyXSxcclxuICAgIFxyXG4gICAgXHJcbiAgICAgICAgZGVja0J1aWxkUHJlZmFiOiBjYy5QcmVmYWIsXHJcblxyXG4gICAgICAgIC8v5LiA5Liq5Y2h57uE55qE5pWw5o2uXHJcbiAgICAgICAgLy90b3RhbERlY2tEYXRhOiBbR2xvYmFsLnRvdGFsRGVja0RhdGEudHlwZV0sXHJcbiAgICAgICAgLy/njqnlrrbnjrDlnKjlnKjnu4TnmoTljaHnu4TnmoTnu4TmiJBcclxuICAgICAgICBteU1EZWNrOntcclxuICAgICAgICAgICAgZGVmYXVsdDpbXSxcclxuICAgICAgICAgICAgdHlwZTogY2MuSW50ZWdlcixcclxuICAgICAgICB9LFxyXG4gICAgICAgIG15Q0RlY2s6e1xyXG4gICAgICAgICAgICBkZWZhdWx0OltdLFxyXG4gICAgICAgICAgICB0eXBlOiBjYy5JbnRlZ2VyLFxyXG4gICAgICAgIH0sXHJcbiAgICAgICAgXHJcbiAgICAgICAgXHJcbiAgICAgICAgc2hvd01QcmVmYWI6e1xyXG4gICAgICAgICAgICBkZWZhdWx0OiBbXSxcclxuICAgICAgICAgICAgdHlwZTogY2MuUHJlZmFiLFxyXG4gICAgICAgIH0sXHJcbiAgICAgICAgXHJcbiAgICAgICAgc2hvd0NQcmVmYWI6e1xyXG4gICAgICAgICAgICBkZWZhdWx0OiBbXSxcclxuICAgICAgICAgICAgdHlwZTogY2MuUHJlZmFiLFxyXG4gICAgICAgIH0sXHJcblxyXG4gICAgICAgIC8v562b6YCJ57G75Z6L77yM5LiJ56eN77yM5YiG5Yir5pivIOato+iQpe+8jOeogOacieW6pu+8jOazleWKm+a2iOiAl1xyXG4gICAgICAgIGZpbHRlclR5cGU6e1xyXG4gICAgICAgICAgICBkZWZhdWx0OiBbXSxcclxuICAgICAgICAgICAgdHlwZTogY2MuSW50ZWdlcixcclxuICAgICAgICB9LFxyXG4gICAgICAgIFxyXG4gICAgICAgIG1heERlY2tOdW06MCxcclxuXHJcbiAgICAgICAgY2FyZExpc3Q6Y2MuTm9kZSxcclxuICAgICAgICAvLyBmb286IHtcclxuICAgICAgICAvLyAgICBkZWZhdWx0OiBudWxsLCAgICAgIC8vIFRoZSBkZWZhdWx0IHZhbHVlIHdpbGwgYmUgdXNlZCBvbmx5IHdoZW4gdGhlIGNvbXBvbmVudCBhdHRhY2hpbmdcclxuICAgICAgICAvLyAgICAgICAgICAgICAgICAgICAgICAgICAgIHRvIGEgbm9kZSBmb3IgdGhlIGZpcnN0IHRpbWVcclxuICAgICAgICAvLyAgICB1cmw6IGNjLlRleHR1cmUyRCwgIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIHR5cGVvZiBkZWZhdWx0XHJcbiAgICAgICAgLy8gICAgc2VyaWFsaXphYmxlOiB0cnVlLCAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyB0cnVlXHJcbiAgICAgICAgLy8gICAgdmlzaWJsZTogdHJ1ZSwgICAgICAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyB0cnVlXHJcbiAgICAgICAgLy8gICAgZGlzcGxheU5hbWU6ICdGb28nLCAvLyBvcHRpb25hbFxyXG4gICAgICAgIC8vICAgIHJlYWRvbmx5OiBmYWxzZSwgICAgLy8gb3B0aW9uYWwsIGRlZmF1bHQgaXMgZmFsc2VcclxuICAgICAgICAvLyB9LFxyXG4gICAgICAgIC8vIC4uLlxyXG4gICAgfSxcclxuICAgIGZpbHRlclR5cGVTZWxlY3Q6ZnVuY3Rpb24oZXZlbnQsIGN1c3RvbUV2ZW50RGF0YSkge1xyXG4gICAgICAgIHRoaXMuZmlsdGVyVHlwZVtjdXN0b21FdmVudERhdGFbMF0gLSAnMCddID0gY3VzdG9tRXZlbnREYXRhWzFdIC0gJzAnO1xyXG4gICAgICAgIHRoaXMuY2FyZExpc3RTY3JpcHQucmVuZXdTaG93Q2FyZEdyb3VwKCk7XHJcbiAgICAgICAgY2MubG9nKHRoaXMuZmlsdGVyVHlwZSk7XHJcbiAgICB9LFxyXG4gICAgLy8gdXNlIHRoaXMgZm9yIGluaXRpYWxpemF0aW9uXHJcbiAgICBvbkxvYWQ6IGZ1bmN0aW9uICgpIHtcclxuICAgICAgICAvL3ZhciBkZWNrRGF0YXMgPSBHbG9iYWwuZGVja0RhdGE7XHJcbiAgICAgICAgLy9kZWNrRGF0YXMubWFnaWNEZWNrID0gWzEsMiwzXTtcclxuICAgICAgICB2YXIgZGVja0RhdGFzID0ge1xyXG4gICAgICAgICAgICBuYW1lOlwi5oiR55qE5Y2h57uEXCIsXHJcbiAgICAgICAgICAgIG51bTowLFxyXG4gICAgICAgICAgICBtYWdpY0RlY2s6e1xyXG4gICAgICAgICAgICAgICAgZGVmYXVsdDogW10sXHJcbiAgICAgICAgICAgICAgICB0eXBlOiBjYy5JbnRlZ2VyLFxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICBjcmVhdHVyZURlY2s6e1xyXG4gICAgICAgICAgICAgICAgZGVmYXVsdDpbXSxcclxuICAgICAgICAgICAgICAgIHR5cGU6IGNjLkludGVnZXIsXHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIC8v5Y2h57uE55qE57G75Z6LXHJcbiAgICAgICAgICAgIHR5cGU6IHtcclxuICAgICAgICAgICAgICAgIHR5cGU6IGNjLkVudW0oe1xyXG4gICAgICAgICAgICAgICAgICAgIC8v5bm75oOzXHJcbiAgICAgICAgICAgICAgICAgICAgLy/np5HlraZcclxuICAgICAgICAgICAgICAgICAgICBTY2llbmNlOiAwLFxyXG4gICAgICAgICAgICAgICAgICAgIEZhbnRhc3k6IDEsXHJcbiAgICAgICAgICAgICAgICAgICAgLy/mt7fmsoxcclxuICAgICAgICAgICAgICAgICAgICBDaGFvczogMixcclxuICAgICAgICAgICAgICAgIH0pLFxyXG4gICAgICAgICAgICAgICAgZGVmYXVsdDogMCxcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgdXNhYmxlOnRydWUsXHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICB0aGlzLmNhcmRMaXN0U2NyaXB0ID0gdGhpcy5jYXJkTGlzdC5nZXRDb21wb25lbnQoJ0NhcmRMaXN0Jyk7XHJcbiAgICAgICAgR2xvYmFsLnRvdGFsRGVja0RhdGEucHVzaChkZWNrRGF0YXMpO1xyXG4gICAgICAgIEdsb2JhbC50b3RhbERlY2tEYXRhW0dsb2JhbC5kZWNrVXNhZ2VdLm1hZ2ljRGVjayA9IHRoaXMubXlNRGVjaztcclxuICAgICAgICBHbG9iYWwudG90YWxEZWNrRGF0YVtHbG9iYWwuZGVja1VzYWdlXS5jcmVhdHVyZURlY2sgPSB0aGlzLm15Q0RlY2s7XHJcblxyXG4gICAgfSxcclxuXHJcbiAgICAvLyBjYWxsZWQgZXZlcnkgZnJhbWUsIHVuY29tbWVudCB0aGlzIGZ1bmN0aW9uIHRvIGFjdGl2YXRlIHVwZGF0ZSBjYWxsYmFja1xyXG4gICAgLy8gdXBkYXRlOiBmdW5jdGlvbiAoZHQpIHtcclxuXHJcbiAgICAvLyB9LFxyXG59KTtcclxuIiwiY2MuQ2xhc3Moe1xyXG4gICAgZXh0ZW5kczogY2MuQ29tcG9uZW50LFxyXG5cclxuICAgIHByb3BlcnRpZXM6IHtcclxuICAgICAgICAvL+mtlOazlea2iOiAl1xyXG4gICAgICAgIG1hbmFDb25zdW1lOiAwLFxyXG4gICAgICAgIC8v6a2U5rOV5raI6ICX5qCH562+XHJcbiAgICAgICAgbWFuYUNvbnN1bWVMYWJlbDogY2MuTGFiZWwsIFxyXG4gICAgICAgIFxyXG4gICAgICAgIC8v5Y2h54mH57G75Z6LXHJcbiAgICAgICAgY2FyZFR5cGU6IDAsICAgICAvLzDms5XmnK/niYzvvJsx55Sf54mp54mMIFxyXG4gICAgICAgIC8v5Y2h54mHSURcclxuICAgICAgICBjYXJkSUQ6IDAsXHJcblxyXG4gICAgICAgIC8v56iA5pyJ5bqmXHJcbiAgICAgICAgcmFyaXR5OntcclxuICAgICAgICAgICAgdHlwZTogY2MuRW51bSh7XHJcbiAgICAgICAgICAgICAgICBOOiAwLFxyXG4gICAgICAgICAgICAgICAgUjogMSxcclxuICAgICAgICAgICAgICAgIFNSOiAyLFxyXG4gICAgICAgICAgICAgICAgU1NSOiAzLFxyXG4gICAgICAgICAgICB9KSxcclxuICAgICAgICAgICAgZGVmYXVsdDogMCxcclxuICAgICAgICB9LFxyXG5cclxuICAgICAgICAvL+W8oOaVsFxyXG4gICAgICAgIG51bTogMCxcclxuICAgICAgICAvL+W8oOaVsOagh+etvlxyXG4gICAgICAgIG51bUxhYmVsOiBjYy5MYWJlbCxcclxuICAgICAgICBcclxuICAgICAgICAvL+WNoeeJh+WQjeensFxyXG4gICAgICAgIGNOYW1lOiBjYy5TdHJpbmcsXHJcbiAgICAgICAgLy/ljaHniYflkI3np7DnmoTmoIfnrb5cclxuICAgICAgICBjTmFtZUxhYmVsOiBjYy5MYWJlbCxcclxuICAgIH0sXHJcblxyXG4gICAgLy8gdXNlIHRoaXMgZm9yIGluaXRpYWxpemF0aW9uXHJcbiAgICBvbkxvYWQ6IGZ1bmN0aW9uICgpIHtcclxuICAgICAgICB0aGlzLmluaXQoKTtcclxuICAgIH0sXHJcbiAgICBcclxuICAgIGluaXQ6IGZ1bmN0aW9uKCl7XHJcbiAgICAgICAgdmFyIHNlbGYgPSB0aGlzO1xyXG4gICAgICAgIHNlbGYubWFuYUNvbnN1bWVMYWJlbC5zdHJpbmcgPSBzZWxmLm1hbmFDb25zdW1lO1xyXG4gICAgICAgIHNlbGYubnVtTGFiZWwuc3RyaW5nID0gJ1gnICsgc2VsZi5udW07XHJcbiAgICAgICAgc2VsZi5jTmFtZUxhYmVsLnN0cmluZyA9IHNlbGYuY05hbWU7XHJcbiAgICAgICAgdGhpcy5pbml0TW91c2VFdmVudCgpOyAgICAgICAgXHJcbiAgICB9LFxyXG4gICAgXHJcbiAgICBhZGp1c3RDb3VudDogZnVuY3Rpb24obnVtKXtcclxuICAgICAgICB0aGlzLm51bSA9IG51bTtcclxuICAgICAgICB0aGlzLm51bUxhYmVsLnN0cmluZyA9ICdYJyArIG51bTtcclxuICAgIH0sXHJcbiAgICBcclxuICAgIGluaXRNb3VzZUV2ZW50OmZ1bmN0aW9uKCl7XHJcbiAgICAgICAgdmFyIG5ld0luZm9Cb2FyZCA9IG51bGw7XHJcbiAgICAgICAgdGhpcy5ub2RlLm9uKGNjLk5vZGUuRXZlbnRUeXBlLk1PVVNFX0VOVEVSLHRoaXMuc2hvd0luZm8sIHRoaXMpO1xyXG4gICAgICAgIHRoaXMubm9kZS5vbihjYy5Ob2RlLkV2ZW50VHlwZS5NT1VTRV9MRUFWRSx0aGlzLmNsZWFuSW5mbywgdGhpcyk7XHJcbiAgICAgICAgdGhpcy5ub2RlLm9uKGNjLk5vZGUuRXZlbnRUeXBlLk1PVVNFX1VQLHRoaXMuYWRkQ2FyZHRvRGVjaywgdGhpcyk7XHJcblxyXG5cclxuICAgIH0sXHJcbiAgICBzaG93SW5mbzpmdW5jdGlvbigpe1xyXG4gICAgICAgIHZhciBldmVudHNlbmQgPSBuZXcgY2MuRXZlbnQuRXZlbnRDdXN0b20oJ3doZW5Nb3VzZUVudGVyVGhlTWluaUNhcmQnLHRydWUpO1xyXG4gICAgICAgIGV2ZW50c2VuZC5zZXRVc2VyRGF0YSh7aWQ6KHRoaXMuY2FyZElEKSx0eXBlSWQ6dGhpcy5jYXJkVHlwZSxjb3VudDp0aGlzLm51bSxjYXJkU2NyaXB0OnRoaXN9KTtcclxuICAgICAgICB0aGlzLm5vZGUuZGlzcGF0Y2hFdmVudChldmVudHNlbmQpO1xyXG4gICAgICAgIGNjLmxvZygnTW91c2VFbnRlclRoZU1pbmlDYXJkJyk7XHJcbiAgICB9LFxyXG4gICAgY2xlYW5JbmZvOmZ1bmN0aW9uKCl7XHJcbiAgICAgICAgdmFyIGV2ZW50c2VuZCA9IG5ldyBjYy5FdmVudC5FdmVudEN1c3RvbSgnd2hlbk1vdXNlTGVhdmVUaGVNaW5pQ2FyZCcsdHJ1ZSk7XHJcbiAgICAgICAgdGhpcy5ub2RlLmRpc3BhdGNoRXZlbnQoZXZlbnRzZW5kKTtcclxuICAgICAgICBjYy5sb2coJ01vdXNlTGVhdmVUaGVNaW5pQ2FyZCcpO1xyXG4gICAgfSxcclxuICAgIGFkZENhcmR0b0RlY2s6ZnVuY3Rpb24oKXtcclxuICAgICAgICB2YXIgZXZlbnRzZW5kID0gbmV3IGNjLkV2ZW50LkV2ZW50Q3VzdG9tKCd3aGVuTW91c2VVcFRoZU1pbmlDYXJkJyx0cnVlKTtcclxuICAgICAgICBldmVudHNlbmQuc2V0VXNlckRhdGEoe1xyXG4gICAgICAgICAgICBpZDp0aGlzLmNhcmRJRCxcclxuICAgICAgICAgICAgdHlwZUlkOnRoaXMuY2FyZFR5cGUsXHJcbiAgICAgICAgICAgIGNOYW1lOnRoaXMuY05hbWUsXHJcbiAgICAgICAgICAgIG1hbmFDb25zdW1lOnRoaXMubWFuYUNvbnN1bWUsXHJcbiAgICAgICAgICAgIG51bTp0aGlzLm51bSxcclxuICAgICAgICAgICAgY2FyZFNjcmlwdDp0aGlzXHJcbiAgICAgICAgfSk7XHJcbiAgICAgICAgY2MubG9nKCdNb3VzZVVwVGhlTWluaUNhcmQnKTtcclxuICAgICAgICB0aGlzLm5vZGUuZGlzcGF0Y2hFdmVudChldmVudHNlbmQpO1xyXG4gICAgfVxyXG4vLyBjYWxsZWQgZXZlcnkgZnJhbWUsIHVuY29tbWVudCB0aGlzIGZ1bmN0aW9uIHRvIGFjdGl2YXRlIHVwZGF0ZSBjYWxsYmFja1xyXG4gICAgLy8gdXBkYXRlOiBmdW5jdGlvbiAoZHQpIHtcclxuXHJcbiAgICAvLyB9LFxyXG59KTsiLCJ2YXIgR2xvYmFsID0gcmVxdWlyZSgnR2xvYmFsJyk7XHJcblxyXG5jYy5DbGFzcyh7XHJcbiAgICBleHRlbmRzOiBjYy5Db21wb25lbnQsXHJcblxyXG4gICAgcHJvcGVydGllczoge1xyXG5cclxuICAgICAgICBtYWluU2NlbmVNYW5hZ2VyOmNjLk5vZGUsXHJcbiAgICAgICAgY2FyZEJhZ051bUxhYmVsOmNjLkxhYmVsLFxyXG4gICAgICAgIGNhcmRPdXRMYXlvdXQ6Y2MuTm9kZVxyXG4gICAgICAgIC8vIGZvbzoge1xyXG4gICAgICAgIC8vICAgIGRlZmF1bHQ6IG51bGwsICAgICAgLy8gVGhlIGRlZmF1bHQgdmFsdWUgd2lsbCBiZSB1c2VkIG9ubHkgd2hlbiB0aGUgY29tcG9uZW50IGF0dGFjaGluZ1xyXG4gICAgICAgIC8vICAgICAgICAgICAgICAgICAgICAgICAgICAgdG8gYSBub2RlIGZvciB0aGUgZmlyc3QgdGltZVxyXG4gICAgICAgIC8vICAgIHVybDogY2MuVGV4dHVyZTJELCAgLy8gb3B0aW9uYWwsIGRlZmF1bHQgaXMgdHlwZW9mIGRlZmF1bHRcclxuICAgICAgICAvLyAgICBzZXJpYWxpemFibGU6IHRydWUsIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIHRydWVcclxuICAgICAgICAvLyAgICB2aXNpYmxlOiB0cnVlLCAgICAgIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIHRydWVcclxuICAgICAgICAvLyAgICBkaXNwbGF5TmFtZTogJ0ZvbycsIC8vIG9wdGlvbmFsXHJcbiAgICAgICAgLy8gICAgcmVhZG9ubHk6IGZhbHNlLCAgICAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyBmYWxzZVxyXG4gICAgICAgIC8vIH0sXHJcbiAgICAgICAgLy8gLi4uXHJcbiAgICB9LFxyXG5cclxuICAgIC8vIHVzZSB0aGlzIGZvciBpbml0aWFsaXphdGlvblxyXG4gICAgb25Mb2FkOiBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgdGhpcy5tYWluU2NlbmVTY3JpcHQgPSB0aGlzLm1haW5TY2VuZU1hbmFnZXIuZ2V0Q29tcG9uZW50KFwiTWFpblNjZW5lTWFuYWdlclwiKTtcclxuICAgICAgICB0aGlzLnJlbmV3QmFncygpO1xyXG4gICAgfSxcclxuICAgIC8qKlxyXG4gICAgICogQO+/ve+/vdKq77+977+977+977+9IO+/ve+/ve+/ve+/vdK777+977+977+977+977+977+9XHJcbiAgICAgKiBAYXV0aG9yIEMxNFxyXG4gICAgICogQERhdGUgMjAxNy8xMi8yMVxyXG4gICAgICogQHBhcmFtZXRlcnNcclxuICAgICAqIEByZXR1cm5zXHJcbiAgICAgKi9cclxuICAgIG9wZW5CYWc6ZnVuY3Rpb24oKXtcclxuICAgICAgICB2YXIgcmFuZCA9IDA7XHJcbiAgICAgICAgdmFyIGNhcmQgPSBudWxsO1xyXG4gICAgICAgIHZhciBkYXQgPSAwO1xyXG4gICAgICAgIHRoaXMuY2FyZE91dExheW91dC5yZW1vdmVBbGxDaGlsZHJlbigpO1xyXG4gICAgICAgIGlmKHRoaXMubWFpblNjZW5lU2NyaXB0LmJhZ3MgPiAwKXtcclxuICAgICAgICAgICAgdGhpcy5tYWluU2NlbmVTY3JpcHQuYmFncyAtLTtcclxuICAgICAgICAgICAgdGhpcy5yZW5ld0JhZ3MoKTtcclxuICAgICAgICAgICAgZm9yKHZhciBpID0gMDtpIDwgNTtpKyspe1xyXG4gICAgICAgICAgICAgICAgcmFuZCA9IHRoaXMucmFuZG9tQ2FyZCgpO1xyXG4gICAgICAgICAgICAgICAgaWYocmFuZCA8IHRoaXMubWFpblNjZW5lU2NyaXB0Lm1pbmlNYWdpY1ByZWZhYi5sZW5ndGgpe1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMubWFpblNjZW5lU2NyaXB0Lm15TUNhcmRzW3JhbmRdICsrO1xyXG4gICAgICAgICAgICAgICAgICAgIGNhcmQgPSBjYy5pbnN0YW50aWF0ZSh0aGlzLm1haW5TY2VuZVNjcmlwdC5taW5pTWFnaWNQcmVmYWJbcmFuZF0pO1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuY2FyZE91dExheW91dC5hZGRDaGlsZChjYXJkKTtcclxuICAgICAgICAgICAgICAgIH1lbHNle1xyXG5cclxuICAgICAgICAgICAgICAgICAgICBkYXQgPSByYW5kIC0gdGhpcy5tYWluU2NlbmVTY3JpcHQubWluaU1hZ2ljUHJlZmFiLmxlbmd0aDtcclxuICAgICAgICAgICAgICAgICAgICBjYy5sb2coZGF0KTtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLm1haW5TY2VuZVNjcmlwdC5teUNDYXJkc1tkYXRdICsrO1xyXG4gICAgICAgICAgICAgICAgICAgIHZhciBjYXJkMiA9IGNjLmluc3RhbnRpYXRlKHRoaXMubWFpblNjZW5lU2NyaXB0Lm1pbmlDcmVhdHVyZVByZWZhYltkYXRdKTtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLmNhcmRPdXRMYXlvdXQuYWRkQ2hpbGQoY2FyZDIpO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgfSxcclxuXHJcbiAgICAvKipcclxuICAgICAqIEDvv73vv73Squ+/ve+/ve+/ve+/vSDvv73vv73vv73vv73Su++/ve+/ve+/ve+/ve+/ve+/ve+/ve+/vVxyXG4gICAgICogQGF1dGhvciBDMTRcclxuICAgICAqIEBEYXRlIDIwMTcvMTIvMjFcclxuICAgICAqIEBwYXJhbWV0ZXJzXHJcbiAgICAgKiBAcmV0dXJuc1xyXG4gICAgICovXHJcbiAgICByYW5kb21DYXJkOmZ1bmN0aW9uKCl7XHJcbiAgICAgICAgdmFyIG51bSA9IDA7XHJcbiAgICAgICAgbnVtID0gIE1hdGguZmxvb3IoTWF0aC5yYW5kb20oKSAqICh0aGlzLm1haW5TY2VuZVNjcmlwdC5taW5pTWFnaWNQcmVmYWIubGVuZ3RoXHJcbiAgICAgICAgICAgICsgdGhpcy5tYWluU2NlbmVTY3JpcHQubWluaUNyZWF0dXJlUHJlZmFiLmxlbmd0aCkpO1xyXG4gICAgICAgIHJldHVybiBudW07XHJcbiAgICB9LFxyXG4gICAgLyoqXHJcbiAgICAgKiBA77+977+90qrvv73vv73vv73vv70g77+977+977+977+9MTDvv73vv73vv73vv71cclxuICAgICAqIEBhdXRob3IgQzE0XHJcbiAgICAgKiBARGF0ZSAyMDE3LzEyLzIxXHJcbiAgICAgKiBAcGFyYW1ldGVyc1xyXG4gICAgICogQHJldHVybnNcclxuICAgICAqL1xyXG4gICAgYWRkQmFnczpmdW5jdGlvbigpe1xyXG4gICAgICAgIHRoaXMubWFpblNjZW5lU2NyaXB0LmJhZ3MgKz0gMTA7XHJcbiAgICAgICAgdGhpcy5yZW5ld0JhZ3MoKTtcclxuICAgIH0sXHJcbiAgICByZW5ld0JhZ3M6ZnVuY3Rpb24oKXtcclxuICAgICAgICB0aGlzLmNhcmRCYWdOdW1MYWJlbC5zdHJpbmcgPSAnYmFnczonICsgdGhpcy5tYWluU2NlbmVTY3JpcHQuYmFncztcclxuICAgIH1cclxuICAgIC8vIGNhbGxlZCBldmVyeSBmcmFtZSwgdW5jb21tZW50IHRoaXMgZnVuY3Rpb24gdG8gYWN0aXZhdGUgdXBkYXRlIGNhbGxiYWNrXHJcbiAgICAvLyB1cGRhdGU6IGZ1bmN0aW9uIChkdCkge1xyXG5cclxuICAgIC8vIH0sXHJcbn0pO1xyXG4iLCJ2YXIgZ2xvYmFsQ29uc3RhbnQgPSByZXF1aXJlKFwiQ29uc3RhbnRcIik7XHJcblxyXG5jYy5DbGFzcyh7XHJcbiAgICBleHRlbmRzOiBjYy5Db21wb25lbnQsXHJcblxyXG4gICAgcHJvcGVydGllczoge1xyXG5cclxuICAgICAgICAvLyDkuLvop5Lot7Pot4Ppq5jluqZcclxuICAgICAgICBqdW1wSGVpZ2h0OiAwLFxyXG4gICAgICAgIC8vIOS4u+inkui3s+i3g+aMgee7reaXtumXtFxyXG4gICAgICAgIGp1bXBEdXJhdGlvbjogMCxcclxuICAgICAgICAvLyDmnIDlpKfnp7vliqjpgJ/luqZcclxuICAgICAgICBtYXhNb3ZlU3BlZWQ6IDAsXHJcbiAgICAgICAgLy8g5bCE5Ye65a2Q5by5XHJcbiAgICAgICAgbGF1bmNoQnV0dG9uOiBjYy5QcmVmYWIsXHJcbiAgICAgICAgLy/nlJ/lkb3lgLxcclxuICAgICAgICBoZWFsdGg6IDAsXHJcbiAgICAgICAgLy/nlJ/lkb3lgLxcclxuICAgICAgICBtYXhIZWFsdGg6IDAsXHJcbiAgICAgICAgLy/nlJ/lkb3lgLzmoIfnrb5cclxuICAgICAgICBoZWFsdGhMYWJlbDogY2MuTGFiZWwsICAgICAgICBcclxuICAgICAgICAvL+WNleS9jVxyXG4gICAgICAgIGJvZHk6IGNjLk5vZGUsXHJcbiAgICAgICAgLy/ok53mgaLlpI3pgJ/luqZcclxuICAgICAgICBtYW5hUmVjb3ZlclNwZWVkSzogMCxcclxuICAgICAgICAvL+acgOWkp+iTnemHj1xyXG4gICAgICAgIG1heE1hbmE6IDAsXHJcbiAgICAgICAgLy/ogJfok51cclxuICAgICAgICBtYW5hVXNlOiAwLFxyXG4gICAgICAgIC8v6Zif5LyNXHJcbiAgICAgICAgdGVhbTogMCxcclxuICAgICAgICAvL+atu+S6oVxyXG4gICAgICAgIGRlYXRoOiBmYWxzZSxcclxuXHJcbiAgICAgICAgLy/oh6rmiJFcclxuICAgICAgICBzZWxmOnRydWUsXHJcbiAgICAgICAgLy/mmK/lkKbkvb9BSVxyXG4gICAgICAgIGFpOmZhbHNlLFxyXG4gICAgICAgIC8v6IO95ZCm56e75YqoXHJcbiAgICAgICAgbW92YWJsZTp0cnVlLFxyXG5cclxuICAgICAgICBtYWluR2FtZU1hbmFnZXI6Y2MuTm9kZSxcclxuICAgICAgICBnYW1lTWFuYWdlcjpjYy5Ob2RlLFxyXG4gICAgICAgIGNhbWVyYUNvbnRyb2w6Y2MuTm9kZSxcclxuXHJcbiAgICAgICAgZHJhd0NhcmROb2RlOmNjLk5vZGUsXHJcbiAgICAgICAgLy/oi7Hpm4TnmoTmiYvniYxcclxuICAgICAgICBoYW5kQ2FyZDpbY2MuTm9kZV0sXHJcbiAgICB9LFxyXG4gICAgLy8gdXNlIHRoaXMgZm9yIGluaXRpYWxpemF0aW9uXHJcbiAgICBvbkxvYWQ6IGZ1bmN0aW9uICgpIHtcclxuXHJcbiAgICAgICAgdGhpcy5kcmF3Q2FyZFNjcmlwdCA9IHRoaXMuZHJhd0NhcmROb2RlLmdldENvbXBvbmVudChcIkRyYXdDYXJkXCIpO1xyXG5cclxuICAgICAgICB0aGlzLm5ldHdvcmtTY3JpcHQgPSB0aGlzLm1haW5HYW1lTWFuYWdlci5nZXRDb21wb25lbnQoXCJuZXR3b3JrXCIpO1xyXG4gICAgICAgIC8vIOWIneWni+WMlui3s+i3g+WKqOS9nFxyXG4gICAgICAgIHRoaXMuanVtcEFjdGlvbiA9IHRoaXMuc2V0SnVtcEFjdGlvbigpO1xyXG4gICAgICAgIC8vdGhpcy5ub2RlLnJ1bkFjdGlvbih0aGlzLmp1bXBBY3Rpb24pO1xyXG4gICAgICAgIHRoaXMuY2FtZXJhQ29udHJvbFNjcmlwdCA9IHRoaXMuY2FtZXJhQ29udHJvbC5nZXRDb21wb25lbnQoJ0NhbWVyYUNvbnRyb2wnKTtcclxuXHJcbiAgICAgICAgdGhpcy5kZWF0aFRpbWVzID0gMDtcclxuICAgICAgICAvLyDliqDpgJ/luqbmlrnlkJHlvIDlhbNcclxuICAgICAgICB0aGlzLmFjY0xlZnQgPSBmYWxzZTtcclxuICAgICAgICB0aGlzLmFjY1JpZ2h0ID0gZmFsc2U7XHJcbiAgICAgICAgLy8g5Li76KeS5b2T5YmN5rC05bmz5pa55ZCR6YCf5bqmXHJcbiAgICAgICAgdGhpcy54U3BlZWQgPSAwO1xyXG4gICAgICAgIHRoaXMuaXNDYW5KdW1wID0gdHJ1ZTtcclxuXHJcbiAgICAgICAgaWYodGhpcy5haSA9PT0gdHJ1ZSl7XHJcbiAgICAgICAgICAgIHRoaXMuc2NoZWR1bGUoZnVuY3Rpb24oKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmFjY0xlZnQgPSB0cnVlO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5hY2NSaWdodCA9IGZhbHNlO1xyXG4gICAgICAgICAgICB9LDIpO1xyXG4gICAgICAgICAgICB0aGlzLnNjaGVkdWxlKGZ1bmN0aW9uKCkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5hY2NMZWZ0ID0gZmFsc2U7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmFjY1JpZ2h0ID0gdHJ1ZTtcclxuICAgICAgICAgICAgfSwzKTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIC8v5Yid5aeL6JOdXHJcbiAgICAgICAgdGhpcy5tYW5hID0gMDtcclxuICAgICAgICBpZiAodGhpcy5zZWxmID09PSB0cnVlKSB7XHJcbiAgICAgICAgLy8g5Yid5aeL5YyW6ZSu55uY6L6T5YWl55uR5ZCsXHJcbiAgICAgICAgdGhpcy5zZXRJbnB1dENvbnRyb2woKTtcclxuICAgICAgICAvL3RoaXMuX3Bvb2wgPSBuZXcgY2MuTm9kZVBvb2woJ1Bvb2xIYW5kbGVyJyk7XHJcbiAgICAgICAgfVxyXG4gICAgfSxcclxuICAgIC8v5oq95Y+WWOW8oOeJjFxyXG4gICAgZHJhd0NhcmQ6ZnVuY3Rpb24oeCl7XHJcbiAgICAgICAgLy/mir3niYzlvqrnjq9cclxuICAgICAgICBmb3IodmFyIGkgPSAwO2kgPCB4O2krKykge1xyXG4gICAgICAgICAgICB0aGlzLmRyYXdDYXJkU2NyaXB0LmNyZWF0Q2FyZFR5cGUoKTtcclxuICAgICAgICB9XHJcbiAgICB9LFxyXG4gICAgdXBkYXRlOiBmdW5jdGlvbiAoZHQpIHtcclxuICAgICAgICAvL+WkhOeQhljovbTnmoTpgJ/luqZcclxuICAgICAgICBpZiAodGhpcy5hY2NMZWZ0ID09PSB0aGlzLmFjY1JpZ2h0KSB7Ly/lt6blj7PplK7lkIzml7bmjInmiJbkuI3mjInvvIzliJnkuI3liqhcclxuICAgICAgICAgICAgdGhpcy54U3BlZWQgPSAwO1xyXG4gICAgICAgIH0gZWxzZSBpZiAodGhpcy5hY2NMZWZ0ID09PSB0cnVlKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmJvZHkuc2NhbGVYID0gLTE7XHJcbiAgICAgICAgICAgIHRoaXMueFNwZWVkID0gLXRoaXMubWF4TW92ZVNwZWVkOy8v5ZCR5bemXHJcbiAgICAgICAgICAgIGlmKHRoaXMuc2VsZiA9PT0gdHJ1ZSlcclxuICAgICAgICAgICAgdGhpcy5jYW1lcmFDb250cm9sU2NyaXB0LnRhcmdldCA9IHRoaXMuY2FtZXJhQ29udHJvbFNjcmlwdC50YXJnZXRzWzBdO1xyXG4gICAgICAgIH0gZWxzZSBpZiAodGhpcy5hY2NSaWdodCA9PT0gdHJ1ZSkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5ib2R5LnNjYWxlWCA9IDE7XHJcbiAgICAgICAgICAgIHRoaXMueFNwZWVkID0gdGhpcy5tYXhNb3ZlU3BlZWQ7Ly/lkJHlj7NcclxuICAgICAgICAgICAgaWYodGhpcy5zZWxmID09PSB0cnVlKVxyXG4gICAgICAgICAgICB0aGlzLmNhbWVyYUNvbnRyb2xTY3JpcHQudGFyZ2V0ID0gdGhpcy5jYW1lcmFDb250cm9sU2NyaXB0LnRhcmdldHNbMF07XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlmKDAgPiB0aGlzLm5vZGUueCl7XHJcbiAgICAgICAgICAgIHRoaXMubm9kZS54ID0gMDtcclxuICAgICAgICB9XHJcbiAgICAgICAgaWYodGhpcy5ub2RlLnggPiBjYy5kaXJlY3Rvci5nZXRXaW5TaXplKCkud2lkdGggKiBnbG9iYWxDb25zdGFudC5zY2VuZVdpZHRoKXtcclxuICAgICAgICAgICAgdGhpcy5ub2RlLnggPSBjYy5kaXJlY3Rvci5nZXRXaW5TaXplKCkud2lkdGggKiBnbG9iYWxDb25zdGFudC5zY2VuZVdpZHRoO1xyXG4gICAgICAgIH1cclxuICAgICAgICBpZih0aGlzLmRlYXRoID09PSBmYWxzZSAmJiAwIDw9IHRoaXMubm9kZS54ICYmIHRoaXMubm9kZS54IDw9IGNjLmRpcmVjdG9yLmdldFdpblNpemUoKS53aWR0aCAqIGdsb2JhbENvbnN0YW50LnNjZW5lV2lkdGgpIHtcclxuICAgICAgICAgICAgLy8g5qC55o2u5b2T5YmN6YCf5bqm5pu05paw5Li76KeS55qE5L2N572uXHJcbiAgICAgICAgICAgIHRoaXMubm9kZS54ICs9IHRoaXMueFNwZWVkO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgaWYgKHRoaXMubWFuYSA8IHRoaXMubWF4TWFuYSl7XHJcbiAgICAgICAgICAgIHRoaXMubWFuYSArPSB0aGlzLm1hbmFSZWNvdmVyU3BlZWRLICogTWF0aC5zcXJ0KDEgLSB0aGlzLm1hbmEgLyB0aGlzLm1heE1hbmEpICogZHQ7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgdGhpcy5tYW5hID0gdGhpcy5tYXhNYW5hO1xyXG4gICAgICAgIH1cclxuICAgICAgICBcclxuICAgICAgICB0aGlzLmhlYWx0aExhYmVsLnN0cmluZyA9IHRoaXMuaGVhbHRoLnRvRml4ZWQoMCk7XHJcbiAgICAgICAgLy90aGlzLm1hbmFCYXIucHJvZ3Jlc3MgPSB0aGlzLm1hbmEgLyB0aGlzLm1heE1hbmE7XHJcbiAgICAgICAgLy90aGlzLm1hbmFMYWJlbC5zdHJpbmcgPSB0aGlzLm1hbmEudG9GaXhlZCgwKSArIFwiL1wiICsgdGhpcy5tYXhNYW5hLnRvRml4ZWQoMCk7XHJcbiAgICB9LFxyXG4gICAgXHJcbiAgICBzZXRKdW1wQWN0aW9uOiBmdW5jdGlvbigpe1xyXG4gICAgICAgIHZhciBqdW1wVXAgPSBjYy5tb3ZlQnkodGhpcy5qdW1wRHVyYXRpb24sIGNjLnAoMCwgdGhpcy5qdW1wSGVpZ2h0KSkuZWFzaW5nKGNjLmVhc2VDdWJpY0FjdGlvbk91dCgpKTtcclxuICAgICAgICB2YXIganVtcERvd24gPSBjYy5tb3ZlQnkodGhpcy5qdW1wRHVyYXRpb24sIGNjLnAoMCwgLXRoaXMuanVtcEhlaWdodCkpLmVhc2luZyhjYy5lYXNlQ3ViaWNBY3Rpb25JbigpKTtcclxuICAgICAgICBcclxuICAgICAgICByZXR1cm4gY2MucmVwZWF0Rm9yZXZlcihjYy5zZXF1ZW5jZShqdW1wVXAsIGp1bXBEb3duKSk7XHJcbiAgICB9LFxyXG4gICAgXHJcbiAgICBvbmNlSnVtcEFjaXRvbjogZnVuY3Rpb24oKSB7XHJcbiAgICAgICAgdmFyIHNlbGYgPSB0aGlzO1xyXG4gICAgICAgIHZhciBqdW1wVXAgPSBjYy5tb3ZlQnkoc2VsZi5qdW1wRHVyYXRpb24sIGNjLnAoMCwgc2VsZi5qdW1wSGVpZ2h0KSkuZWFzaW5nKGNjLmVhc2VDdWJpY0FjdGlvbk91dCgpKTtcclxuICAgICAgICB2YXIganVtcERvd24gPSBjYy5tb3ZlQnkoc2VsZi5qdW1wRHVyYXRpb24sIGNjLnAoMCwgLXNlbGYuanVtcEhlaWdodCkpLmVhc2luZyhjYy5lYXNlQ3ViaWNBY3Rpb25JbigpKTtcclxuICAgICAgICBcclxuICAgICAgICBzZWxmLm5vZGUucnVuQWN0aW9uKGNjLnNlcXVlbmNlKGp1bXBVcCwganVtcERvd24sXHJcbiAgICAgICAgY2MuY2FsbEZ1bmMoZnVuY3Rpb24oKXtzZWxmLmlzQ2FuSnVtcCA9IHRydWU7fSkpKTtcclxuICAgICAgICBcclxuICAgIH0sXHJcbiAgICBcclxuICAgIGNoYW5nZUhlYWx0aDogZnVuY3Rpb24odmFsdWUpe1xyXG5cdCAgICBpZih0aGlzLmhlYWx0aCArIHZhbHVlID4gMCl7XHJcblx0XHQgICAgdGhpcy5oZWFsdGggPSB0aGlzLmhlYWx0aCArIHZhbHVlO1xyXG5cdCAgICB9ZWxzZSBpZih0aGlzLmRlYXRoID09PSBmYWxzZSl7XHJcbiAgICAgICAgICAgIHRoaXMuaGVhbHRoID0gMDtcclxuICAgICAgICAgICAgdGhpcy5kZWF0aCA9IHRydWU7XHJcblx0ICAgIH1cclxuICAgICAgICByZXR1cm4gdGhpcy5kZWF0aDtcclxuICAgIH0sXHJcblxyXG4gICAgcmVsZWFzZVRhcmdldDpmdW5jdGlvbigpe1xyXG4gICAgICAgIGlmKHRoaXMuZGVhdGhUaW1lcyA8IDMpIHtcclxuICAgICAgICAgICAgdGhpcy5kZWF0aFRpbWVzICsrO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgdmFyIGV2ZW50c2VuZCA9IG5ldyBjYy5FdmVudC5FdmVudEN1c3RvbSgnaGVyb0RlYXRoJyx0cnVlKTtcclxuICAgICAgICBldmVudHNlbmQuc2V0VXNlckRhdGEoe2hlcm9TY3JpcHQ6dGhpc30pO1xyXG4gICAgICAgIHRoaXMubm9kZS5kaXNwYXRjaEV2ZW50KGV2ZW50c2VuZCk7XHJcbiAgICB9LFxyXG4gICAgLy/lpI3mtLvoi7Hpm4RcclxuICAgIHJlbGl2ZTpmdW5jdGlvbigpe1xyXG4gICAgICAgIC8vWeWdkOagh+S4uiAtODVcclxuICAgICAgICB0aGlzLm5vZGUueSA9IC04NTtcclxuICAgICAgICAvL+mAj+aYjuW6plxyXG4gICAgICAgIHRoaXMubm9kZS5vcGFjaXR5ID0gMTAwMDtcclxuICAgICAgICB0aGlzLmhlYWx0aCA9IHRoaXMubWF4SGVhbHRoO1xyXG4gICAgICAgIHRoaXMuZGVhdGggPSBmYWxzZTtcclxuICAgIH0sXHJcblxyXG4gICAgc2VuZE1vdmVNZXNzYWdlOmZ1bmN0aW9uKCl7XHJcbiAgICAgICAgdmFyIHNlbGYgPSB0aGlzO1xyXG4gICAgICAgIHNlbGYubmV0d29ya1NjcmlwdC5yb29tTXNnKCdyb29tQ2hhdCcsIHtcclxuICAgICAgICAgICAgbmFtZTogXCJlbmVteU1vdmVcIixcclxuICAgICAgICAgICAgZGV0YWlsOiB7XHJcbiAgICAgICAgICAgICAgICBhY2NMZWZ0OiBzZWxmLmFjY0xlZnQsXHJcbiAgICAgICAgICAgICAgICBhY2NSaWdodDogc2VsZi5hY2NSaWdodCxcclxuICAgICAgICAgICAgICAgIGhlYWx0aDpzZWxmLmhlYWx0aCxcclxuICAgICAgICAgICAgICAgIHg6c2VsZi5ub2RlLnhcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0pXHJcbiAgICB9LFxyXG4gICAgc2V0SW5wdXRDb250cm9sOiBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgdmFyIHNlbGYgPSB0aGlzO1xyXG4gICAgICAgIC8vIOa3u+WKoOmUruebmOS6i+S7tuebkeWQrFxyXG4gICAgICAgIGNjLmV2ZW50TWFuYWdlci5hZGRMaXN0ZW5lcih7XHJcbiAgICAgICAgICAgIGV2ZW50OiBjYy5FdmVudExpc3RlbmVyLktFWUJPQVJELFxyXG4gICAgICAgICAgICAvLyDmnInmjInplK7mjInkuIvml7bvvIzliKTmlq3mmK/lkKbmmK/miJHku6zmjIflrprnmoTmlrnlkJHmjqfliLbplK7vvIzlubborr7nva7lkJHlr7nlupTmlrnlkJHliqDpgJ9cclxuICAgICAgICAgICAgb25LZXlQcmVzc2VkOiBmdW5jdGlvbihrZXlDb2RlLCBldmVudCkge1xyXG4gICAgICAgICAgICAgICAgc3dpdGNoKGtleUNvZGUpIHtcclxuICAgICAgICAgICAgICAgICAgICBjYXNlIGNjLktFWS5hOlxyXG4gICAgICAgICAgICAgICAgICAgIGNhc2UgY2MuS0VZLmxlZnQ6XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vY2MubG9nKHNlbGYuZGVhdGgpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc2VsZi5hY2NMZWZ0ID0gdHJ1ZTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNlbGYuc2VuZE1vdmVNZXNzYWdlKCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjYy5sb2coc2VsZi5ub2RlLnggKyBcIljlnZDmoIfvvIxZ5Z2Q5qCH77yaXCIgKyBzZWxmLm5vZGUueSArIFwi6YCP5piOXCIgKyBzZWxmLm5vZGUub3BhY2l0eSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vIHNlbGYuYWNjUmlnaHQgPSBmYWxzZTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgICAgICAgICAgY2FzZSBjYy5LRVkuZDpcclxuICAgICAgICAgICAgICAgICAgICBjYXNlIGNjLktFWS5yaWdodDpcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIHNlbGYuYWNjTGVmdCA9IGZhbHNlO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc2VsZi5hY2NSaWdodCA9IHRydWU7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZWxmLnNlbmRNb3ZlTWVzc2FnZSgpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgICAgICAgICBjYXNlIGNjLktFWS53OlxyXG4gICAgICAgICAgICAgICAgICAgIGNhc2UgY2MuS0VZLnVwOlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoc2VsZi5pc0Nhbkp1bXApe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc2VsZi5pc0Nhbkp1bXAgPSBmYWxzZTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNlbGYub25jZUp1bXBBY2l0b24oKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgICAgICAgICBjYXNlIGNjLktFWS5qOlxyXG4gICAgICAgICAgICAgICAgICAgIGNhc2UgY2MuS0VZLno6XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChzZWxmLm1hbmEgPj0gc2VsZi5tYW5hVXNlKXtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNlbGYubWFuYSAtPSBzZWxmLm1hbmFVc2U7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZWxmLmdlbmVyYXRlTm9kZSgpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAvLyDmnb7lvIDmjInplK7ml7bvvIzlgZzmraLlkJHor6XmlrnlkJHnmoTliqDpgJ9cclxuICAgICAgICAgICAgb25LZXlSZWxlYXNlZDogZnVuY3Rpb24oa2V5Q29kZSwgZXZlbnQpIHtcclxuICAgICAgICAgICAgICAgIHN3aXRjaChrZXlDb2RlKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgY2FzZSBjYy5LRVkuYTpcclxuICAgICAgICAgICAgICAgICAgICBjYXNlIGNjLktFWS5sZWZ0OlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBzZWxmLmFjY0xlZnQgPSBmYWxzZTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgc2VsZi5zZW5kTW92ZU1lc3NhZ2UoKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgICAgICAgICAgY2FzZSBjYy5LRVkuZDpcclxuICAgICAgICAgICAgICAgICAgICBjYXNlIGNjLktFWS5yaWdodDpcclxuICAgICAgICAgICAgICAgICAgICAgICAgc2VsZi5hY2NSaWdodCA9IGZhbHNlO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBzZWxmLnNlbmRNb3ZlTWVzc2FnZSgpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0sIHNlbGYubm9kZSk7XHJcbiAgICB9LFxyXG5cclxuICAgIC8vIOWIpOaWremtlOazleaYr+WQpui2s+Wkn1xyXG4gICAgY2hlY2tNYW5hOiBmdW5jdGlvbihjb3N0KSB7XHJcbiAgICAgICAgdmFyIHNlbGYgPSB0aGlzO1xyXG4gICAgICAgIHJldHVybiAoY29zdCA8PSBzZWxmLm1hbmEpO1xyXG4gICAgfSxcclxuICAgIFxyXG4gICAgZ2VuZXJhdGVOb2RlOiBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgdmFyIG1vbnN0ZXIgPSB0aGlzLl9wb29sLmdldCgpO1xyXG4gICAgICAgIGlmICghbW9uc3Rlcikge1xyXG4gICAgICAgICAgICBtb25zdGVyID0gY2MuaW5zdGFudGlhdGUodGhpcy5sYXVuY2hCdXR0b24pO1xyXG4gICAgICAgIFxyXG4gICAgICAgICAgICAvLyBBZGQgcG9vbCBoYW5kbGVyIGNvbXBvbmVudCB3aGljaCB3aWxsIGNvbnRyb2wgdGhlIHRvdWNoIGV2ZW50XHJcbiAgICAgICAgICAgIG1vbnN0ZXIuYWRkQ29tcG9uZW50KCdQb29sSGFuZGxlcicpO1xyXG4gICAgICAgIH1cclxuICAgICAgICBtb25zdGVyLnggPSB0aGlzLm5vZGUueDtcclxuICAgICAgICBtb25zdGVyLnkgPSB0aGlzLm5vZGUueTtcclxuICAgICAgICBcclxuICAgICAgICB2YXIgZHggPSBtb25zdGVyLmdldENvbXBvbmVudCgnRmlyZScpLmZseURpc3RhbmNlICogdGhpcy5ib2R5LnNjYWxlWDtcclxuICAgICAgICB2YXIgZHkgPSAwO1xyXG4gICAgICAgIFxyXG4gICAgICAgIGNvbnNvbGUubG9nKGR4LCBkeSk7XHJcbiAgICAgICAgXHJcbiAgICAgICAgbW9uc3Rlci5ydW5BY3Rpb24oY2Muc2VxdWVuY2UoXHJcbiAgICAgICAgICAgIGNjLm1vdmVCeShtb25zdGVyLmdldENvbXBvbmVudCgnRmlyZScpLmZseURpc3RhbmNlIC8gbW9uc3Rlci5nZXRDb21wb25lbnQoJ0ZpcmUnKS5mbHlTcGVlZCwgZHgsIGR5KSxcclxuICAgICAgICAgICAgY2MuY2FsbEZ1bmModGhpcy5yZW1vdmVOb2RlLCB0aGlzLCBtb25zdGVyKVxyXG4gICAgICAgICkpO1xyXG4gICAgICAgIFxyXG4gICAgICAgIHRoaXMubm9kZS5wYXJlbnQuYWRkQ2hpbGQobW9uc3Rlcik7XHJcbiAgICB9LFxyXG4gICAgXHJcbiAgICByZW1vdmVOb2RlOiBmdW5jdGlvbiAoc2VuZGVyLCBtb25zdGVyKSB7XHJcbiAgICAgICAgdGhpcy5fcG9vbC5wdXQobW9uc3Rlcik7XHJcbiAgICB9XHJcblxyXG4gICAgLy8gY2FsbGVkIGV2ZXJ5IGZyYW1lLCB1bmNvbW1lbnQgdGhpcyBmdW5jdGlvbiB0byBhY3RpdmF0ZSB1cGRhdGUgY2FsbGJhY2tcclxuXHJcbn0pO1xyXG4iLCJmdW5jdGlvbiBwYXVzZXJlc3VtZSAoKSB7XHJcbiAgICBpZiAodGhpcy5wYXVzZWQpIHtcclxuICAgICAgICBjYy5kaXJlY3Rvci5nZXRBY3Rpb25NYW5hZ2VyKCkucmVzdW1lVGFyZ2V0KHRoaXMpO1xyXG4gICAgfVxyXG4gICAgZWxzZSB7IFxyXG4gICAgICAgIGNjLmRpcmVjdG9yLmdldEFjdGlvbk1hbmFnZXIoKS5wYXVzZVRhcmdldCh0aGlzKTtcclxuICAgIH1cclxuICAgIHRoaXMucGF1c2VkID0gIXRoaXMucGF1c2VkO1xyXG59XHJcblxyXG5jYy5DbGFzcyh7XHJcbiAgICBleHRlbmRzOiBjYy5Db21wb25lbnQsXHJcblxyXG4gICAgcHJvcGVydGllczoge1xyXG4gICAgfSxcclxuICAgIFxyXG4gICAgb25Mb2FkOiBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgdGhpcy5ub2RlLnBhdXNlZCA9IGZhbHNlO1xyXG4gICAgICAgIHRoaXMubm9kZS5vbihjYy5Ob2RlLkV2ZW50VHlwZS5UT1VDSF9FTkQsIHBhdXNlcmVzdW1lLCB0aGlzLm5vZGUpO1xyXG4gICAgfSxcclxuICAgIFxyXG4gICAgdW51c2U6IGZ1bmN0aW9uICgpIHtcclxuICAgICAgICB0aGlzLm5vZGUub2ZmKGNjLk5vZGUuRXZlbnRUeXBlLlRPVUNIX0VORCwgcGF1c2VyZXN1bWUsIHRoaXMubm9kZSk7XHJcbiAgICB9LFxyXG4gICAgXHJcbiAgICByZXVzZTogZnVuY3Rpb24gKCkge1xyXG4gICAgICAgIHRoaXMubm9kZS5vbihjYy5Ob2RlLkV2ZW50VHlwZS5UT1VDSF9FTkQsIHBhdXNlcmVzdW1lLCB0aGlzLm5vZGUpO1xyXG4gICAgfVxyXG59KTtcclxuIiwiY2MuQ2xhc3Moe1xyXG4gICAgZXh0ZW5kczogY2MuQ29tcG9uZW50LFxyXG5cclxuICAgIHByb3BlcnRpZXM6IHtcclxuICAgICAgICBzZWxlY3RNZW51S2luZDp7XHJcbiAgICAgICAgICAgIGRlZmF1bHQ6IG51bGwsXHJcbiAgICAgICAgICAgIHR5cGU6IGNjLkxhYmVsLFxyXG4gICAgICAgIH0sXHJcbiAgICAgICAgc2VsZWN0TWVudUxpc3Q6e1xyXG4gICAgICAgICAgICBkZWZhdWx0OiBudWxsLFxyXG4gICAgICAgICAgICB0eXBlOiBjYy5Ob2RlLFxyXG4gICAgICAgIH0sXHJcbiAgICAgICAgc2VsZWN0TWVudUJ1dHRvbjp7XHJcbiAgICAgICAgICAgIGRlZmF1bHQ6IG51bGwsXHJcbiAgICAgICAgICAgIHR5cGU6IGNjLkJ1dHRvbixcclxuICAgICAgICB9LFxyXG4gICAgICAgIC8vb2NjdXBhdGlvbkxpc3Q6e1xyXG4gICAgICAgIC8vICAgIGRlZmF1bHQ6IFtdLFxyXG4gICAgICAgIC8vICAgIHR5cGU6IGNjLk5vZGUsXHJcbiAgICAgICAgLy99LFxyXG4gICAgICAgIC8vb2NjdXBhdGlvbkxpc3ROYW1lOntcclxuICAgICAgICAvLyAgICBkZWZhdWx0OiBbXSxcclxuICAgICAgICAvLyAgICB0eXBlOiBjYy5MYWJlbCxcclxuICAgICAgICAvL30sXHJcbiAgICB9LFxyXG4gICAgY2FsbGJhY2s6ZnVuY3Rpb24oZXZlbnQsIGN1c3RvbUV2ZW50RGF0YSl7XHJcbiAgICAgICAgc3dpdGNoKGN1c3RvbUV2ZW50RGF0YSl7XHJcbiAgICAgICAgICAgIGNhc2UgJ3RvdGFsJzpcclxuICAgICAgICAgICAgICAgIHRoaXMuc2VsZWN0TWVudUxpc3QuYWN0aXZlID0gZmFsc2U7XHJcbiAgICAgICAgICAgICAgICB0aGlzLnNlbGVjdE1lbnVLaW5kLnN0cmluZyA9IFwi5omA5pyJ6Zi16JClXCI7YnJlYWs7XHJcbiAgICAgICAgICAgIGNhc2UgJ3NjaWVuY2UnOlxyXG4gICAgICAgICAgICAgICAgdGhpcy5zZWxlY3RNZW51TGlzdC5hY3RpdmUgPSBmYWxzZTtcclxuICAgICAgICAgICAgICAgIHRoaXMuc2VsZWN0TWVudUtpbmQuc3RyaW5nID0gXCLnp5HlraZcIjticmVhaztcclxuICAgICAgICAgICAgY2FzZSAnZmFudGFzeSc6XHJcbiAgICAgICAgICAgICAgICB0aGlzLnNlbGVjdE1lbnVMaXN0LmFjdGl2ZSA9IGZhbHNlO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5zZWxlY3RNZW51S2luZC5zdHJpbmcgPSBcIuW5u+aDs1wiO2JyZWFrO1xyXG4gICAgICAgICAgICBjYXNlICdjaGFvcyc6XHJcbiAgICAgICAgICAgICAgICB0aGlzLnNlbGVjdE1lbnVMaXN0LmFjdGl2ZSA9IGZhbHNlO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5zZWxlY3RNZW51S2luZC5zdHJpbmcgPSBcIua3t+ayjFwiO2JyZWFrO1xyXG4gICAgICAgICAgICBjYXNlICduZXV0cmFsaXR5JzpcclxuICAgICAgICAgICAgICAgIHRoaXMuc2VsZWN0TWVudUxpc3QuYWN0aXZlID0gZmFsc2U7XHJcbiAgICAgICAgICAgICAgICB0aGlzLnNlbGVjdE1lbnVLaW5kLnN0cmluZyA9IFwi5Lit56uLXCI7YnJlYWs7XHJcbiAgICAgICAgICAgIGRlZmF1bHQ6IGJyZWFrO1xyXG4gICAgICAgIH1cclxuICAgIH0sXHJcbiAgICByYXJlU2VsZWN0OmZ1bmN0aW9uKGV2ZW50LCBjdXN0b21FdmVudERhdGEpe1xyXG4gICAgICAgIHN3aXRjaChjdXN0b21FdmVudERhdGEpe1xyXG4gICAgICAgICAgICBjYXNlICd0b3RhbCc6XHJcbiAgICAgICAgICAgICAgICB0aGlzLnNlbGVjdE1lbnVMaXN0LmFjdGl2ZSA9IGZhbHNlO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5zZWxlY3RNZW51S2luZC5zdHJpbmcgPSBcIuWFqOmDqFwiO2JyZWFrO1xyXG4gICAgICAgICAgICBjYXNlICdOJzpcclxuICAgICAgICAgICAgICAgIHRoaXMuc2VsZWN0TWVudUxpc3QuYWN0aXZlID0gZmFsc2U7XHJcbiAgICAgICAgICAgICAgICB0aGlzLnNlbGVjdE1lbnVLaW5kLnN0cmluZyA9IFwiTlwiO2JyZWFrO1xyXG4gICAgICAgICAgICBjYXNlICdSJzpcclxuICAgICAgICAgICAgICAgIHRoaXMuc2VsZWN0TWVudUxpc3QuYWN0aXZlID0gZmFsc2U7XHJcbiAgICAgICAgICAgICAgICB0aGlzLnNlbGVjdE1lbnVLaW5kLnN0cmluZyA9IFwiUlwiO2JyZWFrO1xyXG4gICAgICAgICAgICBjYXNlICdTUic6XHJcbiAgICAgICAgICAgICAgICB0aGlzLnNlbGVjdE1lbnVMaXN0LmFjdGl2ZSA9IGZhbHNlO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5zZWxlY3RNZW51S2luZC5zdHJpbmcgPSBcIlNSXCI7YnJlYWs7XHJcbiAgICAgICAgICAgIGNhc2UgJ1NTUic6XHJcbiAgICAgICAgICAgICAgICB0aGlzLnNlbGVjdE1lbnVMaXN0LmFjdGl2ZSA9IGZhbHNlO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5zZWxlY3RNZW51S2luZC5zdHJpbmcgPSBcIlNTUlwiO2JyZWFrO1xyXG4gICAgICAgICAgICBkZWZhdWx0OiBicmVhaztcclxuICAgICAgICB9XHJcbiAgICB9LFxyXG4gICAgY29uc3VtZVNlbGVjdDpmdW5jdGlvbihldmVudCwgY3VzdG9tRXZlbnREYXRhKXtcclxuICAgICAgICBpZihjdXN0b21FdmVudERhdGEgPT09ICd0b3RhbCcpXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgICB0aGlzLnNlbGVjdE1lbnVMaXN0LmFjdGl2ZSA9IGZhbHNlO1xyXG4gICAgICAgICAgICB0aGlzLnNlbGVjdE1lbnVLaW5kLnN0cmluZyA9IFwi5omA5pyJ5raI6ICXXCI7XHJcbiAgICAgICAgfWVsc2Uge1xyXG4gICAgICAgICAgICB0aGlzLnNlbGVjdE1lbnVMaXN0LmFjdGl2ZSA9IGZhbHNlO1xyXG4gICAgICAgICAgICB0aGlzLnNlbGVjdE1lbnVLaW5kLnN0cmluZyA9IFwiXCIgKyBjdXN0b21FdmVudERhdGE7XHJcbiAgICAgICAgfVxyXG4gICAgfSxcclxuICAgIC8vIHVzZSB0aGlzIGZvciBpbml0aWFsaXphdGlvblxyXG4gICAgb25Mb2FkOiBmdW5jdGlvbiAoKVxyXG4gICAge1xyXG4gICAgICAgIHRoaXMuc2VsZWN0TWVudUxpc3QuYWN0aXZlID0gZmFsc2U7XHJcbiAgICB9LFxyXG4gICAgc2hvd1NlbGVjdE1lbnVMaXN0OiBmdW5jdGlvbigpe1xyXG4gICAgICAgIHRoaXMuc2VsZWN0TWVudUxpc3QuYWN0aXZlID0gdHJ1ZTtcclxuICAgICAgICAvL3RoaXMuc2VsZWN0TWVudUxpc3RPcGVyYXRpb24odGhpcy5vY2N1cGF0aW9uTGlzdCk7XHJcbiAgICAgICAgdGhpcy5oaWRlU2VsZWN0TWVudUxpc3QodGhpcy5zZWxlY3RNZW51TGlzdCk7XHJcbiAgICAgICAgLy90aGlzLnBpY2tTZWxlY3RNZW51SXRlbSh0aGlzLm9jY3VwYXRpb25MaXN0KTtcclxuICAgIH0sXHJcbiAgICAgICAgLy9mdW5jdGlvbiBzdG9wQWN0aW9uKCkge1xyXG4gICAgICAgIC8vICAgIHRoaXMuc2VsZWN0TWVudUxpc3QuYWN0aXZlID0gZmFsc2U7XHJcbiAgICAgICAgLy99XHJcbiAgICBoaWRlU2VsZWN0TWVudUxpc3Q6IGZ1bmN0aW9uKHNlbGVjdEJvYXJkKXtcclxuICAgICAgICBzZWxlY3RCb2FyZC5vbihjYy5Ob2RlLkV2ZW50VHlwZS5NT1VTRV9MRUFWRSxoaWRlU2VsZWN0Qm9hcmQsIHRoaXMpO1xyXG4gICAgICAgIGZ1bmN0aW9uIGhpZGVTZWxlY3RCb2FyZCgpe1xyXG4gICAgICAgICAgICBzZWxlY3RCb2FyZC5hY3RpdmUgPSBmYWxzZTtcclxuICAgICAgICB9XHJcbiAgICB9LFxyXG4gICAgXHJcbiAgICAvLyBjYWxsZWQgZXZlcnkgZnJhbWUsIHVuY29tbWVudCB0aGlzIGZ1bmN0aW9uIHRvIGFjdGl2YXRlIHVwZGF0ZSBjYWxsYmFja1xyXG4gICAgLy8gdXBkYXRlOiBmdW5jdGlvbiAoZHQpIHtcclxuXHJcbiAgICAvLyB9LFxyXG59KTtcclxuIiwidmFyIGdsb2JhbENvbnN0YW50ID0gcmVxdWlyZShcIkNvbnN0YW50XCIpO1xyXG5jYy5DbGFzcyh7XHJcbiAgICBleHRlbmRzOiBjYy5Db21wb25lbnQsXHJcblxyXG4gICAgcHJvcGVydGllczoge1xyXG4gICAgICAgIGNyZWF0dXJlOiBjYy5Ob2RlLFxyXG4gICAgICAgIGF0dGFjazpjYy5MYWJlbCxcclxuICAgICAgICBoZWFsdGg6Y2MuTGFiZWwsXHJcbiAgICAgICAgc2NyaXB0Om51bGwsXHJcbiAgICAgICAgLy/vv73Qtu+/ve+/ve+/ve+/ve+/ve+/ve+/vSBoZXJvIGNyZWF0dXJlXHJcbiAgICAgICAgbm9kZVR5cGU6e1xyXG4gICAgICAgICAgICB0eXBlOiBjYy5FbnVtKHtcclxuICAgICAgICAgICAgICAgIENyZWF0dXJlOiAwLFxyXG4gICAgICAgICAgICAgICAgSGVybzogMSxcclxuICAgICAgICAgICAgICAgIEJhc2U6IDIsXHJcbiAgICAgICAgICAgIH0pLFxyXG4gICAgICAgICAgICBkZWZhdWx0OiAwXHJcbiAgICAgICAgfSxcclxuXHJcbiAgICAgICAgc2lnblN0YXRlOjAsXHJcbiAgICAgICAgc2lnbk5vZGU6W2NjLk5vZGVdLFxyXG4gICAgICAgIC8vIGZvbzoge1xyXG4gICAgICAgIC8vICAgIGRlZmF1bHQ6IG51bGwsICAgICAgLy8gVGhlIGRlZmF1bHQgdmFsdWUgd2lsbCBiZSB1c2VkIG9ubHkgd2hlbiB0aGUgY29tcG9uZW50IGF0dGFjaGluZ1xyXG4gICAgICAgIC8vICAgICAgICAgICAgICAgICAgICAgICAgICAgdG8gYSBub2RlIGZvciB0aGUgZmlyc3QgdGltZVxyXG4gICAgICAgIC8vICAgIHVybDogY2MuVGV4dHVyZTJELCAgLy8gb3B0aW9uYWwsIGRlZmF1bHQgaXMgdHlwZW9mIGRlZmF1bHRcclxuICAgICAgICAvLyAgICBzZXJpYWxpemFibGU6IHRydWUsIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIHRydWVcclxuICAgICAgICAvLyAgICB2aXNpYmxlOiB0cnVlLCAgICAgIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIHRydWVcclxuICAgICAgICAvLyAgICBkaXNwbGF5TmFtZTogJ0ZvbycsIC8vIG9wdGlvbmFsXHJcbiAgICAgICAgLy8gICAgcmVhZG9ubHk6IGZhbHNlLCAgICAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyBmYWxzZVxyXG4gICAgICAgIC8vIH0sXHJcbiAgICAgICAgLy8gLi4uXHJcbiAgICB9LFxyXG5cclxuICAgIC8vIHVzZSB0aGlzIGZvciBpbml0aWFsaXphdGlvblxyXG4gICAgb25Mb2FkOiBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgdGhpcy5ub2RlLnkgPSAtIDE2O1xyXG4gICAgfSxcclxuICAgIGZuR2l2ZU5vZGU6IGZ1bmN0aW9uKG5vZGUpe1xyXG4gICAgICAgIHRoaXMuY3JlYXR1cmUgPSBub2RlO1xyXG4gICAgICAgIHRoaXMubm9kZS54ID0gdGhpcy5jcmVhdHVyZS54IC8gKGNjLmRpcmVjdG9yLmdldFdpblNpemUoKS53aWR0aCAqIDMpICogZ2xvYmFsQ29uc3RhbnQuc21hbGxNYXBMZW5ndGg7XHJcbiAgICAgICAgaWYodGhpcy5ub2RlVHlwZSA9PT0gMCl7XHJcbiAgICAgICAgICAgIHRoaXMuc2NyaXB0ID0gdGhpcy5jcmVhdHVyZS5nZXRDb21wb25lbnQoJ0NyZWF0dXJlJyk7XHJcbiAgICAgICAgfWVsc2UgaWYodGhpcy5ub2RlVHlwZSA9PT0gMSl7XHJcbiAgICAgICAgICAgIHRoaXMuc2NyaXB0ID0gdGhpcy5jcmVhdHVyZS5nZXRDb21wb25lbnQoJ1BsYXllcicpO1xyXG4gICAgICAgIH1lbHNle1xyXG5cclxuICAgICAgICB9XHJcbiAgICB9LFxyXG4gICAgZm5SZW5ld1NpZ246ZnVuY3Rpb24oKXtcclxuICAgICAgICB0aGlzLm5vZGUueCA9IHRoaXMuY3JlYXR1cmUueCAvIChjYy5kaXJlY3Rvci5nZXRXaW5TaXplKCkud2lkdGggKiAzKSAqIGdsb2JhbENvbnN0YW50LnNtYWxsTWFwTGVuZ3RoO1xyXG4gICAgICAgIHRoaXMuYXR0YWNrLnN0cmluZyA9IHRoaXMuc2NyaXB0LmF0dGFjaztcclxuICAgICAgICB0aGlzLmhlYWx0aC5zdHJpbmcgPSB0aGlzLnNjcmlwdC5oZWFsdGg7XHJcbiAgICAgICAgZm9yKHZhciBpID0gMDtpIDwgdGhpcy5zaWduTm9kZS5sZW5ndGg7aSsrKXtcclxuICAgICAgICAgICAgaWYodGhpcy5zaWduU3RhdGUgPT09IGkpe1xyXG4gICAgICAgICAgICAgICAgdGhpcy5zaWduTm9kZVtpXS5hY3RpdmUgPSB0cnVlO1xyXG4gICAgICAgICAgICB9ZWxzZXtcclxuICAgICAgICAgICAgICAgIHRoaXMuc2lnbk5vZGVbaV0uYWN0aXZlID0gZmFsc2U7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9LFxyXG4gICAgcmVuZXdUZWFtOmZ1bmN0aW9uKCl7XHJcbiAgICAgICAgaWYodGhpcy5ub2RlVHlwZSA9PT0gMCkge1xyXG4gICAgICAgICAgICBpZiAodGhpcy5zY3JpcHQudGVhbSA8IDApIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuc2lnblN0YXRlID0gMDtcclxuICAgICAgICAgICAgfSBlbHNlIGlmICh0aGlzLnNjcmlwdC50ZWFtID4gMCkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5zaWduU3RhdGUgPSAxO1xyXG4gICAgICAgICAgICB9IGVsc2Uge1xyXG5cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1lbHNlIHtcclxuICAgICAgICAgICAgaWYgKHRoaXMuc2NyaXB0LnRlYW0gPCAwKSB7XHJcbiAgICAgICAgICAgICAgICBpZih0aGlzLnNjcmlwdC5kZWF0aCA9PT0gdHJ1ZSl7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5zaWduU3RhdGUgPSA0O1xyXG4gICAgICAgICAgICAgICAgfWVsc2V7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5zaWduU3RhdGUgPSAyO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9IGVsc2UgaWYgKHRoaXMuc2NyaXB0LnRlYW0gPiAwKSB7XHJcbiAgICAgICAgICAgICAgICBpZih0aGlzLnNjcmlwdC5kZWF0aCA9PT0gdHJ1ZSl7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5zaWduU3RhdGUgPSA1O1xyXG4gICAgICAgICAgICAgICAgfWVsc2V7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5zaWduU3RhdGUgPSAzO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9IGVsc2Uge1xyXG5cclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICB9XHJcbiAgICB9LFxyXG4gICAgcmVtb3ZlU2lnbjogZnVuY3Rpb24oKXtcclxuICAgICAgICB0aGlzLm5vZGUucmVtb3ZlRnJvbVBhcmVudCgpO1xyXG4gICAgICAgIHRoaXMubm9kZS5hY3RpdmUgPSBmYWxzZTtcclxuICAgIH0sXHJcblxyXG4gICAgLy8gY2FsbGVkIGV2ZXJ5IGZyYW1lLCB1bmNvbW1lbnQgdGhpcyBmdW5jdGlvbiB0byBhY3RpdmF0ZSB1cGRhdGUgY2FsbGJhY2tcclxuICAgIHVwZGF0ZTogZnVuY3Rpb24gKGR0KSB7XHJcbiAgICAgICAgdGhpcy5yZW5ld1RlYW0oKTtcclxuICAgICAgICB0aGlzLmZuUmVuZXdTaWduKCk7XHJcbiAgICB9LFxyXG4gICAgXHJcbiAgICBcclxufSk7XHJcbiIsIi8qKlxyXG4gKiBA5Li76KaB5Yqf6IO9OiAgIOWwj+WcsOWbvuexu1xyXG4gKiBAdHlwZSB7RnVuY3Rpb259XHJcbiAqL1xyXG52YXIgc21hbGxNYXAgPSBjYy5DbGFzcyh7XHJcbiAgICBleHRlbmRzOiBjYy5Db21wb25lbnQsXHJcblxyXG4gICAgcHJvcGVydGllczoge1xyXG4gICAgICAgIHNpZ25zOiBbY2MuTm9kZV0sXHJcbiAgICAgICAgc2lnblByZWZhYjogW2NjLlByZWZhYl0sXHJcbiAgICAgICAgLy/lsI/lnLDlm77moIfor4Yw77ya6JOd6ImyIOWxnuS6juWwj+S6jjDnmoTpmLXokKVcclxuICAgICAgICAvL+Wwj+WcsOWbvuagh+ivhjHvvJrnuqLoibIg5bGe5LqO5aSn5LqOMOeahOmYteiQpVxyXG4gICAgICAgIGRhdGE6IGNjLk5vZGUsXHJcbiAgICAgICAgc2NyaXB0OiBudWxsLFxyXG4gICAgfSxcclxuXHJcbiAgICBvbkxvYWQ6IGZ1bmN0aW9uICgpIHtcclxuICAgICAgICB0aGlzLnNjcmlwdCA9IHRoaXMuZGF0YS5nZXRDb21wb25lbnQoJ01haW5HYW1lTWFuYWdlcicpO1xyXG4gICAgfSxcclxuXHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBA5Li76KaB5Yqf6IO9OiAg5Yib5bu65bCP5Zyw5Zu+5qCH6K6w6IqC54K5XHJcbiAgICAgKiBAcGFyYW0gbm9kZVxyXG4gICAgICovXHJcbiAgICBmbkNyZWF0ZUNyZWF0dXJlU2lnbjogZnVuY3Rpb24obm9kZSl7XHJcbiAgICAgICAgLy/lgJ/nlKjkuIDkuKpub2Rl5p2l5Yib5bu65LiA5Liq5bCP5YW15qCH6K6w77yM5bCGTm9kZee7keWumuWcqOmihOWItui1hOa6kOS4rVxyXG4gICAgICAgIHZhciBzY3JpcHQgPSBub2RlLmdldENvbXBvbmVudCgnQ3JlYXR1cmUnKTtcclxuICAgICAgICB2YXIgbmV3c2lnbjtcclxuXHJcbiAgICAgICAgbmV3c2lnbiA9IGNjLmluc3RhbnRpYXRlKHRoaXMuc2lnblByZWZhYlswXSk7XHJcbiAgICAgICAgdmFyIHNpZ25TY3JpcHQgPSBuZXdzaWduLmdldENvbXBvbmVudCgnU2lnblNjcmlwdCcpO1xyXG5cclxuICAgICAgICBzaWduU2NyaXB0Lm5vZGVUeXBlID0gMDtcclxuICAgICAgICBzaWduU2NyaXB0LmZuR2l2ZU5vZGUobm9kZSk7XHJcblxyXG4gICAgICAgIHRoaXMuc2lnbnMucHVzaChuZXdzaWduKTtcclxuICAgICAgICB0aGlzLm5vZGUuYWRkQ2hpbGQodGhpcy5zaWduc1t0aGlzLnNpZ25zLmxlbmd0aCAtIDFdKTtcclxuICAgIH0sXHJcbiAgICBmbkNyZWF0ZUhlcm9TaWduOiBmdW5jdGlvbihub2RlKXtcclxuICAgICAgICAvL+WAn+eUqOS4gOS4qm5vZGXmnaXliJvlu7rkuIDkuKrlsI/lhbXmoIforrDvvIzlsIZOb2Rl57uR5a6a5Zyo6aKE5Yi26LWE5rqQ5LitXHJcbiAgICAgICAgdmFyIHNjcmlwdCA9IG5vZGUuZ2V0Q29tcG9uZW50KCdQbGF5ZXInKTtcclxuICAgICAgICB2YXIgbmV3c2lnbjtcclxuXHJcbiAgICAgICAgbmV3c2lnbiA9IGNjLmluc3RhbnRpYXRlKHRoaXMuc2lnblByZWZhYlswXSk7XHJcbiAgICAgICAgdmFyIHNpZ25TY3JpcHQgPSBuZXdzaWduLmdldENvbXBvbmVudCgnU2lnblNjcmlwdCcpO1xyXG5cclxuICAgICAgICBzaWduU2NyaXB0Lm5vZGVUeXBlID0gMTtcclxuICAgICAgICBzaWduU2NyaXB0LmZuR2l2ZU5vZGUobm9kZSk7XHJcblxyXG4gICAgICAgIHRoaXMuc2lnbnMucHVzaChuZXdzaWduKTtcclxuICAgICAgICB0aGlzLm5vZGUuYWRkQ2hpbGQodGhpcy5zaWduc1t0aGlzLnNpZ25zLmxlbmd0aCAtIDFdKTtcclxuICAgIH0sXHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBA5Li76KaB5Yqf6IO9OiDph4rmlL7lsI/lhbXoioLngrlcclxuICAgICAqICAgICAgICAgIOW7uuiuruS9v+eUqOi1hOa6kOaxoOWbnuaUtuiKgueCuVxyXG4gICAgICogQHBhcmFtIG5vZGVcclxuICAgICAqL1xyXG4gICAgZm5EZWxldGVTaWduOiBmdW5jdGlvbihub2RlKXtcclxuICAgICAgICB2YXIgaSxzY3JpcHQ7XHJcbiAgICAgICAgZm9yKGkgPSAwO2kgPCB0aGlzLnNpZ25zLmxlbmd0aDsgaSsrKXtcclxuICAgICAgICAgICAgc2NyaXB0ID0gdGhpcy5zaWduc1tpXS5nZXRDb21wb25lbnQoJ1NpZ25TY3JpcHQnKTtcclxuICAgICAgICAgICAgaWYoc2NyaXB0LmNyZWF0dXJlID09PSBub2RlKXtcclxuICAgICAgICAgICAgICAgIHRoaXMubm9kZS5yZW1vdmVDaGlsZCh0aGlzLnNpZ25zW2ldLHRydWUpO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5zaWduc1tpXS5hY3RpdmUgPSBmYWxzZTtcclxuICAgICAgICAgICAgICAgIHRoaXMuc2lnbnMuc3BsaWNlKGksMSk7XHJcbiAgICAgICAgICAgICAgICBzY3JpcHQucmVtb3ZlU2lnbigpO1xyXG4gICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIC8va2VuYW4g5Zug5Li65rKh5pyJ5Zue5pS25rGgICDov5nph4zpnIDopoHph4rmlL7otYTmupBcclxuICAgICAgICAvL25vZGUuZGVzdHJveSgpO1xyXG5cclxuICAgIH0sXHJcblxyXG59KTtcclxuIiwiY2MuQ2xhc3Moe1xyXG4gICAgZXh0ZW5kczogY2MuQ29tcG9uZW50LFxyXG5cclxuICAgIHByb3BlcnRpZXM6IHtcclxuICAgICAgICBzdG9yZU5vZGU6Y2MuTm9kZSxcclxuICAgICAgICAvLyBmb286IHtcclxuICAgICAgICAvLyAgICBkZWZhdWx0OiBudWxsLCAgICAgIC8vIFRoZSBkZWZhdWx0IHZhbHVlIHdpbGwgYmUgdXNlZCBvbmx5IHdoZW4gdGhlIGNvbXBvbmVudCBhdHRhY2hpbmdcclxuICAgICAgICAvLyAgICAgICAgICAgICAgICAgICAgICAgICAgIHRvIGEgbm9kZSBmb3IgdGhlIGZpcnN0IHRpbWVcclxuICAgICAgICAvLyAgICB1cmw6IGNjLlRleHR1cmUyRCwgIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIHR5cGVvZiBkZWZhdWx0XHJcbiAgICAgICAgLy8gICAgc2VyaWFsaXphYmxlOiB0cnVlLCAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyB0cnVlXHJcbiAgICAgICAgLy8gICAgdmlzaWJsZTogdHJ1ZSwgICAgICAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyB0cnVlXHJcbiAgICAgICAgLy8gICAgZGlzcGxheU5hbWU6ICdGb28nLCAvLyBvcHRpb25hbFxyXG4gICAgICAgIC8vICAgIHJlYWRvbmx5OiBmYWxzZSwgICAgLy8gb3B0aW9uYWwsIGRlZmF1bHQgaXMgZmFsc2VcclxuICAgICAgICAvLyB9LFxyXG4gICAgICAgIC8vIC4uLlxyXG4gICAgfSxcclxuXHJcbiAgICBvcGVuU3RvcmU6IGZ1bmN0aW9uKCl7XHJcbiAgICAgICAgdGhpcy5zdG9yZU5vZGUuYWN0aXZlID0gdHJ1ZTtcclxuICAgIH0sXHJcbiAgICAvLyB1c2UgdGhpcyBmb3IgaW5pdGlhbGl6YXRpb25cclxuICAgIG9uTG9hZDogZnVuY3Rpb24gKCkge1xyXG5cclxuICAgIH1cclxuXHJcbiAgICAvLyBjYWxsZWQgZXZlcnkgZnJhbWUsIHVuY29tbWVudCB0aGlzIGZ1bmN0aW9uIHRvIGFjdGl2YXRlIHVwZGF0ZSBjYWxsYmFja1xyXG4gICAgLy8gdXBkYXRlOiBmdW5jdGlvbiAoZHQpIHtcclxuXHJcbiAgICAvLyB9LFxyXG59KTtcclxuIiwiY2MuQ2xhc3Moe1xyXG4gICAgZXh0ZW5kczogY2MuQ29tcG9uZW50LFxyXG5cclxuICAgIHByb3BlcnRpZXM6IHtcclxuICAgICAgICBzdG9yZU5vZGU6Y2MuTm9kZVxyXG4gICAgICAgIC8vIGZvbzoge1xyXG4gICAgICAgIC8vICAgIGRlZmF1bHQ6IG51bGwsICAgICAgLy8gVGhlIGRlZmF1bHQgdmFsdWUgd2lsbCBiZSB1c2VkIG9ubHkgd2hlbiB0aGUgY29tcG9uZW50IGF0dGFjaGluZ1xyXG4gICAgICAgIC8vICAgICAgICAgICAgICAgICAgICAgICAgICAgdG8gYSBub2RlIGZvciB0aGUgZmlyc3QgdGltZVxyXG4gICAgICAgIC8vICAgIHVybDogY2MuVGV4dHVyZTJELCAgLy8gb3B0aW9uYWwsIGRlZmF1bHQgaXMgdHlwZW9mIGRlZmF1bHRcclxuICAgICAgICAvLyAgICBzZXJpYWxpemFibGU6IHRydWUsIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIHRydWVcclxuICAgICAgICAvLyAgICB2aXNpYmxlOiB0cnVlLCAgICAgIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIHRydWVcclxuICAgICAgICAvLyAgICBkaXNwbGF5TmFtZTogJ0ZvbycsIC8vIG9wdGlvbmFsXHJcbiAgICAgICAgLy8gICAgcmVhZG9ubHk6IGZhbHNlLCAgICAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyBmYWxzZVxyXG4gICAgICAgIC8vIH0sXHJcbiAgICAgICAgLy8gLi4uXHJcbiAgICB9LFxyXG5cclxuICAgIGNsb3NlU3RvcmU6IGZ1bmN0aW9uKCl7XHJcbiAgICAgICAgdGhpcy5zdG9yZU5vZGUuYWN0aXZlID0gZmFsc2U7XHJcbiAgICB9LFxyXG4gICAgLy8gdXNlIHRoaXMgZm9yIGluaXRpYWxpemF0aW9uXHJcbiAgICBvbkxvYWQ6IGZ1bmN0aW9uICgpIHtcclxuXHJcbiAgICB9XHJcblxyXG4gICAgLy8gY2FsbGVkIGV2ZXJ5IGZyYW1lLCB1bmNvbW1lbnQgdGhpcyBmdW5jdGlvbiB0byBhY3RpdmF0ZSB1cGRhdGUgY2FsbGJhY2tcclxuICAgIC8vIHVwZGF0ZTogZnVuY3Rpb24gKGR0KSB7XHJcblxyXG4gICAgLy8gfSxcclxufSk7XHJcbiIsInZhciBnbG9iYWwgPSByZXF1aXJlKFwiR2xvYmFsXCIpO1xyXG52YXIgZ2xvYmFsQ29uc3RhbnQgPSByZXF1aXJlKFwiQ29uc3RhbnRcIik7XHJcbmNjLkNsYXNzKHtcclxuICAgIGV4dGVuZHM6IGNjLkNvbXBvbmVudCxcclxuXHJcbiAgICBwcm9wZXJ0aWVzOiB7XHJcblxyXG4gICAgICAgIHB1cmNoYXNlQnV0dG9uOltjYy5Ob2RlXSxcclxuICAgICAgICBwdXJjaGFzZU51bUxhYmVsOmNjLkVkaXRCb3gsXHJcbiAgICAgICAgLy/mmL7npLrnlKjnmoTmiYDpnIDph5HluIFcclxuICAgICAgICBuZWVkTW9uZXk6MCxcclxuICAgICAgICBuZWVkTW9uZXlMYWJlbDpjYy5MYWJlbCxcclxuICAgICAgICBuZWVkTW9uZXlTdG9yeUxhYmVsOmNjLkxhYmVsLFxyXG4gICAgICAgIG1hc3NhZ2U6Y2MuTGFiZWwsXHJcbiAgICAgICAgbWFzc2FnZU5vZGU6Y2MuTm9kZSxcclxuICAgICAgICAvL+aVheS6i+aooeW8j+eahOmHkeW4gVxyXG4gICAgICAgIHN0b3J5TmVlZE1vbmV5OjAsXHJcbiAgICAgICAgLy/otK3kubDnmoTljaHljIXnvJblj7fmmK9cclxuICAgICAgICBwdXJjaGFzZUlkOjAsXHJcbiAgICAgICAgLy/lvZPliY3pobXpnaLkvY3nva5cclxuICAgICAgICBwYWdlSWQ6MCxcclxuICAgICAgICAvL+eOsOWcqOeahOWNleS7t1xyXG4gICAgICAgIG5vd01vbmV5OjAsXHJcbiAgICAgICAgLy/mu5HliqjpobXpnaJcclxuICAgICAgICBwYWdlczpbY2MuTm9kZV0sXHJcbiAgICAgICAgLy/ljaHljIXotK3kubDpobnnm65cclxuICAgICAgICBiYWdJdGVtOmNjLk5vZGUsXHJcbiAgICAgICAgLy/mlYXkuovotK3kubDpobnnm65cclxuICAgICAgICBzdG9yeUl0ZW06Y2MuTm9kZSxcclxuICAgICAgICAvL+awqumHkei0reS5sOmhueebrlxyXG4gICAgICAgIG1vbmV5SXRlbTpjYy5Ob2RlXHJcbiAgICB9LFxyXG5cclxuICAgIC8vIHVzZSB0aGlzIGZvciBpbml0aWFsaXphdGlvblxyXG4gICAgb25Mb2FkOiBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgdGhpcy5ub2RlLm9uKCdwdXJjaGFzZUlkJyx0aGlzLnB1cmNoYXNlSWRDaGFuZ2UsdGhpcyk7XHJcbiAgICB9LFxyXG4gICAgcHVyY2hhc2VJZENoYW5nZTpmdW5jdGlvbihldmVudCl7XHJcbiAgICAgICAgdGhpcy5wdXJjaGFzZUlkID0gZXZlbnQuZGV0YWlsLmlkO1xyXG4gICAgICAgIHRoaXMubm93TW9uZXkgPSBldmVudC5kZXRhaWwuc2NyaXB0Lm1vbmV5O1xyXG5cclxuICAgICAgICBpZihldmVudC5kZXRhaWwuc2NyaXB0LnR5cGUgPT09IDApe1xyXG4gICAgICAgICAgICB0aGlzLnB1cmNoYXNlTnVtQ2hhbmdlKCk7XHJcbiAgICAgICAgfWVsc2UgaWYoZXZlbnQuZGV0YWlsLnNjcmlwdC50eXBlID09PSAxKXtcclxuICAgICAgICAgICAgdGhpcy5jaGFuZ2VTdG9yeU1vZGUoKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgdGhpcy5wdXJjaGFzZUJ1dHRvblswXS5ydW5BY3Rpb24oY2MubW92ZVRvKDAuNSwyMDAgKiB0aGlzLnB1cmNoYXNlSWQgKyAtMzAwLHRoaXMucHVyY2hhc2VCdXR0b25bMF0ueSkuZWFzaW5nKFxyXG4gICAgICAgICAgICBjYy5lYXNlQ2lyY2xlQWN0aW9uSW5PdXQoKVxyXG4gICAgICAgICkpO1xyXG4gICAgICAgIHRoaXMucHVyY2hhc2VCdXR0b25bMV0ucnVuQWN0aW9uKGNjLm1vdmVUbygwLjUsMjAwICogdGhpcy5wdXJjaGFzZUlkICsgLTMwMCx0aGlzLnB1cmNoYXNlQnV0dG9uWzFdLnkpLmVhc2luZyhcclxuICAgICAgICAgICAgY2MuZWFzZUNpcmNsZUFjdGlvbkluT3V0KClcclxuICAgICAgICApKTtcclxuICAgIH0sXHJcbiAgICAvKipcclxuICAgICAqIEDkuLvopoHlip/og70g5o+Q5L6b6LSt5Lmw5pWw6YeP5pu05paw55qE5pON5L2cXHJcbiAgICAgKiBAYXV0aG9yIEMxNFxyXG4gICAgICogQERhdGUgMjAxOC8xLzFcclxuICAgICAqIEBwYXJhbWV0ZXJzXHJcbiAgICAgKiBAcmV0dXJuc1xyXG4gICAgICovXHJcbiAgICBwdXJjaGFzZU51bUNoYW5nZTpmdW5jdGlvbigpe1xyXG4gICAgICAgIHRoaXMucHVyY2hhc2VOdW1MYWJlbC5zdHJpbmcgPSBNYXRoLmZsb29yKHRoaXMucHVyY2hhc2VOdW1MYWJlbC5zdHJpbmcpO1xyXG4gICAgICAgIHRoaXMubmVlZE1vbmV5ID0gdGhpcy5wdXJjaGFzZU51bUxhYmVsLnN0cmluZyAqIHRoaXMubm93TW9uZXk7XHJcbiAgICAgICAgdGhpcy5uZWVkTW9uZXlMYWJlbC5zdHJpbmcgPSAgdGhpcy5uZWVkTW9uZXk7XHJcbiAgICB9LFxyXG4gICAgLyoqXHJcbiAgICAgKiBA5Li76KaB5Yqf6IO9IOabtOaWsOaVheS6i+aooeW8j+eahOaTjeS9nFxyXG4gICAgICogQGF1dGhvciBDMTRcclxuICAgICAqIEBEYXRlIDIwMTgvMS8yXHJcbiAgICAgKiBAcGFyYW1ldGVyc1xyXG4gICAgICogQHJldHVybnNcclxuICAgICAqL1xyXG4gICAgY2hhbmdlU3RvcnlNb2RlOmZ1bmN0aW9uKCl7XHJcbiAgICAgICAgdGhpcy5uZWVkTW9uZXkgPSAxICogdGhpcy5ub3dNb25leTtcclxuICAgICAgICB0aGlzLm5lZWRNb25leVN0b3J5TGFiZWwuc3RyaW5nID0gIHRoaXMubmVlZE1vbmV5O1xyXG4gICAgfSxcclxuICAgIC8qKlxyXG4gICAgICogQOS4u+imgeWKn+iDvSDotK3kubDljaHljIVY5LiqXHJcbiAgICAgKiBAYXV0aG9yIEMxNFxyXG4gICAgICogQERhdGUgMjAxOC8xLzFcclxuICAgICAqIEBwYXJhbWV0ZXJzXHJcbiAgICAgKiBAcmV0dXJuc1xyXG4gICAgICovXHJcbiAgICBwdXJjaGFzZUNhcmRCYWc6ZnVuY3Rpb24oKXtcclxuICAgICAgICBpZihnbG9iYWwubW9uZXkgPj0gdGhpcy5uZWVkTW9uZXkpe1xyXG4gICAgICAgICAgICBnbG9iYWwubW9uZXkgLT0gdGhpcy5uZWVkTW9uZXk7XHJcbiAgICAgICAgICAgIHRoaXMucHVyY2hhc2VOdW1MYWJlbC5zdHJpbmcgPSAwO1xyXG4gICAgICAgICAgICB0aGlzLnB1cmNoYXNlTnVtQ2hhbmdlKCk7XHJcbiAgICAgICAgfWVsc2V7XHJcbiAgICAgICAgICAgIHRoaXMubWFzc2FnZS5zdHJpbmcgPSBcIuaKseatie+8jOW3sue7j+ayoeaciemSseS6hlwiO1xyXG4gICAgICAgICAgICB2YXIgYWN0aW9uID0gY2Muc2VxdWVuY2UoY2MuZmFkZUluKDEpLmVhc2luZyhjYy5lYXNlU2luZU91dCgpKSxjYy5mYWRlT3V0KDEpLmVhc2luZyhjYy5lYXNlU2luZUluKCkpKTtcclxuICAgICAgICAgICAgdGhpcy5tYXNzYWdlTm9kZS5ydW5BY3Rpb24oYWN0aW9uKTtcclxuICAgICAgICB9XHJcbiAgICB9LFxyXG4gICAgLyoqXHJcbiAgICAgKiBA5Li76KaB5Yqf6IO9IOi0reS5sOWNoeWMhVjkuKpcclxuICAgICAqIEBhdXRob3IgQzE0XHJcbiAgICAgKiBARGF0ZSAyMDE4LzEvMlxyXG4gICAgICogQHBhcmFtZXRlcnNcclxuICAgICAqIEByZXR1cm5zXHJcbiAgICAgKi9cclxuICAgIHB1cmNoYXNlU3RvcnlNb2RlOmZ1bmN0aW9uKCl7XHJcbiAgICAgICAgaWYoZ2xvYmFsLm1vbmV5ID49IGdsb2JhbENvbnN0YW50LnN0b3J5TW9kZU5lZWRNb25leSl7XHJcbiAgICAgICAgICAgIGdsb2JhbC5tb25leSAtPSBnbG9iYWxDb25zdGFudC5zdG9yeU1vZGVOZWVkTW9uZXk7XHJcbiAgICAgICAgICAgIHRoaXMucHVyY2hhc2VOdW1MYWJlbC5zdHJpbmcgPSAwO1xyXG4gICAgICAgICAgICB0aGlzLnB1cmNoYXNlTnVtQ2hhbmdlKCk7XHJcbiAgICAgICAgfWVsc2V7XHJcbiAgICAgICAgICAgIHRoaXMubWFzc2FnZS5zdHJpbmcgPSBcIuaKseatie+8jOW3sue7j+ayoeaciemSseS6hlwiO1xyXG4gICAgICAgICAgICB2YXIgYWN0aW9uID0gY2Muc2VxdWVuY2UoY2MuZmFkZUluKDEpLmVhc2luZyhjYy5lYXNlU2luZU91dCgpKSxjYy5mYWRlT3V0KDEpLmVhc2luZyhjYy5lYXNlU2luZUluKCkpKTtcclxuICAgICAgICAgICAgdGhpcy5tYXNzYWdlTm9kZS5ydW5BY3Rpb24oYWN0aW9uKTtcclxuICAgICAgICB9XHJcbiAgICB9LFxyXG4gICAgLyoqXHJcbiAgICAgKiBA5Li76KaB5Yqf6IO9XHJcbiAgICAgKiBAYXV0aG9yXHJcbiAgICAgKiBARGF0ZSAyMDE4LzEvMVxyXG4gICAgICogQHBhcmFtZXRlcnNcclxuICAgICAqIEByZXR1cm5zXHJcbiAgICAgKi9cclxuICAgIHBhZ2VUdXJuaW5nOmZ1bmN0aW9uKHN0cmluZyl7XHJcbiAgICAgICAgdGhpcy5wYWdlSWQgPSBwYXJzZUludChzdHJpbmcpO1xyXG5cclxuICAgICAgICB2YXIgYmFnSXRlbSA9IHRoaXMuYmFnSXRlbS5jaGlsZHJlbjtcclxuICAgICAgICB2YXIgc3RvcnlJdGVtID0gdGhpcy5zdG9yeUl0ZW0uY2hpbGRyZW47XHJcblxyXG4gICAgICAgIGZvcih2YXIgaSA9IDA7aSA8IGJhZ0l0ZW0ubGVuZ3RoO2krKyl7XHJcbiAgICAgICAgICAgIHZhciBzY3JpcHQgPSBiYWdJdGVtW2ldLmdldENvbXBvbmVudChcIkl0ZW1cIik7XHJcbiAgICAgICAgICAgIGJhZ0l0ZW1baV0uc2NhbGUgPSAxO1xyXG4gICAgICAgICAgICBzY3JpcHQuaW5pdCgpO1xyXG4gICAgICAgIH1cclxuICAgICAgICBmb3IoaSA9IDA7aSA8IHN0b3J5SXRlbS5sZW5ndGg7aSsrKXtcclxuICAgICAgICAgICAgdmFyIHNjcmlwdCA9IHN0b3J5SXRlbVtpXS5nZXRDb21wb25lbnQoXCJJdGVtXCIpO1xyXG4gICAgICAgICAgICBzdG9yeUl0ZW1baV0uc2NhbGUgPSAxO1xyXG4gICAgICAgICAgICBzY3JpcHQuaW5pdCgpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuICAgIC8vIGNhbGxlZCBldmVyeSBmcmFtZSwgdW5jb21tZW50IHRoaXMgZnVuY3Rpb24gdG8gYWN0aXZhdGUgdXBkYXRlIGNhbGxiYWNrXHJcbiAgICAvLyB1cGRhdGU6IGZ1bmN0aW9uIChkdCkge1xyXG5cclxuICAgIC8vIH0sXHJcbn0pO1xyXG4iLCJjYy5DbGFzcyh7XHJcbiAgICBleHRlbmRzOiBjYy5Db21wb25lbnQsXHJcblxyXG4gICAgcHJvcGVydGllczoge1xyXG4gICAgICAgIC8vIGZvbzoge1xyXG4gICAgICAgIC8vICAgIGRlZmF1bHQ6IG51bGwsICAgICAgLy8gVGhlIGRlZmF1bHQgdmFsdWUgd2lsbCBiZSB1c2VkIG9ubHkgd2hlbiB0aGUgY29tcG9uZW50IGF0dGFjaGluZ1xyXG4gICAgICAgIC8vICAgICAgICAgICAgICAgICAgICAgICAgICAgdG8gYSBub2RlIGZvciB0aGUgZmlyc3QgdGltZVxyXG4gICAgICAgIC8vICAgIHVybDogY2MuVGV4dHVyZTJELCAgLy8gb3B0aW9uYWwsIGRlZmF1bHQgaXMgdHlwZW9mIGRlZmF1bHRcclxuICAgICAgICAvLyAgICBzZXJpYWxpemFibGU6IHRydWUsIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIHRydWVcclxuICAgICAgICAvLyAgICB2aXNpYmxlOiB0cnVlLCAgICAgIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIHRydWVcclxuICAgICAgICAvLyAgICBkaXNwbGF5TmFtZTogJ0ZvbycsIC8vIG9wdGlvbmFsXHJcbiAgICAgICAgLy8gICAgcmVhZG9ubHk6IGZhbHNlLCAgICAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyBmYWxzZVxyXG4gICAgICAgIC8vIH0sXHJcbiAgICAgICAgLy8gLi4uXHJcbiAgICAgICAgLy8g5L2/55So5Lit6IqC54K5XHJcbiAgICAgICAgY2FyZFVzaW5nOiBjYy5Ob2RlLFxyXG4gICAgICAgIC8vIOaJi+eJjOiKgueCuVxyXG4gICAgICAgIGNhcmRIYW5kOiBjYy5Ob2RlLFxyXG4gICAgICAgIC8vIOitpuWRiuaPkOekuuiKgueCuVxyXG4gICAgICAgIGxhYmVsVGlwczogY2MuTGFiZWwsXHJcbiAgICAgICAgbm9kZVRpcHM6IGNjLk5vZGVcclxuICAgIH0sXHJcblxyXG4gICAgLy8gdXNlIHRoaXMgZm9yIGluaXRpYWxpemF0aW9uXHJcbiAgICBvbkxvYWQ6IGZ1bmN0aW9uICgpIHtcclxuICAgICAgICAvLyDlvZPliY3kvb/nlKjljaHniYxcclxuICAgICAgICB0aGlzLmNhcmRPYmplY3QgPSBudWxsO1xyXG5cclxuICAgICAgICAvLyDljaHniYzpgInmi6nkuI7pgIDlh7rnmoTnm5HlkKxcclxuICAgICAgICB0aGlzLm5vZGUub24oXCJjYXJkU2VsZWN0XCIsIHRoaXMuY2FyZFNlbGVjdEV2ZW50LCB0aGlzKTtcclxuICAgICAgICB0aGlzLm5vZGUub24oXCJjYXJkRXhpdFwiLCB0aGlzLmNhcmRFeGl0RXZlbnQsIHRoaXMpO1xyXG4gICAgICAgIHRoaXMubm9kZS5vbihcImVycm9yVGlwc1wiLCB0aGlzLmNhdGNoVGlwcywgdGhpcyk7XHJcbiAgICAgICAgXHJcbiAgICAgICAgdGhpcy5jYXJkSGFuZFNjcmlwdCA9IHRoaXMuY2FyZEhhbmQuZ2V0Q29tcG9uZW50KFwiRHJhd0NhcmRcIik7XHJcbiAgICAgICAgLy9cclxuICAgICAgICAvLyB0aGlzLm5vZGUub24oY2MuTm9kZS5FdmVudFR5cGUuTU9VU0VfRE9XTix0aGlzLmRvd25Nb3VzZUV2ZW50LHRoaXMpO1xyXG4gICAgICAgIC8vIHRoaXMubm9kZS5vbihjYy5Ob2RlLkV2ZW50VHlwZS5NT1VTRV9VUCx0aGlzLnVwTW91c2VFdmVudCx0aGlzKTtcclxuICAgIH0sXHJcblxyXG4gICAgY2FyZFNlbGVjdEV2ZW50OiBmdW5jdGlvbiAoZXZlbnQpIHtcclxuICAgICAgICB2YXIgc2VsZiA9IHRoaXM7XHJcblxyXG4gICAgICAgIGNvbnNvbGUubG9nKFwic2VsZWN0IGEgY2FyZFwiKTtcclxuICAgICAgICBzZWxmLmNhcmRPYmplY3QgPSBldmVudC5kZXRhaWwuY2FyZDtcclxuICAgICAgICBzZWxmLmNhcmRPYmplY3QucGFyZW50ID0gc2VsZi5jYXJkVXNpbmc7XHJcbiAgICAgICAgLy8gdGhpcy5jYXJkT2JqZWN0LnggPSBldmVudC5kZXRhaWwucG9zWDtcclxuICAgICAgICAvLyB0aGlzLmNhcmRPYmplY3QueSA9IGV2ZW50LmRldGFpbC5wb3NZO1xyXG4gICAgICAgIGV2ZW50LnN0b3BQcm9wYWdhdGlvbigpO1xyXG4gICAgfSxcclxuICAgIGNhcmRFeGl0RXZlbnQ6IGZ1bmN0aW9uIChldmVudCkge1xyXG4gICAgICAgIGNvbnNvbGUubG9nKFwiZXhpdCBhIGNhcmRcIik7XHJcbiAgICAgICAgLy8gdGhpcy5jYXJkT2JqZWN0LnBhcmVudCA9IHRoaXMuY2FyZEhhbmQ7XHJcbiAgICAgICAgdGhpcy5jYXJkT2JqZWN0LnBhcmVudCA9IG51bGw7XHJcbiAgICAgICAgdGhpcy5jYXJkSGFuZC5hZGRDaGlsZCh0aGlzLmNhcmRPYmplY3QsIHRoaXMuY2FyZE9iamVjdC5nZXRDb21wb25lbnQoXCJDYXJkXCIpLmNhcmRJbmRleCk7XHJcbiAgICAgICAgdGhpcy5jYXJkT2JqZWN0ID0gbnVsbDtcclxuICAgICAgICBldmVudC5zdG9wUHJvcGFnYXRpb24oKTtcclxuICAgIH0sXHJcblxyXG4gICAgY2F0Y2hUaXBzOiBmdW5jdGlvbiAoZXZlbnQpIHtcclxuICAgICAgICB2YXIgc2VsZiA9IHRoaXM7XHJcbiAgICAgICAgaWYgKGV2ZW50LmRldGFpbC50ZXh0ICE9PSBudWxsKSB7XHJcbiAgICAgICAgICAgIHZhciBmYWRlSW4gPSBjYy5mYWRlSW4oMS4wKTtcclxuICAgICAgICAgICAgdmFyIGZhZGVPdXQgPSBjYy5mYWRlT3V0KDEuMCk7XHJcbiAgICAgICAgICAgIC8vIGNvbnNvbGUubG9nKHNlbGYud2FybmluZ1RpcHMuc3RyKTtcclxuICAgICAgICAgICAgc2VsZi5sYWJlbFRpcHMuc3RyaW5nID0gZXZlbnQuZGV0YWlsLnRleHQ7XHJcbiAgICAgICAgICAgIC8vIGNvbnNvbGUubG9nKHNlbGYud2FybmluZ1RpcHMuc3RyaW5nKTtcclxuXHJcbiAgICAgICAgICAgIHNlbGYubGFiZWxUaXBzLm5vZGUucnVuQWN0aW9uKGNjLnNlcXVlbmNlKGZhZGVJbiwgZmFkZU91dCkpO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgZXZlbnQuc3RvcFByb3BhZ2F0aW9uKCk7XHJcbiAgICB9LFxyXG5cclxuXHJcblxyXG4gICAgLy8gY2FsbGVkIGV2ZXJ5IGZyYW1lLCB1bmNvbW1lbnQgdGhpcyBmdW5jdGlvbiB0byBhY3RpdmF0ZSB1cGRhdGUgY2FsbGJhY2tcclxuICAgIC8vIHVwZGF0ZTogZnVuY3Rpb24gKGR0KSB7XHJcblxyXG4gICAgLy8gfSxcclxufSk7IiwiY2MuQ2xhc3Moe1xyXG4gICAgZXh0ZW5kczogY2MuQ29tcG9uZW50LFxyXG5cclxuICAgIHByb3BlcnRpZXM6IHtcclxuICAgICAgICBcclxuICAgICAgICAvL+mtlOazlea2iOiAl1xyXG4gICAgICAgIG1hbmFDb25zdW1lOiAwLFxyXG4gICAgICAgIC8v6a2U5rOV5raI6ICX5qCH562+XHJcbiAgICAgICAgbWFuYUNvbnN1bWVMYWJlbDogY2MuTGFiZWwsIFxyXG4gICAgICAgIFxyXG4gICAgICAgIC8v5Y2h54mH57G75Z6LXHJcbiAgICAgICAgY2FyZFR5cGU6IDAsICAgICAvLzDms5XmnK/niYzvvJsx55Sf54mp54mMIFxyXG4gICAgICAgIC8v5Y2h54mHSURcclxuICAgICAgICBjYXJkSWQ6IDAsXHJcbiAgICAgICAgXHJcbiAgICAgICAgLy/lvKDmlbBcclxuICAgICAgICBudW06IDAsXHJcbiAgICAgICAgLy/lvKDmlbDmoIfnrb5cclxuICAgICAgICBudW1MYWJlbDogY2MuTGFiZWwsXHJcbiAgICAgICAgXHJcbiAgICAgICAgLy/ljaHniYflkI3np7BcclxuICAgICAgICBjTmFtZTogY2MuU3RyaW5nLFxyXG4gICAgICAgIC8v5Y2h54mH5ZCN56ew55qE5qCH562+XHJcbiAgICAgICAgY05hbWVMYWJlbDogY2MuTGFiZWwsICAgICAgICBcclxuICAgICAgICBcclxuICAgIH0sXHJcblxyXG4gICAgLy8gdXNlIHRoaXMgZm9yIGluaXRpYWxpemF0aW9uXHJcbiAgICBvbkxvYWQ6IGZ1bmN0aW9uICgpIHtcclxuICAgICAgICB0aGlzLmluaXQoKTtcclxuICAgICAgICB0aGlzLmluaXRNb3VzZUV2ZW50KCk7XHJcbiAgICB9LFxyXG4gICAgXHJcbiAgICBpbml0OiBmdW5jdGlvbigpe1xyXG4gICAgICAgIHZhciBzZWxmID0gdGhpcztcclxuICAgICAgICBzZWxmLm1hbmFDb25zdW1lTGFiZWwuc3RyaW5nID0gc2VsZi5tYW5hQ29uc3VtZTtcclxuICAgICAgICBpZihzZWxmLm51bSA+IDEpe1xyXG4gICAgICAgICAgICBzZWxmLm51bUxhYmVsLnN0cmluZyA9ICd4JyArIHNlbGYubnVtO1xyXG4gICAgICAgIH1lbHNle1xyXG4gICAgICAgICAgICBzZWxmLm51bUxhYmVsLnN0cmluZyA9ICcnOyAgIFxyXG4gICAgICAgIH1cclxuICAgICAgICBcclxuICAgICAgICBpZihzZWxmLmNOYW1lLmxlbmd0aCA8PSAzICl7XHJcbiAgICAgICAgICAgIHNlbGYuY05hbWVMYWJlbC5zdHJpbmcgPSBzZWxmLmNOYW1lO1xyXG4gICAgICAgIH1lbHNle1xyXG4gICAgICAgICAgICBzZWxmLmNOYW1lTGFiZWwuc3RyaW5nID0gc2VsZi5jTmFtZS5zbGljZSgwLDMpICsgJy4uLic7XHJcbiAgICAgICAgfVxyXG4gICAgfSxcclxuICAgIGFkZFZpZXdDYXJkOiBmdW5jdGlvbihkZXRhaWwpe1xyXG4gICAgICAgIHZhciBzZWxmID0gdGhpcztcclxuICAgICAgICBcclxuICAgICAgICBzZWxmLm1hbmFDb25zdW1lID0gZGV0YWlsLm1hbmFDb25zdW1lO1xyXG4gICAgICAgIHNlbGYuY05hbWUgPSBkZXRhaWwuY05hbWU7XHJcbiAgICAgICAgICAgICBzZWxmLm51bSA9IDE7ICAgICBcclxuICAgICAgICBcclxuICAgICAgICBzZWxmLmNhcmRUeXBlID0gZGV0YWlsLnR5cGVJZDtcclxuICAgICAgICBzZWxmLmNhcmRJZCA9IGRldGFpbC5pZDtcclxuICAgICAgICBcclxuICAgICAgICBzZWxmLmluaXQoKTtcclxuICAgIH0sXHJcbiAgICBhZGROdW1CeTogZnVuY3Rpb24obnVtKXtcclxuICAgICAgICB2YXIgc2VsZiA9IHRoaXM7ICAgIFxyXG4gICAgICAgIHNlbGYubnVtICs9IG51bTtcclxuICAgICAgICBzZWxmLm51bUxhYmVsLnN0cmluZyA9ICd4JyArIHNlbGYubnVtO1xyXG4gICAgfSxcclxuICAgIFxyXG4gICAgaW5pdE1vdXNlRXZlbnQ6ZnVuY3Rpb24oKXtcclxuICAgICAgICB0aGlzLm5vZGUub24oY2MuTm9kZS5FdmVudFR5cGUuTU9VU0VfRE9XTixyZW1vdmVDYXJkLCB0aGlzKTtcclxuXHJcbiAgICAgICAgZnVuY3Rpb24gcmVtb3ZlQ2FyZCgpe1xyXG4gICAgICAgICAgICB2YXIgZXZlbnRzZW5kID0gbmV3IGNjLkV2ZW50LkV2ZW50Q3VzdG9tKCdtb3VzZURvd25UaGVTaG93Q2FyZCcsdHJ1ZSk7XHJcbiAgICAgICAgICAgIGV2ZW50c2VuZC5zZXRVc2VyRGF0YSh7b2JqZWN0OnRoaXN9KTtcclxuICAgICAgICAgICAgdGhpcy5ub2RlLmRpc3BhdGNoRXZlbnQoZXZlbnRzZW5kKTtcclxuICAgICAgICB9XHJcbiAgICB9LFxyXG4gICAgXHJcbiAgICBcclxuICAgIC8vIGNhbGxlZCBldmVyeSBmcmFtZSwgdW5jb21tZW50IHRoaXMgZnVuY3Rpb24gdG8gYWN0aXZhdGUgdXBkYXRlIGNhbGxiYWNrXHJcbiAgICAvLyB1cGRhdGU6IGZ1bmN0aW9uIChkdCkge1xyXG5cclxuICAgIC8vIH0sXHJcbn0pO1xyXG4iLCJjYy5DbGFzcyh7XHJcbiAgICBleHRlbmRzOiBjYy5Db21wb25lbnQsXHJcblxyXG4gICAgcHJvcGVydGllczoge1xyXG4gICAgICAgIG51bTowLFxyXG4gICAgICAgIC8v77+977+977+977+977+977+977+977+977+977+9XHJcbiAgICAgICAgdHlwZToge1xyXG4gICAgICAgICAgICB0eXBlOiBjYy5FbnVtKHtcclxuICAgICAgICAgICAgICAgIC8v77+977+90adcclxuICAgICAgICAgICAgICAgIFNjaWVuY2U6IDAsXHJcbiAgICAgICAgICAgICAgICAvL++/ve+/ve+/ve+/vVxyXG4gICAgICAgICAgICAgICAgRmFudGFzeTogMSxcclxuICAgICAgICAgICAgICAgIC8v77+977+977+977+9XHJcbiAgICAgICAgICAgICAgICBDaGFvczogMixcclxuICAgICAgICAgICAgICAgIH0pLFxyXG4gICAgICAgICAgICBkZWZhdWx0OiAwLFxyXG4gICAgICAgIH0sXHJcbiAgICAgICAgLy/vv73Ht++/ve+/ve+/ve+/ve+/vcq577+9w6Pvv73vv73vv73KvM6q77+977+9XHJcbiAgICAgICAgdXNhYmxlOnRydWUsXHJcblxyXG4gICAgICAgIG5hbWVMYWJlbDpjYy5MYWJlbCxcclxuICAgICAgICAvLyBmb286IHtcclxuICAgICAgICAvLyAgICBkZWZhdWx0OiBudWxsLCAgICAgIC8vIFRoZSBkZWZhdWx0IHZhbHVlIHdpbGwgYmUgdXNlZCBvbmx5IHdoZW4gdGhlIGNvbXBvbmVudCBhdHRhY2hpbmdcclxuICAgICAgICAvLyAgICAgICAgICAgICAgICAgICAgICAgICAgIHRvIGEgbm9kZSBmb3IgdGhlIGZpcnN0IHRpbWVcclxuICAgICAgICAvLyAgICB1cmw6IGNjLlRleHR1cmUyRCwgIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIHR5cGVvZiBkZWZhdWx0XHJcbiAgICAgICAgLy8gICAgc2VyaWFsaXphYmxlOiB0cnVlLCAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyB0cnVlXHJcbiAgICAgICAgLy8gICAgdmlzaWJsZTogdHJ1ZSwgICAgICAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyB0cnVlXHJcbiAgICAgICAgLy8gICAgZGlzcGxheU5hbWU6ICdGb28nLCAvLyBvcHRpb25hbFxyXG4gICAgICAgIC8vICAgIHJlYWRvbmx5OiBmYWxzZSwgICAgLy8gb3B0aW9uYWwsIGRlZmF1bHQgaXMgZmFsc2VcclxuICAgICAgICAvLyB9LFxyXG4gICAgICAgIC8vIC4uLlxyXG4gICAgfSxcclxuXHJcbiAgICAvLyB1c2UgdGhpcyBmb3IgaW5pdGlhbGl6YXRpb25cclxuICAgIG9uTG9hZDogZnVuY3Rpb24gKCkge1xyXG4gICAgICAgIHRoaXMuaW5pdE1vdXNlRXZlbnQoKTtcclxuICAgIH0sXHJcbiAgICBpbml0TW91c2VFdmVudDpmdW5jdGlvbigpe1xyXG4gICAgICAgIHRoaXMubm9kZS5vbihjYy5Ob2RlLkV2ZW50VHlwZS5NT1VTRV9ET1dOLHJlbW92ZUNhcmQsIHRoaXMpO1xyXG5cclxuICAgICAgICBmdW5jdGlvbiByZW1vdmVDYXJkKCl7XHJcbiAgICAgICAgICAgIHZhciBldmVudHNlbmQgPSBuZXcgY2MuRXZlbnQuRXZlbnRDdXN0b20oJ21vdXNlRG93blRoZURlY2snLHRydWUpO1xyXG4gICAgICAgICAgICBldmVudHNlbmQuc2V0VXNlckRhdGEoe29iamVjdDp0aGlzfSk7XHJcbiAgICAgICAgICAgIHRoaXMubm9kZS5kaXNwYXRjaEV2ZW50KGV2ZW50c2VuZCk7XHJcbiAgICAgICAgfVxyXG4gICAgfSxcclxuICAgIHJlbW92ZVRoaXNEZWNrOmZ1bmN0aW9uKCl7XHJcbiAgICB2YXIgZXZlbnRzZW5kID0gbmV3IGNjLkV2ZW50LkV2ZW50Q3VzdG9tKCdyZW1vdmVUaGVEZWNrJyx0cnVlKTtcclxuICAgIGV2ZW50c2VuZC5zZXRVc2VyRGF0YSh7b2JqZWN0OnRoaXN9KTtcclxuICAgIHRoaXMubm9kZS5kaXNwYXRjaEV2ZW50KGV2ZW50c2VuZCk7XHJcbiAgICB9LFxyXG4gICAgY2hhbmdlVHlwZTpmdW5jdGlvbih0eXBlKXtcclxuICAgICAgICB0aGlzLnR5cGUgPSB0eXBlO1xyXG4gICAgfSxcclxuICAgIGNoYW5nZU5hbWU6ZnVuY3Rpb24obmFtZSl7XHJcbiAgICAgICAgdGhpcy5uYW1lTGFiZWwuc3RyaW5nID0gbmFtZTtcclxuICAgIH0sXHJcbiAgICAvLyBjYWxsZWQgZXZlcnkgZnJhbWUsIHVuY29tbWVudCB0aGlzIGZ1bmN0aW9uIHRvIGFjdGl2YXRlIHVwZGF0ZSBjYWxsYmFja1xyXG4gICAgLy8gdXBkYXRlOiBmdW5jdGlvbiAoZHQpIHtcclxuXHJcbiAgICAvLyB9LFxyXG59KTtcclxuIiwiY2MuQ2xhc3Moe1xyXG4gICAgZXh0ZW5kczogY2MuQ29tcG9uZW50LFxyXG5cclxuICAgIHByb3BlcnRpZXM6IHtcclxuICAgICAgICAvLyBmb286IHtcclxuICAgICAgICAvLyAgICBkZWZhdWx0OiBudWxsLCAgICAgIC8vIFRoZSBkZWZhdWx0IHZhbHVlIHdpbGwgYmUgdXNlZCBvbmx5IHdoZW4gdGhlIGNvbXBvbmVudCBhdHRhY2hpbmdcclxuICAgICAgICAvLyAgICAgICAgICAgICAgICAgICAgICAgICAgIHRvIGEgbm9kZSBmb3IgdGhlIGZpcnN0IHRpbWVcclxuICAgICAgICAvLyAgICB1cmw6IGNjLlRleHR1cmUyRCwgIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIHR5cGVvZiBkZWZhdWx0XHJcbiAgICAgICAgLy8gICAgc2VyaWFsaXphYmxlOiB0cnVlLCAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyB0cnVlXHJcbiAgICAgICAgLy8gICAgdmlzaWJsZTogdHJ1ZSwgICAgICAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyB0cnVlXHJcbiAgICAgICAgLy8gICAgZGlzcGxheU5hbWU6ICdGb28nLCAvLyBvcHRpb25hbFxyXG4gICAgICAgIC8vICAgIHJlYWRvbmx5OiBmYWxzZSwgICAgLy8gb3B0aW9uYWwsIGRlZmF1bHQgaXMgZmFsc2VcclxuICAgICAgICAvLyB9LFxyXG4gICAgICAgIC8vIC4uLlxyXG4gICAgfSxcclxuXHJcbiAgICAvLyB1c2UgdGhpcyBmb3IgaW5pdGlhbGl6YXRpb25cclxuICAgIG9uTG9hZDogZnVuY3Rpb24gKCkge1xyXG4gICAgICAgIC8vdGhpcy5ub2RlLm9uKGNjLk5vZGUuRXZlbnRUeXBlLk1PVVNFX0RPV04sYmFjaywgdGhpcyk7XHJcblxyXG5cclxuICAgIH0sXHJcbiAgICBjaGFuZ2VOYW1lOmZ1bmN0aW9uKCl7XHJcbiAgICB2YXIgZXZlbnRzZW5kID0gbmV3IGNjLkV2ZW50LkV2ZW50Q3VzdG9tKCduYW1lVGhlRGVjaycsdHJ1ZSk7XHJcbiAgICB2YXIgdGV4dCA9IHRoaXMubm9kZS5nZXRDb21wb25lbnQoY2MuRWRpdEJveCk7XHJcbiAgICBldmVudHNlbmQuc2V0VXNlckRhdGEoe25hbWU6dGV4dC5zdHJpbmd9KTtcclxuICAgIHRoaXMubm9kZS5kaXNwYXRjaEV2ZW50KGV2ZW50c2VuZCk7XHJcbiAgICB9XHJcblxyXG5cclxuICAgIC8vIGNhbGxlZCBldmVyeSBmcmFtZSwgdW5jb21tZW50IHRoaXMgZnVuY3Rpb24gdG8gYWN0aXZhdGUgdXBkYXRlIGNhbGxiYWNrXHJcbiAgICAvLyB1cGRhdGU6IGZ1bmN0aW9uIChkdCkge1xyXG5cclxuICAgIC8vIH0sXHJcbn0pO1xyXG4iLCJjYy5DbGFzcyh7XHJcbiAgICBleHRlbmRzOiBjYy5Db21wb25lbnQsXHJcblxyXG4gICAgcHJvcGVydGllczoge1xyXG4gICAgICAgIGxhYmVsOmNjLkxhYmVsLFxyXG4gICAgICAgIC8vZWRpdEJveDpjYy5Ob2RlLFxyXG4gICAgICAgIHVybDpcImh0dHA6Ly8zOS4xMDYuNjcuMTEyOjMwMDBcIixcclxuICAgICAgICBzb2NrZXQ6bnVsbCxcclxuICAgICAgICB0b2tlbjoxLFxyXG4gICAgICAgIHVzZXJOYW1lOlwia2VuYW5cIixcclxuICAgICAgICBwYXNzd29yZDpcIjEyMzQ1NlwiLFxyXG4gICAgICAgIC8v77+977+977+977+977+977+977+977+977+9y7Pvv73vv73vv73vv73vv73vv73Ese+/ve+/ve+/vVxyXG4gICAgICAgIHNpZ246MCxcclxuXHJcbiAgICAgICAgbWFuYWdlcjpjYy5TY3JpcHQsXHJcblxyXG4gICAgICAgIGVkaXRCb3hOb2RlOmNjLk5vZGUsXHJcblxyXG4gICAgICAgIG1lc3NhZ2VMYWJlbDpjYy5MYWJlbCxcclxuICAgICAgICAvLyBmb286IHtcclxuICAgICAgICAvLyAgICBkZWZhdWx0OiBudWxsLCAgICAgIC8vIFRoZSBkZWZhdWx0IHZhbHVlIHdpbGwgYmUgdXNlZCBvbmx5IHdoZW4gdGhlIGNvbXBvbmVudCBhdHRhY2hpbmdcclxuICAgICAgICAvLyAgICAgICAgICAgICAgICAgICAgICAgICAgIHRvIGEgbm9kZSBmb3IgdGhlIGZpcnN0IHRpbWVcclxuICAgICAgICAvLyAgICB1cmw6IGNjLlRleHR1cmUyRCwgIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIHR5cGVvZiBkZWZhdWx0XHJcbiAgICAgICAgLy8gICAgc2VyaWFsaXphYmxlOiB0cnVlLCAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyB0cnVlXHJcbiAgICAgICAgLy8gICAgdmlzaWJsZTogdHJ1ZSwgICAgICAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyB0cnVlXHJcbiAgICAgICAgLy8gICAgZGlzcGxheU5hbWU6ICdGb28nLCAvLyBvcHRpb25hbFxyXG4gICAgICAgIC8vICAgIHJlYWRvbmx5OiBmYWxzZSwgICAgLy8gb3B0aW9uYWwsIGRlZmF1bHQgaXMgZmFsc2VcclxuICAgICAgICAvLyB9LFxyXG4gICAgICAgIC8vIC4uLlxyXG4gICAgfSxcclxuXHJcbiAgICAvLyB1c2UgdGhpcyBmb3IgaW5pdGlhbGl6YXRpb25cclxuICAgIG9uTG9hZDogZnVuY3Rpb24gKCkge1xyXG5cclxuXHJcbiAgICAgICAgLy90aGlzLmVkaXQgPSB0aGlzLmVkaXRCb3hOb2RlLmdldENvbXBvbmVudChjYy5FZGl0Qm94KTtcclxuICAgICAgICB0aGlzLm1hbmFnZXIgPSB0aGlzLm5vZGUuZ2V0Q29tcG9uZW50KFwiTWFpbkdhbWVNYW5hZ2VyXCIpO1xyXG4gICAgICAgIGNjLmxvZyh0aGlzLm1hbmFnZXIpO1xyXG5cclxuICAgICAgICAvL++/ve+/vcq877+977+90rPvv73vv70gIO+/ve+/vcK977+977+977+977+9ICAg77+977+977+977+977+9y7vvv70ga2VuYW4gOiAxMjM0NTZcclxuICAgICAgICB0aGlzLmxvZ2luID0gZnVuY3Rpb24oKXtcclxuICAgICAgICAgICAgdGhpcy5zb2NrZXQuZW1pdCgnbG9naW4nLCB7J3VzZXJOYW1lJzp0aGlzLnVzZXJOYW1lLCdwYXNzd29yZCc6dGhpcy5wYXNzd29yZH0pO1xyXG4gICAgICAgIH07XHJcbiAgICAgICAgLy/ErO+/vc+/1bzvv70gIMSs77+977+9cm9vbSAg77+977+9zajvv73vv73Pou+/ve+/ve+/ve+/vVxyXG4gICAgICAgIHRoaXMuYnJvYWRjYXN0TXNnID0gZnVuY3Rpb24obXNnKXtcclxuICAgICAgICAgICAgdGhpcy5zb2NrZXQuZW1pdCgnYnJvYWRjYXN0TXNnJywgeydtc2cnOiBtc2csICd0b2tlbic6dGhpcy50b2tlbn0pO1xyXG4gICAgICAgIH07XHJcbiAgICAgICAgLy9yb29t77+977+977+977+977+977+977+977+977+977+9XHJcbiAgICAgICAgdGhpcy5yb29tTXNnID0gZnVuY3Rpb24ocm9vbSwgbXNnKXtcclxuICAgICAgICAgICAgdGhpcy5zb2NrZXQuZW1pdCgncm9vbScsIHsncm9vbSc6cm9vbSwgJ21zZyc6bXNnLCAndG9rZW4nOnRoaXMudG9rZW59KTtcclxuICAgICAgICAgICAgY2MubG9nKFwic2VuZCBtZXNzYWdlXCIpO1xyXG4gICAgICAgIH07XHJcbiAgICAgICAgLy/vv73vv73NqO+/ve+/vc+i77+977+977+977+9XHJcbiAgICAgICAgdGhpcy5tc2cgPSBmdW5jdGlvbihtc2csaWQpe1xyXG4gICAgICAgICAgICB0aGlzLnNvY2tldC5lbWl0KCdtc2cnLCB7J21zZyc6IG1zZywgJ2lkJzppZCwgJ3Rva2VuJzp0aGlzLnRva2VufSk7XHJcbiAgICAgICAgfTtcclxuXHJcblxyXG5cclxuICAgICAgICB0aGlzLnN0YXJ0ID0gZnVuY3Rpb24oKXtcclxuICAgICAgICAgICAgdGhpcy5zb2NrZXQgPSBpby5jb25uZWN0KHRoaXMudXJsK1wiL2luZGV4XCIpO1xyXG4gICAgICAgICAgICB2YXIgdG9rZW4gPSB0aGlzLnRva2VuO1xyXG4gICAgICAgICAgICB2YXIgc2VsZiA9IHRoaXM7XHJcbiAgICAgICAgICAgIC8v77+977+9wr3vv73vv73vv73vv73vv73vv73vv73vv71cclxuICAgICAgICAgICAgdGhpcy5zb2NrZXQub24oJ2xvZ2luUmVzdWx0JywgZnVuY3Rpb24oZGF0YSl7XHJcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZygnbG9naW5SZXN1bHQ6JyArIGRhdGEubXNnICsgXCIgcmVzdWx0czpcIiArIGRhdGEucmVzdWx0cyk7XHJcbiAgICAgICAgICAgICAgICB0b2tlbiA9IGRhdGEucmVzdWx0cztcclxuICAgICAgICAgICAgICAgIHNlbGYucm9vbU1zZygncm9vbUNoYXQnLCcgIGRvIHlvdSBsaWtlIG1lPycpO1xyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgLy/vv73vv73vv73vv73vv73vv73vv73vv71cclxuICAgICAgICAgICAgdGhpcy5zb2NrZXQub24oJ2Vycm9yJywgZnVuY3Rpb24oZXJyb3Ipe1xyXG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coJ2Vycm9yOicgKyBlcnJvcik7XHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAvL++/ve+/ve+/ve+/ve+/vdG52LHvv71cclxuICAgICAgICAgICAgdGhpcy5zb2NrZXQub24oJ2Rpc2Nvbm5lY3QnLCBmdW5jdGlvbigpe1xyXG4gICAgICAgICAgICAgICAgaWYgKHNlbGYudXNlck5hbWUgIT0gbnVsbCAmJiBzZWxmLnVzZXJOYW1lLmxlbmd0aCA+IDApIHtcclxuICAgICAgICAgICAgICAgICAgICBsb2dpbigpO1xyXG4gICAgICAgICAgICAgICAgICAgIC8vc2VsZi5yb29tTXNnKCdyb29tQ2hhdCcsJyAgZG8geW91IGxpa2UgbWU/Jyk7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZygnZGlzY29ubmVjdCcpO1xyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgLy/vv73vv73vv73vv73vv73vv73vv73vv71cclxuICAgICAgICAgICAgdGhpcy5zb2NrZXQub24oJ3JlY29ubmVjdCcsIGZ1bmN0aW9uICgpIHtcclxuICAgICAgICAgICAgICAgIGxvZygncmVjb25uZWN0Jyk7XHJcbiAgICAgICAgICAgICAgICBpZiAodGhpcy51c2VyTmFtZSAhPSBudWxsICYmIHRoaXMudXNlck5hbWUubGVuZ3RoID4gMCkge1xyXG4gICAgICAgICAgICAgICAgICAgIHNlbGYubG9naW4oKTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIC8v77+977+977+977+977+977+977+977+9XHJcbiAgICAgICAgICAgIHRoaXMuc29ja2V0Lm9uKCdyZWNvbm5lY3RfZXJyb3InLCBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgICAgICAgICBsb2coJ3JlY29ubmVjdF9lcnJvcicpO1xyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgLy/vv73jsqXvv73vv73Pou+/ve+/ve+/ve+/vVxyXG4gICAgICAgICAgICB0aGlzLnNvY2tldC5vbignbXNnJywgZnVuY3Rpb24oZGF0YSl7XHJcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZygnbXNnJyArIGRhdGEubXNnKTtcclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIC8vcm9vbe+/ve+/ve+/ve+/vVxyXG4gICAgICAgICAgICB0aGlzLnNvY2tldC5vbigncm9vbUNoYXQnLCBmdW5jdGlvbihkYXRhKXtcclxuICAgICAgICAgICAgICAgIGNjLmxvZyhkYXRhLm1zZy5uYW1lKTtcclxuICAgICAgICAgICAgICAgIGlmKGRhdGEubXNnLm5hbWUgPT09IFwiY3JlYXR1cmVDcmVhdGVcIil7XHJcbiAgICAgICAgICAgICAgICAgICAgc2VsZi5tYW5hZ2VyLmNyZWF0dXJlQ3JlYXRlTmV0d29yayhkYXRhLm1zZy5kZXRhaWwpO1xyXG4gICAgICAgICAgICAgICAgfWVsc2UgaWYoZGF0YS5tc2cubmFtZSA9PT0gXCJtYWdpY0NyZWF0ZVwiKXtcclxuICAgICAgICAgICAgICAgICAgICBzZWxmLm1hbmFnZXIubWFnaWNDcmVhdGVOZXR3b3JrKGRhdGEubXNnLmRldGFpbCk7XHJcbiAgICAgICAgICAgICAgICB9ZWxzZSBpZihkYXRhLm1zZy5uYW1lID09PSBcImNoYW50Q3JlYXRlXCIpe1xyXG4gICAgICAgICAgICAgICAgICAgIHNlbGYubWFuYWdlci5jaGFudENyZWF0ZU5ldHdvcmsoZGF0YS5tc2cuZGV0YWlsKTtcclxuICAgICAgICAgICAgICAgIH1lbHNlIGlmKGRhdGEubXNnLm5hbWUgPT09IFwiaGVyb0RlYXRoXCIpe1xyXG4gICAgICAgICAgICAgICAgICAgIC8vc2VsZi5tYW5hZ2VyLmhlcm9EZWF0aERldGFpbChkYXRhLm1zZy5kZXRhaWwpO1xyXG4gICAgICAgICAgICAgICAgfWVsc2UgaWYoZGF0YS5tc2cubmFtZSA9PT0gXCJlbmVteU1vdmVcIil7XHJcbiAgICAgICAgICAgICAgICAgICAgc2VsZi5tYW5hZ2VyLmNoYW5nZUVuZW15TW92ZShkYXRhLm1zZy5kZXRhaWwpO1xyXG4gICAgICAgICAgICAgICAgfWVsc2UgaWYoZGF0YS5tc2cubmFtZSA9PT0gXCJtZXNzYWdlXCIpe1xyXG4gICAgICAgICAgICAgICAgICAgIHNlbGYubWVzc2FnZUxhYmVsLnN0cmluZyA9IGRhdGEubXNnLmRldGFpbDtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgfTtcclxuXHJcblxyXG4gICAgICAgIHRoaXMuc3RhcnQoKTtcclxuICAgICAgICB0aGlzLmxvZ2luKCk7XHJcblxyXG4gICAgfSxcclxuXHJcbiAgICAgLy9zZW5kTWVzc2FnZTpmdW5jdGlvbigpIHtcclxuICAgICAvLyAgICAvL3Jvb23vv73vv73vv73vv73vv73vv73vv73vv73vv73vv71cclxuICAgICAvLyAgICB2YXIgc29ja2V0ID0gdGhpcy5zb2NrZXQ7XHJcbiAgICAgLy8gICAgdmFyIHJvb21Nc2cgPSBmdW5jdGlvbiAocm9vbSwgbXNnKSB7XHJcbiAgICAgLy8gICAgICAgIHNvY2tldC5lbWl0KCdyb29tJywgeydyb29tJzogcm9vbSwgJ21zZyc6IG1zZywgJ3Rva2VuJzogMX0pO1xyXG4gICAgIC8vICAgIH07XHJcbiAgICAgLy9cclxuICAgICAvLyAgICByb29tTXNnKCdyb29tQ2hhdCcsIHtuYW1lOlwibWVzc2FnZVwiLGRldGFpbDp0aGlzLmVkaXQuc3RyaW5nfSk7XHJcbiAgICAgLy99XHJcbiAgICAvLyBjYWxsZWQgZXZlcnkgZnJhbWUsIHVuY29tbWVudCB0aGlzIGZ1bmN0aW9uIHRvIGFjdGl2YXRlIHVwZGF0ZSBjYWxsYmFja1xyXG4gICAgLy8gdXBkYXRlOiBmdW5jdGlvbiAoZHQpIHtcclxuXHJcbiAgICAvLyB9LFxyXG4gICAgLy9vbkxvYWQ6IGZ1bmN0aW9uICgpIHtcclxuICAgIC8vICAgIHZhciB1cmwgPSBcImh0dHA6Ly8zOS4xMDYuNjcuMTEyOjMwMDBcIjtcclxuICAgIC8vICAgIHZhciBzb2NrZXQ7XHJcbiAgICAvLyAgICB2YXIgdG9rZW47XHJcbiAgICAvLyAgICB2YXIgdXNlck5hbWUgPSBcImtlbmFuXCI7XHJcbiAgICAvLyAgICB2YXIgcGFzc3dvcmQgPSBcIjEyMzQ1NlwiO1xyXG4gICAgLy8gICAgdmFyIGxhYmVsID0gdGhpcy5sYWJlbDtcclxuICAgIC8vXHJcbiAgICAvLyAgICB0aGlzLmVkaXQgPSB0aGlzLmVkaXRCb3guZ2V0Q29tcG9uZW50KGNjLkVkaXRCb3gpO1xyXG4gICAgLy9cclxuICAgIC8vICAgIC8v77+977+9yrzvv73vv73Ss++/ve+/vSAg77+977+9wr3vv73vv73vv73vv70gICDvv73vv73vv73vv73vv73Lu++/vSBrZW5hbiA6IDEyMzQ1NlxyXG4gICAgLy8gICAgdGhpcy5sb2dpbiA9IGZ1bmN0aW9uKCl7XHJcbiAgICAvLyAgICAgICAgc29ja2V0LmVtaXQoJ2xvZ2luJywgeyd1c2VyTmFtZSc6dXNlck5hbWUsJ3Bhc3N3b3JkJzpwYXNzd29yZH0pO1xyXG4gICAgLy8gICAgfTtcclxuICAgIC8vICAgIC8vxKzvv73Pv9W877+9ICDErO+/ve+/vXJvb20gIO+/ve+/vc2o77+977+9z6Lvv73vv73vv73vv71cclxuICAgIC8vICAgIHRoaXMuYnJvYWRjYXN0TXNnID0gZnVuY3Rpb24obXNnKXtcclxuICAgIC8vICAgICAgICBzb2NrZXQuZW1pdCgnYnJvYWRjYXN0TXNnJywgeydtc2cnOiBtc2csICd0b2tlbic6dG9rZW59KTtcclxuICAgIC8vICAgIH07XHJcbiAgICAvLyAgICAvL3Jvb23vv73vv73vv73vv73vv73vv73vv73vv73vv73vv71cclxuICAgIC8vICAgIHRoaXMucm9vbU1zZyA9IGZ1bmN0aW9uKHJvb20sIG1zZyl7XHJcbiAgICAvLyAgICAgICAgc29ja2V0LmVtaXQoJ3Jvb20nLCB7J3Jvb20nOnJvb20sICdtc2cnOm1zZywgJ3Rva2VuJzp0b2tlbn0pO1xyXG4gICAgLy8gICAgICAgIGNjLmxvZyhcInNlbmQgbWVzc2FnZVwiKTtcclxuICAgIC8vICAgIH07XHJcbiAgICAvLyAgICAvL++/ve+/vc2o77+977+9z6Lvv73vv73vv73vv71cclxuICAgIC8vICAgIHRoaXMubXNnID0gZnVuY3Rpb24obXNnLGlkKXtcclxuICAgIC8vICAgICAgICBzb2NrZXQuZW1pdCgnbXNnJywgeydtc2cnOiBtc2csICdpZCc6aWQsICd0b2tlbic6dG9rZW59KTtcclxuICAgIC8vICAgIH07XHJcbiAgICAvL1xyXG4gICAgLy9cclxuICAgIC8vXHJcbiAgICAvLyAgICB0aGlzLnN0YXJ0ID0gZnVuY3Rpb24oKXtcclxuICAgIC8vICAgICAgICBzb2NrZXQgPSBpby5jb25uZWN0KHVybCtcIi9pbmRleFwiKTtcclxuICAgIC8vICAgICAgICBjYy5sb2coXCJzdGFydFwiKTtcclxuICAgIC8vICAgICAgICAvL++/ve+/vcK977+977+977+977+977+977+977+977+9XHJcbiAgICAvLyAgICAgICAgc29ja2V0Lm9uKCdsb2dpblJlc3VsdCcsIGZ1bmN0aW9uKGRhdGEpe1xyXG4gICAgLy8gICAgICAgICAgICBjb25zb2xlLmxvZygnbG9naW5SZXN1bHQ6JyArIGRhdGEubXNnICsgXCIgcmVzdWx0czpcIiArIGRhdGEucmVzdWx0cyk7XHJcbiAgICAvLyAgICAgICAgICAgIHRva2VuID0gZGF0YS5yZXN1bHRzO1xyXG4gICAgLy8gICAgICAgICAgICByb29tTXNnKCdyb29tQ2hhdCcsJyAgZG8geW91IGxpa2UgbWU/Jyk7XHJcbiAgICAvLyAgICAgICAgfSk7XHJcbiAgICAvLyAgICAgICAgLy/vv73vv73vv73vv73vv73vv73vv73vv71cclxuICAgIC8vICAgICAgICBzb2NrZXQub24oJ2Vycm9yJywgZnVuY3Rpb24oZXJyb3Ipe1xyXG4gICAgLy8gICAgICAgICAgICBjb25zb2xlLmxvZygnZXJyb3I6JyArIGVycm9yKTtcclxuICAgIC8vICAgICAgICB9KTtcclxuICAgIC8vICAgICAgICAvL++/ve+/ve+/ve+/ve+/vdG52LHvv71cclxuICAgIC8vICAgICAgICBzb2NrZXQub24oJ2Rpc2Nvbm5lY3QnLCBmdW5jdGlvbigpe1xyXG4gICAgLy8gICAgICAgICAgICBjb25zb2xlLmxvZygnZGlzY29ubmVjdCcpO1xyXG4gICAgLy8gICAgICAgIH0pO1xyXG4gICAgLy8gICAgICAgIC8v77+977+977+977+977+977+977+977+9XHJcbiAgICAvLyAgICAgICAgc29ja2V0Lm9uKCdyZWNvbm5lY3QnLCBmdW5jdGlvbiAoKSB7XHJcbiAgICAvLyAgICAgICAgICAgIGxvZygncmVjb25uZWN0Jyk7XHJcbiAgICAvLyAgICAgICAgICAgIGlmICh1c2VyTmFtZSAhPSBudWxsICYmIHVzZXJOYW1lLmxlbmd0aCA+IDApIHtcclxuICAgIC8vICAgICAgICAgICAgICAgIGxvZ2luKCk7XHJcbiAgICAvLyAgICAgICAgICAgIH1cclxuICAgIC8vICAgICAgICB9KTtcclxuICAgIC8vICAgICAgICAvL++/ve+/ve+/ve+/ve+/ve+/ve+/ve+/vVxyXG4gICAgLy8gICAgICAgIHNvY2tldC5vbigncmVjb25uZWN0X2Vycm9yJywgZnVuY3Rpb24gKCkge1xyXG4gICAgLy8gICAgICAgICAgICBsb2coJ3JlY29ubmVjdF9lcnJvcicpO1xyXG4gICAgLy8gICAgICAgIH0pO1xyXG4gICAgLy8gICAgICAgIC8v77+947Kl77+977+9z6Lvv73vv73vv73vv71cclxuICAgIC8vICAgICAgICBzb2NrZXQub24oJ21zZycsIGZ1bmN0aW9uKGRhdGEpe1xyXG4gICAgLy8gICAgICAgICAgICBjb25zb2xlLmxvZygnbXNnJyArIGRhdGEubXNnKTtcclxuICAgIC8vICAgICAgICB9KTtcclxuICAgIC8vICAgICAgICAvL3Jvb23vv73vv73vv73vv71cclxuICAgIC8vICAgICAgICBzb2NrZXQub24oJ3Jvb21DaGF0JywgZnVuY3Rpb24oZGF0YSl7XHJcbiAgICAvLyAgICAgICAgICAgIGxhYmVsLnN0cmluZyA9IGRhdGEubXNnO1xyXG4gICAgLy8gICAgICAgICAgICBjb25zb2xlLmxvZygnbXNnJyArIGRhdGEubXNnKTtcclxuICAgIC8vICAgICAgICB9KTtcclxuICAgIC8vICAgIH07XHJcbiAgICAvL1xyXG4gICAgLy9cclxuICAgIC8vICAgIHRoaXMuc3RhcnQoKTtcclxuICAgIC8vICAgIHRoaXMubG9naW4oKTtcclxuICAgIC8vXHJcbiAgICAvL30sXHJcbn0pO1xyXG4iXSwic291cmNlUm9vdCI6IiJ9